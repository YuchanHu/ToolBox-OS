package com.pianchang.lighting;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import java.io.IOException;
import java.net.BindException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.Locale;
import java.util.Objects;
import java.util.regex.Pattern;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class TimelineSyncBridge {
    private static final int DEFAULT_PORT = 37999;
    private static final int MAX_DATAGRAM_BYTES = 1024;
    private static final long MAX_SAFE_INTEGER = 9007199254740991L;
    private static final long MIN_PUSH_INTERVAL_MS = 25;
    private static final int RECENT_LIMIT = 256;
    private static final long TIMESTAMPED_WINDOW_MS = 750;
    private static final long UNSTAMPED_WINDOW_MS = 100;
    private boolean closed;
    private long duplicates;
    private long filtered;
    private long invalid;
    private long lastPushAt;
    private DatagramSocket listener;
    private Long newestTimestamp;
    private boolean pushPending;
    private long sequence;
    private long stale;
    private Received update;
    private long valid;
    private final WebView view;
    private static final Pattern DECIMAL = Pattern.compile("[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?");
    private static final Pattern IPV4_OCTET = Pattern.compile("0|[1-9][0-9]{0,2}");
    private static final Pattern DIGITS = Pattern.compile("[0-9]+");
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable push = new Runnable() { // from class: com.pianchang.lighting.TimelineSyncBridge$$ExternalSyntheticLambda0
        @Override // java.lang.Runnable
        public final void run() {
            TimelineSyncBridge.m101$r8$lambda$gEzNthiG68eOB3o9mdps2dzQ(this.f$0);
        }
    };
    private final ArrayDeque<Received> recent = new ArrayDeque<>();
    private int port = DEFAULT_PORT;
    private String sourceFilter = "";
    private String activeSource = "";
    private String lastError = "";

    /* renamed from: $r8$lambda$gEzNth--iG68eOB3o9mdps2dz-Q, reason: not valid java name */
    public static /* synthetic */ void m101$r8$lambda$gEzNthiG68eOB3o9mdps2dzQ(TimelineSyncBridge timelineSyncBridge) {
        timelineSyncBridge.pushStatus();
    }

    public TimelineSyncBridge(WebView webView) {
        this.view = webView;
    }

    @JavascriptInterface
    public synchronized void start(String str, int i, String str2) {
        String str3;
        final DatagramSocket datagramSocket;
        if (acceptRequest(str)) {
            String strTrim = str2 == null ? "" : str2.trim();
            if (i >= 1 && i <= 65535) {
                if (!strTrim.isEmpty() && !isIPv4(strTrim)) {
                    reply(str, "来源 IP 必须是有效的 IPv4 地址，或留空。");
                    return;
                }
                DatagramSocket datagramSocket2 = null;
                if (this.listener != null && this.port == i) {
                    if (!this.sourceFilter.equals(strTrim)) {
                        this.sourceFilter = strTrim;
                        resetSession();
                    }
                    reply(str, null);
                    return;
                }
                try {
                    datagramSocket = new DatagramSocket((SocketAddress) null);
                } catch (IOException e) {
                    e = e;
                } catch (SecurityException e2) {
                    e = e2;
                }
                try {
                    datagramSocket.setReuseAddress(false);
                    datagramSocket.bind(new InetSocketAddress(InetAddress.getByAddress(new byte[4]), i));
                    DatagramSocket datagramSocket3 = this.listener;
                    if (datagramSocket3 != null) {
                        datagramSocket3.close();
                    }
                    this.listener = datagramSocket;
                    this.port = i;
                    this.sourceFilter = strTrim;
                    resetSession();
                    reply(str, null);
                    Thread thread = new Thread(new Runnable() { // from class: com.pianchang.lighting.TimelineSyncBridge$$ExternalSyntheticLambda1
                        @Override // java.lang.Runnable
                        public final void run() throws IOException {
                            this.f$0.m103lambda$start$0$compianchanglightingTimelineSyncBridge(datagramSocket);
                        }
                    }, "lighting-timeline-udp");
                    thread.setDaemon(true);
                    thread.start();
                    return;
                } catch (IOException | SecurityException e3) {
                    e = e3;
                    datagramSocket2 = datagramSocket;
                    if (datagramSocket2 != null) {
                        datagramSocket2.close();
                    }
                    String message = e.getMessage();
                    String lowerCase = message == null ? "" : message.toLowerCase(Locale.ROOT);
                    if ((e instanceof BindException) || lowerCase.contains("eaddrinuse") || lowerCase.contains("address already in use")) {
                        this.lastError = "UDP 端口 " + i + " 已被占用。";
                    } else {
                        StringBuilder sb = new StringBuilder("无法监听 UDP 端口 ");
                        sb.append(i);
                        if (message == null) {
                            str3 = "。";
                        } else {
                            str3 = "：" + message;
                        }
                        sb.append(str3);
                        this.lastError = sb.toString();
                    }
                    reply(str, this.lastError);
                    return;
                }
            }
            reply(str, "UDP 端口必须在 1 到 65535 之间。");
        }
    }

    /* renamed from: lambda$start$0$com-pianchang-lighting-TimelineSyncBridge, reason: not valid java name */
    /* synthetic */ void m103lambda$start$0$compianchanglightingTimelineSyncBridge(DatagramSocket datagramSocket) throws IOException {
        receive(datagramSocket);
    }

    @JavascriptInterface
    public synchronized void stop(String str) {
        if (acceptRequest(str)) {
            releaseListener();
            reply(str, null);
        }
    }

    @JavascriptInterface
    public synchronized void status(String str) {
        if (acceptRequest(str)) {
            reply(str, null);
        }
    }

    public synchronized void close() {
        this.closed = true;
        releaseListener();
        this.main.removeCallbacks(this.push);
    }

    private boolean acceptRequest(String str) {
        return (this.closed || str == null || str.isEmpty() || str.length() > 128) ? false : true;
    }

    private void releaseListener() {
        DatagramSocket datagramSocket = this.listener;
        if (datagramSocket != null) {
            datagramSocket.close();
            this.listener = null;
        }
        clearSamples();
    }

    private void resetSession() {
        clearSamples();
        this.stale = 0L;
        this.filtered = 0L;
        this.invalid = 0L;
        this.duplicates = 0L;
        this.valid = 0L;
        this.lastError = "";
    }

    private void clearSamples() {
        this.update = null;
        this.activeSource = "";
        this.newestTimestamp = null;
        this.recent.clear();
    }

    private void receive(DatagramSocket datagramSocket) throws IOException {
        String str;
        DatagramPacket datagramPacket = new DatagramPacket(new byte[1025], 1025);
        while (!datagramSocket.isClosed()) {
            try {
                datagramPacket.setLength(1025);
                datagramSocket.receive(datagramPacket);
                handleDatagram(datagramSocket, datagramPacket, SystemClock.elapsedRealtime(), System.currentTimeMillis());
            } catch (IOException | SecurityException e) {
                synchronized (this) {
                    if (this.listener != datagramSocket) {
                        return;
                    }
                    releaseListener();
                    StringBuilder sb = new StringBuilder();
                    sb.append("UDP 接收中断");
                    if (e.getMessage() == null) {
                        str = "。";
                    } else {
                        str = "：" + e.getMessage();
                    }
                    sb.append(str);
                    this.lastError = sb.toString();
                    schedulePush();
                    return;
                }
            }
        }
    }

    private synchronized void handleDatagram(DatagramSocket datagramSocket, DatagramPacket datagramPacket, long j, long j2) {
        if (this.listener != datagramSocket) {
            return;
        }
        String hostAddress = datagramPacket.getAddress().getHostAddress();
        if (!(datagramPacket.getAddress() instanceof Inet4Address) || (!this.sourceFilter.isEmpty() && !this.sourceFilter.equals(hostAddress))) {
            this.filtered++;
        } else {
            try {
                process(parse(datagramPacket.getData(), datagramPacket.getOffset(), datagramPacket.getLength()), hostAddress, j, j2);
            } catch (BadPacket e) {
                this.invalid++;
                this.lastError = e.getMessage();
            }
        }
        schedulePush();
    }

    private void process(Sample sample, String str, long j, long j2) {
        long j3;
        Received received;
        while (true) {
            boolean zIsEmpty = this.recent.isEmpty();
            j3 = TIMESTAMPED_WINDOW_MS;
            if (zIsEmpty || j - this.recent.peekFirst().elapsed <= TIMESTAMPED_WINDOW_MS) {
                break;
            } else {
                this.recent.removeFirst();
            }
        }
        if (sample.ts == null) {
            j3 = UNSTAMPED_WINDOW_MS;
        }
        Iterator<Received> it = this.recent.iterator();
        while (it.hasNext()) {
            Received next = it.next();
            if (j - next.elapsed <= j3 && sample.matches(next.sample)) {
                if (sample.duration != null && (received = this.update) != null && received.sample.duration == null && sample.matches(this.update.sample)) {
                    this.update.sample.duration = sample.duration;
                }
                this.duplicates++;
                return;
            }
        }
        boolean zEquals = this.activeSource.equals(str);
        if (zEquals && sample.ts != null && this.newestTimestamp != null && sample.ts.longValue() < this.newestTimestamp.longValue()) {
            this.stale++;
            return;
        }
        if (!zEquals) {
            this.activeSource = str;
            this.newestTimestamp = null;
        }
        if (sample.ts != null) {
            this.newestTimestamp = sample.ts;
        }
        long j4 = this.sequence + 1;
        this.sequence = j4;
        this.update = new Received(sample, str, j, j2, j4);
        this.valid++;
        if (this.recent.size() >= 256) {
            this.recent.removeFirst();
        }
        this.recent.addLast(this.update);
    }

    private void schedulePush() {
        if (this.pushPending || this.closed) {
            return;
        }
        this.pushPending = true;
        this.main.postDelayed(this.push, Math.max(0L, (this.lastPushAt + MIN_PUSH_INTERVAL_MS) - SystemClock.elapsedRealtime()));
    }

    private void pushStatus() {
        synchronized (this) {
            this.pushPending = false;
            if (this.closed) {
                return;
            }
            this.lastPushAt = SystemClock.elapsedRealtime();
            JSONObject jSONObjectSnapshot = snapshot();
            this.view.evaluateJavascript("if(typeof window.onLightingTimelineStatus==='function')window.onLightingTimelineStatus(" + jSONObjectSnapshot + ");", null);
        }
    }

    private void reply(final String str, String str2) throws JSONException {
        final JSONObject jSONObject = new JSONObject();
        put(jSONObject, "ok", Boolean.valueOf(str2 == null));
        put(jSONObject, "status", snapshot());
        if (str2 != null) {
            put(jSONObject, "message", str2);
        }
        this.main.post(new Runnable() { // from class: com.pianchang.lighting.TimelineSyncBridge$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m102lambda$reply$1$compianchanglightingTimelineSyncBridge(str, jSONObject);
            }
        });
    }

    /* renamed from: lambda$reply$1$com-pianchang-lighting-TimelineSyncBridge, reason: not valid java name */
    /* synthetic */ void m102lambda$reply$1$compianchanglightingTimelineSyncBridge(String str, JSONObject jSONObject) {
        synchronized (this) {
            if (this.closed) {
                return;
            }
            this.view.evaluateJavascript("if(typeof window.onLightingTimelineResult==='function')window.onLightingTimelineResult(" + JSONObject.quote(str) + "," + jSONObject + ");", null);
        }
    }

    private JSONObject snapshot() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        put(jSONObject, "listening", Boolean.valueOf(this.listener != null));
        put(jSONObject, "port", Integer.valueOf(this.port));
        put(jSONObject, "sourceFilter", this.sourceFilter);
        if (this.update == null) {
            put(jSONObject, "update", JSONObject.NULL);
        } else {
            JSONObject jSONObject2 = new JSONObject();
            put(jSONObject2, "t", Double.valueOf(this.update.sample.t));
            put(jSONObject2, "s", this.update.sample.state);
            put(jSONObject2, "ts", this.update.sample.ts == null ? JSONObject.NULL : this.update.sample.ts);
            put(jSONObject2, "duration", this.update.sample.duration == null ? JSONObject.NULL : this.update.sample.duration);
            put(jSONObject2, "sourceIp", this.update.source);
            put(jSONObject2, "receivedAt", Long.valueOf(this.update.wallTime));
            put(jSONObject2, "ageMs", Long.valueOf(Math.max(0L, SystemClock.elapsedRealtime() - this.update.elapsed)));
            put(jSONObject2, "sequence", Long.valueOf(this.update.sequence));
            put(jSONObject, "update", jSONObject2);
        }
        put(jSONObject, "valid", Long.valueOf(this.valid));
        put(jSONObject, "duplicates", Long.valueOf(this.duplicates));
        put(jSONObject, "invalid", Long.valueOf(this.invalid));
        put(jSONObject, "filtered", Long.valueOf(this.filtered));
        put(jSONObject, "stale", Long.valueOf(this.stale));
        put(jSONObject, "lastError", this.lastError);
        return jSONObject;
    }

    private static void put(JSONObject jSONObject, String str, Object obj) throws JSONException {
        try {
            jSONObject.put(str, obj);
        } catch (JSONException e) {
            throw new IllegalStateException("Could not serialize timeline status", e);
        }
    }

    private static boolean isIPv4(String str) {
        String[] strArrSplit = str.split("\\.", -1);
        if (strArrSplit.length != 4) {
            return false;
        }
        for (String str2 : strArrSplit) {
            if (!IPV4_OCTET.matcher(str2).matches() || Integer.parseInt(str2) > 255) {
                return false;
            }
        }
        return true;
    }

    private static Sample parse(byte[] bArr, int i, int i2) throws BadPacket, NumberFormatException {
        Double duration;
        if (i2 == 0 || i2 > 1024) {
            throw new BadPacket("报文为空或超过 1024 字节。");
        }
        try {
            String string = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bArr, i, i2)).toString();
            if (string.indexOf(0) >= 0) {
                throw new BadPacket("报文包含无效控制字符。");
            }
            String strTrim = string.trim();
            if (strTrim.startsWith("{")) {
                return parseJson(strTrim);
            }
            String[] strArrSplit = strTrim.split("\\s+");
            int length = strArrSplit.length;
            Long lValueOf = null;
            if (length <= 3 || !strArrSplit[length - 1].startsWith("duration=")) {
                duration = null;
            } else {
                length--;
                duration = parseDuration(strArrSplit[length].substring(9));
            }
            if ((length != 3 && length != 4) || !"LSYNC".equals(strArrSplit[0])) {
                throw new BadPacket("报文不是 JSON 对象或 LSYNC 文本。");
            }
            if (!DECIMAL.matcher(strArrSplit[2]).matches()) {
                throw new BadPacket("视频时间必须是非负的有限数字。");
            }
            if (length == 4) {
                if (!DIGITS.matcher(strArrSplit[3]).matches()) {
                    throw new BadPacket("发送时间戳必须是非负整数毫秒。");
                }
                try {
                    long j = Long.parseLong(strArrSplit[3]);
                    lValueOf = Long.valueOf(j);
                    lValueOf.getClass();
                    if (j > MAX_SAFE_INTEGER) {
                        throw new BadPacket("发送时间戳超出有效范围。");
                    }
                } catch (NumberFormatException unused) {
                    throw new BadPacket("发送时间戳超出有效范围。");
                }
            }
            try {
                return validated(strArrSplit[1], Double.parseDouble(strArrSplit[2]), lValueOf, duration);
            } catch (NumberFormatException unused2) {
                throw new BadPacket("视频时间必须是非负的有限数字。");
            }
        } catch (CharacterCodingException unused3) {
            throw new BadPacket("报文不是有效的 UTF-8。");
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:27:0x005e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static com.pianchang.lighting.TimelineSyncBridge.Sample parseJson(java.lang.String r11) throws java.io.IOException {
        /*
            Method dump skipped, instructions count: 295
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.pianchang.lighting.TimelineSyncBridge.parseJson(java.lang.String):com.pianchang.lighting.TimelineSyncBridge$Sample");
    }

    private static Double parseDuration(String str) throws NumberFormatException {
        if (!DECIMAL.matcher(str).matches()) {
            return null;
        }
        try {
            double d = Double.parseDouble(str);
            if (!Double.isFinite(d) || d <= 0.0d) {
                return null;
            }
            return Double.valueOf(d);
        } catch (NumberFormatException unused) {
            return null;
        }
    }

    private static Sample validated(String str, double d, Long l, Double d2) throws BadPacket {
        if (!"play".equals(str) && !"pause".equals(str) && !"stop".equals(str)) {
            throw new BadPacket("播放状态必须是 play、pause 或 stop。");
        }
        if (!Double.isFinite(d) || d < 0.0d) {
            throw new BadPacket("视频时间必须是非负的有限数字。");
        }
        return new Sample(d, str, l, d2);
    }

    private static final class BadPacket extends IOException {
        BadPacket(String str) {
            super(str);
        }
    }

    private static final class Sample {
        Double duration;
        final String state;
        final double t;
        final Long ts;

        Sample(double d, String str, Long l, Double d2) {
            this.t = d;
            this.state = str;
            this.ts = l;
            this.duration = d2;
        }

        boolean matches(Sample sample) {
            return this.t == sample.t && this.state.equals(sample.state) && Objects.equals(this.ts, sample.ts);
        }
    }

    private static final class Received {
        final long elapsed;
        final Sample sample;
        final long sequence;
        final String source;
        final long wallTime;

        Received(Sample sample, String str, long j, long j2, long j3) {
            this.sample = sample;
            this.source = str;
            this.elapsed = j;
            this.wallTime = j2;
            this.sequence = j3;
        }
    }
}
