package com.pianchang.lighting;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.File;
import java.io.FileNotFoundException;

/* loaded from: classes.dex */
public final class UpdateApkProvider extends ContentProvider {
    private static final String APK_NAME = "app-update.apk";
    static final String APK_TYPE = "application/vnd.android.package-archive";

    @Override // android.content.ContentProvider
    public boolean onCreate() {
        return true;
    }

    static Uri apkUri(Context context) {
        return new Uri.Builder().scheme("content").authority(context.getPackageName() + ".update").appendPath(APK_NAME).build();
    }

    static File apkFile(Context context) {
        return new File(context.getCacheDir(), APK_NAME);
    }

    @Override // android.content.ContentProvider
    public String getType(Uri uri) {
        if (apkUri(getContext()).equals(uri)) {
            return APK_TYPE;
        }
        return null;
    }

    @Override // android.content.ContentProvider
    public ParcelFileDescriptor openFile(Uri uri, String str) throws FileNotFoundException {
        if (getType(uri) == null || !"r".equals(str)) {
            throw new FileNotFoundException();
        }
        return ParcelFileDescriptor.open(apkFile(getContext()), 268435456);
    }

    @Override // android.content.ContentProvider
    public Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        File fileApkFile = apkFile(getContext());
        if (getType(uri) == null || !fileApkFile.isFile()) {
            return null;
        }
        if (strArr == null) {
            strArr = new String[]{"_display_name", "_size"};
        }
        Object[] objArr = new Object[strArr.length];
        for (int i = 0; i < strArr.length; i++) {
            if ("_display_name".equals(strArr[i])) {
                objArr[i] = APK_NAME;
            }
            if ("_size".equals(strArr[i])) {
                objArr[i] = Long.valueOf(fileApkFile.length());
            }
        }
        MatrixCursor matrixCursor = new MatrixCursor(strArr, 1);
        matrixCursor.addRow(objArr);
        return matrixCursor;
    }

    @Override // android.content.ContentProvider
    public Uri insert(Uri uri, ContentValues contentValues) {
        throw new UnsupportedOperationException();
    }

    @Override // android.content.ContentProvider
    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        throw new UnsupportedOperationException();
    }

    @Override // android.content.ContentProvider
    public int delete(Uri uri, String str, String[] strArr) {
        throw new UnsupportedOperationException();
    }
}
