package com.pianchang.lighting;

import com.telink.ble.mesh.core.access.fu.FUDistributor;
import java.util.Locale;

/* loaded from: classes.dex */
final class UlanziAdvertisement {
    private static boolean supported(int i) {
        if (i == 162 || i == 163 || i == 166 || i == 167 || i == 169 || i == 175 || i == 181 || i == 177 || i == 178) {
            return true;
        }
        switch (i) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
                return true;
            default:
                return false;
        }
    }

    private UlanziAdvertisement() {
    }

    static String productCode(String str, byte[] bArr) {
        int i;
        if (str != null && str.toLowerCase(Locale.ROOT).contains("ulanzi") && bArr != null) {
            int i2 = 0;
            while (i2 < bArr.length && (i = bArr[i2] & FUDistributor.UPDATE_TTL) != 0 && i <= (bArr.length - i2) - 1) {
                int i3 = i2 + 2;
                if (i >= 8 && (bArr[i2 + 1] & FUDistributor.UPDATE_TTL) == 255 && (bArr[i3] & FUDistributor.UPDATE_TTL) >= 9 && bArr[i2 + 7] == 13) {
                    int i4 = 255 & bArr[i2 + 8];
                    if (supported(i4)) {
                        return String.format(Locale.ROOT, "0D&%02X", Integer.valueOf(i4));
                    }
                }
                i2 += i + 1;
            }
        }
        return null;
    }
}
