package com.pianchang.lighting;

import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.entity.BindingDevice;
import com.telink.ble.mesh.entity.CompositionData;
import com.telink.ble.mesh.entity.Element;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* loaded from: classes.dex */
final class LuminMeshProtocol {
    static final String CONTROL_PROFILE = "lumin-ae86";
    private static final int MODEL_ID = 110214;
    static final int OPCODE = 11437760;
    private static final Pattern MODEL_NAME = Pattern.compile("^(C4|60C|60DN|220DN|320DN|80BN(?:_1)?|80C(?:_1)?|130DNA|200DNA|60BNA|130BNA|200BNA|LX200BNA|TL1-7C30|TL30|LX200DNA|200D|LX200N|X200BNA|X200N|200B|60CA|400BNS|300C|S300C|800BNS|F200B|130CA)(?=$|[\\s_-])", 2);
    private static final Pattern BRAND_NAME = Pattern.compile("^(?:i-?footage|lumin\\+?|anglerfish|suncrafter|印迹)(?=$|[\\s_-])[\\s_-]*", 2);

    private LuminMeshProtocol() {
    }

    static String recognizedName(String str) {
        if (str == null) {
            return null;
        }
        String strTrim = str.replace("/", "").trim();
        Matcher matcher = BRAND_NAME.matcher(strTrim);
        boolean zFind = matcher.find();
        Matcher matcher2 = MODEL_NAME.matcher(zFind ? strTrim.substring(matcher.end()) : strTrim);
        if (matcher2.find()) {
            return matcher2.group(1);
        }
        if (zFind) {
            return strTrim;
        }
        return null;
    }

    static boolean hasKnownModel(String str) {
        return MODEL_NAME.matcher(str).matches();
    }

    static List<BindingDevice.ModelTarget> select(CompositionData compositionData) {
        if (compositionData != null && compositionData.elements != null) {
            for (int i = 0; i < compositionData.elements.size(); i++) {
                Element element = compositionData.elements.get(i);
                if (element.vendorModels != null && element.vendorModels.contains(Integer.valueOf(MODEL_ID))) {
                    return Collections.singletonList(new BindingDevice.ModelTarget(i, MODEL_ID, false));
                }
            }
        }
        return Collections.emptyList();
    }

    static byte[] statusRequest() {
        return new byte[]{9, 0, 9, 0};
    }

    static boolean validSet(byte[] bArr) {
        byte b;
        if (bArr.length == 4) {
            return bArr[0] == 13 && ((b = bArr[1]) == 0 || b == 1) && validChecksum(bArr);
        }
        if (bArr.length != 6 || !validChecksum(bArr)) {
            return false;
        }
        int iWord = word(bArr, 1);
        int i = bArr[3] & FUDistributor.UPDATE_TTL;
        byte b2 = bArr[0];
        if (b2 == 0) {
            return iWord <= 1000 && i <= 2;
        }
        if (b2 == 1) {
            return iWord >= 1800 && iWord <= 20000 && i <= 200;
        }
        if (b2 != 2) {
            return false;
        }
        return iWord <= 360 && i <= 100;
    }

    static int statusProduct(int i, byte[] bArr) {
        if ((i == OPCODE || i == 11437761 || i == 11437770) && bArr != null && bArr.length >= 7 && bArr[0] == 10 && validChecksum(bArr)) {
            return bArr[1] & FUDistributor.UPDATE_TTL;
        }
        return -1;
    }

    private static boolean validChecksum(byte[] bArr) {
        int length = bArr.length - 2;
        int i = 0;
        for (int i2 = 0; i2 < length; i2++) {
            i += bArr[i2] & FUDistributor.UPDATE_TTL;
        }
        return (65535 & i) == word(bArr, length);
    }

    private static int word(byte[] bArr, int i) {
        return ((bArr[i + 1] & FUDistributor.UPDATE_TTL) << 8) | (bArr[i] & FUDistributor.UPDATE_TTL);
    }
}
