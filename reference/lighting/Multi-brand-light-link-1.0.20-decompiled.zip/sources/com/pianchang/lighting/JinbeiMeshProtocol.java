package com.pianchang.lighting;

import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.entity.BindingDevice;
import com.telink.ble.mesh.entity.CompositionData;
import com.telink.ble.mesh.entity.Element;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/* loaded from: classes.dex */
final class JinbeiMeshProtocol {
    static final String CONTROL_PROFILE = "jinbei-sig";
    private static final int FRAME_MARKER = 126;
    private static final int JINBEI_COMPANY = 93;
    private static final String[] LED_CATALOG;
    static final int OPCODE = 24010;
    private static final int PAIRLINK_COMPANY = 1465;
    private static final int PAIRLINK_COMPANY_REVERSED = 47365;
    private static final int STATUS_OPCODE = 24013;
    private static final Pattern SEPARATORS = Pattern.compile("[\\s_–—:-]+");
    private static final Pattern ADDRESS_SUFFIX = Pattern.compile("[0-9A-F]{4,12}");
    private static final Map<Integer, String> PRODUCTS = new LinkedHashMap();

    static {
        String[] strArr = {"1 EFII-100", "2 EFII-150", "3 EFII-200", "4 EFII-60", "5 EF-300", "6 EFP-50", "7 EF-200BI", "8 EFP-400", "9 EFD-150", "10 EFD-200", "11 EFP-100", "12 EFD-300", "13 EFD-500", "14 EFD-60M", "15 EFD-60BI", "17 EFT-360", "18 EFT-550", "19 EF-P10", "20 ICE-LIGHT3", "21 EFT-8C", "22 EFT-8C BI", "23 LX-100", "24 LX-100BI", "25 LX-60", "26 LX-60BI", "27 EFD-300BI", "28 EF-300BI", "29 EFC-150", "30 EF-60RGB", "31 EFP-100RGB", "33 Soluna 200Bi", "34 Soluna 500pro", "39 LED 1500D", "40 LED 2000D", "41 LED 1000", "42 LED 200D", "43 LED 160D", "49 EFIII-100", "50 EFIII-150", "51 EFIII-200", "52 EFII-200BI", "53 EF-150BI", "54 EFII-300", "55 Soluna 150", "56 L60-B", "57 EF-600", "58 EF-150PRO", "59 EF-220", "60 EF-160BI", "61 EF-220BI", "62 EFT-361", "63 EFT-551", "64 EF-600BI", "65 EL-300", "66 EL-300BI", "67 EF-80", "68 EF-80BI", "69 EF-120", "70 EF-120BI", "71 EFT-220RGB", "72 EFT-860", "73 Soluna L-60", "74 Soluna L100", "76 Soluna 80", "77 Soluna 80Bi", "78 Soluna 120", "79 Soluna120Bi", "80 EFT_220RGB", "81 P6PRO", "84 P80RGB", "85 P80BI", "90 L120-B", "91 LED 300BI", "92 LED 120BI", "93 LED 80BI", "94 LED 24RGB", "95 LED 8RGB", "96 EF-60BI", "97 EF_220", "98 EF_220BI"};
        LED_CATALOG = strArr;
        for (String str : strArr) {
            int iIndexOf = str.indexOf(32);
            PRODUCTS.put(Integer.valueOf(Integer.parseInt(str.substring(0, iIndexOf))), str.substring(iIndexOf + 1));
        }
    }

    private JinbeiMeshProtocol() {
    }

    static String recognizedName(String str) {
        String str2 = null;
        if (str == null) {
            return null;
        }
        String strNormalizeModel = normalizeModel(str);
        String[] strArr = {"JINBEI", "金贝", "ROLLEI"};
        int length = 0;
        int i = 0;
        while (true) {
            if (i >= 3) {
                break;
            }
            String str3 = strArr[i];
            if (strNormalizeModel.startsWith(str3)) {
                strNormalizeModel = strNormalizeModel.substring(str3.length());
                break;
            }
            i++;
        }
        for (String str4 : PRODUCTS.values()) {
            String strNormalizeModel2 = normalizeModel(str4);
            if (strNormalizeModel2.length() > length && strNormalizeModel.startsWith(strNormalizeModel2)) {
                String strSubstring = strNormalizeModel.substring(strNormalizeModel2.length());
                if (strSubstring.isEmpty() || ADDRESS_SUFFIX.matcher(strSubstring).matches()) {
                    length = strNormalizeModel2.length();
                    str2 = str4;
                }
            }
        }
        return str2;
    }

    private static String normalizeModel(String str) {
        return SEPARATORS.matcher(str).replaceAll("").toUpperCase(Locale.ROOT);
    }

    static byte[] provisioningData(byte[] bArr, byte[] bArr2) {
        return SidusAdvertisement.validProvisioningData(bArr) ? bArr : SidusAdvertisement.provisioningBeacon(bArr2);
    }

    static boolean isKnownProduct(int i) {
        return PRODUCTS.containsKey(Integer.valueOf(i));
    }

    static List<BindingDevice.ModelTarget> select(CompositionData compositionData) {
        if (compositionData == null || compositionData.elements == null) {
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        for (int i = 0; i < compositionData.elements.size(); i++) {
            Element element = compositionData.elements.get(i);
            if (element.vendorModels != null) {
                Iterator<Integer> it = element.vendorModels.iterator();
                while (it.hasNext()) {
                    int iIntValue = it.next().intValue();
                    int i2 = 65535 & iIntValue;
                    if (i2 == JINBEI_COMPANY) {
                        arrayList.add(new BindingDevice.ModelTarget(i, iIntValue, false));
                    } else if (i2 == PAIRLINK_COMPANY || i2 == PAIRLINK_COMPANY_REVERSED) {
                        arrayList2.add(new BindingDevice.ModelTarget(i, iIntValue, false));
                    }
                }
            }
        }
        return arrayList.isEmpty() ? arrayList2 : arrayList;
    }

    static boolean needsReadback(List<BindingDevice.ModelTarget> list) {
        return (list.isEmpty() || (list.get(0).modelId & 65535) == JINBEI_COMPANY) ? false : true;
    }

    static byte[] statusRequest() {
        return new byte[]{126, 34, 2, 126};
    }

    static boolean validSet(byte[] bArr) {
        if (!validFrame(bArr)) {
            return false;
        }
        int length = bArr.length - 4;
        int i = length > 0 ? bArr[3] & FUDistributor.UPDATE_TTL : -1;
        switch (bArr[1]) {
            case 1:
            case 3:
                if (length == 1 && i == 1) {
                    break;
                }
                break;
            case 7:
                if (length == 1) {
                    break;
                }
                break;
            case 9:
                if (length == 2 && i >= 1 && i <= 9 && bArr[4] == 0) {
                    break;
                }
                break;
            case 11:
                if (length == 1 && i >= 20 && i <= 100) {
                    break;
                }
                break;
            case 13:
                if (length == 3 && ((i << 8) | (bArr[4] & FUDistributor.UPDATE_TTL)) <= 359 && (bArr[5] & FUDistributor.UPDATE_TTL) <= 100) {
                    break;
                }
                break;
            case 15:
                if (length == 1 && i <= 100) {
                    break;
                }
                break;
            case 19:
                if (length == 1 && i <= 20) {
                    break;
                }
                break;
            case 46:
                if (length == 1 && i <= 1) {
                    break;
                }
                break;
            case 56:
                if (length == 1 && i <= 2) {
                    break;
                }
                break;
            case 61:
                if (length == 1 && i <= 3) {
                    break;
                }
                break;
        }
        return false;
    }

    static int statusProduct(int i, byte[] bArr) {
        if (i == STATUS_OPCODE && validFrame(bArr) && bArr.length >= 7 && bArr[1] == 35) {
            return bArr[3] & FUDistributor.UPDATE_TTL;
        }
        return -1;
    }

    private static boolean validFrame(byte[] bArr) {
        return bArr != null && bArr.length >= 4 && bArr[0] == FRAME_MARKER && bArr[bArr.length - 1] == FRAME_MARKER && (bArr[2] & FUDistributor.UPDATE_TTL) + 2 == bArr.length;
    }
}
