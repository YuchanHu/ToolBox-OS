package com.pianchang.lighting;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.ParcelUuid;
import android.util.SparseArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.pianchang.lighting.FixtureMeshTransport;
import com.pianchang.lighting.SidusAdvertisement;
import com.telink.ble.mesh.core.Encipher;
import com.telink.ble.mesh.core.access.BindingBearer;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.NotificationMessage;
import com.telink.ble.mesh.entity.BindingDevice;
import com.telink.ble.mesh.entity.CompositionData;
import com.telink.ble.mesh.entity.Element;
import com.telink.ble.mesh.entity.ProvisioningDevice;
import com.telink.ble.mesh.foundation.Event;
import com.telink.ble.mesh.foundation.EventHandler;
import com.telink.ble.mesh.foundation.MeshConfiguration;
import com.telink.ble.mesh.foundation.MeshService;
import com.telink.ble.mesh.foundation.event.AutoConnectEvent;
import com.telink.ble.mesh.foundation.event.BindingEvent;
import com.telink.ble.mesh.foundation.event.MeshEvent;
import com.telink.ble.mesh.foundation.event.NetworkInfoUpdateEvent;
import com.telink.ble.mesh.foundation.event.ProvisioningEvent;
import com.telink.ble.mesh.foundation.event.StatusNotificationEvent;
import com.telink.ble.mesh.foundation.parameter.AutoConnectParameters;
import com.telink.ble.mesh.foundation.parameter.BindingParameters;
import com.telink.ble.mesh.foundation.parameter.ProvisioningParameters;
import com.telink.ble.mesh.util.MeshLogger;
import java.nio.ByteBuffer;
import java.security.SecureRandom;
import java.security.Security;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.spongycastle.crypto.tls.CipherSuite;
import org.spongycastle.jce.provider.BouncyCastleProvider;

/* loaded from: classes.dex */
final class FixtureMeshTransport {
    private static final int APP_KEY_INDEX = 0;
    private static final long BIND_TIME = 55000;
    private static final long CONNECT_TIME = 22000;
    private static final long CONTROL_READBACK_TIME = 1800;
    private static final int GODOX_OPCODE = 135664;
    private static final int GODOX_SERVER_MODEL = 529;
    private static final long JINBEI_READBACK_TIME = 3000;
    private static final int LOCAL_ADDRESS = 1;
    private static final long PROVISION_TIME = 40000;
    private static final long SCAN_TIME = 7000;
    private static final long SELECTION_TIME = 90000;
    private static final long SEND_INTERVAL = 80;
    private static final long SIDUS_BIND_RETRY_DELAY = 1500;
    private String activeProject;
    private final Map<Integer, Node> activeTargets;
    private final Activity activity;
    private final BiConsumer<String, JSONObject> addProgress;
    private final Map<String, Candidate> candidates;
    private boolean closed;
    private MeshConfiguration configuration;
    private final Context context;
    private final BiConsumer<String, JSONObject> deliver;
    private final Handler handler;
    private byte[] identityKey;
    private final Consumer<String> linkLost;
    private boolean loggedIn;
    private final MeshService mesh;
    private byte[] networkId;
    private final Map<String, Node> nodes;
    private Operation operation;
    private final Runnable operationTimeout;
    private final Profile profile;
    private MeshScan scan;
    private int sendFailures;
    private final Runnable sendNext;
    private final ArrayDeque<SendJob> sendQueue;
    private boolean sending;
    private final SharedPreferences store;
    private static final ParcelUuid PROVISIONING_SERVICE = ParcelUuid.fromString("00001827-0000-1000-8000-00805f9b34fb");
    private static final ParcelUuid PROXY_SERVICE = ParcelUuid.fromString("00001828-0000-1000-8000-00805f9b34fb");

    private enum Phase {
        PROVISIONING,
        BINDING,
        CONNECTING,
        READING_CONTROL_STATUS
    }

    public static /* synthetic */ void $r8$lambda$7O27M9R0dneeWsjEGLoV7YLrQss(FixtureMeshTransport fixtureMeshTransport, Event event) {
        fixtureMeshTransport.receiveEvent(event);
    }

    /* renamed from: $r8$lambda$PEKmXUpPs2_uEapy_-qzAVykxDY, reason: not valid java name */
    public static /* synthetic */ void m6$r8$lambda$PEKmXUpPs2_uEapy_qzAVykxDY(FixtureMeshTransport fixtureMeshTransport) {
        fixtureMeshTransport.flushSendQueue();
    }

    public static /* synthetic */ void $r8$lambda$e4J2DA7W6uB4nCw8nc4Ux7aLMSY(FixtureMeshTransport fixtureMeshTransport) throws JSONException {
        fixtureMeshTransport.timeOutOperation();
    }

    static /* synthetic */ void lambda$new$0(String str, JSONObject jSONObject) {
    }

    static /* synthetic */ boolean access$000(byte[] bArr) {
        return validSidusPayload(bArr);
    }

    static /* synthetic */ MeshScan access$1000(FixtureMeshTransport fixtureMeshTransport) {
        return fixtureMeshTransport.scan;
    }

    static /* synthetic */ JSONObject access$1100(FixtureMeshTransport fixtureMeshTransport, String str, String str2) {
        return fixtureMeshTransport.profileError(str, str2);
    }

    static /* synthetic */ Map access$1200(FixtureMeshTransport fixtureMeshTransport) {
        return fixtureMeshTransport.nodes;
    }

    static /* synthetic */ Candidate access$1300(FixtureMeshTransport fixtureMeshTransport, ScanResult scanResult) {
        return fixtureMeshTransport.identifyGodox(scanResult);
    }

    static /* synthetic */ String access$1400(String str) {
        return upper(str);
    }

    static /* synthetic */ ParcelUuid access$1500() {
        return PROXY_SERVICE;
    }

    static /* synthetic */ Node access$1600(FixtureMeshTransport fixtureMeshTransport, byte[] bArr, String str) {
        return fixtureMeshTransport.identifyProxy(bArr, str);
    }

    static /* synthetic */ ParcelUuid access$1700() {
        return PROVISIONING_SERVICE;
    }

    static /* synthetic */ String access$1900(byte[] bArr) {
        return toHex(bArr);
    }

    static /* synthetic */ byte[] access$2000(String str) {
        return fromHex(str);
    }

    static /* synthetic */ Activity access$300(FixtureMeshTransport fixtureMeshTransport) {
        return fixtureMeshTransport.activity;
    }

    static /* synthetic */ Profile access$400(FixtureMeshTransport fixtureMeshTransport) {
        return fixtureMeshTransport.profile;
    }

    static /* synthetic */ Handler access$500(FixtureMeshTransport fixtureMeshTransport) {
        return fixtureMeshTransport.handler;
    }

    static /* synthetic */ Map access$800(FixtureMeshTransport fixtureMeshTransport) {
        return fixtureMeshTransport.candidates;
    }

    static /* synthetic */ void access$900(FixtureMeshTransport fixtureMeshTransport, MeshScan meshScan, JSONObject jSONObject) {
        fixtureMeshTransport.finishScan(meshScan, jSONObject);
    }

    enum Profile {
        GODOX("神牛", "godox-mesh", "Godox", 1),
        SIDUS("爱图仕", "sidus-mesh", "Sidus", 0),
        LUMIN("印迹", "lumin-mesh", "Lumin", 0),
        JINBEI("金贝", "jinbei-mesh", "Jinbei", 0);

        final String errorPrefix;
        final int initialIvIndex;
        final String label;
        final String preferences;

        Profile(String str, String str2, String str3, int i) {
            this.label = str;
            this.preferences = str2;
            this.errorPrefix = str3;
            this.initialIvIndex = i;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    enum SidusControl {
        TELINK("sidus-0x26", FixtureMeshTransport.GODOX_SERVER_MODEL, 38, new Predicate() { // from class: com.pianchang.lighting.FixtureMeshTransport$SidusControl$$ExternalSyntheticLambda0
            @Override // java.util.function.Predicate
            public final boolean test(Object obj) {
                return FixtureMeshTransport.SidusControl.lambda$static$0((byte[]) obj);
            }
        }),
        ITON("sidus-iton-0x26", 268436470, 38, new Predicate() { // from class: com.pianchang.lighting.FixtureMeshTransport$SidusControl$$ExternalSyntheticLambda1
            @Override // java.util.function.Predicate
            public final boolean test(Object obj) {
                return FixtureMeshTransport.SidusControl.lambda$static$1((byte[]) obj);
            }
        });

        final String id;
        final int modelId;
        final int opcode;
        final Predicate<byte[]> validPayload;

        static /* synthetic */ boolean lambda$static$0(byte[] bArr) {
            return FixtureMeshTransport.access$000(bArr);
        }

        static /* synthetic */ boolean lambda$static$1(byte[] bArr) {
            return FixtureMeshTransport.access$000(bArr);
        }

        SidusControl(String str, int i, int i2, Predicate predicate) {
            this.id = str;
            this.modelId = i;
            this.opcode = i2;
            this.validPayload = predicate;
        }

        static SidusControl saved(String str) {
            if (str.isEmpty()) {
                return TELINK;
            }
            for (SidusControl sidusControl : values()) {
                if (sidusControl.id.equals(str)) {
                    return sidusControl;
                }
            }
            return null;
        }

        static List<BindingDevice.ModelTarget> select(CompositionData compositionData, Node node) {
            if (compositionData == null || compositionData.elements == null) {
                return Collections.emptyList();
            }
            int size = compositionData.elements.size();
            if (size > 255 || node.unicast + size > 32768) {
                return Collections.emptyList();
            }
            if (node.elementCount > 0 && size != node.elementCount) {
                return Collections.emptyList();
            }
            for (SidusControl sidusControl : values()) {
                for (int i = 0; i < size; i++) {
                    List<Integer> list = compositionData.elements.get(i).vendorModels;
                    if (list != null && list.contains(Integer.valueOf(sidusControl.modelId))) {
                        return Collections.singletonList(new BindingDevice.ModelTarget(i, sidusControl.modelId, false));
                    }
                }
            }
            return Collections.emptyList();
        }

        static SidusControl forTarget(BindingDevice.ModelTarget modelTarget) {
            for (SidusControl sidusControl : values()) {
                if (!modelTarget.sig && sidusControl.modelId == modelTarget.modelId) {
                    return sidusControl;
                }
            }
            throw new IllegalArgumentException("Unsupported Sidus binding target");
        }
    }

    FixtureMeshTransport(Profile profile, Activity activity, Handler handler, BiConsumer<String, JSONObject> biConsumer, Consumer<String> consumer) {
        this(profile, activity, handler, biConsumer, consumer, new BiConsumer() { // from class: com.pianchang.lighting.FixtureMeshTransport$$ExternalSyntheticLambda8
            @Override // java.util.function.BiConsumer
            public final void accept(Object obj, Object obj2) {
                FixtureMeshTransport.lambda$new$0((String) obj, (JSONObject) obj2);
            }
        });
    }

    FixtureMeshTransport(Profile profile, Activity activity, Handler handler, BiConsumer<String, JSONObject> biConsumer, Consumer<String> consumer, BiConsumer<String, JSONObject> biConsumer2) {
        this.mesh = new MeshService();
        this.nodes = new LinkedHashMap();
        this.candidates = new LinkedHashMap();
        this.activeTargets = new LinkedHashMap();
        this.sendQueue = new ArrayDeque<>();
        this.sendNext = new Runnable() { // from class: com.pianchang.lighting.FixtureMeshTransport$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                FixtureMeshTransport.m6$r8$lambda$PEKmXUpPs2_uEapy_qzAVykxDY(this.f$0);
            }
        };
        this.operationTimeout = new Runnable() { // from class: com.pianchang.lighting.FixtureMeshTransport$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() throws JSONException {
                FixtureMeshTransport.$r8$lambda$e4J2DA7W6uB4nCw8nc4Ux7aLMSY(this.f$0);
            }
        };
        this.activeProject = "";
        this.profile = profile;
        this.activity = activity;
        Context applicationContext = activity.getApplicationContext();
        this.context = applicationContext;
        this.handler = handler;
        this.deliver = biConsumer;
        this.linkLost = consumer;
        this.addProgress = biConsumer2;
        this.store = applicationContext.getSharedPreferences(profile.preferences, 0);
    }

    void scan(String str, BluetoothAdapter bluetoothAdapter, String str2) {
        if (this.scan != null || this.operation != null) {
            this.deliver.accept(str, busy());
            return;
        }
        HashSet hashSet = new HashSet();
        try {
            JSONArray jSONArray = new JSONArray(str2);
            boolean z = false;
            for (int i = 0; i < jSONArray.length(); i++) {
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                hashSet.add(upper(jSONObject.optString("uuid")));
                hashSet.add(upper(jSONObject.optString("address")));
            }
            BluetoothLeScanner bluetoothLeScanner = bluetoothAdapter.getBluetoothLeScanner();
            if (bluetoothLeScanner == null && this.profile != Profile.SIDUS) {
                this.deliver.accept(str, LightingBluetoothBridge.error("ScanFailed", "无法启动" + this.profile.label + "灯具搜索，请检查系统蓝牙。"));
                return;
            }
            this.candidates.clear();
            MeshScan meshScan = new MeshScan(str, bluetoothLeScanner, hashSet);
            this.scan = meshScan;
            try {
                initialize();
                meshScan.open();
                if (bluetoothLeScanner == null) {
                    MeshScan.access$100(meshScan, "无法启动蓝牙搜索，请检查系统蓝牙。");
                    return;
                }
                if (this.profile != Profile.GODOX && bluetoothAdapter.isLeExtendedAdvertisingSupported()) {
                    z = true;
                }
                meshScan.start(z);
            } catch (RuntimeException unused) {
                MeshScan.access$100(meshScan, "无法启动" + this.profile.label + "灯具搜索，请检查系统蓝牙。");
            }
        } catch (JSONException unused2) {
            this.deliver.accept(str, LightingBluetoothBridge.error("InvalidExclusions", this.profile.label + "灯具搜索的排除列表格式不正确。"));
        }
    }

    void add(String str, String str2, String str3) {
        if (this.scan != null || this.operation != null) {
            this.deliver.accept(str, busy());
            return;
        }
        try {
            JSONObject jSONObject = new JSONObject(str3);
            Candidate candidate = this.candidates.get(upper(jSONObject.optString("uuid")));
            if (candidate == null || !upper(jSONObject.optString("address")).equals(candidate.address)) {
                this.deliver.accept(str, profileError("ScanAgain", "请重新搜索并选择要添加的" + this.profile.label + "灯具。"));
                return;
            }
            if (validProject(str, str2)) {
                initialize();
                if (!this.activeProject.equals(str2)) {
                    this.activeTargets.clear();
                }
                this.activeProject = str2;
                Operation operation = new Operation(str, candidate, new JSONArray());
                this.operation = operation;
                if (candidate.node != null) {
                    operation.node = candidate.node;
                    if (canControl(candidate.node)) {
                        startProxy(operation);
                        return;
                    } else {
                        startBinding(operation);
                        return;
                    }
                }
                try {
                    this.mesh.idle(false);
                    invalidateProxy();
                    setPhase(operation, Phase.PROVISIONING, PROVISION_TIME);
                    operation.provisioningDevice = new ProvisioningDevice(candidate.device, fromHex(candidate.uuid));
                    operation.provisioningDevice.setOobInfo(candidate.oobInfo);
                    operation.provisioningDevice.setAutoUseNoOOB(true);
                    operation.provisioningDevice.setAutoStart(false);
                    if (this.mesh.startProvisioning(new ProvisioningParameters(operation.provisioningDevice))) {
                        return;
                    }
                    failOperation("ProvisionFailed", "无法开始" + this.profile.label + "灯具入网，请重新搜索后重试。");
                } catch (RuntimeException unused) {
                    failOperation("ProvisionFailed", this.profile.label + "灯具入网失败，请重新搜索后重试。");
                }
            }
        } catch (JSONException unused2) {
            this.deliver.accept(str, profileError("ScanAgain", "请重新搜索并选择要添加的" + this.profile.label + "灯具。"));
        }
    }

    void connect(String str, String str2, String str3) {
        if (this.scan != null || this.operation != null) {
            this.deliver.accept(str, busy());
            return;
        }
        if (validProject(str, str2)) {
            initialize();
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            JSONArray jSONArray = new JSONArray();
            try {
                JSONArray jSONArray2 = new JSONArray(str3);
                for (int i = 0; i < jSONArray2.length(); i++) {
                    JSONObject jSONObject = jSONArray2.getJSONObject(i);
                    String strUpper = upper(jSONObject.optString("uuid"));
                    Node node = this.nodes.get(strUpper);
                    if (node != null && node.unicast == jSONObject.optInt("unicast") && canControl(node)) {
                        linkedHashMap.put(Integer.valueOf(node.unicast), node);
                    } else {
                        jSONArray.put(strUpper);
                    }
                }
                if (linkedHashMap.isEmpty()) {
                    this.deliver.accept(str, profileError("NotPaired", "此设备没有这些" + this.profile.label + "灯具的入网记录，请将灯具设为可配网后重新添加。"));
                    return;
                }
                if (!this.activeProject.equals(str2)) {
                    cancelSends();
                }
                this.activeProject = str2;
                this.activeTargets.clear();
                this.activeTargets.putAll(linkedHashMap);
                Operation operation = new Operation(str, null, jSONArray);
                this.operation = operation;
                startProxy(operation);
            } catch (JSONException unused) {
                this.deliver.accept(str, profileError("NotPaired", this.profile.label + "灯具的入网记录无效，请重新添加。"));
            }
        }
    }

    private boolean canControl(Node node) {
        if (!node.bound) {
            return false;
        }
        if (this.profile == Profile.SIDUS) {
            return SidusControl.saved(node.controlProfile) != null;
        }
        if (this.profile == Profile.LUMIN) {
            return "lumin-ae86".equals(node.controlProfile);
        }
        if (this.profile == Profile.JINBEI) {
            return "jinbei-sig".equals(node.controlProfile);
        }
        return true;
    }

    void send(String str, String str2, int i, String str3) {
        Node node = this.activeTargets.get(Integer.valueOf(i));
        if (!this.loggedIn || !this.activeProject.equals(str2) || node == null || this.operation != null) {
            this.deliver.accept(str, profileError("Disconnected", this.profile.label + " Mesh 控制连接尚未就绪。"));
            return;
        }
        if (this.sendQueue.size() >= 128) {
            this.deliver.accept(str, LightingBluetoothBridge.error("Busy", this.profile.label + "灯具指令正在发送，请稍候。"));
            return;
        }
        SidusControl sidusControlSaved = this.profile == Profile.SIDUS ? SidusControl.saved(node.controlProfile) : null;
        if (this.profile == Profile.SIDUS && sidusControlSaved == null) {
            this.deliver.accept(str, profileError("UnsupportedModel", "当前灯具没有可用的控灯协议。"));
            return;
        }
        try {
            JSONArray jSONArray = new JSONArray(str3);
            if (jSONArray.length() < 1 || jSONArray.length() > 8) {
                throw new JSONException("Invalid packet count");
            }
            ArrayList arrayList = new ArrayList();
            for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                JSONObject jSONObject = jSONArray.getJSONObject(i2);
                int i3 = jSONObject.getInt("opcode");
                byte[] bArrFromHex = fromHex(jSONObject.getString("payload"));
                if (i3 != expectedControlOpcode(sidusControlSaved) || !validControlPayload(sidusControlSaved, bArrFromHex)) {
                    throw new JSONException("Invalid mesh message");
                }
                MeshMessage meshMessage = new MeshMessage();
                meshMessage.setOpcode(i3);
                meshMessage.setParams(bArrFromHex);
                meshMessage.setAppKeyIndex(0);
                meshMessage.setDestinationAddress(node.controlAddress);
                meshMessage.setRetryCnt(0);
                arrayList.add(meshMessage);
            }
            this.sendQueue.add(new SendJob(str, arrayList));
            if (this.sending) {
                return;
            }
            flushSendQueue();
        } catch (IllegalArgumentException | JSONException unused) {
            this.deliver.accept(str, LightingBluetoothBridge.error("InvalidPayload", this.profile.label + "控灯指令格式不正确。"));
        }
    }

    private int expectedControlOpcode(SidusControl sidusControl) {
        if (this.profile == Profile.LUMIN) {
            return 11437760;
        }
        if (this.profile == Profile.JINBEI) {
            return 24010;
        }
        return sidusControl == null ? GODOX_OPCODE : sidusControl.opcode;
    }

    private boolean validControlPayload(SidusControl sidusControl, byte[] bArr) {
        if (this.profile == Profile.LUMIN) {
            return LuminMeshProtocol.validSet(bArr);
        }
        if (this.profile == Profile.JINBEI) {
            return JinbeiMeshProtocol.validSet(bArr);
        }
        if (sidusControl != null) {
            return sidusControl.validPayload.test(bArr);
        }
        if (bArr.length != 8) {
            return false;
        }
        int i = bArr[0] & FUDistributor.UPDATE_TTL;
        if (i != 240 && i != 241 && i != 254) {
            return false;
        }
        if ((bArr[1] & FUDistributor.UPDATE_TTL) > (i == 254 ? (char) 1 : 'd')) {
            return false;
        }
        int i2 = 0;
        for (int i3 = 0; i3 < bArr.length - 1; i3++) {
            i2 ^= bArr[i3] & FUDistributor.UPDATE_TTL;
            for (int i4 = 0; i4 < 8; i4++) {
                i2 = (i2 >>> 1) ^ ((i2 & 1) == 0 ? 0 : CipherSuite.TLS_PSK_WITH_AES_128_CBC_SHA);
            }
        }
        return i2 == (bArr[bArr.length - 1] & FUDistributor.UPDATE_TTL);
    }

    private static boolean validSidusPayload(byte[] bArr) {
        if (bArr.length != 10) {
            return false;
        }
        int i = bArr[9] & FUDistributor.UPDATE_TTL;
        if (i == 140 || i == 143 || i == 130 || i == 129) {
            return validSidusChecksum(bArr);
        }
        return false;
    }

    private static boolean validSidusChecksum(byte[] bArr) {
        int i = 0;
        for (int i2 = 1; i2 < bArr.length; i2++) {
            i += bArr[i2] & FUDistributor.UPDATE_TTL;
        }
        return (i & 255) == (bArr[0] & FUDistributor.UPDATE_TTL);
    }

    void disconnect(String str) {
        cancelScan();
        if (this.operation != null) {
            failOperation("Cancelled", "已结束" + this.profile.label + "连接操作。");
        }
        this.activeProject = "";
        this.activeTargets.clear();
        this.loggedIn = false;
        this.sendFailures = 0;
        cancelSends();
        if (this.configuration != null) {
            this.mesh.idle(true);
        }
        this.deliver.accept(str, LightingBluetoothBridge.json("ok", true));
    }

    void cancelScan() {
        MeshScan meshScan = this.scan;
        if (meshScan != null) {
            finishScan(meshScan, LightingBluetoothBridge.json("cancelled", true));
        }
    }

    void close() {
        this.closed = true;
        MeshScan meshScan = this.scan;
        if (meshScan != null) {
            finishScan(meshScan, LightingBluetoothBridge.json("cancelled", true));
        }
        this.handler.removeCallbacks(this.operationTimeout);
        this.handler.removeCallbacks(this.sendNext);
        if (this.configuration != null) {
            this.mesh.clear();
        }
    }

    private boolean validProject(String str, String str2) {
        if (str2 != null && !str2.isEmpty() && str2.length() <= 128 && !str2.contains("\u2028") && !str2.contains("\u2029")) {
            return true;
        }
        this.deliver.accept(str, LightingBluetoothBridge.error("InvalidProject", "当前工程标识无效。"));
        return false;
    }

    private void initialize() {
        if (this.configuration != null) {
            return;
        }
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
        byte[] bArrLoadOrCreateKey = loadOrCreateKey("netKey");
        byte[] bArrLoadOrCreateKey2 = loadOrCreateKey("appKey");
        MeshConfiguration meshConfiguration = new MeshConfiguration();
        meshConfiguration.networkKey = bArrLoadOrCreateKey;
        meshConfiguration.netKeyIndex = 0;
        meshConfiguration.appKeyMap = new SparseArray<>();
        meshConfiguration.appKeyMap.put(0, bArrLoadOrCreateKey2);
        meshConfiguration.ivIndex = this.store.getInt("ivIndex", this.profile.initialIvIndex);
        meshConfiguration.sequenceNumber = this.store.getInt("sequence", 0);
        meshConfiguration.localAddress = 1;
        meshConfiguration.proxyFilterWhiteList = new int[]{1, 65535};
        meshConfiguration.deviceKeyMap = new SparseArray<>();
        loadNodes();
        for (Node node : this.nodes.values()) {
            meshConfiguration.deviceKeyMap.put(node.unicast, node.deviceKey);
        }
        this.networkId = Encipher.k3(bArrLoadOrCreateKey);
        this.identityKey = Encipher.generateIdentityKey(bArrLoadOrCreateKey);
        MeshLogger.enablePrint(false);
        MeshLogger.enableRecord(false);
        this.mesh.init(this.context, new EventHandler() { // from class: com.pianchang.lighting.FixtureMeshTransport$$ExternalSyntheticLambda0
            @Override // com.telink.ble.mesh.foundation.EventHandler
            public final void onEventHandle(Event event) {
                FixtureMeshTransport.$r8$lambda$7O27M9R0dneeWsjEGLoV7YLrQss(this.f$0, event);
            }
        }, this.profile != Profile.GODOX);
        this.mesh.setupMeshNetwork(meshConfiguration);
        this.configuration = meshConfiguration;
    }

    private byte[] loadOrCreateKey(String str) {
        String string = this.store.getString(str, "");
        if (string != null && string.matches("[0-9A-Fa-f]{32}")) {
            return fromHex(string);
        }
        if (string != null && !string.isEmpty()) {
            throw new IllegalStateException("Invalid Mesh key storage");
        }
        byte[] bArr = new byte[16];
        new SecureRandom().nextBytes(bArr);
        if (this.store.edit().putString(str, toHex(bArr)).commit()) {
            return bArr;
        }
        throw new IllegalStateException("Mesh key storage failed");
    }

    private void loadNodes() {
        for (Map.Entry<String, ?> entry : this.store.getAll().entrySet()) {
            if (entry.getKey().startsWith("node:") && (entry.getValue() instanceof String)) {
                try {
                    Node node = new Node(new JSONObject((String) entry.getValue()));
                    this.nodes.put(node.uuid, node);
                } catch (IllegalArgumentException | JSONException unused) {
                }
            }
        }
    }

    private boolean saveNode(Node node) throws JSONException {
        JSONObject jSONObjectBinding = node.binding();
        try {
            jSONObjectBinding.put("deviceKey", toHex(node.deviceKey));
            jSONObjectBinding.put("bound", node.bound);
            if (node.elementCount > 0) {
                jSONObjectBinding.put("elementCount", node.elementCount);
            }
            if (node.controlAddress != node.unicast) {
                jSONObjectBinding.put("controlAddress", node.controlAddress);
            }
            if (!this.store.edit().putString("node:" + node.uuid, jSONObjectBinding.toString()).commit()) {
                return false;
            }
            Node nodePut = this.nodes.put(node.uuid, node);
            if (nodePut == null || nodePut.unicast == node.unicast) {
                return true;
            }
            this.activeTargets.remove(Integer.valueOf(nodePut.unicast));
            this.mesh.removeDevice(nodePut.unicast);
            return true;
        } catch (JSONException e) {
            throw new IllegalArgumentException(e);
        }
    }

    private void receiveEvent(final Event<String> event) {
        if (event instanceof NetworkInfoUpdateEvent) {
            NetworkInfoUpdateEvent networkInfoUpdateEvent = (NetworkInfoUpdateEvent) event;
            this.store.edit().putInt("sequence", networkInfoUpdateEvent.getSequenceNumber()).putInt("ivIndex", networkInfoUpdateEvent.getIvIndex()).commit();
        } else {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.FixtureMeshTransport$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() throws JSONException {
                    this.f$0.m8xc6353ca7(event);
                }
            });
        }
    }

    /* renamed from: lambda$receiveEvent$1$com-pianchang-lighting-FixtureMeshTransport, reason: not valid java name */
    /* synthetic */ void m8xc6353ca7(Event event) throws JSONException {
        handleEvent(event);
    }

    private void handleEvent(Event<String> event) throws JSONException {
        Operation operation;
        Operation operation2;
        Operation operation3;
        Operation operation4;
        Operation operation5;
        if (this.closed) {
            return;
        }
        String type = event.getType();
        if (MeshEvent.EVENT_TYPE_DISCONNECTED.equals(type)) {
            invalidateProxy();
            return;
        }
        if (AutoConnectEvent.EVENT_TYPE_AUTO_CONNECT_LOGIN.equals(type)) {
            boolean zIsProxyLogin = this.mesh.isProxyLogin();
            this.loggedIn = zIsProxyLogin;
            if (zIsProxyLogin && (operation5 = this.operation) != null && operation5.phase == Phase.CONNECTING) {
                proxyReady(this.operation);
                return;
            }
            return;
        }
        if (AutoConnectEvent.EVENT_TYPE_AUTO_CONNECT_FAIL.equals(type) && (operation4 = this.operation) != null && operation4.phase == Phase.CONNECTING && !this.mesh.isProxyLogin()) {
            failOperation("ProxyFailed", "无法建立" + this.profile.label + " Mesh 代理连接，请保持至少一盏同网络灯具开机后重试。");
            return;
        }
        if ((event instanceof ProvisioningEvent) && (operation3 = this.operation) != null && operation3.phase == Phase.PROVISIONING) {
            handleProvisioning((ProvisioningEvent) event);
            return;
        }
        if ((event instanceof BindingEvent) && (operation2 = this.operation) != null && operation2.phase == Phase.BINDING) {
            handleBinding((BindingEvent) event);
            return;
        }
        if ((event instanceof StatusNotificationEvent) && (operation = this.operation) != null && operation.phase == Phase.READING_CONTROL_STATUS) {
            NotificationMessage notificationMessage = ((StatusNotificationEvent) event).getNotificationMessage();
            Node node = this.operation.node;
            if (this.loggedIn && this.mesh.isProxyLogin()) {
                if (this.profile == Profile.LUMIN || this.profile == Profile.JINBEI) {
                    if (notificationMessage == null || node == null || notificationMessage.getDst() != 1) {
                        return;
                    }
                    int src = notificationMessage.getSrc();
                    if (src == node.controlAddress || (this.profile == Profile.JINBEI && src == node.unicast)) {
                        int iStatusProduct = this.profile == Profile.LUMIN ? LuminMeshProtocol.statusProduct(notificationMessage.getOpcode(), notificationMessage.getParams()) : JinbeiMeshProtocol.statusProduct(notificationMessage.getOpcode(), notificationMessage.getParams());
                        if (iStatusProduct < 0) {
                            return;
                        }
                        node.radioId = Integer.toString(iStatusProduct);
                        if (this.profile == Profile.JINBEI && !JinbeiMeshProtocol.isKnownProduct(iStatusProduct)) {
                            node.bound = false;
                            saveNode(node);
                            failOperation("UnsupportedDevice", "收到的型号未确认为金贝 LED 常亮灯。");
                            return;
                        }
                        if (this.operation.requiresJinbeiStatus) {
                            node.bound = true;
                            if (!saveNode(node)) {
                                node.bound = false;
                                failOperation("Storage", "无法保存金贝灯具的控灯配置。");
                                return;
                            }
                        } else {
                            saveNode(node);
                        }
                        this.operation.controlReadback = "confirmed";
                        finishProxy();
                        return;
                    }
                    return;
                }
                if (isSidusControlReadback(notificationMessage, node)) {
                    this.operation.controlReadback = "confirmed";
                    finishProxy();
                }
            }
        }
    }

    private void handleProvisioning(ProvisioningEvent provisioningEvent) throws JSONException {
        int i;
        Operation operation = this.operation;
        ProvisioningDevice provisioningDevice = provisioningEvent.getProvisioningDevice();
        if (provisioningDevice != operation.provisioningDevice) {
            return;
        }
        String type = provisioningEvent.getType();
        if (ProvisioningEvent.EVENT_TYPE_CAPABILITY_RECEIVED.equals(type)) {
            int i2 = provisioningDevice.getDeviceCapability().eleNum & FUDistributor.UPDATE_TTL;
            int i3 = this.store.getInt("nextAddress", 2);
            if (i2 < 1 || i3 < 2 || (i = i3 + i2) > 32768 || !this.store.edit().putInt("nextAddress", i).commit()) {
                failOperation("Address", "无法为" + this.profile.label + "灯具分配 Mesh 地址。");
                return;
            }
            if (!this.mesh.continueProvision(i3)) {
                failOperation("ProvisionFailed", "无法继续" + this.profile.label + "灯具入网。");
                return;
            }
            operation.elementCount = i2;
            return;
        }
        if (ProvisioningEvent.EVENT_TYPE_PROVISION_SUCCESS.equals(type)) {
            operation.node = new Node(operation.candidate, provisioningDevice.getUnicastAddress(), provisioningDevice.getDeviceKey(), operation.elementCount);
            if (saveNode(operation.node)) {
                if (this.profile != Profile.GODOX) {
                    operation.candidate.node = operation.node;
                }
                startBinding(operation);
                return;
            } else {
                failOperation("Storage", "无法保存" + this.profile.label + "灯具的入网记录。");
                return;
            }
        }
        if (ProvisioningEvent.EVENT_TYPE_PROVISION_FAIL.equals(type)) {
            failOperation("ProvisionFailed", this.profile.label + "灯具入网失败，请确认灯具处于可配网状态后重新搜索。");
        }
    }

    private void startBinding(final Operation operation) throws JSONException {
        invalidateProxy();
        setPhase(operation, Phase.BINDING, BIND_TIME);
        try {
            BindingDevice bindingDevice = new BindingDevice(operation.node.unicast, fromHex(operation.node.uuid), 0);
            if (this.profile == Profile.SIDUS) {
                bindingDevice.setBearer((operation.bindingRetried || operation.candidate.device == null) ? BindingBearer.Any : BindingBearer.Flex);
                bindingDevice.setRequireConfirmedBinding(true);
                bindingDevice.setModelSelector(new Function() { // from class: com.pianchang.lighting.FixtureMeshTransport$$ExternalSyntheticLambda4
                    @Override // java.util.function.Function
                    public final Object apply(Object obj) {
                        return FixtureMeshTransport.lambda$startBinding$2(operation, (CompositionData) obj);
                    }
                });
            } else if (this.profile == Profile.LUMIN) {
                bindingDevice.setBearer(BindingBearer.Flex);
                bindingDevice.setRequireConfirmedBinding(true);
                bindingDevice.setModelSelector(new Function() { // from class: com.pianchang.lighting.FixtureMeshTransport$$ExternalSyntheticLambda5
                    @Override // java.util.function.Function
                    public final Object apply(Object obj) {
                        return LuminMeshProtocol.select((CompositionData) obj);
                    }
                });
            } else if (this.profile == Profile.JINBEI) {
                bindingDevice.setBearer(BindingBearer.Flex);
                bindingDevice.setRequireConfirmedBinding(true);
                bindingDevice.setModelSelector(new Function() { // from class: com.pianchang.lighting.FixtureMeshTransport$$ExternalSyntheticLambda6
                    @Override // java.util.function.Function
                    public final Object apply(Object obj) {
                        return this.f$0.m9xd3dd66f5(operation, (CompositionData) obj);
                    }
                });
            } else {
                bindingDevice.setModels(new int[]{GODOX_SERVER_MODEL});
            }
            operation.bindingDevice = bindingDevice;
            this.mesh.startBinding(new BindingParameters(bindingDevice));
        } catch (RuntimeException unused) {
            failOperation("BindFailed", this.profile.label + "灯具的应用密钥绑定失败，请重新搜索后重试。");
        }
    }

    static /* synthetic */ List lambda$startBinding$2(Operation operation, CompositionData compositionData) {
        return SidusControl.select(compositionData, operation.node);
    }

    /* renamed from: lambda$startBinding$3$com-pianchang-lighting-FixtureMeshTransport, reason: not valid java name */
    /* synthetic */ List m9xd3dd66f5(Operation operation, CompositionData compositionData) {
        return jinbeiControlTargets(compositionData, operation.node);
    }

    private void handleBinding(BindingEvent bindingEvent) throws JSONException {
        int iGodoxControlElement;
        Operation operation = this.operation;
        if (bindingEvent.getBindingDevice() != operation.bindingDevice) {
            return;
        }
        if (BindingEvent.EVENT_TYPE_BIND_SUCCESS.equals(bindingEvent.getType())) {
            CompositionData compositionData = bindingEvent.getBindingDevice().getCompositionData();
            if (this.profile == Profile.SIDUS) {
                List<BindingDevice.ModelTarget> listSelect = SidusControl.select(compositionData, operation.node);
                iGodoxControlElement = listSelect.isEmpty() ? -1 : listSelect.get(0).elementOffset;
                if (iGodoxControlElement >= 0) {
                    operation.node.controlProfile = SidusControl.forTarget(listSelect.get(0)).id;
                }
            } else if (this.profile == Profile.LUMIN) {
                List<BindingDevice.ModelTarget> listSelect2 = LuminMeshProtocol.select(compositionData);
                iGodoxControlElement = listSelect2.isEmpty() ? -1 : listSelect2.get(0).elementOffset;
                if (iGodoxControlElement >= 0) {
                    operation.node.controlProfile = "lumin-ae86";
                }
            } else if (this.profile == Profile.JINBEI) {
                List<BindingDevice.ModelTarget> listJinbeiControlTargets = jinbeiControlTargets(compositionData, operation.node);
                iGodoxControlElement = listJinbeiControlTargets.isEmpty() ? -1 : listJinbeiControlTargets.get(0).elementOffset;
                if (iGodoxControlElement >= 0) {
                    operation.node.controlProfile = "jinbei-sig";
                    operation.requiresJinbeiStatus = JinbeiMeshProtocol.needsReadback(listJinbeiControlTargets);
                }
            } else {
                iGodoxControlElement = godoxControlElement(compositionData);
            }
            if (iGodoxControlElement < 0) {
                failOperation("UnsupportedModel", "这款" + this.profile.label + "设备没有片场灯光台支持的灯光控制模型。");
                return;
            }
            operation.node.controlAddress = operation.node.unicast + iGodoxControlElement;
            operation.node.bound = !operation.requiresJinbeiStatus;
            if (saveNode(operation.node)) {
                startProxy(operation);
                return;
            }
            operation.node.bound = false;
            failOperation("Storage", "无法保存" + this.profile.label + "灯具的密钥绑定记录。");
            return;
        }
        if (BindingEvent.EVENT_TYPE_BIND_FAIL.equals(bindingEvent.getType())) {
            if (this.profile == Profile.SIDUS) {
                handleSidusBindingFailure(operation, bindingEvent.getDesc());
                return;
            }
            if (this.profile != Profile.GODOX && "no target models found".equals(bindingEvent.getDesc())) {
                failOperation("UnsupportedModel", "这盏" + this.profile.label + "灯具已入网，但未发现支持的灯光控制模型。");
                return;
            }
            failOperation("BindFailed", this.profile.label + "灯具已入网，应用密钥绑定失败。请保持灯具开机，重新搜索后重试。");
        }
    }

    private void handleSidusBindingFailure(final Operation operation, String str) throws JSONException {
        if (str == null) {
            str = "";
        }
        str.hashCode();
        switch (str) {
            case "invalid composition data":
            case "unexpected composition data page":
                failOperation("BindCompositionInvalid", "爱图仕灯具已入网，但返回的 Mesh 模型数据无法解析。请复制诊断。");
                break;
            case "device not found when scanning":
                if (!operation.bindingRetried) {
                    operation.bindingRetried = true;
                    operation.bindingDevice = null;
                    this.handler.postDelayed(new Runnable() { // from class: com.pianchang.lighting.FixtureMeshTransport$$ExternalSyntheticLambda7
                        @Override // java.lang.Runnable
                        public final void run() throws JSONException {
                            this.f$0.m7xf3fce762(operation);
                        }
                    }, SIDUS_BIND_RETRY_DELAY);
                    break;
                } else {
                    failOperation("BindProxyNotFound", "爱图仕灯具已入网，重试后仍未找到同一 Mesh 网络的代理。请保持灯具开机，靠近后重新搜索。");
                    break;
                }
            case "proxy scan failed":
            case "connection interrupt":
            case "connect fail":
                failOperation("BindProxyFailed", "爱图仕灯具已入网，但绑定时未能维持 Mesh 代理连接。请检查蓝牙并重新搜索。");
                break;
            case "no target models found":
            case "no models in composition data":
                CompositionData compositionData = operation.bindingDevice.getCompositionData();
                if (compositionData != null && compositionData.elements != null && operation.node.elementCount > 0 && compositionData.elements.size() != operation.node.elementCount) {
                    failOperation("BindCompositionIncomplete", "爱图仕灯具已入网，但返回的 Mesh 元素数量与入网时声明的不一致。请复制诊断。");
                    break;
                } else {
                    failOperation("UnsupportedModel", "爱图仕灯具已入网，但返回的控制模型中没有片场灯光台支持的模型。");
                    break;
                }
                break;
            case "app key confirmation missing":
                failOperation("BindAppKeyUnconfirmed", "爱图仕灯具已入网，但未收到应用密钥写入确认。请保持灯具开机后重试。");
                break;
            case "composition response missing":
                failOperation("BindCompositionFailed", "爱图仕灯具已入网，但未收到灯具的控制模型数据。请保持灯具开机后重试。");
                break;
            case "model binding confirmation missing":
                failOperation("BindModelUnconfirmed", "爱图仕灯具已入网，但未收到控制模型的密钥绑定确认。请保持灯具开机后重试。");
                break;
            case "model selection failed":
            case "selected model not found in composition data":
                failOperation("BindModelSelectionFailed", "爱图仕灯具已入网，但无法确认控灯模型的绑定地址。请复制诊断。");
                break;
            case "proxy candidates exhausted":
                failOperation("BindProxyFailed", "爱图仕灯具已入网，但可用的同网代理均未连接成功。请保持灯具开机后继续配置。");
                break;
            default:
                if (str.startsWith("app key rejected: ")) {
                    failOperation("BindAppKeyRejected", "爱图仕灯具已入网，但灯具拒绝写入应用密钥（状态码 " + str.substring(18) + "）。");
                    break;
                } else if (str.startsWith("model binding rejected: ")) {
                    failOperation("BindModelRejected", "爱图仕灯具已入网，但灯具拒绝为控制模型绑定应用密钥（状态码 " + str.substring(24) + "）。");
                    break;
                } else {
                    failOperation("BindFailed", "爱图仕灯具已入网，但应用密钥绑定未完成。请保持灯具开机，重新搜索后重试。");
                    break;
                }
        }
    }

    /* renamed from: lambda$handleSidusBindingFailure$4$com-pianchang-lighting-FixtureMeshTransport, reason: not valid java name */
    /* synthetic */ void m7xf3fce762(Operation operation) throws JSONException {
        if (!this.closed && this.operation == operation && operation.phase == Phase.BINDING) {
            startBinding(operation);
        }
    }

    private int godoxControlElement(CompositionData compositionData) {
        List<Integer> list;
        return (compositionData == null || compositionData.elements == null || compositionData.elements.isEmpty() || (list = compositionData.elements.get(0).vendorModels) == null || !list.contains(Integer.valueOf(GODOX_SERVER_MODEL))) ? -1 : 0;
    }

    private List<BindingDevice.ModelTarget> jinbeiControlTargets(CompositionData compositionData, Node node) {
        if (compositionData == null || compositionData.elements == null) {
            return Collections.emptyList();
        }
        int size = compositionData.elements.size();
        if (size > 255 || node.unicast + size > 32768 || (node.elementCount > 0 && size != node.elementCount)) {
            return Collections.emptyList();
        }
        return JinbeiMeshProtocol.select(compositionData);
    }

    private void startProxy(Operation operation) throws JSONException {
        try {
            setPhase(operation, Phase.CONNECTING, CONNECT_TIME);
            if (this.mesh.isProxyLogin()) {
                this.loggedIn = true;
                this.mesh.autoConnect(new AutoConnectParameters());
                if (this.operation == operation && operation.phase == Phase.CONNECTING) {
                    proxyReady(operation);
                }
            } else {
                this.mesh.autoConnect(new AutoConnectParameters());
            }
        } catch (RuntimeException unused) {
            failOperation("ProxyFailed", "无法建立" + this.profile.label + " Mesh 代理连接，请检查已入网的灯具。");
        }
    }

    private void proxyReady(Operation operation) throws JSONException {
        Node node = operation.node;
        SidusControl sidusControlSaved = (this.profile != Profile.SIDUS || node == null) ? null : SidusControl.saved(node.controlProfile);
        if (sidusControlSaved != null || (node != null && (this.profile == Profile.LUMIN || this.profile == Profile.JINBEI))) {
            setPhase(operation, Phase.READING_CONTROL_STATUS, this.profile == Profile.JINBEI ? JINBEI_READBACK_TIME : CONTROL_READBACK_TIME);
            MeshMessage meshMessage = new MeshMessage();
            if (sidusControlSaved != null) {
                byte[] bArr = new byte[10];
                bArr[9] = 14;
                bArr[0] = 14;
                meshMessage.setOpcode(sidusControlSaved.opcode);
                meshMessage.setParams(bArr);
            } else if (this.profile == Profile.LUMIN) {
                meshMessage.setOpcode(11437760);
                meshMessage.setParams(LuminMeshProtocol.statusRequest());
            } else {
                meshMessage.setOpcode(24010);
                meshMessage.setParams(JinbeiMeshProtocol.statusRequest());
            }
            meshMessage.setDestinationAddress(node.controlAddress);
            meshMessage.setAppKeyIndex(0);
            meshMessage.setRetryCnt(0);
            try {
                if (this.mesh.sendMeshMessage(meshMessage)) {
                    return;
                }
            } catch (RuntimeException unused) {
            }
            if (operation.requiresJinbeiStatus) {
                failOperation("ControlUnconfirmed", "已入网，但没有发出验证金贝控灯协议的指令。请重新搜索并继续配置。");
                return;
            }
            operation.controlReadback = "not-sent";
        }
        finishProxy();
    }

    private static boolean isSidusControlReadback(NotificationMessage notificationMessage, Node node) {
        byte[] params;
        SidusControl sidusControlSaved = SidusControl.saved(node.controlProfile);
        if (sidusControlSaved == null || notificationMessage == null || notificationMessage.getSrc() != node.controlAddress || notificationMessage.getDst() != 1 || notificationMessage.getOpcode() != sidusControlSaved.opcode || (params = notificationMessage.getParams()) == null || params.length != 10 || !validSidusChecksum(params)) {
            return false;
        }
        int i = params[9] & 127;
        return i == 1 || i == 2;
    }

    private void finishProxy() {
        Operation operation = this.operation;
        this.operation = null;
        this.handler.removeCallbacks(this.operationTimeout);
        if (operation.node != null) {
            this.activeTargets.put(Integer.valueOf(operation.node.unicast), operation.node);
            this.candidates.remove(operation.node.uuid);
            this.deliver.accept(operation.id, LightingBluetoothBridge.json("ok", true, "connected", true, "binding", operation.node.binding(), "controlReadback", operation.controlReadback));
            return;
        }
        this.deliver.accept(operation.id, LightingBluetoothBridge.json("ok", true, "connected", true, "unavailable", operation.unavailable));
    }

    private void setPhase(Operation operation, Phase phase, long j) {
        operation.phase = phase;
        this.handler.removeCallbacks(this.operationTimeout);
        this.handler.postDelayed(this.operationTimeout, j);
        if (this.profile != Profile.SIDUS || operation.candidate == null) {
            return;
        }
        this.addProgress.accept(operation.id, LightingBluetoothBridge.json("deviceId", operation.candidate.uuid, "stage", phase == Phase.READING_CONTROL_STATUS ? "reading" : phase.name().toLowerCase(Locale.ROOT)));
    }

    private void timeOutOperation() throws JSONException {
        Operation operation = this.operation;
        if (operation == null) {
            return;
        }
        if (operation.phase == Phase.PROVISIONING) {
            failOperation("ProvisionFailed", this.profile.label + "灯具入网超时，请保持灯具开机并重新搜索。");
            return;
        }
        if (this.operation.phase == Phase.BINDING) {
            failOperation("BindFailed", this.profile.label + "灯具绑定超时，请保持灯具开机并重新搜索。");
            return;
        }
        if (this.operation.phase == Phase.READING_CONTROL_STATUS && this.loggedIn && this.mesh.isProxyLogin()) {
            if (this.operation.requiresJinbeiStatus) {
                failOperation("ControlUnconfirmed", "已入网，但替代模型未返回可识别的金贝常亮灯状态。请保持灯具开机后继续配置。");
                return;
            } else {
                this.operation.controlReadback = "no-reply";
                finishProxy();
                return;
            }
        }
        failOperation("ProxyFailed", this.profile.label + " Mesh 代理连接超时，请保持一盏已入网的灯具开机。");
    }

    private void failOperation(String str, String str2) throws JSONException {
        Operation operation = this.operation;
        if (operation == null) {
            return;
        }
        this.operation = null;
        this.handler.removeCallbacks(this.operationTimeout);
        if (this.configuration != null) {
            this.mesh.idle(true);
        }
        invalidateProxy();
        boolean zEquals = "Cancelled".equals(str);
        JSONObject jSONObjectError = zEquals ? LightingBluetoothBridge.error(str, str2) : profileError(str, str2);
        if (!zEquals && this.profile != Profile.GODOX && operation.candidate != null) {
            if (this.profile == Profile.SIDUS) {
                addSidusDiagnostic(jSONObjectError, operation, str);
            }
            try {
                jSONObjectError.put("setupState", operation.candidate.setupState());
            } catch (JSONException unused) {
            }
        }
        this.deliver.accept(operation.id, jSONObjectError);
    }

    private static String diagnosticStage(Phase phase, String str) {
        if (phase == Phase.PROVISIONING) {
            return "provisioning";
        }
        if (phase == Phase.CONNECTING) {
            return "connecting";
        }
        if (phase == Phase.READING_CONTROL_STATUS) {
            return "control-readback";
        }
        if (str.startsWith("BindProxy")) {
            return "proxy";
        }
        if (str.startsWith("BindComposition")) {
            return "composition";
        }
        if (str.equals("UnsupportedModel") || str.equals("BindModelSelectionFailed")) {
            return "model-selection";
        }
        return str.startsWith("BindAppKey") ? "application-key" : str.startsWith("BindModel") ? "model-binding" : "binding";
    }

    private static void addSidusDiagnostic(JSONObject jSONObject, Operation operation, String str) throws JSONException {
        try {
            jSONObject.put("diagnostic", sidusDiagnostic(operation, str));
        } catch (JSONException unused) {
        }
    }

    private static JSONObject sidusDiagnostic(Operation operation, String str) throws JSONException {
        String str2;
        JSONObject jSONObjectJson = LightingBluetoothBridge.json("name", operation.candidate.name, "productCode", operation.candidate.radioId, "stage", diagnosticStage(operation.phase, str), "failure", "Sidus" + str, "retriedProxy", Boolean.valueOf(operation.bindingRetried));
        Node node = operation.node;
        int i = node == null ? operation.elementCount : node.elementCount;
        if (i > 0) {
            jSONObjectJson.put("expectedElements", i);
        }
        if (node != null) {
            jSONObjectJson.put("primaryAddress", meshHex(node.unicast, 4));
        }
        BindingDevice bindingDevice = operation.bindingDevice;
        if (bindingDevice == null) {
            return jSONObjectJson;
        }
        int receivedCompositionPage = bindingDevice.getReceivedCompositionPage();
        if (receivedCompositionPage >= 0) {
            jSONObjectJson.put("page", meshHex(receivedCompositionPage, 2));
        }
        CompositionData compositionData = bindingDevice.getCompositionData();
        if (compositionData == null || compositionData.elements == null || node == null) {
            if (receivedCompositionPage == 0) {
                str2 = "Page 0 解析失败";
            } else if (receivedCompositionPage > 0) {
                str2 = "灯具返回其他页";
            } else {
                str2 = str.equals("BindCompositionInvalid") ? "模型回复缺少页码" : "未收到模型数据";
            }
            jSONObjectJson.put("parseStatus", str2);
            return jSONObjectJson;
        }
        int size = compositionData.elements.size();
        jSONObjectJson.put("parseStatus", (i <= 0 || size == i) ? "已解析 Page 0" : "元素数量不一致");
        jSONObjectJson.put("companyId", meshHex(compositionData.cid, 4));
        jSONObjectJson.put("meshProductId", meshHex(compositionData.pid, 4));
        int i2 = compositionData.vid;
        if (compositionData.raw != null && compositionData.raw.length >= 6) {
            i2 = (compositionData.raw[4] & FUDistributor.UPDATE_TTL) | ((compositionData.raw[5] & FUDistributor.UPDATE_TTL) << 8);
        }
        jSONObjectJson.put("versionId", meshHex(i2, 4));
        jSONObjectJson.put("receivedElements", size);
        JSONArray jSONArray = new JSONArray();
        for (int i3 = 0; i3 < size; i3++) {
            Element element = compositionData.elements.get(i3);
            jSONArray.put(LightingBluetoothBridge.json("address", meshHex(node.unicast + i3, 4), "sigModels", meshModelIds(element.sigModels, 4), "vendorModels", meshModelIds(element.vendorModels, 8)));
        }
        jSONObjectJson.put("elements", jSONArray);
        List<BindingDevice.ModelTarget> listSelect = SidusControl.select(compositionData, node);
        if (!listSelect.isEmpty()) {
            BindingDevice.ModelTarget modelTarget = listSelect.get(0);
            jSONObjectJson.put("controlProfile", SidusControl.forTarget(modelTarget).id);
            jSONObjectJson.put("selectedModel", meshHex(modelTarget.modelId, 8));
            jSONObjectJson.put("targetAddress", meshHex(node.unicast + modelTarget.elementOffset, 4));
        }
        return jSONObjectJson;
    }

    private static JSONArray meshModelIds(List<Integer> list, int i) {
        JSONArray jSONArray = new JSONArray();
        if (list != null) {
            Iterator<Integer> it = list.iterator();
            while (it.hasNext()) {
                jSONArray.put(meshHex(it.next().intValue(), i));
            }
        }
        return jSONArray;
    }

    private static String meshHex(int i, int i2) {
        return String.format(Locale.ROOT, "0x%0" + i2 + "X", Integer.valueOf(i));
    }

    private void invalidateProxy() {
        this.sendFailures = 0;
        if (this.loggedIn) {
            this.loggedIn = false;
            cancelSends();
            if (this.activeProject.isEmpty()) {
                return;
            }
            this.linkLost.accept(this.activeProject);
        }
    }

    private void cancelSends() {
        this.handler.removeCallbacks(this.sendNext);
        this.sending = false;
        while (!this.sendQueue.isEmpty()) {
            this.deliver.accept(this.sendQueue.remove().id, profileError("Disconnected", this.profile.label + " Mesh 控制连接已断开。"));
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x0094, code lost:
    
        if (r0 >= 2) goto L23;
     */
    /* JADX WARN: Removed duplicated region for block: B:16:0x005c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void flushSendQueue() {
        /*
            r6 = this;
            java.util.ArrayDeque<com.pianchang.lighting.FixtureMeshTransport$SendJob> r0 = r6.sendQueue
            java.lang.Object r0 = r0.peek()
            com.pianchang.lighting.FixtureMeshTransport$SendJob r0 = (com.pianchang.lighting.FixtureMeshTransport.SendJob) r0
            r1 = 0
            if (r0 != 0) goto Le
            r6.sending = r1
            return
        Le:
            r2 = 1
            r6.sending = r2
            boolean r3 = r6.loggedIn     // Catch: java.lang.RuntimeException -> L5c
            if (r3 == 0) goto L5c
            com.telink.ble.mesh.foundation.MeshService r3 = r6.mesh     // Catch: java.lang.RuntimeException -> L5c
            boolean r3 = r3.isProxyLogin()     // Catch: java.lang.RuntimeException -> L5c
            if (r3 == 0) goto L5c
            com.telink.ble.mesh.foundation.MeshService r3 = r6.mesh     // Catch: java.lang.RuntimeException -> L5c
            java.util.List<com.telink.ble.mesh.core.message.MeshMessage> r4 = r0.messages     // Catch: java.lang.RuntimeException -> L5c
            int r5 = r0.position     // Catch: java.lang.RuntimeException -> L5c
            java.lang.Object r4 = r4.get(r5)     // Catch: java.lang.RuntimeException -> L5c
            com.telink.ble.mesh.core.message.MeshMessage r4 = (com.telink.ble.mesh.core.message.MeshMessage) r4     // Catch: java.lang.RuntimeException -> L5c
            boolean r3 = r3.sendMeshMessage(r4)     // Catch: java.lang.RuntimeException -> L5c
            if (r3 == 0) goto L5c
            r6.sendFailures = r1
            int r1 = r0.position
            int r1 = r1 + r2
            r0.position = r1
            java.util.List<com.telink.ble.mesh.core.message.MeshMessage> r0 = r0.messages
            int r0 = r0.size()
            if (r1 != r0) goto L97
            java.util.function.BiConsumer<java.lang.String, org.json.JSONObject> r0 = r6.deliver
            java.util.ArrayDeque<com.pianchang.lighting.FixtureMeshTransport$SendJob> r1 = r6.sendQueue
            java.lang.Object r1 = r1.remove()
            com.pianchang.lighting.FixtureMeshTransport$SendJob r1 = (com.pianchang.lighting.FixtureMeshTransport.SendJob) r1
            java.lang.String r1 = r1.id
            java.lang.String r3 = "ok"
            java.lang.Boolean r2 = java.lang.Boolean.valueOf(r2)
            java.lang.Object[] r2 = new java.lang.Object[]{r3, r2}
            org.json.JSONObject r2 = com.pianchang.lighting.LightingBluetoothBridge.json(r2)
            r0.accept(r1, r2)
            goto L97
        L5c:
            java.util.function.BiConsumer<java.lang.String, org.json.JSONObject> r0 = r6.deliver
            java.util.ArrayDeque<com.pianchang.lighting.FixtureMeshTransport$SendJob> r1 = r6.sendQueue
            java.lang.Object r1 = r1.remove()
            com.pianchang.lighting.FixtureMeshTransport$SendJob r1 = (com.pianchang.lighting.FixtureMeshTransport.SendJob) r1
            java.lang.String r1 = r1.id
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            com.pianchang.lighting.FixtureMeshTransport$Profile r4 = r6.profile
            java.lang.String r4 = r4.label
            r3.append(r4)
            java.lang.String r4 = " Mesh 指令未发出，请检查代理连接。"
            r3.append(r4)
            java.lang.String r3 = r3.toString()
            java.lang.String r4 = "SendFailed"
            org.json.JSONObject r3 = r6.profileError(r4, r3)
            r0.accept(r1, r3)
            com.telink.ble.mesh.foundation.MeshService r0 = r6.mesh
            boolean r0 = r0.isProxyLogin()
            if (r0 == 0) goto La1
            int r0 = r6.sendFailures
            int r0 = r0 + r2
            r6.sendFailures = r0
            r1 = 2
            if (r0 < r1) goto L97
            goto La1
        L97:
            android.os.Handler r0 = r6.handler
            java.lang.Runnable r1 = r6.sendNext
            r2 = 80
            r0.postDelayed(r1, r2)
            return
        La1:
            r6.invalidateProxy()
            com.telink.ble.mesh.foundation.MeshService r0 = r6.mesh     // Catch: java.lang.RuntimeException -> La9
            r0.idle(r2)     // Catch: java.lang.RuntimeException -> La9
        La9:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.pianchang.lighting.FixtureMeshTransport.flushSendQueue():void");
    }

    private void finishScan(MeshScan meshScan, JSONObject jSONObject) {
        if (this.scan != meshScan) {
            return;
        }
        this.scan = null;
        MeshScan.access$200(meshScan);
        this.handler.removeCallbacks(meshScan.selectionTimeout);
        if (meshScan.dialog != null) {
            meshScan.dialog.dismiss();
        }
        this.candidates.keySet().retainAll(meshScan.confirmed);
        if (this.closed) {
            return;
        }
        this.deliver.accept(meshScan.id, jSONObject);
    }

    private Candidate identifyGodox(ScanResult scanResult) {
        ScanRecord scanRecord = scanResult.getScanRecord();
        if (scanRecord == null || !scanResult.isConnectable()) {
            return null;
        }
        BluetoothDevice device = scanResult.getDevice();
        String strUpper = upper(device.getAddress());
        byte[] serviceData = scanRecord.getServiceData(PROVISIONING_SERVICE);
        String deviceName = scanRecord.getDeviceName();
        String radioId = "GD_LED".equals(deviceName) ? readRadioId(scanRecord) : null;
        if (serviceData != null && serviceData.length >= 18 && radioId != null) {
            return new Candidate(device, strUpper, toHex(Arrays.copyOf(serviceData, 16)), deviceName, radioId, scanResult.getRssi(), (serviceData[16] & FUDistributor.UPDATE_TTL) | ((serviceData[17] & FUDistributor.UPDATE_TTL) << 8), null);
        }
        Node nodeIdentifyProxy = identifyProxy(scanRecord.getServiceData(PROXY_SERVICE), strUpper);
        if (nodeIdentifyProxy == null) {
            return null;
        }
        return new Candidate(device, strUpper, nodeIdentifyProxy.uuid, nodeIdentifyProxy.name, nodeIdentifyProxy.radioId, scanResult.getRssi(), 0, nodeIdentifyProxy);
    }

    private static String readRadioId(ScanRecord scanRecord) {
        byte[] bytes = scanRecord.getBytes();
        String hex = "";
        int i = 0;
        while (bytes != null && i < bytes.length) {
            int i2 = bytes[i] & FUDistributor.UPDATE_TTL;
            if (i2 == 0 || i + i2 >= bytes.length) {
                break;
            }
            if ((bytes[i + 1] & FUDistributor.UPDATE_TTL) == 255) {
                if (i2 <= 10) {
                    hex = "";
                } else {
                    hex = toHex(new byte[]{bytes[i + 9], bytes[i + 8]});
                }
            }
            i += i2 + 1;
        }
        return hex;
    }

    private Node identifyProxy(byte[] bArr, String str) {
        byte[] bArrGeneratePrivateNodeIdentityHash;
        if (bArr != null && bArr.length >= 9 && !this.nodes.isEmpty()) {
            int i = bArr[0] & FUDistributor.UPDATE_TTL;
            byte[] bArrCopyOfRange = Arrays.copyOfRange(bArr, 1, 9);
            byte[] bArrCopyOfRange2 = bArr.length >= 17 ? Arrays.copyOfRange(bArr, 9, 17) : null;
            if (i != 1 && i != 3) {
                if (i == 0 && !Arrays.equals(bArrCopyOfRange, this.networkId)) {
                    return null;
                }
                if (i == 2 && (bArrCopyOfRange2 == null || !matchesPrivateNetwork(bArrCopyOfRange, bArrCopyOfRange2))) {
                    return null;
                }
                if (i != 0 && i != 2) {
                    return null;
                }
                for (Node node : this.nodes.values()) {
                    if (node.address.equals(str)) {
                        return node;
                    }
                }
                return null;
            }
            if (bArrCopyOfRange2 == null) {
                return null;
            }
            for (Node node2 : this.nodes.values()) {
                if (i == 1) {
                    bArrGeneratePrivateNodeIdentityHash = Encipher.generateNodeIdentityHash(this.identityKey, bArrCopyOfRange2, node2.unicast);
                } else {
                    bArrGeneratePrivateNodeIdentityHash = Encipher.generatePrivateNodeIdentityHash(this.identityKey, bArrCopyOfRange2, node2.unicast);
                }
                if (Arrays.equals(bArrCopyOfRange, bArrGeneratePrivateNodeIdentityHash)) {
                    return node2;
                }
            }
        }
        return null;
    }

    private boolean matchesPrivateNetwork(byte[] bArr, byte[] bArr2) {
        byte[] bArrAes = Encipher.aes(ByteBuffer.allocate(16).put(this.networkId).put(bArr2).array(), this.identityKey);
        return bArrAes != null && bArrAes.length == 16 && Arrays.equals(bArr, Arrays.copyOfRange(bArrAes, 8, 16));
    }

    /* JADX INFO: Access modifiers changed from: private */
    final class MeshScan {
        int advertisements;
        AlertDialog dialog;
        final Set<String> exclusions;
        boolean extendedScan;
        final String id;
        boolean legacyFallback;
        final ArrayAdapter<Candidate> rows;
        boolean sawExcluded;
        boolean sawJinbeiLegacy;
        ScanCallback scanCallback;
        final BluetoothLeScanner scanner;
        String sidusScanError;
        final TextView status;
        final Set<String> checked = new LinkedHashSet();
        final Set<String> confirmed = new HashSet();
        final Map<String, SidusAdvertisement.Observation> observed = new LinkedHashMap();
        final Map<String, NamedProvisioningObservation> namedObserved = new LinkedHashMap();
        final Set<String> legacyAddresses = new HashSet();
        final Map<String, String> acceptedAddresses = new LinkedHashMap();
        final Runnable scanTimeout = new Runnable() { // from class: com.pianchang.lighting.FixtureMeshTransport$MeshScan$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                FixtureMeshTransport.MeshScan.m10$r8$lambda$TroVLfTQ9EIMqAxeXgliRJFh5s(this.f$0);
            }
        };
        final Runnable selectionTimeout = new Runnable() { // from class: com.pianchang.lighting.FixtureMeshTransport$MeshScan$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m11x687775f9();
            }
        };

        /* renamed from: $r8$lambda$TroVLfT-Q9EIMqAxeXgliRJFh5s, reason: not valid java name */
        public static /* synthetic */ void m10$r8$lambda$TroVLfTQ9EIMqAxeXgliRJFh5s(MeshScan meshScan) {
            meshScan.finishDiscovery();
        }

        static /* synthetic */ void access$100(MeshScan meshScan, String str) {
            meshScan.discoveryFailed(str);
        }

        static /* synthetic */ void access$200(MeshScan meshScan) {
            meshScan.stop();
        }

        static /* synthetic */ void access$600(MeshScan meshScan) {
            meshScan.useLegacyFallback();
        }

        static /* synthetic */ void access$700(MeshScan meshScan, ScanResult scanResult) {
            meshScan.collect(scanResult);
        }

        /* renamed from: lambda$new$0$com-pianchang-lighting-FixtureMeshTransport$MeshScan, reason: not valid java name */
        /* synthetic */ void m11x687775f9() {
            FixtureMeshTransport.access$900(FixtureMeshTransport.this, this, LightingBluetoothBridge.json("cancelled", true));
        }

        MeshScan(String str, BluetoothLeScanner bluetoothLeScanner, Set<String> set) {
            this.id = str;
            this.scanner = bluetoothLeScanner;
            this.exclusions = set;
            this.rows = new ArrayAdapter<>(FixtureMeshTransport.access$300(FixtureMeshTransport.this), android.R.layout.simple_list_item_multiple_choice);
            this.status = new TextView(FixtureMeshTransport.access$300(FixtureMeshTransport.this));
        }

        void open() {
            int iDp = dp(20);
            LinearLayout linearLayout = new LinearLayout(FixtureMeshTransport.access$300(FixtureMeshTransport.this));
            linearLayout.setOrientation(1);
            linearLayout.setPadding(iDp, dp(12), iDp, 0);
            this.status.setText("正在搜索附近灯具…");
            linearLayout.addView(this.status);
            final ListView listView = new ListView(FixtureMeshTransport.access$300(FixtureMeshTransport.this));
            listView.setChoiceMode(2);
            listView.setAdapter((ListAdapter) this.rows);
            listView.setContentDescription(FixtureMeshTransport.access$400(FixtureMeshTransport.this).label + "蓝牙灯具");
            linearLayout.addView(listView, new LinearLayout.LayoutParams(-1, dp(220)));
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.pianchang.lighting.FixtureMeshTransport$MeshScan$$ExternalSyntheticLambda2
                @Override // android.widget.AdapterView.OnItemClickListener
                public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
                    this.f$0.m12xeb308254(listView, adapterView, view, i, j);
                }
            });
            AlertDialog alertDialogCreate = new AlertDialog.Builder(FixtureMeshTransport.access$300(FixtureMeshTransport.this)).setTitle("搜索" + FixtureMeshTransport.access$400(FixtureMeshTransport.this).label + "灯具").setView(linearLayout).setNegativeButton("取消", new DialogInterface.OnClickListener() { // from class: com.pianchang.lighting.FixtureMeshTransport$MeshScan$$ExternalSyntheticLambda3
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m13x54c00f3(dialogInterface, i);
                }
            }).setPositiveButton("确认选择", new DialogInterface.OnClickListener() { // from class: com.pianchang.lighting.FixtureMeshTransport$MeshScan$$ExternalSyntheticLambda4
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) throws JSONException {
                    this.f$0.m14x1f677f92(dialogInterface, i);
                }
            }).create();
            this.dialog = alertDialogCreate;
            alertDialogCreate.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.pianchang.lighting.FixtureMeshTransport$MeshScan$$ExternalSyntheticLambda5
                @Override // android.content.DialogInterface.OnDismissListener
                public final void onDismiss(DialogInterface dialogInterface) {
                    this.f$0.m15x3982fe31(dialogInterface);
                }
            });
            this.dialog.show();
            updateSelection();
        }

        /* renamed from: lambda$open$1$com-pianchang-lighting-FixtureMeshTransport$MeshScan, reason: not valid java name */
        /* synthetic */ void m12xeb308254(ListView listView, AdapterView adapterView, View view, int i, long j) {
            String str = this.rows.getItem(i).uuid;
            if (listView.isItemChecked(i)) {
                this.checked.add(str);
            } else {
                this.checked.remove(str);
            }
            updateSelection();
        }

        /* renamed from: lambda$open$2$com-pianchang-lighting-FixtureMeshTransport$MeshScan, reason: not valid java name */
        /* synthetic */ void m13x54c00f3(DialogInterface dialogInterface, int i) {
            FixtureMeshTransport.access$900(FixtureMeshTransport.this, this, LightingBluetoothBridge.json("cancelled", true));
        }

        /* renamed from: lambda$open$3$com-pianchang-lighting-FixtureMeshTransport$MeshScan, reason: not valid java name */
        /* synthetic */ void m14x1f677f92(DialogInterface dialogInterface, int i) throws JSONException {
            confirm();
        }

        /* renamed from: lambda$open$4$com-pianchang-lighting-FixtureMeshTransport$MeshScan, reason: not valid java name */
        /* synthetic */ void m15x3982fe31(DialogInterface dialogInterface) {
            FixtureMeshTransport.access$900(FixtureMeshTransport.this, this, LightingBluetoothBridge.json("cancelled", true));
        }

        /* renamed from: com.pianchang.lighting.FixtureMeshTransport$MeshScan$1, reason: invalid class name */
        class AnonymousClass1 extends ScanCallback {
            final /* synthetic */ boolean val$extended;

            AnonymousClass1(boolean z) {
                this.val$extended = z;
            }

            @Override // android.bluetooth.le.ScanCallback
            public void onScanResult(int i, final ScanResult scanResult) {
                FixtureMeshTransport.access$500(FixtureMeshTransport.this).post(new Runnable() { // from class: com.pianchang.lighting.FixtureMeshTransport$MeshScan$1$$ExternalSyntheticLambda2
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m18x3f51f0f3(scanResult);
                    }
                });
            }

            /* renamed from: lambda$onScanResult$0$com-pianchang-lighting-FixtureMeshTransport$MeshScan$1, reason: not valid java name */
            /* synthetic */ void m18x3f51f0f3(ScanResult scanResult) {
                if (MeshScan.this.scanCallback == this) {
                    MeshScan.access$700(MeshScan.this, scanResult);
                }
            }

            @Override // android.bluetooth.le.ScanCallback
            public void onBatchScanResults(final List<ScanResult> list) {
                FixtureMeshTransport.access$500(FixtureMeshTransport.this).post(new Runnable() { // from class: com.pianchang.lighting.FixtureMeshTransport$MeshScan$1$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m16x728d324d(list);
                    }
                });
            }

            /* renamed from: lambda$onBatchScanResults$1$com-pianchang-lighting-FixtureMeshTransport$MeshScan$1, reason: not valid java name */
            /* synthetic */ void m16x728d324d(List list) {
                if (MeshScan.this.scanCallback == this) {
                    Iterator it = list.iterator();
                    while (it.hasNext()) {
                        MeshScan.access$700(MeshScan.this, (ScanResult) it.next());
                    }
                }
            }

            @Override // android.bluetooth.le.ScanCallback
            public void onScanFailed(final int i) {
                Handler handlerAccess$500 = FixtureMeshTransport.access$500(FixtureMeshTransport.this);
                final boolean z = this.val$extended;
                handlerAccess$500.post(new Runnable() { // from class: com.pianchang.lighting.FixtureMeshTransport$MeshScan$1$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m17xc3862e91(z, i);
                    }
                });
            }

            /* renamed from: lambda$onScanFailed$2$com-pianchang-lighting-FixtureMeshTransport$MeshScan$1, reason: not valid java name */
            /* synthetic */ void m17xc3862e91(boolean z, int i) {
                if (MeshScan.this.scanCallback != this) {
                    return;
                }
                if (z && i == 4) {
                    try {
                        MeshScan.access$600(MeshScan.this);
                    } catch (RuntimeException unused) {
                        MeshScan.access$100(MeshScan.this, "安卓蓝牙搜索无法启动，请稍后重试。");
                    }
                } else {
                    MeshScan.access$100(MeshScan.this, "安卓蓝牙搜索失败（" + i + "），请稍后重试。");
                }
            }
        }

        void start(boolean z) {
            this.extendedScan = z;
            AnonymousClass1 anonymousClass1 = new AnonymousClass1(z);
            this.scanCallback = anonymousClass1;
            ScanSettings.Builder scanMode = new ScanSettings.Builder().setScanMode(2);
            if (z) {
                scanMode.setLegacy(false).setPhy(255);
            }
            try {
                this.scanner.startScan((List<ScanFilter>) null, scanMode.build(), anonymousClass1);
                FixtureMeshTransport.access$500(FixtureMeshTransport.this).postDelayed(this.scanTimeout, FixtureMeshTransport.SCAN_TIME);
            } catch (IllegalArgumentException | UnsupportedOperationException e) {
                if (!z) {
                    throw e;
                }
                useLegacyFallback();
            }
        }

        private void useLegacyFallback() {
            stop();
            this.legacyFallback = true;
            start(false);
        }

        private int dp(int i) {
            return Math.round(i * FixtureMeshTransport.access$300(FixtureMeshTransport.this).getResources().getDisplayMetrics().density);
        }

        private void updateSelection() {
            String str;
            Button button = this.dialog.getButton(-1);
            button.setEnabled(!this.checked.isEmpty());
            if (this.checked.isEmpty()) {
                str = "确认选择";
            } else {
                str = "确认选择（" + this.checked.size() + "）";
            }
            button.setText(str);
        }

        private void confirm() throws JSONException {
            JSONArray jSONArray = new JSONArray();
            for (String str : this.checked) {
                Candidate candidate = (Candidate) FixtureMeshTransport.access$800(FixtureMeshTransport.this).get(str);
                if (candidate != null) {
                    jSONArray.put(candidate.descriptor());
                    this.confirmed.add(str);
                }
            }
            JSONObject jSONObjectJson = LightingBluetoothBridge.json("ok", true, "devices", jSONArray, "preselected", true);
            if (FixtureMeshTransport.access$400(FixtureMeshTransport.this) == Profile.SIDUS) {
                jSONObjectJson = LightingBluetoothBridge.json("ok", true, "devices", jSONArray, "preselected", true, "alreadyAdded", Boolean.valueOf(this.sawExcluded), "scanError", this.sidusScanError);
            }
            FixtureMeshTransport.access$900(FixtureMeshTransport.this, this, withDiagnostics(jSONObjectJson));
        }

        private void finishDiscovery() {
            JSONObject jSONObjectAccess$1100;
            if (FixtureMeshTransport.access$1000(FixtureMeshTransport.this) != this) {
                return;
            }
            if (FixtureMeshTransport.access$400(FixtureMeshTransport.this) == Profile.SIDUS) {
                finishSidusDiscovery(null);
                return;
            }
            stop();
            if (FixtureMeshTransport.access$800(FixtureMeshTransport.this).isEmpty()) {
                if (this.sawExcluded) {
                    jSONObjectAccess$1100 = LightingBluetoothBridge.error("AlreadyAdded", "附近可识别的灯具都已添加到当前工程。");
                } else {
                    jSONObjectAccess$1100 = this.sawJinbeiLegacy ? FixtureMeshTransport.access$1100(FixtureMeshTransport.this, "PairlinkOnly", "附近发现了旧版 Pairlink Mesh 金贝灯具。当前支持可配网的 SIG Mesh 常亮灯。") : LightingBluetoothBridge.json("ok", true, "devices", new JSONArray());
                }
                FixtureMeshTransport.access$900(FixtureMeshTransport.this, this, jSONObjectAccess$1100);
                return;
            }
            this.status.setText("请勾选需要添加的灯具");
            FixtureMeshTransport.access$500(FixtureMeshTransport.this).postDelayed(this.selectionTimeout, FixtureMeshTransport.SELECTION_TIME);
        }

        private void discoveryFailed(String str) {
            if (FixtureMeshTransport.access$400(FixtureMeshTransport.this) == Profile.SIDUS) {
                finishSidusDiscovery(str);
            } else {
                FixtureMeshTransport.access$900(FixtureMeshTransport.this, this, LightingBluetoothBridge.error("ScanFailed", str));
            }
        }

        private void finishSidusDiscovery(String str) {
            AlertDialog alertDialog;
            if (FixtureMeshTransport.access$1000(FixtureMeshTransport.this) != this) {
                return;
            }
            stop();
            this.sidusScanError = str;
            for (Node node : FixtureMeshTransport.access$1200(FixtureMeshTransport.this).values()) {
                if (excludes(node.uuid, node.address)) {
                    this.sawExcluded = true;
                } else if (!this.acceptedAddresses.containsKey(node.address)) {
                    Candidate candidate = new Candidate(null, node.address, node.uuid, node.name, node.radioId, 0, 0, node, node.modelUnknown, node.displayId);
                    if (FixtureMeshTransport.access$800(FixtureMeshTransport.this).putIfAbsent(node.uuid, candidate) == null) {
                        this.acceptedAddresses.put(candidate.address, candidate.uuid);
                        this.rows.add(candidate);
                    }
                }
            }
            if (!FixtureMeshTransport.access$800(FixtureMeshTransport.this).isEmpty() && (alertDialog = this.dialog) != null && alertDialog.isShowing()) {
                this.status.setText(str == null ? "请勾选需要添加的灯具" : str + "\n可选择已列出的灯具。");
                FixtureMeshTransport.access$500(FixtureMeshTransport.this).postDelayed(this.selectionTimeout, FixtureMeshTransport.SELECTION_TIME);
                return;
            }
            JSONArray jSONArray = new JSONArray();
            for (Candidate candidate2 : FixtureMeshTransport.access$800(FixtureMeshTransport.this).values()) {
                jSONArray.put(candidate2.descriptor());
                this.confirmed.add(candidate2.uuid);
            }
            FixtureMeshTransport.access$900(FixtureMeshTransport.this, this, withDiagnostics(LightingBluetoothBridge.json("ok", true, "devices", jSONArray, "preselected", false, "alreadyAdded", Boolean.valueOf(this.sawExcluded), "scanError", str)));
        }

        private void stop() {
            FixtureMeshTransport.access$500(FixtureMeshTransport.this).removeCallbacks(this.scanTimeout);
            ScanCallback scanCallback = this.scanCallback;
            this.scanCallback = null;
            if (scanCallback == null) {
                return;
            }
            try {
                this.scanner.stopScan(scanCallback);
            } catch (RuntimeException unused) {
            }
        }

        private void collect(ScanResult scanResult) {
            Candidate candidateIdentifyNamedFixture;
            String str;
            if (FixtureMeshTransport.access$1000(FixtureMeshTransport.this) != this || scanResult == null) {
                return;
            }
            try {
                if (FixtureMeshTransport.access$400(FixtureMeshTransport.this) == Profile.SIDUS) {
                    candidateIdentifyNamedFixture = identifySidus(scanResult);
                } else {
                    candidateIdentifyNamedFixture = FixtureMeshTransport.access$400(FixtureMeshTransport.this) != Profile.GODOX ? identifyNamedFixture(scanResult) : FixtureMeshTransport.access$1300(FixtureMeshTransport.this, scanResult);
                }
                if (candidateIdentifyNamedFixture == null) {
                    return;
                }
                if (excludes(candidateIdentifyNamedFixture.uuid, candidateIdentifyNamedFixture.address)) {
                    this.sawExcluded = true;
                    return;
                }
                if (FixtureMeshTransport.access$400(FixtureMeshTransport.this) != Profile.JINBEI || (str = this.acceptedAddresses.get(candidateIdentifyNamedFixture.address)) == null || str.equals(candidateIdentifyNamedFixture.uuid)) {
                    Candidate candidate = (Candidate) FixtureMeshTransport.access$800(FixtureMeshTransport.this).get(candidateIdentifyNamedFixture.uuid);
                    if (candidate == null) {
                        FixtureMeshTransport.access$800(FixtureMeshTransport.this).put(candidateIdentifyNamedFixture.uuid, candidateIdentifyNamedFixture);
                        if (FixtureMeshTransport.access$400(FixtureMeshTransport.this) == Profile.SIDUS || FixtureMeshTransport.access$400(FixtureMeshTransport.this) == Profile.JINBEI) {
                            this.acceptedAddresses.put(candidateIdentifyNamedFixture.address, candidateIdentifyNamedFixture.uuid);
                        }
                        if (this.dialog != null) {
                            this.rows.add(candidateIdentifyNamedFixture);
                            this.status.setText("已找到 " + FixtureMeshTransport.access$800(FixtureMeshTransport.this).size() + " 盏灯具");
                            return;
                        }
                        return;
                    }
                    if (FixtureMeshTransport.access$400(FixtureMeshTransport.this) == Profile.SIDUS) {
                        if (candidate.node != null && candidateIdentifyNamedFixture.node == null) {
                            this.acceptedAddresses.remove(candidate.address, candidate.uuid);
                            candidate.address = candidateIdentifyNamedFixture.address;
                            candidate.device = candidateIdentifyNamedFixture.device;
                            candidate.rssi = candidateIdentifyNamedFixture.rssi;
                            candidate.oobInfo = candidateIdentifyNamedFixture.oobInfo;
                            candidate.node = null;
                            candidate.updateIdentity(candidateIdentifyNamedFixture);
                            this.acceptedAddresses.put(candidate.address, candidate.uuid);
                            this.rows.notifyDataSetChanged();
                            return;
                        }
                        if (candidate.address.equals(candidateIdentifyNamedFixture.address) && candidate.modelUnknown && !candidateIdentifyNamedFixture.modelUnknown) {
                            candidate.updateIdentity(candidateIdentifyNamedFixture);
                            if (this.dialog != null) {
                                this.rows.notifyDataSetChanged();
                                return;
                            }
                            return;
                        }
                        return;
                    }
                    if (FixtureMeshTransport.access$400(FixtureMeshTransport.this) == Profile.GODOX || !candidate.address.equals(candidateIdentifyNamedFixture.address)) {
                        return;
                    }
                    if (candidate.node != null && candidateIdentifyNamedFixture.node == null) {
                        candidate.node = null;
                        candidate.device = candidateIdentifyNamedFixture.device;
                        candidate.oobInfo = candidateIdentifyNamedFixture.oobInfo;
                        candidate.updateIdentity(candidateIdentifyNamedFixture);
                        this.rows.notifyDataSetChanged();
                        return;
                    }
                    if (!candidate.modelUnknown || candidateIdentifyNamedFixture.modelUnknown) {
                        return;
                    }
                    candidate.updateIdentity(candidateIdentifyNamedFixture);
                    this.rows.notifyDataSetChanged();
                }
            } catch (RuntimeException unused) {
            }
        }

        private boolean excludes(String str, String str2) {
            return this.exclusions.contains(str) || this.exclusions.contains(str2);
        }

        private Candidate identifyNamedFixture(ScanResult scanResult) {
            Node nodeAccess$1600;
            ScanRecord scanRecord = scanResult.getScanRecord();
            BluetoothDevice device = scanResult.getDevice();
            if (scanRecord == null || device == null) {
                return null;
            }
            String strAccess$1400 = FixtureMeshTransport.access$1400(device.getAddress());
            if (strAccess$1400.isEmpty()) {
                return null;
            }
            if (scanResult.isConnectable() && (nodeAccess$1600 = FixtureMeshTransport.access$1600(FixtureMeshTransport.this, scanRecord.getServiceData(FixtureMeshTransport.access$1500()), strAccess$1400)) != null) {
                return new Candidate(device, strAccess$1400, nodeAccess$1600.uuid, nodeAccess$1600.name, nodeAccess$1600.radioId, scanResult.getRssi(), 0, nodeAccess$1600, nodeAccess$1600.modelUnknown, nodeAccess$1600.displayId);
            }
            String strRecognizedName = recognizedName(scanRecord.getDeviceName());
            if (strRecognizedName == null) {
                strRecognizedName = recognizedName(device.getName());
            }
            byte[] serviceData = scanRecord.getServiceData(FixtureMeshTransport.access$1700());
            if (FixtureMeshTransport.access$400(FixtureMeshTransport.this) == Profile.JINBEI) {
                byte[] manufacturerSpecificData = scanRecord.getManufacturerSpecificData(65535);
                if (manufacturerSpecificData != null && manufacturerSpecificData.length >= 3 && (manufacturerSpecificData[0] & FUDistributor.UPDATE_TTL) == 192 && (manufacturerSpecificData[1] & FUDistributor.UPDATE_TTL) == 255 && manufacturerSpecificData[2] == 9) {
                    if (this.legacyAddresses.size() < 512) {
                        this.legacyAddresses.add(strAccess$1400);
                    }
                    if (strRecognizedName != null || (this.namedObserved.containsKey(strAccess$1400) && this.namedObserved.get(strAccess$1400).name != null)) {
                        this.sawJinbeiLegacy = true;
                    }
                    return null;
                }
                if (this.legacyAddresses.contains(strAccess$1400)) {
                    if (strRecognizedName != null) {
                        this.sawJinbeiLegacy = true;
                    }
                    return null;
                }
                serviceData = JinbeiMeshProtocol.provisioningData(serviceData, scanRecord.getBytes());
            } else if (!SidusAdvertisement.validProvisioningData(serviceData)) {
                serviceData = SidusAdvertisement.provisioningBeacon(scanRecord.getBytes());
            }
            NamedProvisioningObservation namedProvisioningObservation = this.namedObserved.get(strAccess$1400);
            if (namedProvisioningObservation == null) {
                if ((strRecognizedName == null && serviceData == null) || this.namedObserved.size() >= 512) {
                    return null;
                }
                namedProvisioningObservation = new NamedProvisioningObservation(null);
                this.namedObserved.put(strAccess$1400, namedProvisioningObservation);
            }
            if (strRecognizedName != null && (namedProvisioningObservation.name == null || knownModel(strRecognizedName))) {
                namedProvisioningObservation.name = strRecognizedName;
            }
            if (serviceData != null && scanResult.isConnectable()) {
                namedProvisioningObservation.provisioning = serviceData;
                namedProvisioningObservation.device = device;
            }
            if (namedProvisioningObservation.name == null || namedProvisioningObservation.provisioning == null) {
                return null;
            }
            byte[] bArr = namedProvisioningObservation.provisioning;
            return new Candidate(namedProvisioningObservation.device, strAccess$1400, FixtureMeshTransport.access$1900(Arrays.copyOf(bArr, 16)), namedProvisioningObservation.name, "", scanResult.getRssi(), ((bArr[16] & FUDistributor.UPDATE_TTL) << 8) | (bArr[17] & FUDistributor.UPDATE_TTL), null, !knownModel(namedProvisioningObservation.name), strAccess$1400.replace(":", "").substring(Math.max(0, r2.length() - 6)));
        }

        private String recognizedName(String str) {
            return FixtureMeshTransport.access$400(FixtureMeshTransport.this) == Profile.JINBEI ? JinbeiMeshProtocol.recognizedName(str) : LuminMeshProtocol.recognizedName(str);
        }

        private boolean knownModel(String str) {
            return FixtureMeshTransport.access$400(FixtureMeshTransport.this) == Profile.JINBEI || LuminMeshProtocol.hasKnownModel(str);
        }

        private Candidate identifySidus(ScanResult scanResult) {
            SidusAdvertisement.Identity identity;
            this.advertisements++;
            ScanRecord scanRecord = scanResult.getScanRecord();
            BluetoothDevice device = scanResult.getDevice();
            if (scanRecord != null && device != null) {
                String strAccess$1400 = FixtureMeshTransport.access$1400(device.getAddress());
                if (strAccess$1400.isEmpty()) {
                    return null;
                }
                String str = this.acceptedAddresses.get(strAccess$1400);
                Candidate candidate = str == null ? null : (Candidate) FixtureMeshTransport.access$800(FixtureMeshTransport.this).get(str);
                if (candidate != null && candidate.node == null && !candidate.modelUnknown) {
                    return null;
                }
                List<ParcelUuid> serviceUuids = scanRecord.getServiceUuids();
                byte[] serviceData = scanRecord.getServiceData(FixtureMeshTransport.access$1700());
                byte[] serviceData2 = scanRecord.getServiceData(FixtureMeshTransport.access$1500());
                Node nodeAccess$1600 = scanResult.isConnectable() ? FixtureMeshTransport.access$1600(FixtureMeshTransport.this, serviceData2, strAccess$1400) : null;
                if (nodeAccess$1600 != null && candidate == null) {
                    return new Candidate(device, strAccess$1400, nodeAccess$1600.uuid, nodeAccess$1600.name, nodeAccess$1600.radioId, scanResult.getRssi(), 0, nodeAccess$1600, nodeAccess$1600.modelUnknown, nodeAccess$1600.displayId);
                }
                byte[] bArrProvisioningBeacon = SidusAdvertisement.provisioningBeacon(scanRecord.getBytes());
                if (!this.observed.containsKey(strAccess$1400) && this.observed.size() >= 512) {
                    return null;
                }
                SidusAdvertisement.Observation observationComputeIfAbsent = this.observed.computeIfAbsent(strAccess$1400, new Function() { // from class: com.pianchang.lighting.FixtureMeshTransport$MeshScan$$ExternalSyntheticLambda6
                    @Override // java.util.function.Function
                    public final Object apply(Object obj) {
                        return FixtureMeshTransport.MeshScan.lambda$identifySidus$5((String) obj);
                    }
                });
                observationComputeIfAbsent.update(scanRecord.getDeviceName(), device.getName(), scanResult.isConnectable(), serviceUuids != null && serviceUuids.contains(FixtureMeshTransport.access$1700()), serviceData2 != null || (serviceUuids != null && serviceUuids.contains(FixtureMeshTransport.access$1500())), serviceData, bArrProvisioningBeacon);
                byte[] bArrProvisioningData = observationComputeIfAbsent.provisioningData();
                if (bArrProvisioningData == null || !observationComputeIfAbsent.canConnect() || (identity = observationComputeIfAbsent.identity(strAccess$1400)) == null) {
                    return null;
                }
                String strAccess$1900 = FixtureMeshTransport.access$1900(Arrays.copyOf(bArrProvisioningData, 16));
                if (str == null || str.equals(strAccess$1900)) {
                    return new Candidate(device, strAccess$1400, strAccess$1900, identity.model, identity.radioId, scanResult.getRssi(), ((bArrProvisioningData[16] & FUDistributor.UPDATE_TTL) << 8) | (bArrProvisioningData[17] & FUDistributor.UPDATE_TTL), null, identity.modelUnknown, identity.displayId);
                }
                return null;
            }
            return null;
        }

        static /* synthetic */ SidusAdvertisement.Observation lambda$identifySidus$5(String str) {
            return new SidusAdvertisement.Observation();
        }

        private JSONObject withDiagnostics(JSONObject jSONObject) {
            if (FixtureMeshTransport.access$400(FixtureMeshTransport.this) != Profile.SIDUS) {
                return jSONObject;
            }
            int i = 0;
            int i2 = 0;
            int i3 = 0;
            int i4 = 0;
            int i5 = 0;
            int i6 = 0;
            for (Map.Entry<String, SidusAdvertisement.Observation> entry : this.observed.entrySet()) {
                SidusAdvertisement.Observation value = entry.getValue();
                SidusAdvertisement.Identity identity = value.identity(entry.getKey());
                if (!value.hasProvisioningSignal()) {
                    if (value.hasProxySignal()) {
                        i6++;
                    }
                    if (identity != null) {
                        i2++;
                    }
                } else {
                    i++;
                    if (!value.canConnect()) {
                        i5++;
                    }
                    if (value.provisioningData() == null) {
                        i2++;
                    }
                    if (identity == null) {
                        i4++;
                    } else if (identity.modelUnknown) {
                        i3++;
                    }
                }
            }
            try {
                return jSONObject.put("diagnostics", LightingBluetoothBridge.json("advertisements", Integer.valueOf(this.advertisements), "meshCandidates", Integer.valueOf(i), "missingProvisioningData", Integer.valueOf(i2), "unknownModels", Integer.valueOf(i3), "unidentifiedMesh", Integer.valueOf(i4), "nonConnectable", Integer.valueOf(i5), "proxyOnly", Integer.valueOf(i6), "extendedScan", Boolean.valueOf(this.extendedScan), "legacyFallback", Boolean.valueOf(this.legacyFallback)));
            } catch (JSONException unused) {
                return jSONObject;
            }
        }
    }

    private static final class NamedProvisioningObservation {
        BluetoothDevice device;
        String name;
        byte[] provisioning;

        private NamedProvisioningObservation() {
        }

        /* synthetic */ NamedProvisioningObservation(AnonymousClass1 anonymousClass1) {
            this();
        }
    }

    private static final class Candidate {
        String address;
        BluetoothDevice device;
        String displayId;
        boolean modelUnknown;
        String name;
        Node node;
        int oobInfo;
        String radioId;
        int rssi;
        final String uuid;

        Candidate(BluetoothDevice bluetoothDevice, String str, String str2, String str3, String str4, int i, int i2, Node node) {
            this(bluetoothDevice, str, str2, str3, str4, i, i2, node, false, "");
        }

        Candidate(BluetoothDevice bluetoothDevice, String str, String str2, String str3, String str4, int i, int i2, Node node, boolean z, String str5) {
            this.device = bluetoothDevice;
            this.address = str;
            this.uuid = str2;
            this.name = str3.trim();
            this.radioId = str4;
            this.rssi = i;
            this.oobInfo = i2;
            this.node = node;
            this.modelUnknown = z;
            this.displayId = str5;
        }

        void updateIdentity(Candidate candidate) {
            this.name = candidate.name;
            this.radioId = candidate.radioId;
            this.modelUnknown = candidate.modelUnknown;
            this.displayId = candidate.displayId;
        }

        JSONObject descriptor() {
            String str = this.address;
            String str2 = this.uuid;
            String str3 = this.name;
            String str4 = this.radioId;
            Integer numValueOf = this.device == null ? null : Integer.valueOf(this.rssi);
            Node node = this.node;
            return LightingBluetoothBridge.json("address", str, "uuid", str2, "name", str3, "model", str3, "radioId", str4, "rssi", numValueOf, "paired", Boolean.valueOf(node != null && node.bound), "setupState", setupState(), "modelUnknown", Boolean.valueOf(this.modelUnknown), "displayId", this.displayId);
        }

        String setupState() {
            Node node = this.node;
            return node == null ? "new" : node.bound ? "bound" : "pending";
        }

        public String toString() {
            String str;
            String str2 = (this.name.isEmpty() || "GD_LED".equals(this.name)) ? "神牛蓝牙灯具" : this.name;
            if (!this.radioId.isEmpty() && "GD_LED".equals(this.name)) {
                str2 = str2 + " · 型号 " + this.radioId;
            }
            if (this.device == null) {
                str = "本机配置记录";
            } else {
                str = this.rssi + " dBm";
            }
            StringBuilder sb = new StringBuilder();
            sb.append(str2);
            sb.append("\n");
            sb.append(this.displayId.isEmpty() ? this.address : this.displayId);
            sb.append(" · ");
            sb.append(str);
            sb.append("pending".equals(setupState()) ? " · 待配置" : "");
            return sb.toString();
        }
    }

    private static final class Node {
        final String address;
        boolean bound;
        int controlAddress;
        String controlProfile;
        final byte[] deviceKey;
        final String displayId;
        final int elementCount;
        final boolean modelUnknown;
        final String name;
        String radioId;
        final int unicast;
        final String uuid;

        Node(Candidate candidate, int i, byte[] bArr, int i2) {
            this.controlProfile = "";
            this.uuid = candidate.uuid;
            this.address = candidate.address;
            this.name = candidate.name;
            this.radioId = candidate.radioId;
            this.modelUnknown = candidate.modelUnknown;
            this.displayId = candidate.displayId;
            this.unicast = i;
            this.deviceKey = bArr;
            this.elementCount = i2;
            this.controlAddress = i;
        }

        Node(JSONObject jSONObject) throws JSONException {
            int i;
            this.controlProfile = "";
            String string = jSONObject.getString("uuid");
            this.uuid = string;
            this.address = jSONObject.getString("address");
            this.name = jSONObject.getString("name");
            this.radioId = jSONObject.optString("radioId");
            this.modelUnknown = jSONObject.optBoolean("modelUnknown");
            this.displayId = jSONObject.optString("displayId");
            int i2 = jSONObject.getInt("unicast");
            this.unicast = i2;
            byte[] bArrAccess$2000 = FixtureMeshTransport.access$2000(jSONObject.getString("deviceKey"));
            this.deviceKey = bArrAccess$2000;
            this.bound = jSONObject.optBoolean("bound");
            this.controlAddress = jSONObject.optInt("controlAddress", i2);
            this.controlProfile = jSONObject.optString("controlProfile");
            int iOptInt = jSONObject.optInt("elementCount");
            this.elementCount = iOptInt;
            if (!string.matches("[0-9A-F]{32}") || i2 <= 1 || i2 > 32767 || (i = this.controlAddress) < i2 || i > 32767 || iOptInt < 0 || iOptInt > 255 || i2 + iOptInt > 32768 || bArrAccess$2000.length != 16) {
                throw new JSONException("Invalid mesh node");
            }
        }

        JSONObject binding() {
            String str = this.uuid;
            String str2 = this.address;
            String str3 = this.name;
            return LightingBluetoothBridge.json("uuid", str, "address", str2, "name", str3, "model", str3, "radioId", this.radioId, "unicast", Integer.valueOf(this.unicast), "modelUnknown", Boolean.valueOf(this.modelUnknown), "displayId", this.displayId, "controlProfile", this.controlProfile.isEmpty() ? null : this.controlProfile);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    static final class Operation {
        BindingDevice bindingDevice;
        boolean bindingRetried;
        final Candidate candidate;
        String controlReadback;
        int elementCount;
        final String id;
        Node node;
        Phase phase;
        ProvisioningDevice provisioningDevice;
        boolean requiresJinbeiStatus;
        final JSONArray unavailable;

        Operation(String str, Candidate candidate, JSONArray jSONArray) {
            this.id = str;
            this.candidate = candidate;
            this.unavailable = jSONArray;
        }
    }

    private static final class SendJob {
        final String id;
        final List<MeshMessage> messages;
        int position;

        SendJob(String str, List<MeshMessage> list) {
            this.id = str;
            this.messages = list;
        }
    }

    private JSONObject busy() {
        return LightingBluetoothBridge.error("Busy", "请先完成当前的" + this.profile.label + "灯具操作。");
    }

    private JSONObject profileError(String str, String str2) {
        return LightingBluetoothBridge.error(this.profile.errorPrefix + str, str2);
    }

    private static String upper(String str) {
        return str == null ? "" : str.toUpperCase(Locale.ROOT);
    }

    private static byte[] fromHex(String str) {
        if (str.length() % 2 != 0 || !str.matches("[0-9A-Fa-f]*")) {
            throw new IllegalArgumentException("Invalid hex");
        }
        int length = str.length() / 2;
        byte[] bArr = new byte[length];
        for (int i = 0; i < length; i++) {
            int i2 = i * 2;
            bArr[i] = (byte) Integer.parseInt(str.substring(i2, i2 + 2), 16);
        }
        return bArr;
    }

    private static String toHex(byte[] bArr) {
        char[] cArr = new char[bArr.length * 2];
        for (int i = 0; i < bArr.length; i++) {
            byte b = bArr[i];
            int i2 = i * 2;
            cArr[i2] = "0123456789ABCDEF".charAt((b & FUDistributor.UPDATE_TTL) >>> 4);
            cArr[i2 + 1] = "0123456789ABCDEF".charAt(b & 15);
        }
        return new String(cArr);
    }
}
