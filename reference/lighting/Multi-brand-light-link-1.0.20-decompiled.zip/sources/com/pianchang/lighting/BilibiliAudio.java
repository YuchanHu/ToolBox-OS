package com.pianchang.lighting;

import android.os.SystemClock;
import android.webkit.WebResourceResponse;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.ToLongFunction;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.spongycastle.asn1.cmp.PKIFailureInfo;
import org.spongycastle.asn1.x509.DisplayText;
import org.spongycastle.i18n.MessageBundle;

/* loaded from: classes.dex */
final class BilibiliAudio implements AutoCloseable {
    private static final String API = "https://api.bilibili.com";
    private static final int MAX_AUDIO_BYTES = 104857600;
    private static final int MAX_AUDIO_SOURCES = 9;
    private static final int MAX_JSON_BYTES = 2097152;
    private static final int MAX_REDIRECTS = 5;
    static final String MEDIA_PREFIX = "/media/bilibili/";
    private static final String SITE = "https://www.bilibili.com/";
    private static final String TEMP_PREFIX = "bilibili-audio-";
    private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
    private boolean busy;
    private final File cache;
    private boolean closed;
    private ScheduledFuture<?> expiration;
    private File pendingAudio;
    private String pendingPath;
    private final ScheduledExecutorService worker = Executors.newSingleThreadScheduledExecutor();
    private static final Pattern VIDEO = Pattern.compile("/video/(BV[A-Za-z0-9]{10}|av[0-9]{1,19})/?");
    private static final Pattern SHORT_LINK = Pattern.compile("/[A-Za-z0-9-]{2,32}/?");
    private static final Pattern PAGE_NUMBER = Pattern.compile("(?:^|&)p=([0-9]{1,9})(?:&|$)");
    private static final long RESULT_MAX_AGE_MS = TimeUnit.MINUTES.toMillis(3);

    /* renamed from: $r8$lambda$RAlYj5_WPG3nkZgacGmK-6nIS-E, reason: not valid java name */
    public static /* synthetic */ void m4$r8$lambda$RAlYj5_WPG3nkZgacGmK6nISE(BilibiliAudio bilibiliAudio) {
        bilibiliAudio.discardPending();
    }

    private static boolean isRedirect(int i) {
        return i == 301 || i == 302 || i == 303 || i == 307 || i == 308;
    }

    BilibiliAudio(File file) {
        this.cache = file;
    }

    synchronized void download(final String str, final Consumer<JSONObject> consumer, final Consumer<String> consumer2) {
        if (this.closed) {
            consumer2.accept("音频导入已关闭，请重试。");
            return;
        }
        if (!this.busy && this.pendingAudio == null) {
            this.busy = true;
            this.worker.execute(new Runnable() { // from class: com.pianchang.lighting.BilibiliAudio$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    this.f$0.m5lambda$download$0$compianchanglightingBilibiliAudio(str, consumer, consumer2);
                }
            });
            return;
        }
        consumer2.accept("已有音轨正在导入，请稍后重试。");
    }

    /* renamed from: lambda$download$0$com-pianchang-lighting-BilibiliAudio, reason: not valid java name */
    /* synthetic */ void m5lambda$download$0$compianchanglightingBilibiliAudio(String str, Consumer consumer, Consumer consumer2) throws Throwable {
        Video videoResolveVideo;
        File fileDownloadAudio;
        File file = null;
        try {
            try {
                try {
                    long jElapsedRealtime = SystemClock.elapsedRealtime() + TimeUnit.SECONDS.toMillis(170L);
                    discardStaleFiles();
                    videoResolveVideo = resolveVideo(str, jElapsedRealtime);
                    fileDownloadAudio = downloadAudio(videoResolveVideo, jElapsedRealtime);
                } catch (Throwable th) {
                    th = th;
                }
            } catch (IOException | JSONException unused) {
            }
        } catch (ImportError e) {
            e = e;
        }
        try {
            String str2 = MEDIA_PREFIX + UUID.randomUUID();
            JSONObject jSONObjectPut = new JSONObject().put("ok", true).put(MessageBundle.TITLE_ENTRY, videoResolveVideo.title).put("path", str2);
            try {
                synchronized (this) {
                    try {
                        if (this.closed) {
                            if (fileDownloadAudio != null) {
                                fileDownloadAudio.delete();
                            }
                            synchronized (this) {
                                this.busy = false;
                            }
                            return;
                        }
                        this.pendingAudio = fileDownloadAudio;
                        this.pendingPath = str2;
                        this.expiration = this.worker.schedule(new Runnable() { // from class: com.pianchang.lighting.BilibiliAudio$$ExternalSyntheticLambda3
                            @Override // java.lang.Runnable
                            public final void run() {
                                BilibiliAudio.m4$r8$lambda$RAlYj5_WPG3nkZgacGmK6nISE(this.f$0);
                            }
                        }, RESULT_MAX_AGE_MS, TimeUnit.MILLISECONDS);
                        consumer.accept(jSONObjectPut);
                        synchronized (this) {
                            this.busy = false;
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        throw th;
                    }
                }
            } catch (Throwable th3) {
                th = th3;
            }
        } catch (ImportError e2) {
            e = e2;
            file = fileDownloadAudio;
            consumer2.accept(e.getMessage());
            if (file != null) {
                file.delete();
            }
            synchronized (this) {
                this.busy = false;
            }
        } catch (IOException | JSONException unused2) {
            file = fileDownloadAudio;
            consumer2.accept("暂时无法读取 B 站音轨，请检查网络后重试。");
            if (file != null) {
                file.delete();
            }
            synchronized (this) {
                this.busy = false;
            }
        } catch (Throwable th4) {
            th = th4;
            file = fileDownloadAudio;
            if (file != null) {
                file.delete();
            }
            synchronized (this) {
                this.busy = false;
                throw th;
            }
        }
    }

    synchronized WebResourceResponse take(String str) throws IOException {
        File file;
        if (!this.closed && str.equals(this.pendingPath) && (file = this.pendingAudio) != null) {
            long length = file.length();
            try {
                FileInputStream fileInputStream = new FileInputStream(file);
                discardPending();
                HashMap map = new HashMap();
                map.put("Cache-Control", "no-store");
                map.put("Content-Length", Long.toString(length));
                map.put("X-Content-Type-Options", "nosniff");
                return new WebResourceResponse("audio/mp4", null, DisplayText.DISPLAY_TEXT_MAXIMUM_SIZE, "OK", map, fileInputStream);
            } catch (Throwable th) {
                discardPending();
                throw th;
            }
        }
        return null;
    }

    private synchronized void discardPending() {
        ScheduledFuture<?> scheduledFuture = this.expiration;
        if (scheduledFuture != null) {
            scheduledFuture.cancel(false);
        }
        this.expiration = null;
        this.pendingPath = null;
        File file = this.pendingAudio;
        if (file != null) {
            file.delete();
        }
        this.pendingAudio = null;
    }

    private void discardStaleFiles() {
        long jCurrentTimeMillis = System.currentTimeMillis() - RESULT_MAX_AGE_MS;
        File[] fileArrListFiles = this.cache.listFiles(new FilenameFilter() { // from class: com.pianchang.lighting.BilibiliAudio$$ExternalSyntheticLambda2
            @Override // java.io.FilenameFilter
            public final boolean accept(File file, String str) {
                return BilibiliAudio.lambda$discardStaleFiles$1(file, str);
            }
        });
        if (fileArrListFiles == null) {
            return;
        }
        for (File file : fileArrListFiles) {
            if (file.lastModified() < jCurrentTimeMillis) {
                file.delete();
            }
        }
    }

    static /* synthetic */ boolean lambda$discardStaleFiles$1(File file, String str) {
        return str.startsWith(TEMP_PREFIX) && str.endsWith(".m4a");
    }

    @Override // java.lang.AutoCloseable
    public synchronized void close() {
        this.closed = true;
        discardPending();
        this.worker.shutdownNow();
    }

    private static final class Video {
        final String bvid;
        final long cid;
        final String title;

        Video(String str, long j, String str2) {
            this.bvid = str;
            this.cid = j;
            this.title = str2;
        }
    }

    private static final class ImportError extends IOException {
        ImportError(String str) {
            super(str);
        }
    }

    private static final class AudioHttpError extends IOException {
        final int status;

        AudioHttpError(int i) {
            super("Bilibili audio HTTP " + i);
            this.status = i;
        }
    }

    private static URI httpsUri(String str) throws ImportError {
        try {
            URI uri = new URI(str);
            String scheme = uri.getScheme();
            if (("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) && uri.getHost() != null && uri.getRawUserInfo() == null && uri.getPort() == -1 && uri.getRawAuthority().equalsIgnoreCase(uri.getHost())) {
                return URI.create("https" + str.substring(str.indexOf(58)));
            }
        } catch (IllegalArgumentException | URISyntaxException unused) {
        }
        throw new ImportError("请输入 B 站公开视频链接。");
    }

    private static boolean isVideoSite(String str) {
        return "www.bilibili.com".equals(str) || "m.bilibili.com".equals(str) || "bilibili.com".equals(str);
    }

    private static URI resolveLink(String str, long j) throws IOException {
        if (str == null || str.length() > 2048) {
            throw new ImportError("请输入 B 站公开视频链接。");
        }
        URI uriHttpsUri = httpsUri(str.trim());
        int i = 0;
        while (true) {
            if (i > 5) {
                break;
            }
            String lowerCase = uriHttpsUri.getHost().toLowerCase(Locale.ROOT);
            if (isVideoSite(lowerCase) && VIDEO.matcher(uriHttpsUri.getRawPath()).matches()) {
                return uriHttpsUri;
            }
            if (!"b23.tv".equals(lowerCase) || !SHORT_LINK.matcher(uriHttpsUri.getRawPath()).matches()) {
                break;
            }
            HttpURLConnection httpURLConnectionOpen = open(uriHttpsUri, SITE, j);
            try {
                if (!isRedirect(httpURLConnectionOpen.getResponseCode())) {
                    break;
                }
                uriHttpsUri = redirect(uriHttpsUri, httpURLConnectionOpen);
                httpURLConnectionOpen.disconnect();
                i++;
            } finally {
                httpURLConnectionOpen.disconnect();
            }
        }
        throw new ImportError("请使用 B 站 BV/av 视频链接或 b23.tv 分享链接。");
    }

    private static Video resolveVideo(String str, long j) throws JSONException, IOException {
        StringBuilder sb;
        URI uriResolveLink = resolveLink(str, j);
        Pattern pattern = VIDEO;
        Matcher matcher = pattern.matcher(uriResolveLink.getRawPath());
        if (!matcher.matches()) {
            throw new ImportError("请输入 B 站公开视频链接。");
        }
        String strGroup = matcher.group(1);
        if (strGroup.startsWith("BV")) {
            sb = new StringBuilder("bvid=");
        } else {
            sb = new StringBuilder("aid=");
            strGroup = strGroup.substring(2);
        }
        sb.append(strGroup);
        JSONObject jSONObjectApiData = apiData("/x/web-interface/view?" + sb.toString(), SITE, j);
        JSONObject jSONObjectOptJSONObject = jSONObjectApiData.optJSONObject("rights");
        if (jSONObjectOptJSONObject != null && (jSONObjectOptJSONObject.optInt("pay") != 0 || jSONObjectOptJSONObject.optInt("arc_pay") != 0 || jSONObjectOptJSONObject.optInt("is_stein_gate") != 0 || jSONObjectOptJSONObject.optInt("is_upower_exclusive") != 0)) {
            throw new ImportError("这个视频没有可直接导入的公开音轨。");
        }
        String strOptString = jSONObjectApiData.optString("bvid");
        if (!pattern.matcher("/video/" + strOptString).matches() || !strOptString.startsWith("BV")) {
            throw new ImportError("B 站没有返回有效的视频信息。");
        }
        Matcher matcher2 = PAGE_NUMBER.matcher(uriResolveLink.getRawQuery() == null ? "" : uriResolveLink.getRawQuery());
        int i = matcher2.find() ? Integer.parseInt(matcher2.group(1)) : 1;
        JSONArray jSONArrayOptJSONArray = jSONObjectApiData.optJSONArray("pages");
        if (jSONArrayOptJSONArray == null) {
            throw new ImportError("B 站没有返回有效的视频分 P 信息。");
        }
        String strTrim = jSONObjectApiData.optString(MessageBundle.TITLE_ENTRY, strOptString).trim();
        if (strTrim.isEmpty()) {
            strTrim = strOptString;
        }
        for (int i2 = 0; i2 < jSONArrayOptJSONArray.length(); i2++) {
            JSONObject jSONObjectOptJSONObject2 = jSONArrayOptJSONArray.optJSONObject(i2);
            if (jSONObjectOptJSONObject2 != null && jSONObjectOptJSONObject2.optInt("page") == i && jSONObjectOptJSONObject2.optLong("cid") > 0) {
                String strTrim2 = jSONObjectOptJSONObject2.optString("part").trim();
                if (jSONArrayOptJSONArray.length() > 1) {
                    strTrim = strTrim + " · P" + i;
                    if (!strTrim2.isEmpty() && !strTrim2.equals(jSONObjectApiData.optString(MessageBundle.TITLE_ENTRY))) {
                        strTrim = strTrim + " " + strTrim2;
                    }
                }
                return new Video(strOptString, jSONObjectOptJSONObject2.optLong("cid"), strTrim);
            }
        }
        throw new ImportError("这个视频分 P 不存在。");
    }

    private static JSONObject apiData(String str, String str2, long j) throws JSONException, IOException {
        HttpURLConnection httpURLConnectionOpen = open(URI.create(API + str), str2, j);
        try {
            if (httpURLConnectionOpen.getResponseCode() != 200) {
                throw new ImportError("B 站暂时无法提供视频信息，请稍后重试。");
            }
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = httpURLConnectionOpen.getInputStream();
            try {
                byte[] bArr = new byte[PKIFailureInfo.certRevoked];
                while (true) {
                    int i = inputStream.read(bArr);
                    if (i != -1) {
                        remainingMillis(j);
                        if (byteArrayOutputStream.size() + i > 2097152) {
                            throw new IOException("Bilibili JSON limit");
                        }
                        byteArrayOutputStream.write(bArr, 0, i);
                    } else {
                        if (inputStream != null) {
                            inputStream.close();
                        }
                        JSONObject jSONObject = new JSONObject(new String(byteArrayOutputStream.toByteArray(), StandardCharsets.UTF_8));
                        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
                        if (jSONObject.optInt("code", -1) != 0 || jSONObjectOptJSONObject == null) {
                            throw new ImportError("无法读取这个 B 站视频的公开音轨。");
                        }
                        return jSONObjectOptJSONObject;
                    }
                }
            } finally {
            }
        } finally {
            httpURLConnectionOpen.disconnect();
        }
    }

    private File downloadAudio(Video video, long j) throws JSONException, IOException {
        String str;
        String str2 = "https://www.bilibili.com/video/" + video.bvid + "/";
        JSONObject jSONObjectApiData = apiData("/x/player/playurl?bvid=" + video.bvid + "&cid=" + video.cid + "&qn=16&fnver=0&fnval=16&fourk=0", str2, j);
        JSONObject jSONObjectOptJSONObject = jSONObjectApiData.optJSONObject("dash");
        if (jSONObjectApiData.optInt("is_preview") != 0 || jSONObjectApiData.optBoolean("is_preview") || jSONObjectOptJSONObject == null) {
            throw new ImportError("这个视频没有可直接导入的公开音轨。");
        }
        JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray("audio");
        ArrayList<JSONObject> arrayList = new ArrayList();
        for (int i = 0; jSONArrayOptJSONArray != null && i < jSONArrayOptJSONArray.length(); i++) {
            JSONObject jSONObjectOptJSONObject2 = jSONArrayOptJSONArray.optJSONObject(i);
            if (jSONObjectOptJSONObject2 != null && jSONObjectOptJSONObject2.optString("codecs").startsWith("mp4a.") && "audio/mp4".equals(jSONObjectOptJSONObject2.optString("mimeType", jSONObjectOptJSONObject2.optString("mime_type")))) {
                arrayList.add(jSONObjectOptJSONObject2);
            }
        }
        if (arrayList.isEmpty()) {
            throw new ImportError("这个视频没有可导入的 AAC 音轨。");
        }
        arrayList.sort(Comparator.comparingLong(new ToLongFunction() { // from class: com.pianchang.lighting.BilibiliAudio$$ExternalSyntheticLambda1
            @Override // java.util.function.ToLongFunction
            public final long applyAsLong(Object obj) {
                return BilibiliAudio.lambda$downloadAudio$2((JSONObject) obj);
            }
        }).reversed());
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        for (JSONObject jSONObject : arrayList) {
            addAudioSource(linkedHashSet, jSONObject.optString("baseUrl"));
            addAudioSource(linkedHashSet, jSONObject.optString("base_url"));
            JSONArray jSONArrayOptJSONArray2 = jSONObject.optJSONArray("backupUrl");
            if (jSONArrayOptJSONArray2 == null) {
                jSONArrayOptJSONArray2 = jSONObject.optJSONArray("backup_url");
            }
            for (int i2 = 0; jSONArrayOptJSONArray2 != null && i2 < jSONArrayOptJSONArray2.length() && i2 < 3; i2++) {
                addAudioSource(linkedHashSet, jSONArrayOptJSONArray2.optString(i2));
            }
            if (linkedHashSet.size() == 9) {
                break;
            }
        }
        if (linkedHashSet.isEmpty()) {
            throw new ImportError("B 站没有返回可用的音轨地址。");
        }
        Iterator it = linkedHashSet.iterator();
        boolean z = true;
        while (it.hasNext()) {
            try {
                return downloadTrack((URI) it.next(), str2, j);
            } catch (ImportError e) {
                throw e;
            } catch (IOException e2) {
                z &= (e2 instanceof AudioHttpError) && ((AudioHttpError) e2).status == 403;
                remainingMillis(j);
            }
        }
        if (z) {
            str = "B 站音轨服务器拒绝了下载（HTTP 403），请稍后重试。";
        } else {
            str = "未能从 B 站下载完整音轨，请稍后重试。";
        }
        throw new ImportError(str);
    }

    static /* synthetic */ long lambda$downloadAudio$2(JSONObject jSONObject) {
        return jSONObject.optLong("bandwidth");
    }

    private static void addAudioSource(Set<URI> set, String str) {
        if (set.size() == 9 || str.isEmpty()) {
            return;
        }
        try {
            if (str.startsWith("//")) {
                str = "https:" + str;
            }
            URI uriHttpsUri = httpsUri(str);
            if (isAudioHost(uriHttpsUri)) {
                set.add(uriHttpsUri);
            }
        } catch (ImportError unused) {
        }
    }

    private static boolean isAudioHost(URI uri) {
        String lowerCase = uri.getHost().toLowerCase(Locale.ROOT);
        return lowerCase.endsWith(".bilivideo.com") || lowerCase.endsWith(".bilivideo.cn") || lowerCase.endsWith(".bilivideo.net");
    }

    private File downloadTrack(URI uri, String str, long j) throws IOException {
        for (int i = 0; i <= 5 && isAudioHost(uri); i++) {
            HttpURLConnection httpURLConnectionOpen = open(uri, str, j);
            try {
                int responseCode = httpURLConnectionOpen.getResponseCode();
                if (!isRedirect(responseCode)) {
                    if (responseCode != 200) {
                        throw new AudioHttpError(responseCode);
                    }
                    return copyTrack(httpURLConnectionOpen, j);
                }
                uri = redirect(uri, httpURLConnectionOpen);
                httpURLConnectionOpen.disconnect();
            } finally {
                httpURLConnectionOpen.disconnect();
            }
        }
        throw new IOException("Unexpected Bilibili audio host");
    }

    private File copyTrack(HttpURLConnection httpURLConnection, long j) throws IOException {
        long contentLengthLong = httpURLConnection.getContentLengthLong();
        if (contentLengthLong > 104857600) {
            throw new ImportError("音轨超过 100 MB，无法导入。");
        }
        File fileCreateTempFile = File.createTempFile(TEMP_PREFIX, ".m4a", this.cache);
        try {
            InputStream inputStream = httpURLConnection.getInputStream();
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(fileCreateTempFile);
                try {
                    byte[] bArr = new byte[8];
                    int i = 0;
                    while (i < 8) {
                        int i2 = inputStream.read(bArr, i, 8 - i);
                        if (i2 == -1) {
                            throw new IOException("Incomplete Bilibili audio header");
                        }
                        i += i2;
                    }
                    if (bArr[4] != 102 || bArr[5] != 116 || bArr[6] != 121 || bArr[7] != 112) {
                        throw new IOException("Unexpected Bilibili audio format");
                    }
                    fileOutputStream.write(bArr);
                    byte[] bArr2 = new byte[PKIFailureInfo.notAuthorized];
                    int i3 = 8;
                    while (true) {
                        int i4 = inputStream.read(bArr2);
                        if (i4 != -1) {
                            remainingMillis(j);
                            i3 += i4;
                            if (i3 > MAX_AUDIO_BYTES) {
                                throw new ImportError("音轨超过 100 MB，无法导入。");
                            }
                            fileOutputStream.write(bArr2, 0, i4);
                        } else {
                            remainingMillis(j);
                            if (i3 == 8 || (contentLengthLong >= 0 && contentLengthLong != i3)) {
                                throw new IOException("Incomplete Bilibili audio");
                            }
                            fileOutputStream.close();
                            if (inputStream != null) {
                                inputStream.close();
                            }
                            return fileCreateTempFile;
                        }
                    }
                } finally {
                }
            } finally {
            }
        } catch (Throwable th) {
            fileCreateTempFile.delete();
            throw th;
        }
    }

    private static URI redirect(URI uri, HttpURLConnection httpURLConnection) throws IOException {
        String headerField = httpURLConnection.getHeaderField("Location");
        if (headerField == null || headerField.length() > 8192) {
            throw new IOException("Unexpected Bilibili redirect");
        }
        try {
            return httpsUri(uri.resolve(headerField).toString());
        } catch (ImportError | IllegalArgumentException e) {
            throw new IOException("Unexpected Bilibili redirect", e);
        }
    }

    private static HttpURLConnection open(URI uri, String str, long j) throws IOException {
        int iRemainingMillis = remainingMillis(j);
        HttpURLConnection httpURLConnection = (HttpURLConnection) uri.toURL().openConnection();
        httpURLConnection.setConnectTimeout(iRemainingMillis);
        httpURLConnection.setReadTimeout(iRemainingMillis);
        httpURLConnection.setInstanceFollowRedirects(false);
        httpURLConnection.setUseCaches(false);
        httpURLConnection.setRequestProperty("User-Agent", USER_AGENT);
        httpURLConnection.setRequestProperty("Referer", str);
        httpURLConnection.setRequestProperty("Accept-Encoding", "identity");
        return httpURLConnection;
    }

    private static int remainingMillis(long j) throws ImportError {
        long jElapsedRealtime = j - SystemClock.elapsedRealtime();
        if (jElapsedRealtime <= 0 || Thread.currentThread().isInterrupted()) {
            throw new ImportError("下载 B 站音轨超时，请重试。");
        }
        return (int) Math.min(jElapsedRealtime, 12000L);
    }
}
