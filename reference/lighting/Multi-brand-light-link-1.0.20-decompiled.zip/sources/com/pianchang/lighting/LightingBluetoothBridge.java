package com.pianchang.lighting;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.pianchang.lighting.FixtureMeshTransport;
import com.pianchang.lighting.LightingBluetoothBridge;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.ToIntFunction;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.spongycastle.crypto.tls.CipherSuite;

/* loaded from: classes.dex */
public final class LightingBluetoothBridge {
    private static final int ADVERTISE_START_MILLIS = 1500;
    private static final int BATCH_SELECTION_MILLIS = 75000;
    private static final int INKEE_BURST_MILLIS = 250;
    private static final int INKEE_MANUFACTURER = 78;
    private static final int INKEE_PAIR = 16;
    private static final int INKEE_PAIR_BURST_MILLIS = 500;
    private static final int LYD_BURST_MILLIS = 250;
    private static final int LYD_MANUFACTURER = 65535;
    private static final int NETRIX_MANUFACTURER = 3702;
    private static final int PERMISSION_REQUEST = 3512;
    private static final int PROXY_SCAN_MILLIS = 4000;
    private static final int SCAN_MILLIS = 10000;
    private static final int SELECTION_MILLIS = 30000;
    private static final String ULANZI_BRAND = "Ulanzi";
    private static final String YONGNUO_BRAND = "永诺YONGNUO";
    private static final String ZHIYUN_BRAND = "智云";
    private final Activity activity;
    private BroadcastSession broadcast;
    private boolean closed;
    private final LampGattTransport gatt;
    private final FixtureMeshTransport godox;
    private final Handler handler;
    private final FixtureMeshTransport jinbei;
    private final FixtureMeshTransport lumin;
    private PermissionRequest permissionRequest;
    private ProxyScan proxyScan;
    private ScanSession session;
    private final FixtureMeshTransport sidus;
    private final WebView webView;
    private static final ParcelUuid ZHIYUN_CONTROL_SERVICE = ParcelUuid.fromString("0000fee9-0000-1000-8000-00805f9b34fb");
    private static final ParcelUuid MESH_PROVISIONING = ParcelUuid.fromString("00001827-0000-1000-8000-00805f9b34fb");
    private static final ParcelUuid MESH_PROXY = ParcelUuid.fromString("00001828-0000-1000-8000-00805f9b34fb");
    private static final char[] HEX_DIGITS = "0123456789abcdef".toCharArray();
    private static final Pattern REQUEST_ID = Pattern.compile("[a-zA-Z0-9_-]{1,100}");
    private static final Pattern LYD_FRAME = Pattern.compile("0215faa500001111abcd0123be89[0-9a-f]{18}", 2);
    private static final Pattern INKEE_FRAME = Pattern.compile("7f6d3f65[0-9a-f]{2}06[0-9a-f]{20}", 2);
    private static final Pattern MAC_ADDRESS = Pattern.compile("(?:[0-9A-F]{2}:){5}[0-9A-F]{2}");
    private static final Pattern MESH_UUID = Pattern.compile("[0-9A-F]{32}");

    /* renamed from: $r8$lambda$6QZmRz-ZmgWF4HE3W1ahiRaUzJ4, reason: not valid java name */
    public static /* synthetic */ void m29$r8$lambda$6QZmRzZmgWF4HE3W1ahiRaUzJ4(LightingBluetoothBridge lightingBluetoothBridge, String str, byte[] bArr) {
        lightingBluetoothBridge.deliverGattNotification(str, bArr);
    }

    /* renamed from: $r8$lambda$X24Dd4aFoap69y6-JbWyuyVblaM, reason: not valid java name */
    public static /* synthetic */ void m30$r8$lambda$X24Dd4aFoap69y6JbWyuyVblaM(LightingBluetoothBridge lightingBluetoothBridge, String str, JSONObject jSONObject) {
        lightingBluetoothBridge.deliverSidusProgress(str, jSONObject);
    }

    /* renamed from: $r8$lambda$a_gIMrFP--oTLYrHWEKR9kwKHkw, reason: not valid java name */
    public static /* synthetic */ void m31$r8$lambda$a_gIMrFPoTLYrHWEKR9kwKHkw(LightingBluetoothBridge lightingBluetoothBridge, String str) {
        lightingBluetoothBridge.deliverGattLinkLost(str);
    }

    /* renamed from: $r8$lambda$yZ30_VpZhB98z1O-g49LgM3wlYU, reason: not valid java name */
    public static /* synthetic */ void m32$r8$lambda$yZ30_VpZhB98z1Og49LgM3wlYU(LightingBluetoothBridge lightingBluetoothBridge, String str, JSONObject jSONObject) {
        lightingBluetoothBridge.deliver(str, jSONObject);
    }

    @JavascriptInterface
    public boolean ulanziLightingSupported() {
        return true;
    }

    @JavascriptInterface
    public boolean zhiyunLightingSupported() {
        return true;
    }

    static /* synthetic */ Handler access$1300(LightingBluetoothBridge lightingBluetoothBridge) {
        return lightingBluetoothBridge.handler;
    }

    static /* synthetic */ ProxyScan access$1400(LightingBluetoothBridge lightingBluetoothBridge) {
        return lightingBluetoothBridge.proxyScan;
    }

    static /* synthetic */ byte[] access$1500(ScanRecord scanRecord) {
        return proxyBeacon(scanRecord);
    }

    static /* synthetic */ String access$1600(byte[] bArr) {
        return encodeHex(bArr);
    }

    static /* synthetic */ JSONObject access$1700(boolean z) {
        return permissionError(z);
    }

    static /* synthetic */ void access$1800(LightingBluetoothBridge lightingBluetoothBridge, String str, JSONObject jSONObject) {
        lightingBluetoothBridge.finishProxyScan(str, jSONObject);
    }

    static /* synthetic */ LampGattTransport access$1900(LightingBluetoothBridge lightingBluetoothBridge) {
        return lightingBluetoothBridge.gatt;
    }

    static /* synthetic */ Activity access$2000(LightingBluetoothBridge lightingBluetoothBridge) {
        return lightingBluetoothBridge.activity;
    }

    static /* synthetic */ int access$2100(LightingBluetoothBridge lightingBluetoothBridge, int i) {
        return lightingBluetoothBridge.dp(i);
    }

    static /* synthetic */ int access$2200(byte[] bArr, int i) {
        return meshWord(bArr, i);
    }

    static /* synthetic */ ScanSession access$2300(LightingBluetoothBridge lightingBluetoothBridge) {
        return lightingBluetoothBridge.session;
    }

    static /* synthetic */ byte[] access$2400(ScanRecord scanRecord) {
        return meshProvisioningUuid(scanRecord);
    }

    static /* synthetic */ ParcelUuid access$2500() {
        return ZHIYUN_CONTROL_SERVICE;
    }

    static /* synthetic */ String access$2600(String str, String str2, ScanRecord scanRecord, byte[] bArr) {
        return variantFor(str, str2, scanRecord, bArr);
    }

    static /* synthetic */ void access$2700(LightingBluetoothBridge lightingBluetoothBridge, ScanSession scanSession, JSONObject jSONObject) {
        lightingBluetoothBridge.finishScan(scanSession, jSONObject);
    }

    static /* synthetic */ JSONObject access$2800() {
        return cancelledScan();
    }

    static /* synthetic */ void access$3200(LightingBluetoothBridge lightingBluetoothBridge, BroadcastSession broadcastSession, JSONObject jSONObject) {
        lightingBluetoothBridge.finishBroadcast(broadcastSession, jSONObject);
    }

    static /* synthetic */ BroadcastSession access$3300(LightingBluetoothBridge lightingBluetoothBridge) {
        return lightingBluetoothBridge.broadcast;
    }

    public LightingBluetoothBridge(Activity activity, WebView webView) {
        Handler handler = new Handler(Looper.getMainLooper());
        this.handler = handler;
        this.activity = activity;
        this.webView = webView;
        this.gatt = new LampGattTransport(activity, handler, new BiConsumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda16
            @Override // java.util.function.BiConsumer
            public final void accept(Object obj, Object obj2) {
                LightingBluetoothBridge.m32$r8$lambda$yZ30_VpZhB98z1Og49LgM3wlYU(this.f$0, (String) obj, (JSONObject) obj2);
            }
        }, new BiConsumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda18
            @Override // java.util.function.BiConsumer
            public final void accept(Object obj, Object obj2) {
                LightingBluetoothBridge.m29$r8$lambda$6QZmRzZmgWF4HE3W1ahiRaUzJ4(this.f$0, (String) obj, (byte[]) obj2);
            }
        }, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda19
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                LightingBluetoothBridge.m31$r8$lambda$a_gIMrFPoTLYrHWEKR9kwKHkw(this.f$0, (String) obj);
            }
        });
        this.godox = new FixtureMeshTransport(FixtureMeshTransport.Profile.GODOX, activity, handler, new BiConsumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda16
            @Override // java.util.function.BiConsumer
            public final void accept(Object obj, Object obj2) {
                LightingBluetoothBridge.m32$r8$lambda$yZ30_VpZhB98z1Og49LgM3wlYU(this.f$0, (String) obj, (JSONObject) obj2);
            }
        }, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda20
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f$0.m62lambda$new$0$compianchanglightingLightingBluetoothBridge((String) obj);
            }
        });
        this.sidus = new FixtureMeshTransport(FixtureMeshTransport.Profile.SIDUS, activity, handler, new BiConsumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda16
            @Override // java.util.function.BiConsumer
            public final void accept(Object obj, Object obj2) {
                LightingBluetoothBridge.m32$r8$lambda$yZ30_VpZhB98z1Og49LgM3wlYU(this.f$0, (String) obj, (JSONObject) obj2);
            }
        }, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda21
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f$0.m63lambda$new$1$compianchanglightingLightingBluetoothBridge((String) obj);
            }
        }, new BiConsumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda22
            @Override // java.util.function.BiConsumer
            public final void accept(Object obj, Object obj2) {
                LightingBluetoothBridge.m30$r8$lambda$X24Dd4aFoap69y6JbWyuyVblaM(this.f$0, (String) obj, (JSONObject) obj2);
            }
        });
        this.lumin = new FixtureMeshTransport(FixtureMeshTransport.Profile.LUMIN, activity, handler, new BiConsumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda16
            @Override // java.util.function.BiConsumer
            public final void accept(Object obj, Object obj2) {
                LightingBluetoothBridge.m32$r8$lambda$yZ30_VpZhB98z1Og49LgM3wlYU(this.f$0, (String) obj, (JSONObject) obj2);
            }
        }, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda23
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f$0.m64lambda$new$2$compianchanglightingLightingBluetoothBridge((String) obj);
            }
        });
        this.jinbei = new FixtureMeshTransport(FixtureMeshTransport.Profile.JINBEI, activity, handler, new BiConsumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda16
            @Override // java.util.function.BiConsumer
            public final void accept(Object obj, Object obj2) {
                LightingBluetoothBridge.m32$r8$lambda$yZ30_VpZhB98z1Og49LgM3wlYU(this.f$0, (String) obj, (JSONObject) obj2);
            }
        }, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda17
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f$0.m65lambda$new$3$compianchanglightingLightingBluetoothBridge((String) obj);
            }
        });
    }

    /* renamed from: lambda$new$0$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m62lambda$new$0$compianchanglightingLightingBluetoothBridge(String str) {
        deliverMeshLinkLost("onLightingGodoxLinkLost", str);
    }

    /* renamed from: lambda$new$1$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m63lambda$new$1$compianchanglightingLightingBluetoothBridge(String str) {
        deliverMeshLinkLost("onLightingSidusLinkLost", str);
    }

    /* renamed from: lambda$new$2$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m64lambda$new$2$compianchanglightingLightingBluetoothBridge(String str) {
        deliverMeshLinkLost("onLightingLuminLinkLost", str);
    }

    /* renamed from: lambda$new$3$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m65lambda$new$3$compianchanglightingLightingBluetoothBridge(String str) {
        deliverMeshLinkLost("onLightingJinbeiLinkLost", str);
    }

    @JavascriptInterface
    public void godoxScan(final String str, final String str2) {
        withMeshRadio(str, FixtureMeshTransport.Profile.GODOX, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda26
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f$0.m46x18e3d443(str, str2, (BluetoothAdapter) obj);
            }
        });
    }

    /* renamed from: lambda$godoxScan$4$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m46x18e3d443(String str, String str2, BluetoothAdapter bluetoothAdapter) {
        this.godox.scan(str, bluetoothAdapter, str2);
    }

    @JavascriptInterface
    public void godoxAdd(final String str, final String str2, final String str3) {
        withMeshRadio(str, FixtureMeshTransport.Profile.GODOX, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda1
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f$0.m43lambda$godoxAdd$5$compianchanglightingLightingBluetoothBridge(str, str2, str3, (BluetoothAdapter) obj);
            }
        });
    }

    /* renamed from: lambda$godoxAdd$5$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m43lambda$godoxAdd$5$compianchanglightingLightingBluetoothBridge(String str, String str2, String str3, BluetoothAdapter bluetoothAdapter) {
        this.godox.add(str, str2, str3);
    }

    @JavascriptInterface
    public void godoxConnect(final String str, final String str2, final String str3) {
        withMeshRadio(str, FixtureMeshTransport.Profile.GODOX, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda36
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f$0.m44xd4c03104(str, str2, str3, (BluetoothAdapter) obj);
            }
        });
    }

    /* renamed from: lambda$godoxConnect$6$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m44xd4c03104(String str, String str2, String str3, BluetoothAdapter bluetoothAdapter) {
        this.godox.connect(str, str2, str3);
    }

    @JavascriptInterface
    public void godoxSend(final String str, final String str2, final int i, final String str3) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda7
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m47x1f64f435(str, str2, i, str3);
                }
            });
        }
    }

    /* renamed from: lambda$godoxSend$7$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m47x1f64f435(String str, String str2, int i, String str3) {
        if (this.closed) {
            return;
        }
        this.godox.send(str, str2, i, str3);
    }

    @JavascriptInterface
    public void godoxDisconnect(final String str) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m45xe85580(str);
                }
            });
        }
    }

    /* renamed from: lambda$godoxDisconnect$8$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m45xe85580(String str) {
        if (this.closed) {
            return;
        }
        this.godox.disconnect(str);
    }

    /* renamed from: lambda$sidusScan$9$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m71x68ee6377(String str, String str2, BluetoothAdapter bluetoothAdapter) {
        this.sidus.scan(str, bluetoothAdapter, str2);
    }

    @JavascriptInterface
    public void sidusScan(final String str, final String str2) {
        withMeshRadio(str, FixtureMeshTransport.Profile.SIDUS, true, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda2
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f$0.m71x68ee6377(str, str2, (BluetoothAdapter) obj);
            }
        });
    }

    @JavascriptInterface
    public void cancelSidusScan(final String str) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda29
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m35x73056f47(str);
                }
            });
        }
    }

    /* renamed from: lambda$cancelSidusScan$10$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m35x73056f47(String str) {
        if (this.closed) {
            return;
        }
        PermissionRequest permissionRequest = this.permissionRequest;
        if (permissionRequest != null && PermissionRequest.access$3400(permissionRequest) && !PermissionRequest.access$000(permissionRequest)) {
            PermissionRequest.access$002(permissionRequest, true);
            deliver(PermissionRequest.access$200(permissionRequest), cancelledScan());
        }
        this.sidus.cancelScan();
        deliver(str, json("ok", true));
    }

    /* renamed from: lambda$sidusAdd$11$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m68xc3e59a26(String str, String str2, String str3, BluetoothAdapter bluetoothAdapter) {
        this.sidus.add(str, str2, str3);
    }

    @JavascriptInterface
    public void sidusAdd(final String str, final String str2, final String str3) {
        withMeshRadio(str, FixtureMeshTransport.Profile.SIDUS, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda30
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f$0.m68xc3e59a26(str, str2, str3, (BluetoothAdapter) obj);
            }
        });
    }

    /* renamed from: lambda$sidusConnect$12$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m69xfc12178e(String str, String str2, String str3, BluetoothAdapter bluetoothAdapter) {
        this.sidus.connect(str, str2, str3);
    }

    @JavascriptInterface
    public void sidusConnect(final String str, final String str2, final String str3) {
        withMeshRadio(str, FixtureMeshTransport.Profile.SIDUS, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda6
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f$0.m69xfc12178e(str, str2, str3, (BluetoothAdapter) obj);
            }
        });
    }

    @JavascriptInterface
    public void sidusSend(final String str, final String str2, final int i, final String str3) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda41
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m72xbc114649(str, str2, i, str3);
                }
            });
        }
    }

    /* renamed from: lambda$sidusSend$13$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m72xbc114649(String str, String str2, int i, String str3) {
        if (this.closed) {
            return;
        }
        this.sidus.send(str, str2, i, str3);
    }

    @JavascriptInterface
    public void sidusDisconnect(final String str) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda14
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m70x1581c4fc(str);
                }
            });
        }
    }

    /* renamed from: lambda$sidusDisconnect$14$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m70x1581c4fc(String str) {
        if (this.closed) {
            return;
        }
        this.sidus.disconnect(str);
    }

    /* renamed from: lambda$luminScan$15$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m58xffc7ba39(String str, String str2, BluetoothAdapter bluetoothAdapter) {
        this.lumin.scan(str, bluetoothAdapter, str2);
    }

    @JavascriptInterface
    public void luminScan(final String str, final String str2) {
        withMeshRadio(str, FixtureMeshTransport.Profile.LUMIN, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda28
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f$0.m58xffc7ba39(str, str2, (BluetoothAdapter) obj);
            }
        });
    }

    /* renamed from: lambda$luminAdd$16$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m55x65baff64(String str, String str2, String str3, BluetoothAdapter bluetoothAdapter) {
        this.lumin.add(str, str2, str3);
    }

    @JavascriptInterface
    public void luminAdd(final String str, final String str2, final String str3) {
        withMeshRadio(str, FixtureMeshTransport.Profile.LUMIN, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda35
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f$0.m55x65baff64(str, str2, str3, (BluetoothAdapter) obj);
            }
        });
    }

    /* renamed from: lambda$luminConnect$17$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m56x79d0d34c(String str, String str2, String str3, BluetoothAdapter bluetoothAdapter) {
        this.lumin.connect(str, str2, str3);
    }

    @JavascriptInterface
    public void luminConnect(final String str, final String str2, final String str3) {
        withMeshRadio(str, FixtureMeshTransport.Profile.LUMIN, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda24
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f$0.m56x79d0d34c(str, str2, str3, (BluetoothAdapter) obj);
            }
        });
    }

    @JavascriptInterface
    public void luminSend(final String str, final String str2, final int i, final String str3) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda10
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m59x782db021(str, str2, i, str3);
                }
            });
        }
    }

    /* renamed from: lambda$luminSend$18$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m59x782db021(String str, String str2, int i, String str3) {
        if (this.closed) {
            return;
        }
        this.lumin.send(str, str2, i, str3);
    }

    @JavascriptInterface
    public void luminDisconnect(final String str) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda42
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m57xfb991d14(str);
                }
            });
        }
    }

    /* renamed from: lambda$luminDisconnect$19$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m57xfb991d14(String str) {
        if (this.closed) {
            return;
        }
        this.lumin.disconnect(str);
    }

    @JavascriptInterface
    public void jinbeiScan(final String str, final String str2) {
        withMeshRadio(str, FixtureMeshTransport.Profile.JINBEI, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda15
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f$0.m53x1eadb267(str, str2, (BluetoothAdapter) obj);
            }
        });
    }

    /* renamed from: lambda$jinbeiScan$20$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m53x1eadb267(String str, String str2, BluetoothAdapter bluetoothAdapter) {
        this.jinbei.scan(str, bluetoothAdapter, str2);
    }

    @JavascriptInterface
    public void jinbeiAdd(final String str, final String str2, final String str3) {
        withMeshRadio(str, FixtureMeshTransport.Profile.JINBEI, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda34
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f$0.m50x676ad782(str, str2, str3, (BluetoothAdapter) obj);
            }
        });
    }

    /* renamed from: lambda$jinbeiAdd$21$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m50x676ad782(String str, String str2, String str3, BluetoothAdapter bluetoothAdapter) {
        this.jinbei.add(str, str2, str3);
    }

    @JavascriptInterface
    public void jinbeiConnect(final String str, final String str2, final String str3) {
        withMeshRadio(str, FixtureMeshTransport.Profile.JINBEI, new Consumer() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda27
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f$0.m51x28102f6a(str, str2, str3, (BluetoothAdapter) obj);
            }
        });
    }

    /* renamed from: lambda$jinbeiConnect$22$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m51x28102f6a(String str, String str2, String str3, BluetoothAdapter bluetoothAdapter) {
        this.jinbei.connect(str, str2, str3);
    }

    @JavascriptInterface
    public void jinbeiSend(final String str, final String str2, final int i, final String str3) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda32
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m54x9713a84f(str, str2, i, str3);
                }
            });
        }
    }

    /* renamed from: lambda$jinbeiSend$23$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m54x9713a84f(String str, String str2, int i, String str3) {
        if (this.closed) {
            return;
        }
        this.jinbei.send(str, str2, i, str3);
    }

    @JavascriptInterface
    public void jinbeiDisconnect(final String str) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda33
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m52x5d4d4f42(str);
                }
            });
        }
    }

    /* renamed from: lambda$jinbeiDisconnect$24$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m52x5d4d4f42(String str) {
        if (this.closed) {
            return;
        }
        this.jinbei.disconnect(str);
    }

    @JavascriptInterface
    public void copyDiagnostic(final String str, final String str2) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda44
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m36xa7d6220a(str2, str);
                }
            });
        }
    }

    /* renamed from: lambda$copyDiagnostic$25$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m36xa7d6220a(String str, String str2) {
        if (this.closed) {
            return;
        }
        if (str == null || str.isEmpty() || str.length() > 128000) {
            deliver(str2, error("Clipboard", "诊断内容为空或过长。"));
            return;
        }
        try {
            ClipboardManager clipboardManager = (ClipboardManager) this.activity.getSystemService(ClipboardManager.class);
            if (clipboardManager == null) {
                deliver(str2, error("Clipboard", "系统剪贴板暂不可用。"));
            } else {
                clipboardManager.setPrimaryClip(ClipData.newPlainText("爱图仕 Mesh 诊断", str));
                deliver(str2, json("ok", true));
            }
        } catch (RuntimeException unused) {
            deliver(str2, error("Clipboard", "无法复制，请手动选择诊断文字。"));
        }
    }

    private void withMeshRadio(String str, FixtureMeshTransport.Profile profile, Consumer<BluetoothAdapter> consumer) {
        withMeshRadio(str, profile, false, consumer);
    }

    private void withMeshRadio(final String str, final FixtureMeshTransport.Profile profile, final boolean z, final Consumer<BluetoothAdapter> consumer) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda43
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m74xc4300b9a(str, consumer, profile, z);
                }
            });
        }
    }

    /* renamed from: lambda$withMeshRadio$27$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m74xc4300b9a(final String str, final Consumer consumer, final FixtureMeshTransport.Profile profile, boolean z) {
        PermissionRequest permissionRequest;
        if (this.closed) {
            return;
        }
        PermissionRequest permissionRequest2 = this.permissionRequest;
        withPermission(str, true, new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m73x8a6569bb(str, consumer, profile);
            }
        });
        if (!z || (permissionRequest = this.permissionRequest) == null || permissionRequest == permissionRequest2) {
            return;
        }
        PermissionRequest.access$3402(permissionRequest, true);
    }

    /* renamed from: lambda$withMeshRadio$26$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m73x8a6569bb(String str, Consumer consumer, FixtureMeshTransport.Profile profile) {
        try {
            BluetoothAdapter bluetoothAdapterAdapter = adapter(str);
            if (bluetoothAdapterAdapter != null) {
                consumer.accept(bluetoothAdapterAdapter);
            }
        } catch (SecurityException unused) {
            deliver(str, permissionError(true));
        } catch (RuntimeException unused2) {
            deliver(str, error(profile.errorPrefix + "BluetoothError", profile.label + "蓝牙操作失败，请检查蓝牙状态后重试。"));
        }
    }

    @JavascriptInterface
    public void gattConnect(final String str, final String str2, final String str3, final String str4, final String str5, final int i) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda45
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m38xdc434ce0(str, str2, str3, str4, str5, i);
                }
            });
        }
    }

    /* renamed from: lambda$gattConnect$29$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m38xdc434ce0(final String str, final String str2, final String str3, final String str4, final String str5, final int i) {
        if (this.closed) {
            return;
        }
        withPermission(str, false, null, new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda40
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m37xa278ab01(str, str2, str3, str4, str5, i);
            }
        });
    }

    /* renamed from: lambda$gattConnect$28$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m37xa278ab01(String str, String str2, String str3, String str4, String str5, int i) {
        try {
            BluetoothAdapter bluetoothAdapterAdapter = adapter(str);
            if (bluetoothAdapterAdapter != null) {
                this.gatt.connect(str, bluetoothAdapterAdapter, str2, str3, str4, str5, i);
            }
        } catch (SecurityException unused) {
            deliver(str, permissionError(false));
        }
    }

    @JavascriptInterface
    public void gattWrite(final String str, final String str2, final String str3, final int i) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda38
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m42x658503ff(str, str2, str3, i);
                }
            });
        }
    }

    /* renamed from: lambda$gattWrite$30$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m42x658503ff(String str, String str2, String str3, int i) {
        if (this.closed) {
            return;
        }
        this.gatt.write(str, str2, str3, i);
    }

    @JavascriptInterface
    public void gattDisconnect(final String str, final String str2) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda13
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m39xdefa9a29(str, str2);
                }
            });
        }
    }

    /* renamed from: lambda$gattDisconnect$31$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m39xdefa9a29(String str, String str2) {
        if (this.closed) {
            return;
        }
        this.gatt.disconnect(str, str2);
    }

    @JavascriptInterface
    public void gattFindMeshProxies(final String str) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda31
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m41x43490c23(str);
                }
            });
        }
    }

    /* renamed from: lambda$gattFindMeshProxies$33$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m41x43490c23(final String str) {
        if (this.closed) {
            return;
        }
        if (this.session != null || this.proxyScan != null) {
            deliver(str, error("Busy", "请先结束上一轮蓝牙搜索。"));
        } else {
            withPermission(str, true, new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda39
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m40x97e6a44(str);
                }
            });
        }
    }

    /* renamed from: lambda$gattFindMeshProxies$32$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m40x97e6a44(String str) {
        startProxyScan(str);
    }

    @JavascriptInterface
    public void scan(String str, String str2) {
        scanAvailable(str, str2, false, "{}");
    }

    @JavascriptInterface
    public void scanBatch(String str, String str2) {
        scanAvailable(str, str2, true, "{}");
    }

    @JavascriptInterface
    public void scanAvailable(final String str, final String str2, final boolean z, final String str3) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m67x440819c1(str2, str, str3, z);
                }
            });
        }
    }

    /* renamed from: lambda$scanAvailable$35$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m67x440819c1(final String str, final String str2, String str3, final boolean z) {
        if (this.closed) {
            return;
        }
        if (!"南光".equals(str) && !"XSJ".equals(str) && !YONGNUO_BRAND.equals(str) && !ULANZI_BRAND.equals(str) && !ZHIYUN_BRAND.equals(str)) {
            deliver(str2, error("NotSupportedError", "此品牌暂未接入蓝牙搜索。"));
            return;
        }
        if (this.session != null || this.proxyScan != null) {
            deliver(str2, error("Busy", "请先结束上一轮蓝牙搜索。"));
            return;
        }
        try {
            if (str3 == null) {
                str3 = "{}";
            }
            JSONObject jSONObject = new JSONObject(str3);
            final Set<String> setScanExclusions = scanExclusions(jSONObject.optJSONArray("addresses"), MAC_ADDRESS);
            final Set<String> setScanExclusions2 = scanExclusions(jSONObject.optJSONArray("meshUuids"), MESH_UUID);
            withPermission(str2, true, new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda8
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m66xa3d77e2(str2, str, z, setScanExclusions, setScanExclusions2);
                }
            });
        } catch (JSONException unused) {
            deliver(str2, error("InvalidExclusions", "蓝牙搜索的灯具排除列表格式不正确。"));
        }
    }

    /* renamed from: lambda$scanAvailable$34$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m66xa3d77e2(String str, String str2, boolean z, Set set, Set set2) {
        startScan(str, str2, z, set, set2);
    }

    private static Set<String> scanExclusions(JSONArray jSONArray, Pattern pattern) {
        HashSet hashSet = new HashSet();
        for (int i = 0; jSONArray != null && i < jSONArray.length(); i++) {
            String upperCase = jSONArray.optString(i).toUpperCase(Locale.ROOT);
            if (pattern.matcher(upperCase).matches()) {
                hashSet.add(upperCase);
            }
        }
        return hashSet;
    }

    @JavascriptInterface
    public void lydStatus(String str) {
        advertiseStatus(str);
    }

    @JavascriptInterface
    public void inkeeStatus(String str) {
        advertiseStatus(str);
    }

    private void advertiseStatus(final String str) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda11
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m34x1ef5e5ac(str);
                }
            });
        }
    }

    /* renamed from: lambda$advertiseStatus$37$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m34x1ef5e5ac(final String str) {
        if (this.closed) {
            return;
        }
        withPermission(str, false, new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m33xe52b43cd(str);
            }
        });
    }

    /* renamed from: lambda$advertiseStatus$36$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m33xe52b43cd(String str) {
        try {
            if (advertiser(str) != null) {
                deliver(str, json("ok", true, "available", true));
            }
        } catch (SecurityException unused) {
            deliver(str, permissionError(false));
        } catch (RuntimeException unused2) {
            deliver(str, error("NotSupportedError", "安卓蓝牙广播暂不可用。请检查平板的蓝牙状态后重试。"));
        }
    }

    @JavascriptInterface
    public void lydBroadcast(final String str, final String str2) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda25
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m61x98cdf055(str2, str);
                }
            });
        }
    }

    /* renamed from: lambda$lydBroadcast$39$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m61x98cdf055(final String str, final String str2) {
        if (this.closed) {
            return;
        }
        if (!validLydFrame(str)) {
            deliver(str2, error("InvalidPayload", "LYD/轻装时代 mode02 广播报文格式不正确。"));
        } else {
            withPermission(str2, false, new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda37
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m60x5f034e76(str2, str);
                }
            });
        }
    }

    /* renamed from: lambda$lydBroadcast$38$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m60x5f034e76(String str, String str2) {
        startBroadcast(str, 65535, decodeFrame(str2), 250);
    }

    @JavascriptInterface
    public void inkeeBroadcast(final String str, final String str2) {
        if (validRequestId(str)) {
            this.handler.post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda12
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m49x62748c2f(str2, str);
                }
            });
        }
    }

    /* renamed from: lambda$inkeeBroadcast$41$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m49x62748c2f(String str, final String str2) {
        if (this.closed) {
            return;
        }
        final byte[] inkeeFrame = parseInkeeFrame(str);
        if (inkeeFrame == null) {
            deliver(str2, error("InvalidPayload", "INKEE 影器广播报文格式不正确。"));
        } else {
            final int i = inkeeFrame[10] == 16 ? INKEE_PAIR_BURST_MILLIS : 250;
            withPermission(str2, false, new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m48x28a9ea50(str2, inkeeFrame, i);
                }
            });
        }
    }

    /* renamed from: lambda$inkeeBroadcast$40$com-pianchang-lighting-LightingBluetoothBridge, reason: not valid java name */
    /* synthetic */ void m48x28a9ea50(String str, byte[] bArr, int i) {
        startBroadcast(str, 78, bArr, i);
    }

    private void withPermission(String str, boolean z, Runnable runnable) {
        withPermission(str, z, z ? "android.permission.BLUETOOTH_SCAN" : "android.permission.BLUETOOTH_ADVERTISE", runnable);
    }

    private void withPermission(String str, boolean z, String str2, Runnable runnable) {
        if (this.permissionRequest != null) {
            deliver(str, error("Busy", "请先完成当前的蓝牙权限请求。"));
            return;
        }
        ArrayList arrayList = new ArrayList();
        if (Build.VERSION.SDK_INT >= 31) {
            addIfMissing(arrayList, "android.permission.BLUETOOTH_CONNECT");
            if (str2 != null) {
                addIfMissing(arrayList, str2);
            }
        } else if (z) {
            addIfMissing(arrayList, "android.permission.ACCESS_FINE_LOCATION");
        }
        if (arrayList.isEmpty()) {
            runnable.run();
        } else {
            this.permissionRequest = new PermissionRequest(str, z, arrayList, runnable);
            this.activity.requestPermissions((String[]) arrayList.toArray(new String[0]), PERMISSION_REQUEST);
        }
    }

    private void addIfMissing(List<String> list, String str) {
        if (this.activity.checkSelfPermission(str) != 0) {
            list.add(str);
        }
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        PermissionRequest permissionRequest;
        if (i != PERMISSION_REQUEST || (permissionRequest = this.permissionRequest) == null || this.closed) {
            return;
        }
        this.permissionRequest = null;
        if (PermissionRequest.access$000(permissionRequest)) {
            return;
        }
        Iterator it = PermissionRequest.access$100(permissionRequest).iterator();
        while (it.hasNext()) {
            if (this.activity.checkSelfPermission((String) it.next()) != 0) {
                deliver(PermissionRequest.access$200(permissionRequest), permissionError(PermissionRequest.access$300(permissionRequest)));
                return;
            }
        }
        PermissionRequest.access$400(permissionRequest).run();
    }

    private static JSONObject permissionError(boolean z) {
        return (!z || Build.VERSION.SDK_INT >= 31) ? error("NotAllowedError", "请在系统应用权限中允许「附近的设备」，然后重试。") : error("NotAllowedError", "此安卓版本需要位置权限才能搜索蓝牙灯具。请在系统应用权限中开启后重试。");
    }

    private BluetoothAdapter adapter(String str) {
        BluetoothManager bluetoothManager = (BluetoothManager) this.activity.getSystemService("bluetooth");
        BluetoothAdapter adapter = bluetoothManager == null ? null : bluetoothManager.getAdapter();
        if (adapter == null || !this.activity.getPackageManager().hasSystemFeature("android.hardware.bluetooth_le")) {
            deliver(str, error("NotSupportedError", "这台平板没有可用的 BLE 蓝牙适配器。"));
            return null;
        }
        if (adapter.isEnabled()) {
            return adapter;
        }
        deliver(str, error("BluetoothOff", "请在平板的系统设置中开启蓝牙，然后重试。"));
        return null;
    }

    private BluetoothLeAdvertiser advertiser(String str) {
        BluetoothAdapter bluetoothAdapterAdapter = adapter(str);
        if (bluetoothAdapterAdapter == null) {
            return null;
        }
        BluetoothLeAdvertiser bluetoothLeAdvertiser = bluetoothAdapterAdapter.getBluetoothLeAdvertiser();
        if (bluetoothLeAdvertiser == null) {
            deliver(str, error("NotSupportedError", "这台平板的蓝牙适配器无法发送 BLE 广播。"));
        }
        return bluetoothLeAdvertiser;
    }

    private void startScan(String str, String str2, boolean z, Set<String> set, Set<String> set2) {
        try {
            BluetoothAdapter bluetoothAdapterAdapter = adapter(str);
            if (bluetoothAdapterAdapter == null) {
                return;
            }
            BluetoothLeScanner bluetoothLeScanner = bluetoothAdapterAdapter.getBluetoothLeScanner();
            if (bluetoothLeScanner == null) {
                deliver(str, error("NotSupportedError", "蓝牙扫描暂不可用。请确认系统蓝牙已开启。"));
                return;
            }
            ScanSession scanSession = new ScanSession(str, str2, bluetoothLeScanner, z, set, set2);
            this.session = scanSession;
            scanSession.open();
            bluetoothLeScanner.startScan((List<ScanFilter>) null, new ScanSettings.Builder().setScanMode(2).build(), scanSession);
            ScanSession.access$502(scanSession, true);
            this.handler.postDelayed(ScanSession.access$600(scanSession), 10000L);
        } catch (SecurityException unused) {
            failScan(str, permissionError(true));
        } catch (RuntimeException unused2) {
            failScan(str, error("ScanFailed", "无法启动蓝牙搜索，请检查平板的蓝牙设置后重试。"));
        }
    }

    private void failScan(String str, JSONObject jSONObject) {
        ScanSession scanSession = this.session;
        if (scanSession == null || !ScanSession.access$700(scanSession).equals(str)) {
            deliver(str, jSONObject);
        } else {
            finishScan(this.session, jSONObject);
        }
    }

    private void finishScan(ScanSession scanSession, JSONObject jSONObject) {
        if (this.session != scanSession) {
            return;
        }
        this.session = null;
        scanSession.stop();
        this.handler.removeCallbacks(ScanSession.access$600(scanSession));
        this.handler.removeCallbacks(ScanSession.access$800(scanSession));
        if (ScanSession.access$900(scanSession) != null) {
            ScanSession.access$900(scanSession).dismiss();
        }
        deliver(ScanSession.access$700(scanSession), jSONObject);
    }

    private void startProxyScan(String str) {
        try {
            BluetoothAdapter bluetoothAdapterAdapter = adapter(str);
            if (bluetoothAdapterAdapter == null) {
                return;
            }
            BluetoothLeScanner bluetoothLeScanner = bluetoothAdapterAdapter.getBluetoothLeScanner();
            if (bluetoothLeScanner == null) {
                deliver(str, error("NotSupportedError", "蓝牙扫描暂不可用。请确认系统蓝牙已开启。"));
                return;
            }
            ProxyScan proxyScan = new ProxyScan(str, bluetoothLeScanner);
            this.proxyScan = proxyScan;
            bluetoothLeScanner.startScan((List<ScanFilter>) null, new ScanSettings.Builder().setScanMode(2).build(), proxyScan);
            this.handler.postDelayed(ProxyScan.access$1000(proxyScan), 4000L);
        } catch (SecurityException unused) {
            finishProxyScan(str, permissionError(true));
        } catch (RuntimeException unused2) {
            finishProxyScan(str, error("ScanFailed", "无法搜索 Mesh 代理，请检查平板的蓝牙设置后重试。"));
        }
    }

    private void finishProxyScan(String str, JSONObject jSONObject) {
        ProxyScan proxyScan = this.proxyScan;
        if (proxyScan != null && ProxyScan.access$1100(proxyScan).equals(str)) {
            this.proxyScan = null;
            this.handler.removeCallbacks(ProxyScan.access$1000(proxyScan));
            try {
                ProxyScan.access$1200(proxyScan).stopScan(proxyScan);
            } catch (RuntimeException unused) {
            }
        }
        deliver(str, jSONObject);
    }

    /* JADX INFO: Access modifiers changed from: private */
    final class ProxyScan extends ScanCallback {
        private final String id;
        private final BluetoothLeScanner scanner;
        private final Map<String, ProxyCandidate> candidates = new LinkedHashMap();
        private final Runnable timeout = new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$ProxyScan$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                LightingBluetoothBridge.ProxyScan.$r8$lambda$7bKTXYZ4JvT7xdeefmOMstceSaw(this.f$0);
            }
        };

        public static /* synthetic */ void $r8$lambda$7bKTXYZ4JvT7xdeefmOMstceSaw(ProxyScan proxyScan) {
            proxyScan.complete();
        }

        static /* synthetic */ Runnable access$1000(ProxyScan proxyScan) {
            return proxyScan.timeout;
        }

        static /* synthetic */ String access$1100(ProxyScan proxyScan) {
            return proxyScan.id;
        }

        static /* synthetic */ BluetoothLeScanner access$1200(ProxyScan proxyScan) {
            return proxyScan.scanner;
        }

        ProxyScan(String str, BluetoothLeScanner bluetoothLeScanner) {
            this.id = str;
            this.scanner = bluetoothLeScanner;
        }

        /* renamed from: lambda$onScanResult$0$com-pianchang-lighting-LightingBluetoothBridge$ProxyScan, reason: not valid java name */
        /* synthetic */ void m81x56a36c9d(ScanResult scanResult) {
            acceptResult(scanResult);
        }

        @Override // android.bluetooth.le.ScanCallback
        public void onScanResult(int i, final ScanResult scanResult) {
            LightingBluetoothBridge.access$1300(LightingBluetoothBridge.this).post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$ProxyScan$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m81x56a36c9d(scanResult);
                }
            });
        }

        @Override // android.bluetooth.le.ScanCallback
        public void onBatchScanResults(final List<ScanResult> list) {
            LightingBluetoothBridge.access$1300(LightingBluetoothBridge.this).post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$ProxyScan$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m79xa813bf77(list);
                }
            });
        }

        /* renamed from: lambda$onBatchScanResults$1$com-pianchang-lighting-LightingBluetoothBridge$ProxyScan, reason: not valid java name */
        /* synthetic */ void m79xa813bf77(List list) {
            Iterator it = list.iterator();
            while (it.hasNext()) {
                acceptResult((ScanResult) it.next());
            }
        }

        @Override // android.bluetooth.le.ScanCallback
        public void onScanFailed(final int i) {
            LightingBluetoothBridge.access$1300(LightingBluetoothBridge.this).post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$ProxyScan$$ExternalSyntheticLambda4
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m80x9ebebabb(i);
                }
            });
        }

        /* renamed from: lambda$onScanFailed$2$com-pianchang-lighting-LightingBluetoothBridge$ProxyScan, reason: not valid java name */
        /* synthetic */ void m80x9ebebabb(int i) {
            if (LightingBluetoothBridge.access$1400(LightingBluetoothBridge.this) == this) {
                LightingBluetoothBridge.access$1800(LightingBluetoothBridge.this, this.id, LightingBluetoothBridge.error("ScanFailed", "Mesh 代理搜索失败（" + i + "）。"));
            }
        }

        private void acceptResult(ScanResult scanResult) {
            if (LightingBluetoothBridge.access$1400(LightingBluetoothBridge.this) == this && scanResult != null && scanResult.isConnectable()) {
                byte[] bArrAccess$1500 = LightingBluetoothBridge.access$1500(scanResult.getScanRecord());
                BluetoothDevice device = scanResult.getDevice();
                if (bArrAccess$1500 == null || device == null) {
                    return;
                }
                try {
                    String upperCase = device.getAddress().toUpperCase(Locale.ROOT);
                    String strAccess$1600 = LightingBluetoothBridge.access$1600(bArrAccess$1500);
                    String str = upperCase + "/" + strAccess$1600;
                    ProxyCandidate proxyCandidate = this.candidates.get(str);
                    if (proxyCandidate == null || scanResult.getRssi() > proxyCandidate.rssi) {
                        this.candidates.put(str, new ProxyCandidate(upperCase, strAccess$1600, scanResult.getRssi(), device));
                    }
                    if (this.candidates.size() > 128) {
                        Map<String, ProxyCandidate> map = this.candidates;
                        map.remove(map.keySet().iterator().next());
                    }
                } catch (SecurityException unused) {
                    LightingBluetoothBridge.access$1800(LightingBluetoothBridge.this, this.id, LightingBluetoothBridge.access$1700(true));
                }
            }
        }

        private void complete() {
            if (LightingBluetoothBridge.access$1400(LightingBluetoothBridge.this) != this) {
                return;
            }
            ArrayList<ProxyCandidate> arrayList = new ArrayList(this.candidates.values());
            arrayList.sort(Comparator.comparingInt(new ToIntFunction() { // from class: com.pianchang.lighting.LightingBluetoothBridge$ProxyScan$$ExternalSyntheticLambda0
                @Override // java.util.function.ToIntFunction
                public final int applyAsInt(Object obj) {
                    return LightingBluetoothBridge.ProxyScan.lambda$complete$3((LightingBluetoothBridge.ProxyCandidate) obj);
                }
            }).reversed());
            JSONArray jSONArray = new JSONArray();
            for (ProxyCandidate proxyCandidate : arrayList) {
                LightingBluetoothBridge.access$1900(LightingBluetoothBridge.this).remember(proxyCandidate.address, proxyCandidate.device);
                jSONArray.put(LightingBluetoothBridge.json("address", proxyCandidate.address, "beacon", proxyCandidate.beacon, "rssi", Integer.valueOf(proxyCandidate.rssi)));
            }
            LightingBluetoothBridge.access$1800(LightingBluetoothBridge.this, this.id, LightingBluetoothBridge.json("ok", true, "proxies", jSONArray));
        }

        static /* synthetic */ int lambda$complete$3(ProxyCandidate proxyCandidate) {
            return proxyCandidate.rssi;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    static final class ProxyCandidate {
        final String address;
        final String beacon;
        final BluetoothDevice device;
        final int rssi;

        ProxyCandidate(String str, String str2, int i, BluetoothDevice bluetoothDevice) {
            this.address = str;
            this.beacon = str2;
            this.rssi = i;
            this.device = bluetoothDevice;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    final class ScanSession extends ScanCallback {
        private final boolean batch;
        private final String brand;
        private AlertDialog dialog;
        private final Set<String> excludedAddresses;
        private final Set<String> excludedMeshUuids;
        private final String requestId;
        private final ArrayAdapter<ScanLamp> rows;
        private boolean sawExcludedLamp;
        private final BluetoothLeScanner scanner;
        private boolean scanning;
        private final TextView status;
        private final Map<String, ScanLamp> lamps = new LinkedHashMap();
        private final Map<String, ScanLamp> meshWithoutUuid = new LinkedHashMap();
        private final LinkedHashSet<ScanLamp> checked = new LinkedHashSet<>();
        private final Runnable scanTimeout = new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$ScanSession$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                LightingBluetoothBridge.ScanSession.m82$r8$lambda$fREGpXxRyuh_PNji_0sjCN6vKE(this.f$0);
            }
        };
        private final Runnable selectionTimeout = new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$ScanSession$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m83x32e77d3e();
            }
        };

        /* renamed from: $r8$lambda$fREGpXxRyuh_PNj-i_0sjCN6vKE, reason: not valid java name */
        public static /* synthetic */ void m82$r8$lambda$fREGpXxRyuh_PNji_0sjCN6vKE(ScanSession scanSession) {
            scanSession.finishDiscovery();
        }

        static /* synthetic */ boolean access$502(ScanSession scanSession, boolean z) {
            scanSession.scanning = z;
            return z;
        }

        static /* synthetic */ Runnable access$600(ScanSession scanSession) {
            return scanSession.scanTimeout;
        }

        static /* synthetic */ String access$700(ScanSession scanSession) {
            return scanSession.requestId;
        }

        static /* synthetic */ Runnable access$800(ScanSession scanSession) {
            return scanSession.selectionTimeout;
        }

        static /* synthetic */ AlertDialog access$900(ScanSession scanSession) {
            return scanSession.dialog;
        }

        /* renamed from: lambda$new$0$com-pianchang-lighting-LightingBluetoothBridge$ScanSession, reason: not valid java name */
        /* synthetic */ void m83x32e77d3e() {
            LightingBluetoothBridge.access$2700(LightingBluetoothBridge.this, this, LightingBluetoothBridge.access$2800());
        }

        ScanSession(String str, String str2, BluetoothLeScanner bluetoothLeScanner, boolean z, Set<String> set, Set<String> set2) {
            this.requestId = str;
            this.brand = str2;
            this.scanner = bluetoothLeScanner;
            this.batch = z;
            this.excludedAddresses = set;
            this.excludedMeshUuids = set2;
            this.rows = new ArrayAdapter<>(LightingBluetoothBridge.access$2000(LightingBluetoothBridge.this), z ? android.R.layout.simple_list_item_multiple_choice : android.R.layout.simple_list_item_1);
            this.status = new TextView(LightingBluetoothBridge.access$2000(LightingBluetoothBridge.this));
        }

        void open() {
            LinearLayout linearLayout = new LinearLayout(LightingBluetoothBridge.access$2000(LightingBluetoothBridge.this));
            linearLayout.setOrientation(1);
            linearLayout.setPadding(LightingBluetoothBridge.access$2100(LightingBluetoothBridge.this, 24), LightingBluetoothBridge.access$2100(LightingBluetoothBridge.this, 12), LightingBluetoothBridge.access$2100(LightingBluetoothBridge.this, 24), 0);
            this.status.setText(this.brand + " · 正在搜索附近灯具…");
            linearLayout.addView(this.status);
            final ListView listView = new ListView(LightingBluetoothBridge.access$2000(LightingBluetoothBridge.this));
            if (this.batch) {
                listView.setChoiceMode(2);
            }
            listView.setAdapter((ListAdapter) this.rows);
            listView.setContentDescription("附近的蓝牙灯具");
            linearLayout.addView(listView, new LinearLayout.LayoutParams(-1, LightingBluetoothBridge.access$2100(LightingBluetoothBridge.this, 220)));
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.pianchang.lighting.LightingBluetoothBridge$ScanSession$$ExternalSyntheticLambda0
                @Override // android.widget.AdapterView.OnItemClickListener
                public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
                    this.f$0.m87x9f7e9959(listView, adapterView, view, i, j);
                }
            });
            AlertDialog.Builder negativeButton = new AlertDialog.Builder(LightingBluetoothBridge.access$2000(LightingBluetoothBridge.this)).setTitle(this.batch ? "勾选蓝牙灯具" : "选择蓝牙灯具").setView(linearLayout).setNegativeButton("取消", new DialogInterface.OnClickListener() { // from class: com.pianchang.lighting.LightingBluetoothBridge$ScanSession$$ExternalSyntheticLambda1
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m88xa58264b8(dialogInterface, i);
                }
            });
            if (this.batch) {
                negativeButton.setPositiveButton("确认选择", new DialogInterface.OnClickListener() { // from class: com.pianchang.lighting.LightingBluetoothBridge$ScanSession$$ExternalSyntheticLambda2
                    @Override // android.content.DialogInterface.OnClickListener
                    public final void onClick(DialogInterface dialogInterface, int i) {
                        this.f$0.m89xab863017(dialogInterface, i);
                    }
                });
            }
            AlertDialog alertDialogCreate = negativeButton.create();
            this.dialog = alertDialogCreate;
            alertDialogCreate.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.pianchang.lighting.LightingBluetoothBridge$ScanSession$$ExternalSyntheticLambda3
                @Override // android.content.DialogInterface.OnDismissListener
                public final void onDismiss(DialogInterface dialogInterface) {
                    this.f$0.m90xb189fb76(dialogInterface);
                }
            });
            this.dialog.show();
            if (this.batch) {
                updateSelectionButton();
            }
        }

        /* renamed from: lambda$open$1$com-pianchang-lighting-LightingBluetoothBridge$ScanSession, reason: not valid java name */
        /* synthetic */ void m87x9f7e9959(ListView listView, AdapterView adapterView, View view, int i, long j) {
            ScanLamp item = this.rows.getItem(i);
            if (!this.batch) {
                LightingBluetoothBridge.access$2700(LightingBluetoothBridge.this, this, LightingBluetoothBridge.json("ok", true, "device", select(item)));
                return;
            }
            if (listView.isItemChecked(i)) {
                this.checked.add(item);
            } else {
                this.checked.remove(item);
            }
            updateSelectionButton();
        }

        /* renamed from: lambda$open$2$com-pianchang-lighting-LightingBluetoothBridge$ScanSession, reason: not valid java name */
        /* synthetic */ void m88xa58264b8(DialogInterface dialogInterface, int i) {
            LightingBluetoothBridge.access$2700(LightingBluetoothBridge.this, this, LightingBluetoothBridge.access$2800());
        }

        /* renamed from: lambda$open$3$com-pianchang-lighting-LightingBluetoothBridge$ScanSession, reason: not valid java name */
        /* synthetic */ void m89xab863017(DialogInterface dialogInterface, int i) {
            JSONArray jSONArray = new JSONArray();
            Iterator<ScanLamp> it = this.checked.iterator();
            while (it.hasNext()) {
                jSONArray.put(select(it.next()));
            }
            LightingBluetoothBridge.access$2700(LightingBluetoothBridge.this, this, LightingBluetoothBridge.json("ok", true, "devices", jSONArray));
        }

        /* renamed from: lambda$open$4$com-pianchang-lighting-LightingBluetoothBridge$ScanSession, reason: not valid java name */
        /* synthetic */ void m90xb189fb76(DialogInterface dialogInterface) {
            LightingBluetoothBridge.access$2700(LightingBluetoothBridge.this, this, LightingBluetoothBridge.access$2800());
        }

        private void updateSelectionButton() {
            String str;
            Button button = this.dialog.getButton(-1);
            button.setEnabled(!this.checked.isEmpty());
            if (this.checked.isEmpty()) {
                str = "确认选择";
            } else {
                str = "确认选择（" + this.checked.size() + "）";
            }
            button.setText(str);
        }

        private JSONObject select(ScanLamp scanLamp) {
            StringBuilder sb = new StringBuilder("ble-");
            sb.append(UUID.nameUUIDFromBytes((LightingBluetoothBridge.access$2000(LightingBluetoothBridge.this).getPackageName() + ":" + scanLamp.address).getBytes(StandardCharsets.UTF_8)));
            String string = sb.toString();
            LightingBluetoothBridge.access$1900(LightingBluetoothBridge.this).remember(scanLamp.address, scanLamp.device);
            byte[] bArr = scanLamp.meshUuid;
            if (bArr == null) {
                return LightingBluetoothBridge.json("id", string, "name", scanLamp.name, "address", scanLamp.address, "variant", scanLamp.variant, "productCode", scanLamp.productCode);
            }
            return LightingBluetoothBridge.json("id", string, "name", scanLamp.name, "address", scanLamp.address, "variant", scanLamp.variant, "meshUuid", LightingBluetoothBridge.access$1600(bArr), "meshModel", LightingBluetoothBridge.access$1600(Arrays.copyOfRange(bArr, 10, 13)).toUpperCase(Locale.ROOT), "meshVersion", Integer.valueOf(LightingBluetoothBridge.access$2200(bArr, 8) & 1023), "channel", Integer.valueOf(LightingBluetoothBridge.access$2200(bArr, 6)));
        }

        /* renamed from: lambda$onScanResult$5$com-pianchang-lighting-LightingBluetoothBridge$ScanSession, reason: not valid java name */
        /* synthetic */ void m86xe2d86846(ScanResult scanResult) {
            acceptResult(scanResult);
        }

        @Override // android.bluetooth.le.ScanCallback
        public void onScanResult(int i, final ScanResult scanResult) {
            LightingBluetoothBridge.access$1300(LightingBluetoothBridge.this).post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$ScanSession$$ExternalSyntheticLambda6
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m86xe2d86846(scanResult);
                }
            });
        }

        @Override // android.bluetooth.le.ScanCallback
        public void onBatchScanResults(final List<ScanResult> list) {
            LightingBluetoothBridge.access$1300(LightingBluetoothBridge.this).post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$ScanSession$$ExternalSyntheticLambda8
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m84x997f6ca0(list);
                }
            });
        }

        /* renamed from: lambda$onBatchScanResults$6$com-pianchang-lighting-LightingBluetoothBridge$ScanSession, reason: not valid java name */
        /* synthetic */ void m84x997f6ca0(List list) {
            Iterator it = list.iterator();
            while (it.hasNext()) {
                acceptResult((ScanResult) it.next());
            }
        }

        /* renamed from: lambda$onScanFailed$7$com-pianchang-lighting-LightingBluetoothBridge$ScanSession, reason: not valid java name */
        /* synthetic */ void m85x9158a6e4(int i) {
            LightingBluetoothBridge.access$2700(LightingBluetoothBridge.this, this, LightingBluetoothBridge.error("ScanFailed", "蓝牙扫描失败（" + i + "），请稍后重试。"));
        }

        @Override // android.bluetooth.le.ScanCallback
        public void onScanFailed(final int i) {
            LightingBluetoothBridge.access$1300(LightingBluetoothBridge.this).post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$ScanSession$$ExternalSyntheticLambda7
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m85x9158a6e4(i);
                }
            });
        }

        /* JADX WARN: Removed duplicated region for block: B:73:0x00f4  */
        /* JADX WARN: Removed duplicated region for block: B:74:0x00f5  */
        /* JADX WARN: Removed duplicated region for block: B:83:0x011d  */
        /* JADX WARN: Removed duplicated region for block: B:91:0x0138 A[Catch: SecurityException -> 0x016d, TryCatch #0 {SecurityException -> 0x016d, blocks: (B:13:0x0021, B:16:0x0029, B:19:0x0037, B:28:0x0062, B:32:0x006c, B:42:0x008c, B:46:0x0099, B:40:0x0084, B:37:0x007c, B:58:0x00b7, B:61:0x00be, B:63:0x00c6, B:66:0x00d1, B:71:0x00ee, B:75:0x00f6, B:78:0x0100, B:81:0x0113, B:84:0x011f, B:86:0x0123, B:89:0x012c, B:91:0x0138, B:93:0x0143, B:95:0x0149, B:97:0x0151, B:99:0x0157, B:100:0x0160, B:69:0x00d9, B:55:0x00ae, B:18:0x0033), top: B:104:0x0021 }] */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        private void acceptResult(android.bluetooth.le.ScanResult r13) {
            /*
                Method dump skipped, instructions count: 375
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: com.pianchang.lighting.LightingBluetoothBridge.ScanSession.acceptResult(android.bluetooth.le.ScanResult):void");
        }

        private void addLamp(ScanLamp scanLamp) {
            this.lamps.put(scanLamp.address, scanLamp);
            this.rows.add(scanLamp);
            this.status.setText(this.brand + " · 已找到 " + this.lamps.size() + " 台设备");
        }

        private void finishDiscovery() {
            String str;
            if (LightingBluetoothBridge.access$2300(LightingBluetoothBridge.this) != this) {
                return;
            }
            stop();
            Iterator<ScanLamp> it = this.meshWithoutUuid.values().iterator();
            while (it.hasNext()) {
                addLamp(it.next());
            }
            this.meshWithoutUuid.clear();
            if (this.lamps.isEmpty()) {
                if (this.sawExcludedLamp) {
                    LightingBluetoothBridge.access$2700(LightingBluetoothBridge.this, this, LightingBluetoothBridge.error("AlreadyAdded", "附近可识别的灯具都已添加到当前工程。"));
                    return;
                }
                if (Build.VERSION.SDK_INT < 31) {
                    str = "未找到匹配灯具。请确认灯具已开启，并检查平板的定位开关。";
                } else {
                    str = "未找到匹配灯具。请确认灯具已开启并处于蓝牙发现状态。";
                }
                LightingBluetoothBridge.access$2700(LightingBluetoothBridge.this, this, LightingBluetoothBridge.error("NotFoundError", str));
                return;
            }
            TextView textView = this.status;
            StringBuilder sb = new StringBuilder();
            sb.append(this.brand);
            sb.append(this.batch ? " · 请勾选需要添加的灯具" : " · 请选择灯具");
            textView.setText(sb.toString());
            LightingBluetoothBridge.access$1300(LightingBluetoothBridge.this).postDelayed(this.selectionTimeout, this.batch ? 75000L : 30000L);
        }

        void stop() {
            if (this.scanning) {
                this.scanning = false;
                try {
                    this.scanner.stopScan(this);
                } catch (RuntimeException unused) {
                }
            }
        }
    }

    private static final class ScanLamp {
        final String address;
        BluetoothDevice device;
        byte[] meshUuid;
        String name;
        final String productCode;
        final String variant;

        ScanLamp(String str, String str2, String str3, String str4, BluetoothDevice bluetoothDevice, byte[] bArr) {
            this.address = str;
            this.name = str2;
            this.variant = str3;
            this.productCode = str4;
            this.device = bluetoothDevice;
            this.meshUuid = bArr;
        }

        public String toString() {
            String str;
            if ("mesh-proxy".equals(this.variant)) {
                str = "  ·  Mesh 已组网";
            } else if (this.meshUuid != null) {
                str = "  ·  CH" + LightingBluetoothBridge.access$2200(this.meshUuid, 6);
            } else {
                str = "";
            }
            return this.name + str + "  ·  " + this.address;
        }
    }

    private int dp(int i) {
        return Math.round(i * this.activity.getResources().getDisplayMetrics().density);
    }

    private static String variantFor(String str, String str2, ScanRecord scanRecord, byte[] bArr) {
        byte[] manufacturerSpecificData;
        if ("XSJ".equals(str)) {
            if (str2 == null || !str2.toUpperCase(Locale.ROOT).contains("GFMESH")) {
                return null;
            }
            return "xsj";
        }
        if (YONGNUO_BRAND.equals(str)) {
            String lowerCase = str2 == null ? "" : str2.toLowerCase(Locale.ROOT);
            if (lowerCase.contains("yongnuo") || lowerCase.startsWith("yn") || lowerCase.contains("p360")) {
                return "yongnuo";
            }
            return null;
        }
        if (scanRecord != null && (manufacturerSpecificData = scanRecord.getManufacturerSpecificData(NETRIX_MANUFACTURER)) != null && manufacturerSpecificData.length >= 12 && (manufacturerSpecificData[3] & FUDistributor.UPDATE_TTL) == 33) {
            return "netrix";
        }
        if (str2 != null && (str2.startsWith("``NL ") || str2.startsWith("..NL "))) {
            return "usr";
        }
        if (scanRecord == null) {
            return null;
        }
        List<ParcelUuid> serviceUuids = scanRecord.getServiceUuids();
        if (bArr == null) {
            if (serviceUuids != null && serviceUuids.contains(MESH_PROVISIONING)) {
                return "mesh";
            }
            if (proxyBeacon(scanRecord) != null) {
                return "mesh-proxy";
            }
            return null;
        }
        return "mesh";
    }

    private static byte[] meshProvisioningUuid(ScanRecord scanRecord) {
        int i;
        if (scanRecord == null) {
            return null;
        }
        byte[] serviceData = scanRecord.getServiceData(MESH_PROVISIONING);
        if (serviceData != null && serviceData.length >= 18) {
            return Arrays.copyOf(serviceData, 16);
        }
        byte[] bytes = scanRecord.getBytes();
        if (bytes == null) {
            return null;
        }
        int i2 = 0;
        while (i2 < bytes.length && (i = bytes[i2] & FUDistributor.UPDATE_TTL) != 0) {
            int i3 = i2 + 1;
            if (i3 + i > bytes.length) {
                break;
            }
            if ((bytes[i3] & FUDistributor.UPDATE_TTL) == 43 && i >= 20 && bytes[i2 + 2] == 0) {
                return Arrays.copyOfRange(bytes, i2 + 3, i2 + 19);
            }
            i2 += i + 1;
        }
        return null;
    }

    private static byte[] proxyBeacon(ScanRecord scanRecord) {
        byte[] serviceData;
        if (scanRecord == null || (serviceData = scanRecord.getServiceData(MESH_PROXY)) == null) {
            return null;
        }
        if ((serviceData.length == 9 && serviceData[0] == 0) || (serviceData.length == 17 && serviceData[0] == 1)) {
            return serviceData;
        }
        return null;
    }

    private static int meshWord(byte[] bArr, int i) {
        return (bArr[i + 1] & FUDistributor.UPDATE_TTL) | ((bArr[i] & FUDistributor.UPDATE_TTL) << 8);
    }

    private static String encodeHex(byte[] bArr) {
        char[] cArr = new char[bArr.length * 2];
        for (int i = 0; i < bArr.length; i++) {
            byte b = bArr[i];
            int i2 = b & FUDistributor.UPDATE_TTL;
            int i3 = i * 2;
            char[] cArr2 = HEX_DIGITS;
            cArr[i3] = cArr2[i2 >>> 4];
            cArr[i3 + 1] = cArr2[b & 15];
        }
        return new String(cArr);
    }

    private static JSONObject cancelledScan() {
        return error("NotFoundError", "已取消搜索。");
    }

    private void startBroadcast(String str, int i, byte[] bArr, int i2) {
        if (this.broadcast != null) {
            deliver(str, error("Busy", "正在发送上一条广播，请稍后重试。"));
            return;
        }
        try {
            BluetoothLeAdvertiser bluetoothLeAdvertiserAdvertiser = advertiser(str);
            if (bluetoothLeAdvertiserAdvertiser == null) {
                return;
            }
            BroadcastSession broadcastSession = new BroadcastSession(str, bluetoothLeAdvertiserAdvertiser, i2);
            this.broadcast = broadcastSession;
            bluetoothLeAdvertiserAdvertiser.startAdvertising(new AdvertiseSettings.Builder().setAdvertiseMode(2).setTxPowerLevel(3).setConnectable(true).setTimeout(i2 + CipherSuite.TLS_RSA_WITH_SEED_CBC_SHA).build(), new AdvertiseData.Builder().setIncludeDeviceName(false).setIncludeTxPowerLevel(false).addManufacturerData(i, bArr).build(), broadcastSession);
            this.handler.postDelayed(BroadcastSession.access$2900(broadcastSession), 1500L);
        } catch (SecurityException unused) {
            failBroadcast(str, permissionError(false));
        } catch (RuntimeException unused2) {
            failBroadcast(str, error("BroadcastFailed", "安卓无法启动蓝牙广播。请检查平板的蓝牙状态后重试。"));
        }
    }

    private void failBroadcast(String str, JSONObject jSONObject) {
        BroadcastSession broadcastSession = this.broadcast;
        if (broadcastSession == null || !BroadcastSession.access$3000(broadcastSession).equals(str)) {
            deliver(str, jSONObject);
        } else {
            finishBroadcast(this.broadcast, jSONObject);
        }
    }

    private void finishBroadcast(BroadcastSession broadcastSession, JSONObject jSONObject) {
        if (this.broadcast != broadcastSession) {
            return;
        }
        this.broadcast = null;
        this.handler.removeCallbacks(BroadcastSession.access$2900(broadcastSession));
        this.handler.removeCallbacks(BroadcastSession.access$3100(broadcastSession));
        broadcastSession.stop();
        deliver(BroadcastSession.access$3000(broadcastSession), jSONObject);
    }

    /* JADX INFO: Access modifiers changed from: private */
    final class BroadcastSession extends AdvertiseCallback {
        private final BluetoothLeAdvertiser advertiser;
        private final int burstMillis;
        private final String requestId;
        private final Runnable startTimeout = new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$BroadcastSession$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m75x94362dd0();
            }
        };
        private final Runnable complete = new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$BroadcastSession$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m76xe1f5a5d1();
            }
        };

        static /* synthetic */ Runnable access$2900(BroadcastSession broadcastSession) {
            return broadcastSession.startTimeout;
        }

        static /* synthetic */ String access$3000(BroadcastSession broadcastSession) {
            return broadcastSession.requestId;
        }

        static /* synthetic */ Runnable access$3100(BroadcastSession broadcastSession) {
            return broadcastSession.complete;
        }

        /* renamed from: lambda$new$0$com-pianchang-lighting-LightingBluetoothBridge$BroadcastSession, reason: not valid java name */
        /* synthetic */ void m75x94362dd0() {
            LightingBluetoothBridge.access$3200(LightingBluetoothBridge.this, this, LightingBluetoothBridge.error("Timeout", "等待蓝牙广播启动超时。"));
        }

        /* renamed from: lambda$new$1$com-pianchang-lighting-LightingBluetoothBridge$BroadcastSession, reason: not valid java name */
        /* synthetic */ void m76xe1f5a5d1() {
            LightingBluetoothBridge.access$3200(LightingBluetoothBridge.this, this, LightingBluetoothBridge.json("ok", true, "status", "started"));
        }

        BroadcastSession(String str, BluetoothLeAdvertiser bluetoothLeAdvertiser, int i) {
            this.requestId = str;
            this.advertiser = bluetoothLeAdvertiser;
            this.burstMillis = i;
        }

        @Override // android.bluetooth.le.AdvertiseCallback
        public void onStartSuccess(AdvertiseSettings advertiseSettings) {
            LightingBluetoothBridge.access$1300(LightingBluetoothBridge.this).post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$BroadcastSession$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m78x40961b4c();
                }
            });
        }

        /* renamed from: lambda$onStartSuccess$2$com-pianchang-lighting-LightingBluetoothBridge$BroadcastSession, reason: not valid java name */
        /* synthetic */ void m78x40961b4c() {
            if (LightingBluetoothBridge.access$3300(LightingBluetoothBridge.this) != this) {
                stop();
            } else {
                LightingBluetoothBridge.access$1300(LightingBluetoothBridge.this).removeCallbacks(this.startTimeout);
                LightingBluetoothBridge.access$1300(LightingBluetoothBridge.this).postDelayed(this.complete, this.burstMillis);
            }
        }

        /* renamed from: lambda$onStartFailure$3$com-pianchang-lighting-LightingBluetoothBridge$BroadcastSession, reason: not valid java name */
        /* synthetic */ void m77xbe48714(int i) {
            LightingBluetoothBridge.access$3200(LightingBluetoothBridge.this, this, LightingBluetoothBridge.error("BroadcastFailed", "安卓蓝牙广播启动失败（" + i + "）。"));
        }

        @Override // android.bluetooth.le.AdvertiseCallback
        public void onStartFailure(final int i) {
            LightingBluetoothBridge.access$1300(LightingBluetoothBridge.this).post(new Runnable() { // from class: com.pianchang.lighting.LightingBluetoothBridge$BroadcastSession$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m77xbe48714(i);
                }
            });
        }

        void stop() {
            try {
                this.advertiser.stopAdvertising(this);
            } catch (RuntimeException unused) {
            }
        }
    }

    private static boolean validRequestId(String str) {
        return str != null && REQUEST_ID.matcher(str).matches();
    }

    private static boolean validLydFrame(String str) throws NumberFormatException {
        if (str == null || !LYD_FRAME.matcher(str).matches()) {
            return false;
        }
        long j = Long.parseLong(str.substring(28, 36), 16);
        int i = Integer.parseInt(str.substring(36, 40), 16);
        int i2 = Integer.parseInt(str.substring(40, 44), 16);
        int i3 = Integer.parseInt(str.substring(44, 46), 16);
        if (j < 1 || j > 100 || (i & 7) >= 6 || i3 > 100) {
            return false;
        }
        if ((32768 & i) != 0) {
            return (i & 255) <= 5 && ((i & 32512) >> 8) <= 100 && i2 <= 360;
        }
        if (i <= 5) {
            return i2 >= 12800 && i2 <= 50688 && i2 % 512 == 0;
        }
        int i4 = i >> 3;
        return i4 >= 1 && i4 <= 24 && i2 == 0;
    }

    private static byte[] parseInkeeFrame(String str) {
        if (str == null || !INKEE_FRAME.matcher(str).matches()) {
            return null;
        }
        byte[] bArrDecodeFrame = decodeFrame(str);
        if (validInkeeFrame(bArrDecodeFrame)) {
            return bArrDecodeFrame;
        }
        return null;
    }

    private static boolean validInkeeFrame(byte[] bArr) {
        if (bArr[15] != 0) {
            return false;
        }
        boolean z = bArr[6] == -1 && bArr[7] == -1 && bArr[8] == -1;
        int i = bArr[9] & FUDistributor.UPDATE_TTL;
        int i2 = bArr[10] & FUDistributor.UPDATE_TTL;
        if (i2 == 16) {
            if (z && i == 254 && (bArr[14] & FUDistributor.UPDATE_TTL) >= 2) {
                return (bArr[11] == -1 && bArr[12] == -1 && bArr[13] == -1) ? false : true;
            }
            return false;
        }
        if (z || i < 2 || bArr[11] != 0 || bArr[12] != 1) {
            return false;
        }
        if (i2 == 70) {
            return (bArr[13] & FUDistributor.UPDATE_TTL) <= 100 && bArr[14] == 0;
        }
        switch (i2) {
            case 65:
            case 66:
                return bArr[13] == 1 && bArr[14] == 0;
            case 67:
                return bArr[13] == 0 && (bArr[14] & FUDistributor.UPDATE_TTL) <= 100;
            default:
                return false;
        }
    }

    private static byte[] decodeFrame(String str) {
        int length = str.length() / 2;
        byte[] bArr = new byte[length];
        for (int i = 0; i < length; i++) {
            int i2 = i * 2;
            bArr[i] = (byte) Integer.parseInt(str.substring(i2, i2 + 2), 16);
        }
        return bArr;
    }

    static JSONObject error(String str, String str2) {
        return json("ok", false, "code", str, "message", str2);
    }

    static JSONObject json(Object... objArr) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        for (int i = 0; i < objArr.length; i += 2) {
            try {
                jSONObject.put((String) objArr[i], objArr[i + 1]);
            } catch (JSONException e) {
                throw new IllegalArgumentException(e);
            }
        }
        return jSONObject;
    }

    private void deliver(String str, JSONObject jSONObject) {
        deliver("onLightingAndroidResult", str, jSONObject);
    }

    private void deliverSidusProgress(String str, JSONObject jSONObject) {
        deliver("onLightingAndroidSidusProgress", str, jSONObject);
    }

    private void deliver(String str, String str2, JSONObject jSONObject) {
        if (this.closed || this.activity.isFinishing() || this.activity.isDestroyed()) {
            return;
        }
        String strReplace = jSONObject.toString().replace("\u2028", "\\u2028").replace("\u2029", "\\u2029");
        this.webView.evaluateJavascript("if(window." + str + ")window." + str + "(" + JSONObject.quote(str2) + "," + strReplace + ")", null);
    }

    private void deliverGattNotification(String str, byte[] bArr) {
        if (this.closed || this.activity.isFinishing() || this.activity.isDestroyed()) {
            return;
        }
        this.webView.evaluateJavascript("if(window.onLightingAndroidGattNotification)window.onLightingAndroidGattNotification(" + JSONObject.quote(str) + "," + JSONObject.quote(encodeHex(bArr)) + ")", null);
    }

    private void deliverGattLinkLost(String str) {
        if (this.closed || this.activity.isFinishing() || this.activity.isDestroyed()) {
            return;
        }
        this.webView.evaluateJavascript("if(window.onLightingAndroidGattLinkLost)window.onLightingAndroidGattLinkLost(" + JSONObject.quote(str) + ")", null);
    }

    private void deliverMeshLinkLost(String str, String str2) {
        if (this.closed || this.activity.isFinishing() || this.activity.isDestroyed()) {
            return;
        }
        this.webView.evaluateJavascript("if(window." + str + ")window." + str + "(" + JSONObject.quote(str2) + ")", null);
    }

    public void close() {
        this.closed = true;
        this.permissionRequest = null;
        this.handler.removeCallbacksAndMessages(null);
        this.gatt.close();
        this.godox.close();
        this.sidus.close();
        this.lumin.close();
        this.jinbei.close();
        ScanSession scanSession = this.session;
        if (scanSession != null) {
            finishScan(scanSession, cancelledScan());
        }
        ProxyScan proxyScan = this.proxyScan;
        if (proxyScan != null) {
            finishProxyScan(ProxyScan.access$1100(proxyScan), cancelledScan());
        }
        BroadcastSession broadcastSession = this.broadcast;
        if (broadcastSession != null) {
            finishBroadcast(broadcastSession, error("Cancelled", "已结束广播。"));
        }
    }

    private static final class PermissionRequest {
        private boolean cancellableSidusScan;
        private boolean cancelled;
        private final List<String> permissions;
        private final String requestId;
        private final Runnable run;
        private final boolean scan;

        static /* synthetic */ boolean access$000(PermissionRequest permissionRequest) {
            return permissionRequest.cancelled;
        }

        static /* synthetic */ boolean access$002(PermissionRequest permissionRequest, boolean z) {
            permissionRequest.cancelled = z;
            return z;
        }

        static /* synthetic */ List access$100(PermissionRequest permissionRequest) {
            return permissionRequest.permissions;
        }

        static /* synthetic */ String access$200(PermissionRequest permissionRequest) {
            return permissionRequest.requestId;
        }

        static /* synthetic */ boolean access$300(PermissionRequest permissionRequest) {
            return permissionRequest.scan;
        }

        static /* synthetic */ boolean access$3400(PermissionRequest permissionRequest) {
            return permissionRequest.cancellableSidusScan;
        }

        static /* synthetic */ boolean access$3402(PermissionRequest permissionRequest, boolean z) {
            permissionRequest.cancellableSidusScan = z;
            return z;
        }

        static /* synthetic */ Runnable access$400(PermissionRequest permissionRequest) {
            return permissionRequest.run;
        }

        PermissionRequest(String str, boolean z, List<String> list, Runnable runnable) {
            this.requestId = str;
            this.scan = z;
            this.permissions = list;
            this.run = runnable;
        }
    }
}
