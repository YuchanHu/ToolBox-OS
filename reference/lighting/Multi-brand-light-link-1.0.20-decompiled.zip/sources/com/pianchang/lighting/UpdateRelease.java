package com.pianchang.lighting;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.spongycastle.asn1.cmp.PKIFailureInfo;

/* loaded from: classes.dex */
final class UpdateRelease {
    static final long MAX_APK_BYTES = 104857600;
    private static final int MAX_METADATA = 1048576;
    private static final Pattern VERSION = Pattern.compile("[vV]?(\\d{1,9})\\.(\\d{1,9})\\.(\\d{1,9})");
    final URI apkUrl;
    final String digest;
    final String releaseNotes;
    final long size;
    final Source source;
    final String version;

    enum Source {
        GITEE("Gitee", "gitee.com", "Dogbrother0113/Multi-brand-light-link", "https://gitee.com/api/v5/repos/"),
        GITHUB("GitHub", "github.com", "Dog-brother0113/Multi-brand-light-link", "https://api.github.com/repos/");

        final String host;
        final String label;
        final URI latest;
        final String repo;

        Source(String str, String str2, String str3, String str4) {
            this.label = str;
            this.host = str2;
            this.repo = str3;
            this.latest = URI.create(str4 + str3 + "/releases/latest");
        }
    }

    private UpdateRelease(Source source, String str, String str2, URI uri, long j, String str3) {
        this.source = source;
        this.version = str;
        this.releaseNotes = str2;
        this.apkUrl = uri;
        this.size = j;
        this.digest = str3;
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x001c  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0022 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    static com.pianchang.lighting.UpdateRelease check(java.lang.String r8) throws java.io.IOException {
        /*
            com.pianchang.lighting.UpdateRelease$Source[] r0 = com.pianchang.lighting.UpdateRelease.Source.values()
            int r1 = r0.length
            r2 = 0
            r3 = 0
            r4 = r2
            r5 = r3
            r6 = r5
        La:
            if (r2 >= r1) goto L25
            r7 = r0[r2]
            com.pianchang.lighting.UpdateRelease r4 = fetch(r7, r8)     // Catch: org.json.JSONException -> L17 java.io.IOException -> L19 com.pianchang.lighting.UpdateRelease.MissingApk -> L1e
            if (r4 == 0) goto L15
            return r4
        L15:
            r4 = 1
            goto L22
        L17:
            r7 = move-exception
            goto L1a
        L19:
            r7 = move-exception
        L1a:
            if (r6 != 0) goto L22
            r6 = r7
            goto L22
        L1e:
            r7 = move-exception
            if (r5 != 0) goto L22
            r5 = r7
        L22:
            int r2 = r2 + 1
            goto La
        L25:
            if (r5 != 0) goto L39
            if (r4 == 0) goto L2a
            return r3
        L2a:
            boolean r8 = r6 instanceof com.pianchang.lighting.UpdateRelease.Failure
            if (r8 == 0) goto L31
            com.pianchang.lighting.UpdateRelease$Failure r6 = (com.pianchang.lighting.UpdateRelease.Failure) r6
            throw r6
        L31:
            com.pianchang.lighting.UpdateRelease$Failure r8 = new com.pianchang.lighting.UpdateRelease$Failure
            java.lang.String r0 = "无法检查更新，请确认网络可以访问 Gitee 或 GitHub 后重试。"
            r8.<init>(r0)
            throw r8
        L39:
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.pianchang.lighting.UpdateRelease.check(java.lang.String):com.pianchang.lighting.UpdateRelease");
    }

    private static UpdateRelease fetch(Source source, String str) throws JSONException, IOException {
        HttpsURLConnection httpsURLConnectionConnect = connect(source.latest);
        try {
            httpsURLConnectionConnect.setConnectTimeout(5000);
            httpsURLConnectionConnect.setReadTimeout(6000);
            httpsURLConnectionConnect.setRequestProperty("Accept", source == Source.GITHUB ? "application/vnd.github+json" : "application/json");
            int responseCode = httpsURLConnectionConnect.getResponseCode();
            if (responseCode == 404) {
                httpsURLConnectionConnect.disconnect();
                return null;
            }
            if (responseCode == 403 || responseCode == 429) {
                throw new Failure(source.label + " 暂时限制了更新查询，请稍后重试。");
            }
            if (responseCode != 200) {
                throw new Failure(source.label + " 更新服务暂不可用（HTTP " + responseCode + "）。");
            }
            InputStream inputStream = httpsURLConnectionConnect.getInputStream();
            try {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                try {
                    byte[] bArr = new byte[PKIFailureInfo.certRevoked];
                    long jNanoTime = System.nanoTime();
                    while (true) {
                        int i = inputStream.read(bArr);
                        if (i != -1) {
                            if (byteArrayOutputStream.size() + i > 1048576) {
                                throw new Failure("更新信息过大。");
                            }
                            if (System.nanoTime() - jNanoTime > 7000000000L) {
                                throw new IOException("Metadata response timed out");
                            }
                            byteArrayOutputStream.write(bArr, 0, i);
                        } else {
                            UpdateRelease updateRelease = parse(source, new JSONObject(new String(byteArrayOutputStream.toByteArray(), StandardCharsets.UTF_8)), str);
                            byteArrayOutputStream.close();
                            if (inputStream != null) {
                                inputStream.close();
                            }
                            return updateRelease;
                        }
                    }
                } finally {
                }
            } finally {
            }
        } finally {
            httpsURLConnectionConnect.disconnect();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r16v3 */
    static UpdateRelease parse(Source source, JSONObject jSONObject, String str) throws IOException {
        boolean z;
        String str2;
        UpdateRelease updateRelease;
        int i;
        JSONArray jSONArray;
        String str3;
        String str4;
        boolean z2;
        URI uriCreate;
        UpdateRelease updateRelease2 = null;
        if (jSONObject.optBoolean("draft") || jSONObject.optBoolean("prerelease")) {
            return null;
        }
        String strOptString = jSONObject.optString("tag_name");
        if (compareVersions(strOptString, str) <= 0) {
            return null;
        }
        String str5 = "";
        String strReplaceFirst = strOptString.replaceFirst("^[vV]", "");
        Object objOpt = jSONObject.opt("body");
        String strTrim = objOpt instanceof String ? ((String) objOpt).trim() : "";
        String str6 = "Multi-brand.light.link-v" + strReplaceFirst + ".apk";
        String str7 = "片场灯光台-v" + strReplaceFirst + ".apk";
        String str8 = "/" + source.repo + "/releases/download/" + strOptString + "/";
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("assets");
        boolean z3 = false;
        boolean z4 = true;
        if (jSONArrayOptJSONArray != null) {
            int i2 = 0;
            int i3 = 0;
            while (i2 < jSONArrayOptJSONArray.length()) {
                JSONObject jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(i2);
                if (jSONObjectOptJSONObject != null && (!((jSONObjectOptJSONObject.isNull("state") ^ z4) || source == Source.GITHUB) || "uploaded".equals(jSONObjectOptJSONObject.optString("state")))) {
                    String strOptString2 = jSONObjectOptJSONObject.optString("name");
                    boolean z5 = !jSONObjectOptJSONObject.isNull("size");
                    String str9 = str8;
                    long jOptLong = jSONObjectOptJSONObject.optLong("size", -1L);
                    if (!strOptString2.toLowerCase(Locale.ROOT).endsWith(".apk") || strOptString2.contains("/") || strOptString2.contains("\\") || (((z5 || source == Source.GITHUB) && jOptLong <= 0) || jOptLong > MAX_APK_BYTES)) {
                        str2 = str9;
                        updateRelease = updateRelease2;
                        i = i2;
                        jSONArray = jSONArrayOptJSONArray;
                        str3 = str5;
                        str4 = strTrim;
                        z2 = true;
                    } else {
                        try {
                            uriCreate = URI.create(jSONObjectOptJSONObject.optString("browser_download_url"));
                            updateRelease = updateRelease2;
                        } catch (IllegalArgumentException unused) {
                        }
                        if (isHttpsHost(uriCreate, source.host) && uriCreate.getRawQuery() == null) {
                            StringBuilder sb = new StringBuilder();
                            str3 = str5;
                            sb.append(str9);
                            sb.append(strOptString2);
                            if (sb.toString().equals(uriCreate.getPath())) {
                                String strOptString3 = jSONObjectOptJSONObject.isNull("digest") ? str3 : jSONObjectOptJSONObject.optString("digest");
                                if (strOptString3.isEmpty() || strOptString3.matches("sha256:[0-9a-fA-F]{64}")) {
                                    String str10 = strOptString3;
                                    str2 = str9;
                                    String str11 = strTrim;
                                    i = i2;
                                    jSONArray = jSONArrayOptJSONArray;
                                    str4 = strTrim;
                                    z2 = true;
                                    updateRelease = new UpdateRelease(source, strReplaceFirst, str11, uriCreate, jOptLong, str10);
                                    if (str6.equalsIgnoreCase(strOptString2) || str7.equals(strOptString2)) {
                                        return updateRelease;
                                    }
                                    i3++;
                                }
                            }
                            i = i2;
                            jSONArray = jSONArrayOptJSONArray;
                            str2 = str9;
                            str4 = strTrim;
                            z2 = true;
                        } else {
                            str2 = str9;
                            i = i2;
                            jSONArray = jSONArrayOptJSONArray;
                            str3 = str5;
                            str4 = strTrim;
                            z2 = true;
                        }
                    }
                } else {
                    updateRelease = updateRelease2;
                    i = i2;
                    jSONArray = jSONArrayOptJSONArray;
                    str2 = str8;
                    str3 = str5;
                    str4 = strTrim;
                    z2 = z4;
                }
                updateRelease2 = updateRelease;
                i2 = i + 1;
                z4 = z2;
                str5 = str3;
                jSONArrayOptJSONArray = jSONArray;
                str8 = str2;
                strTrim = str4;
                i3 = i3;
            }
            z = z4;
            z3 = i3;
        } else {
            z = true;
        }
        if (z3 == z) {
            return updateRelease2;
        }
        throw new MissingApk(source.label + " 发布 " + strReplaceFirst + " 没有可识别的安卓安装包。");
    }

    static int compareVersions(String str, String str2) throws IOException {
        Pattern pattern = VERSION;
        Matcher matcher = pattern.matcher(str);
        Matcher matcher2 = pattern.matcher(str2);
        if (!matcher.matches() || !matcher2.matches()) {
            throw new Failure("无法识别更新版本号。");
        }
        for (int i = 1; i <= 3; i++) {
            int iCompare = Integer.compare(Integer.parseInt(matcher.group(i)), Integer.parseInt(matcher2.group(i)));
            if (iCompare != 0) {
                return iCompare;
            }
        }
        return 0;
    }

    boolean isAssetRedirect(URI uri) {
        if (this.source == Source.GITHUB) {
            return isHttpsHost(uri, "release-assets.githubusercontent.com") || isHttpsHost(uri, "objects.githubusercontent.com");
        }
        String path = uri.getPath();
        if (path == null) {
            return false;
        }
        if (isHttpsHost(uri, "foruda.gitee.com")) {
            return path.matches("/attach_file/[0-9]+/[^/]+");
        }
        String str = "/" + this.source.repo + "/attach_files/";
        return isHttpsHost(uri, this.source.host) && uri.getRawQuery() == null && path.startsWith(str) && path.substring(str.length()).matches("[0-9]+/download/[^/]+");
    }

    private static boolean isHttpsHost(URI uri, String str) {
        return "https".equalsIgnoreCase(uri.getScheme()) && str.equalsIgnoreCase(uri.getRawAuthority()) && uri.getRawFragment() == null;
    }

    static HttpsURLConnection connect(URI uri) throws IOException {
        HttpsURLConnection httpsURLConnection = (HttpsURLConnection) uri.toURL().openConnection();
        httpsURLConnection.setInstanceFollowRedirects(false);
        httpsURLConnection.setConnectTimeout(7000);
        httpsURLConnection.setReadTimeout(8000);
        httpsURLConnection.setUseCaches(false);
        httpsURLConnection.setRequestProperty("User-Agent", "Multi-brand-light-link Android updater");
        return httpsURLConnection;
    }

    static class Failure extends IOException {
        Failure(String str) {
            super(str);
        }
    }

    private static final class MissingApk extends Failure {
        MissingApk(String str) {
            super(str);
        }
    }
}
