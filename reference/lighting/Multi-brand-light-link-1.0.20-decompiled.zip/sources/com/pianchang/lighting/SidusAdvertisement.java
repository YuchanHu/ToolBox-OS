package com.pianchang.lighting;

import com.telink.ble.mesh.core.access.fu.FUDistributor;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* loaded from: classes.dex */
final class SidusAdvertisement {
    private static final String[] CATALOG;
    private static final Pattern PRODUCT_CODE = Pattern.compile("^([0-9A-Z]{5})(?:[-_ ][0-9A-F]{4,12})?$");
    private static final Pattern ADDRESS_SUFFIX = Pattern.compile("[-_ ][0-9A-F]{4,12}$");
    private static final Pattern DISPLAY_ID = Pattern.compile("(?:^|[-_ ])([0-9A-F]{6})$");
    private static final Pattern BRAND_NAME = Pattern.compile("^(?:APUTURE|AMARAN|SIDUS)(?:[-_ ].+)$");
    private static final Pattern PROVISIONING_NAME = Pattern.compile("^[0-9A-Z]{5}-[0-9A-F]{6}$");
    private static final Pattern FIXTURE_FAMILY = Pattern.compile("^(?:40[0-9A-Z]{2}5|(?:00|02|04|05|07|09|0A)0[0-9A-Z]{2})$");
    private static final Map<String, String> MODELS = new LinkedHashMap();
    private static final Map<String, String> MODEL_CODES = new LinkedHashMap();

    static /* synthetic */ String access$000(String str, String str2) {
        return betterName(str, str2);
    }

    static /* synthetic */ Map access$100() {
        return MODELS;
    }

    static {
        String[] strArr = {"00005 LS C300d II", "00015 LS 50d", "00025 LS 50x", "00035 LS 150x", "00045 LS 300x", "00055 LS 600d Pro", "00065 LS 1500d", "00075 LS 60d", "00085 LS 60x", "00095 LS 600x", "000B5 LS 350d", "000C5 LS 600d", "000D5 LS 600X Pro", "000E5 LS 1200d Pro", "000F5 MT Pro", "000G5 LS 600c Pro", "000I5 LS 1500x Pro", "000J5 Electro Storm XT26", "000K5 Electro Storm CS15", "000L5 LS 600c Pro II", "000M5 STORM 1200x", "000N5 STORM 80c", "000P5 STORM 1000c", "000Q5 STORM 400x", "000R5 STORM XT52", "000S5 STORM 700x", "000T5 STORM CS32", "02005 Nova P300c", "02035 Nova P600C", "02065 NOVA II 2x1", "02075 NOVA 9° 2×1", "02085 NOVA II 1x1", "04005 B7c", "05005 MC", "05006 MC", "05007 MC", "05008 MC", "05010 MC Pro", "07006 INFINIBAR PB3", "07007 INFINIBAR PB6", "07008 INFINIBAR PB12", "09005 INFINIMAT 4", "09015 INFINIMAT 16", "40005 amaran P60x", "40015 amaran P60c", "40025 amaran 100d", "40035 amaran 100x", "40045 amaran 200d", "40055 amaran 200x", "40065 amaran COB 60d", "40075 amaran COB 60x", "40085 amaran T2c", "40095 amaran T4c", "400A5 amaran F7c", "400B5 amaran F21x", "400C5 amaran F21c", "400D5 amaran F22x", "400E5 amaran F22c", "400F5 amaran SM5c", "400G5 amaran PT1c", "400H5 amaran PT2c", "400I5 amaran PT4c", "400J5 amaran 150c", "400K5 amaran 300c", "400L5 amaran 60d S", "400M5 amaran 60x S", "400N5 amaran 100d S", "400O5 amaran 100x S", "400P5 amaran 200d S", "400Q5 amaran 200x S", "400R5 amaran 200c", "400S5 amaran P40x", "400T5 amaran Ace 25x", "400U5 amaran Ace 25c", "400V5 amaran Go", "400W5 amaran Pano 60c", "400X5 amaran Pano 120c", "400Y5 amaran Verge", "400Z5 amaran Verge Max", "40145 amaran Ray 60c", "40165 amaran Ray 120c", "40185 amaran Ray 360c", "40195 amaran 300x", "401A5 amaran Ray 660c", "401B5 amaran Halo 60x", "401C5 amaran Halo 100x", "401D5 amaran Halo 200x", "401E5 amaran Halo 300x", "401F5 amaran Halo 600x", "401R5 amaran Frame", "401S5 amaran Halo 300x DMX", "401T5 amaran Halo 600x DMX", "0A005 VEGA", "0A015 VEGA L"};
        CATALOG = strArr;
        for (String str : strArr) {
            String strSubstring = str.substring(0, 5);
            String strSubstring2 = str.substring(6);
            MODELS.put(strSubstring, strSubstring2);
            addAlias(strSubstring2, strSubstring);
            if (strSubstring2.startsWith("amaran ")) {
                addAlias(strSubstring2.substring(7), strSubstring);
            }
        }
        addAlias("60x", "40075");
        addAlias("60d", "40065");
        addAlias("Accent B7c", "04005");
    }

    private SidusAdvertisement() {
    }

    static String radioId(String str) {
        if (str == null) {
            return null;
        }
        String upperCase = str.trim().toUpperCase(Locale.ROOT);
        Matcher matcher = PRODUCT_CODE.matcher(upperCase);
        if (matcher.matches() && MODELS.containsKey(matcher.group(1))) {
            return matcher.group(1);
        }
        String strLookupModel = lookupModel(upperCase);
        return strLookupModel != null ? strLookupModel : lookupModel(ADDRESS_SUFFIX.matcher(upperCase).replaceFirst(""));
    }

    static String model(String str, String str2) {
        return MODELS.getOrDefault(str, str2);
    }

    static boolean hasBrandName(String str) {
        return str != null && BRAND_NAME.matcher(str.trim().toUpperCase(Locale.ROOT)).matches();
    }

    static boolean isNonFixture(String str) {
        if (str == null) {
            return false;
        }
        String strNormalizeModel = normalizeModel(str.trim().replaceFirst("(?i)^(?:Aputure|amaran)[-_ ]", ""));
        return strNormalizeModel.matches("^(?:08005|08015|10005|EM005|EM015)(?:[0-9A-F]{6})?$") || strNormalizeModel.startsWith("SIDUSONE") || strNormalizeModel.startsWith("SIDUSFOUR") || strNormalizeModel.startsWith("SIDUSLINKBRIDGE") || strNormalizeModel.startsWith("MOTORIZED");
    }

    static boolean isFixtureProductCode(String str) {
        return MODELS.containsKey(str) || FIXTURE_FAMILY.matcher(str).matches();
    }

    static String displayId(String str) {
        if (str == null) {
            return "";
        }
        Matcher matcher = DISPLAY_ID.matcher(str.trim().toUpperCase(Locale.ROOT));
        return matcher.find() ? matcher.group(1) : "";
    }

    static boolean validProvisioningData(byte[] bArr) {
        if (bArr != null && (bArr.length == 18 || bArr.length == 22)) {
            for (int i = 0; i < 16; i++) {
                if (bArr[i] != 0) {
                    return true;
                }
            }
        }
        return false;
    }

    static String provisioningName(byte[] bArr) {
        if (!validProvisioningData(bArr)) {
            return null;
        }
        String str = new String(bArr, 0, 12, StandardCharsets.US_ASCII);
        if (PROVISIONING_NAME.matcher(str).matches()) {
            return str;
        }
        return null;
    }

    static byte[] provisioningBeacon(byte[] bArr) {
        int i = 0;
        while (bArr != null && i < bArr.length) {
            int i2 = bArr[i] & FUDistributor.UPDATE_TTL;
            int i3 = i + i2 + 1;
            if (i2 == 0 || i3 > bArr.length) {
                break;
            }
            if ((i2 == 20 || i2 == 24) && bArr[i + 1] == 43 && bArr[i + 2] == 0) {
                byte[] bArrCopyOfRange = Arrays.copyOfRange(bArr, i + 3, i3);
                if (validProvisioningData(bArrCopyOfRange)) {
                    return bArrCopyOfRange;
                }
                return null;
            }
            i = i3;
        }
        return null;
    }

    static final class Observation {
        private byte[] beaconData;
        private boolean connectable;
        private String name;
        private boolean provisioningService;
        private boolean proxy;
        private byte[] serviceData;

        Observation() {
        }

        void update(String str, String str2, boolean z, boolean z2, boolean z3, byte[] bArr, byte[] bArr2) {
            this.connectable = z | this.connectable;
            this.provisioningService |= z2 || bArr != null;
            this.proxy |= z3;
            this.name = SidusAdvertisement.access$000(this.name, SidusAdvertisement.access$000(str, str2));
            if (SidusAdvertisement.validProvisioningData(bArr)) {
                this.serviceData = bArr;
            }
            if (bArr2 != null) {
                this.beaconData = bArr2;
            }
        }

        byte[] provisioningData() {
            byte[] bArr = this.serviceData;
            if (bArr != null) {
                return bArr;
            }
            if (this.provisioningService) {
                return this.beaconData;
            }
            return null;
        }

        boolean canConnect() {
            return this.connectable;
        }

        boolean hasProvisioningSignal() {
            return this.provisioningService || this.beaconData != null;
        }

        boolean hasProxySignal() {
            return this.proxy;
        }

        Identity identity(String str) {
            String strProvisioningName = SidusAdvertisement.provisioningName(provisioningData());
            if (SidusAdvertisement.isNonFixture(strProvisioningName) || SidusAdvertisement.isNonFixture(this.name)) {
                return null;
            }
            if (strProvisioningName != null) {
                String strSubstring = strProvisioningName.substring(0, 5);
                String strReplace = str.replace(":", "");
                if (SidusAdvertisement.access$100().containsKey(strSubstring) || SidusAdvertisement.hasBrandName(this.name) || (SidusAdvertisement.isFixtureProductCode(strSubstring) && strReplace.endsWith(SidusAdvertisement.displayId(strProvisioningName)))) {
                    return new Identity(strSubstring, SidusAdvertisement.displayId(strProvisioningName), this.name, null);
                }
            }
            String strRadioId = SidusAdvertisement.radioId(this.name);
            if (strRadioId != null || SidusAdvertisement.hasBrandName(this.name)) {
                return new Identity(strRadioId != null ? strRadioId : "", SidusAdvertisement.displayId(this.name), this.name, null);
            }
            return null;
        }
    }

    static final class Identity {
        final String displayId;
        final String model;
        final boolean modelUnknown;
        final String radioId;

        /* synthetic */ Identity(String str, String str2, String str3, AnonymousClass1 anonymousClass1) {
            this(str, str2, str3);
        }

        private Identity(String str, String str2, String str3) {
            String strTrim;
            this.radioId = str;
            this.displayId = str2;
            boolean z = !SidusAdvertisement.access$100().containsKey(str) && (str.length() > 0 || SidusAdvertisement.radioId(str3) == null);
            this.modelUnknown = z;
            if (z) {
                strTrim = "Sidus 灯具 · 型号待识别";
            } else {
                strTrim = str3 == null ? "Sidus 灯具" : str3.trim();
            }
            this.model = SidusAdvertisement.model(str, strTrim);
        }
    }

    private static String betterName(String str, String str2) {
        return nameRank(str2) > nameRank(str) ? str2 : str;
    }

    private static int nameRank(String str) {
        if (isNonFixture(str) || radioId(str) != null) {
            return 3;
        }
        if (hasBrandName(str)) {
            return 2;
        }
        return !displayId(str).isEmpty() ? 1 : 0;
    }

    private static void addAlias(String str, String str2) {
        MODEL_CODES.merge(normalizeModel(str), str2, new BiFunction() { // from class: com.pianchang.lighting.SidusAdvertisement$$ExternalSyntheticLambda0
            @Override // java.util.function.BiFunction
            public final Object apply(Object obj, Object obj2) {
                return SidusAdvertisement.lambda$addAlias$0((String) obj, (String) obj2);
            }
        });
    }

    static /* synthetic */ String lambda$addAlias$0(String str, String str2) {
        return str.equals(str2) ? str : "";
    }

    private static String lookupModel(String str) {
        Map<String, String> map = MODEL_CODES;
        String str2 = map.get(normalizeModel(str));
        return str2 == null ? (str.startsWith("APUTURE ") || str.startsWith("AMARAN ")) ? map.get(normalizeModel(str.substring(str.indexOf(32) + 1))) : str2 : str2;
    }

    private static String normalizeModel(String str) {
        return str.toUpperCase(Locale.ROOT).replace((char) 215, 'X').replaceAll("[^A-Z0-9]", "");
    }
}
