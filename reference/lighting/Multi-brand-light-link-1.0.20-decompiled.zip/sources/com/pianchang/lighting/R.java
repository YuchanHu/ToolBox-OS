package com.pianchang.lighting;

/* loaded from: classes.dex */
public final class R {

    public static final class drawable {
        public static final int ic_console = 0x7f010000;
    }

    public static final class string {
        public static final int app_name = 0x7f020000;
    }

    public static final class style {
        public static final int ConsoleTheme = 0x7f030000;
    }
}
