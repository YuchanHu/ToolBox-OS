package com.pianchang.lighting;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import org.json.JSONObject;
import org.spongycastle.asn1.cmp.PKIFailureInfo;
import org.spongycastle.asn1.x509.DisplayText;

/* loaded from: classes.dex */
public final class MainActivity extends Activity {
    private static final String ASSET_PREFIX = "/assets/";
    private static final int BACKGROUND = Color.rgb(17, 18, 20);
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private static final String HOST = "appassets.androidplatform.net";
    private static final int MAX_PROJECT_BYTES = 16777216;
    private static final int OPEN_MEDIA = 7404;
    private static final int OPEN_PROJECT = 7401;
    private static final int SAVE_PROJECT = 7402;
    private static final int TABLET_WIDTH_DP = 600;
    private static final String UI_MODE_KEY = "ui_mode";
    private static final String UPDATE_PERMISSION_KEY = "awaiting_update_permission";
    private AppUpdates appUpdates;
    private volatile BilibiliAudio bilibiliAudio;
    private LightingBluetoothBridge bluetooth;
    private String documentRequestId;
    private String documentToSave;
    private final ExecutorService documents = Executors.newSingleThreadExecutor();
    private ValueCallback<Uri[]> mediaSelection;
    private TimelineSyncBridge timelineSync;
    private WebView webView;

    public static /* synthetic */ void $r8$lambda$FVhUQlsXtT02SgZVlRltli7VtkI(MainActivity mainActivity, String str, String str2) {
        mainActivity.deliverDocumentResult(str, str2);
    }

    static /* synthetic */ void access$100(MainActivity mainActivity, ValueCallback valueCallback) {
        mainActivity.pickTimelineMedia(valueCallback);
    }

    static /* synthetic */ void access$1000(MainActivity mainActivity, String str) {
        mainActivity.applyUiOrientation(str);
    }

    static /* synthetic */ void access$1100(MainActivity mainActivity, String str, String str2) {
        mainActivity.deliverDocumentResult(str, str2);
    }

    static /* synthetic */ AppUpdates access$1200(MainActivity mainActivity) {
        return mainActivity.appUpdates;
    }

    static /* synthetic */ boolean access$200(Uri uri) {
        return trustedOrigin(uri);
    }

    static /* synthetic */ WebResourceResponse access$300(int i, String str) {
        return errorResponse(i, str);
    }

    static /* synthetic */ BilibiliAudio access$400(MainActivity mainActivity) {
        return mainActivity.bilibiliAudio;
    }

    static /* synthetic */ String access$500(String str) {
        return mimeType(str);
    }

    static /* synthetic */ void access$600(MainActivity mainActivity, String str, String str2) {
        mainActivity.deliverDocumentError(str, str2);
    }

    static /* synthetic */ String access$700(MainActivity mainActivity) {
        return mainActivity.defaultUiMode();
    }

    static /* synthetic */ boolean access$800(String str) {
        return validUiMode(str);
    }

    static /* synthetic */ void access$900(MainActivity mainActivity, String str, String str2, String str3) {
        mainActivity.selectDocument(str, str2, str3);
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        boolean z = false;
        String string = getPreferences(0).getString(UI_MODE_KEY, null);
        if (!validUiMode(string)) {
            string = defaultUiMode();
        }
        applyUiOrientation(string);
        FrameLayout frameLayout = new FrameLayout(this);
        int i = BACKGROUND;
        frameLayout.setBackgroundColor(i);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            frameLayout.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() { // from class: com.pianchang.lighting.MainActivity$$ExternalSyntheticLambda0
                @Override // android.view.View.OnApplyWindowInsetsListener
                public final WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                    return MainActivity.lambda$onCreate$0(view, windowInsets);
                }
            });
        }
        WebView webView = new WebView(this);
        this.webView = webView;
        webView.setBackgroundColor(i);
        WebSettings settings = this.webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(1);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        this.webView.setWebViewClient(new LocalWebViewClient(this, null));
        this.webView.setWebChromeClient(new WebChromeClient() { // from class: com.pianchang.lighting.MainActivity.1
            @Override // android.webkit.WebChromeClient
            public boolean onShowFileChooser(WebView webView2, ValueCallback<Uri[]> valueCallback, WebChromeClient.FileChooserParams fileChooserParams) {
                MainActivity.access$100(MainActivity.this, valueCallback);
                return true;
            }
        });
        this.bluetooth = new LightingBluetoothBridge(this, this.webView);
        this.timelineSync = new TimelineSyncBridge(this.webView);
        BiConsumer biConsumer = new BiConsumer() { // from class: com.pianchang.lighting.MainActivity$$ExternalSyntheticLambda1
            @Override // java.util.function.BiConsumer
            public final void accept(Object obj, Object obj2) {
                MainActivity.$r8$lambda$FVhUQlsXtT02SgZVlRltli7VtkI(this.f$0, (String) obj, (String) obj2);
            }
        };
        if (bundle != null && bundle.getBoolean(UPDATE_PERMISSION_KEY)) {
            z = true;
        }
        this.appUpdates = new AppUpdates(this, biConsumer, z);
        this.bilibiliAudio = new BilibiliAudio(getCacheDir());
        this.webView.addJavascriptInterface(this.bluetooth, "AndroidLighting");
        this.webView.addJavascriptInterface(new ProjectBridge(), "AndroidProject");
        this.webView.addJavascriptInterface(this.timelineSync, "AndroidTimelineSync");
        frameLayout.addView(this.webView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frameLayout);
        frameLayout.requestApplyInsets();
        this.webView.loadUrl(HOME);
    }

    static /* synthetic */ WindowInsets lambda$onCreate$0(View view, WindowInsets windowInsets) {
        Insets insets = windowInsets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
        view.setPadding(insets.left, insets.top, insets.right, Math.max(insets.bottom, windowInsets.getInsets(WindowInsets.Type.ime()).bottom));
        return windowInsets;
    }

    private String defaultUiMode() {
        int iMin = getResources().getConfiguration().smallestScreenWidthDp;
        if (iMin <= 0) {
            iMin = (int) (Math.min(r0.widthPixels, r0.heightPixels) / getResources().getDisplayMetrics().density);
        }
        return iMin < TABLET_WIDTH_DP ? "phone" : "tablet";
    }

    private static boolean validUiMode(String str) {
        return "phone".equals(str) || "tablet".equals(str);
    }

    private void applyUiOrientation(String str) {
        int i = "phone".equals(str) ? 1 : 6;
        if (getRequestedOrientation() != i) {
            setRequestedOrientation(i);
        }
    }

    private static boolean trustedOrigin(Uri uri) {
        return "https".equals(uri.getScheme()) && HOST.equals(uri.getEncodedAuthority()) && uri.getQuery() == null;
    }

    private static String mimeType(String str) {
        str.hashCode();
        switch (str) {
            case "media-library.js":
            case "fixture-mesh.js":
            case "android-gatt.js":
            case "app.js":
            case "ulanzi-protocol.js":
            case "bluetooth.js":
            case "lyd.js":
            case "lumin-protocol.js":
            case "timeline.js":
            case "timeline-sync.js":
            case "jinbei-protocol.js":
            case "windows-control.js":
            case "inkee.js":
            case "mesh-protocol.js":
            case "android.js":
            case "stage.js":
            case "state.js":
            case "godox-protocol.js":
            case "yongnuo-protocol.js":
            case "zhiyun-protocol.js":
            case "nanlink-mesh.js":
            case "sidus-protocol.js":
                return "application/javascript";
            case "phone.css":
            case "styles.css":
            case "stage-controls.css":
            case "timeline.css":
                return "text/css";
            case "20261123-180541.png":
            case "mm_facetoface_collect_qrcode_1795428553140.png":
                return "image/png";
            case "index.html":
                return "text/html";
            default:
                return null;
        }
    }

    private final class LocalWebViewClient extends WebViewClient {
        private LocalWebViewClient() {
        }

        /* synthetic */ LocalWebViewClient(MainActivity mainActivity, AnonymousClass1 anonymousClass1) {
            this();
        }

        @Override // android.webkit.WebViewClient
        public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
            Uri url = webResourceRequest.getUrl();
            return (webResourceRequest.isForMainFrame() && MainActivity.access$200(url) && "/assets/index.html".equals(url.getEncodedPath())) ? false : true;
        }

        @Override // android.webkit.WebViewClient
        public WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest webResourceRequest) throws IOException {
            Uri url = webResourceRequest.getUrl();
            String encodedPath = url.getEncodedPath();
            if (!MainActivity.access$200(url) || encodedPath == null || !"GET".equals(webResourceRequest.getMethod())) {
                return MainActivity.access$300(403, "Forbidden");
            }
            boolean zIsForMainFrame = webResourceRequest.isForMainFrame();
            String str = null;
            WebResourceResponse webResourceResponseTake = null;
            if (!zIsForMainFrame && encodedPath.startsWith("/media/bilibili/")) {
                BilibiliAudio bilibiliAudioAccess$400 = MainActivity.access$400(MainActivity.this);
                if (bilibiliAudioAccess$400 != null) {
                    try {
                        webResourceResponseTake = bilibiliAudioAccess$400.take(encodedPath);
                    } catch (IOException unused) {
                        return MainActivity.access$300(404, "Not Found");
                    }
                }
                return webResourceResponseTake == null ? MainActivity.access$300(404, "Not Found") : webResourceResponseTake;
            }
            if (!encodedPath.startsWith(MainActivity.ASSET_PREFIX)) {
                return MainActivity.access$300(403, "Forbidden");
            }
            String strSubstring = encodedPath.substring(8);
            String strAccess$500 = MainActivity.access$500(strSubstring);
            if (strAccess$500 == null) {
                return MainActivity.access$300(404, "Not Found");
            }
            try {
                InputStream inputStreamOpen = MainActivity.this.getAssets().open(strSubstring);
                HashMap map = new HashMap();
                map.put("X-Content-Type-Options", "nosniff");
                if ("index.html".equals(strSubstring)) {
                    map.put("Content-Security-Policy", "default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; media-src blob:; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'");
                }
                if (!"image/png".equals(strAccess$500)) {
                    str = "UTF-8";
                }
                return new WebResourceResponse(strAccess$500, str, DisplayText.DISPLAY_TEXT_MAXIMUM_SIZE, "OK", map, inputStreamOpen);
            } catch (IOException unused2) {
                return MainActivity.access$300(404, "Not Found");
            }
        }
    }

    private static WebResourceResponse errorResponse(int i, String str) {
        return new WebResourceResponse("text/plain", "UTF-8", i, str, Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
    }

    public final class ProjectBridge {
        public ProjectBridge() {
        }

        @JavascriptInterface
        public String versionName() {
            try {
                return MainActivity.this.getPackageManager().getPackageInfo(MainActivity.this.getPackageName(), 0).versionName;
            } catch (PackageManager.NameNotFoundException unused) {
                return "";
            }
        }

        @JavascriptInterface
        public void checkAppUpdate(final String str) {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.pianchang.lighting.MainActivity$ProjectBridge$$ExternalSyntheticLambda6
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m94x7f7391c4(str);
                }
            });
        }

        /* renamed from: lambda$checkAppUpdate$0$com-pianchang-lighting-MainActivity$ProjectBridge, reason: not valid java name */
        /* synthetic */ void m94x7f7391c4(String str) {
            if (MainActivity.access$1200(MainActivity.this) == null || MainActivity.this.isFinishing()) {
                return;
            }
            MainActivity.access$1200(MainActivity.this).check(str);
        }

        @JavascriptInterface
        public void downloadAppUpdate(final String str, final String str2) {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.pianchang.lighting.MainActivity$ProjectBridge$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m95x5fa11aeb(str, str2);
                }
            });
        }

        /* renamed from: lambda$downloadAppUpdate$1$com-pianchang-lighting-MainActivity$ProjectBridge, reason: not valid java name */
        /* synthetic */ void m95x5fa11aeb(String str, String str2) {
            if (MainActivity.access$1200(MainActivity.this) == null || MainActivity.this.isFinishing()) {
                return;
            }
            MainActivity.access$1200(MainActivity.this).download(str, str2);
        }

        @JavascriptInterface
        public void downloadBilibiliAudio(final String str, String str2) {
            if (str == null || str.length() > 128) {
                return;
            }
            BilibiliAudio bilibiliAudioAccess$400 = MainActivity.access$400(MainActivity.this);
            if (bilibiliAudioAccess$400 == null) {
                MainActivity.access$600(MainActivity.this, str, "音频导入已关闭，请重试。");
            } else {
                bilibiliAudioAccess$400.download(str2, new Consumer() { // from class: com.pianchang.lighting.MainActivity$ProjectBridge$$ExternalSyntheticLambda4
                    @Override // java.util.function.Consumer
                    public final void accept(Object obj) {
                        this.f$0.m96x48f84190(str, (JSONObject) obj);
                    }
                }, new Consumer() { // from class: com.pianchang.lighting.MainActivity$ProjectBridge$$ExternalSyntheticLambda5
                    @Override // java.util.function.Consumer
                    public final void accept(Object obj) {
                        this.f$0.m97x8c835f51(str, (String) obj);
                    }
                });
            }
        }

        /* renamed from: lambda$downloadBilibiliAudio$2$com-pianchang-lighting-MainActivity$ProjectBridge, reason: not valid java name */
        /* synthetic */ void m96x48f84190(String str, JSONObject jSONObject) {
            MainActivity.access$1100(MainActivity.this, str, jSONObject.toString());
        }

        /* renamed from: lambda$downloadBilibiliAudio$3$com-pianchang-lighting-MainActivity$ProjectBridge, reason: not valid java name */
        /* synthetic */ void m97x8c835f51(String str, String str2) {
            MainActivity.access$600(MainActivity.this, str, str2);
        }

        @JavascriptInterface
        public String preferredUi() {
            return MainActivity.access$700(MainActivity.this);
        }

        @JavascriptInterface
        public void setUiMode(final String str) {
            if (MainActivity.access$800(str)) {
                MainActivity.this.runOnUiThread(new Runnable() { // from class: com.pianchang.lighting.MainActivity$ProjectBridge$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m100x42ef6065(str);
                    }
                });
            }
        }

        /* renamed from: lambda$setUiMode$4$com-pianchang-lighting-MainActivity$ProjectBridge, reason: not valid java name */
        /* synthetic */ void m100x42ef6065(String str) {
            if (MainActivity.this.isFinishing() || MainActivity.this.isDestroyed()) {
                return;
            }
            SharedPreferences preferences = MainActivity.this.getPreferences(0);
            if (!str.equals(preferences.getString(MainActivity.UI_MODE_KEY, null))) {
                preferences.edit().putString(MainActivity.UI_MODE_KEY, str).apply();
            }
            MainActivity.access$1000(MainActivity.this, str);
        }

        /* renamed from: lambda$open$5$com-pianchang-lighting-MainActivity$ProjectBridge, reason: not valid java name */
        /* synthetic */ void m98lambda$open$5$compianchanglightingMainActivity$ProjectBridge(String str) {
            MainActivity.access$900(MainActivity.this, str, null, null);
        }

        @JavascriptInterface
        public void open(final String str) {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.pianchang.lighting.MainActivity$ProjectBridge$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m98lambda$open$5$compianchanglightingMainActivity$ProjectBridge(str);
                }
            });
        }

        /* renamed from: lambda$save$6$com-pianchang-lighting-MainActivity$ProjectBridge, reason: not valid java name */
        /* synthetic */ void m99lambda$save$6$compianchanglightingMainActivity$ProjectBridge(String str, String str2, String str3) {
            MainActivity mainActivity = MainActivity.this;
            if (str2 == null) {
                str2 = "灯光工程.json";
            }
            MainActivity.access$900(mainActivity, str, str2, str3);
        }

        @JavascriptInterface
        public void save(final String str, final String str2, final String str3) {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.pianchang.lighting.MainActivity$ProjectBridge$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m99lambda$save$6$compianchanglightingMainActivity$ProjectBridge(str, str2, str3);
                }
            });
        }
    }

    private void selectDocument(String str, String str2, String str3) {
        if (str == null || str.length() > 128 || this.webView == null || isFinishing()) {
            return;
        }
        if (this.documentRequestId != null) {
            deliverDocumentError(str, "文件选择窗口已打开。");
            return;
        }
        boolean z = str2 != null;
        if (z && (str3 == null || str3.length() > MAX_PROJECT_BYTES)) {
            deliverDocumentError(str, "工程文件太大，无法导出。");
            return;
        }
        Intent intent = new Intent(z ? "android.intent.action.CREATE_DOCUMENT" : "android.intent.action.OPEN_DOCUMENT");
        intent.addCategory("android.intent.category.OPENABLE");
        if (z) {
            intent.setType("application/json");
            intent.putExtra("android.intent.extra.TITLE", suggestedFilename(str2));
        } else {
            intent.setType("*/*");
            intent.putExtra("android.intent.extra.MIME_TYPES", new String[]{"application/json", "text/json", "text/plain", "application/octet-stream"});
        }
        this.documentRequestId = str;
        this.documentToSave = str3;
        try {
            startActivityForResult(intent, z ? SAVE_PROJECT : OPEN_PROJECT);
        } catch (ActivityNotFoundException unused) {
            this.documentRequestId = null;
            this.documentToSave = null;
            deliverDocumentError(str, "当前系统没有可用的文件选择器。");
        }
    }

    private static String suggestedFilename(String str) {
        String strTrim = str.replace('\\', '-').replaceAll("[/:*?\"<>|\\p{Cntrl}]", "-").trim();
        if (strTrim.toLowerCase(Locale.ROOT).endsWith(".json")) {
            strTrim = strTrim.substring(0, strTrim.length() - 5).trim();
        }
        if (strTrim.isEmpty()) {
            strTrim = "灯光工程";
        }
        return strTrim.substring(0, Math.min(strTrim.length(), 96)) + ".json";
    }

    private void pickTimelineMedia(ValueCallback<Uri[]> valueCallback) {
        if (this.mediaSelection != null) {
            valueCallback.onReceiveValue(null);
            return;
        }
        Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT");
        intent.addCategory("android.intent.category.OPENABLE");
        intent.setType("*/*");
        intent.putExtra("android.intent.extra.MIME_TYPES", new String[]{"audio/*", "video/*", "application/ogg"});
        intent.addFlags(1);
        this.mediaSelection = valueCallback;
        try {
            startActivityForResult(intent, OPEN_MEDIA);
        } catch (ActivityNotFoundException | SecurityException unused) {
            this.mediaSelection = null;
            valueCallback.onReceiveValue(null);
            Toast.makeText(this, "无法打开音视频文件选择器。", 0).show();
        }
    }

    @Override // android.app.Activity
    protected void onActivityResult(final int i, int i2, Intent intent) {
        AppUpdates appUpdates;
        super.onActivityResult(i, i2, intent);
        uriArr = null;
        uriArr = null;
        Uri[] uriArr = null;
        if (i == OPEN_MEDIA) {
            ValueCallback<Uri[]> valueCallback = this.mediaSelection;
            this.mediaSelection = null;
            if (valueCallback == null) {
                return;
            }
            Uri data = (i2 != -1 || intent == null) ? null : intent.getData();
            if (data != null && "content".equals(data.getScheme())) {
                if (!(getPackageName() + ".update").equals(data.getAuthority())) {
                    uriArr = new Uri[]{data};
                }
            }
            valueCallback.onReceiveValue(uriArr);
            return;
        }
        if (i == 7403 && (appUpdates = this.appUpdates) != null) {
            appUpdates.onPermissionResult();
            return;
        }
        if (i == OPEN_PROJECT || i == SAVE_PROJECT) {
            final String str = this.documentRequestId;
            final String str2 = this.documentToSave;
            this.documentRequestId = null;
            this.documentToSave = null;
            if (str == null) {
                return;
            }
            final Uri data2 = intent != null ? intent.getData() : null;
            if (i2 == -1 && data2 != null) {
                if (!"content".equals(data2.getScheme())) {
                    deliverDocumentError(str, "系统未返回可访问的工程文件。");
                    return;
                } else {
                    this.documents.execute(new Runnable() { // from class: com.pianchang.lighting.MainActivity$$ExternalSyntheticLambda3
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m92lambda$onActivityResult$1$compianchanglightingMainActivity(i, data2, str2, str);
                        }
                    });
                    return;
                }
            }
            deliverDocumentResult(str, "{\"ok\":false,\"cancelled\":true}");
        }
    }

    /* renamed from: lambda$onActivityResult$1$com-pianchang-lighting-MainActivity, reason: not valid java name */
    /* synthetic */ void m92lambda$onActivityResult$1$compianchanglightingMainActivity(int i, Uri uri, String str, String str2) {
        try {
            if (i == SAVE_PROJECT) {
                writeDocument(uri, str);
                deliverDocumentResult(str2, "{\"ok\":true}");
            } else {
                deliverDocumentResult(str2, "{\"ok\":true,\"text\":" + JSONObject.quote(readDocument(uri)) + "}");
            }
        } catch (IOException | SecurityException unused) {
            deliverDocumentError(str2, i == SAVE_PROJECT ? "无法保存工程文件。" : "无法读取工程文件，文件大小上限为 16 MB。");
        }
    }

    private String readDocument(Uri uri) throws IOException {
        InputStream inputStreamOpenInputStream = getContentResolver().openInputStream(uri);
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            try {
                if (inputStreamOpenInputStream == null) {
                    throw new IOException("Unavailable document");
                }
                byte[] bArr = new byte[PKIFailureInfo.certRevoked];
                while (true) {
                    int i = inputStreamOpenInputStream.read(bArr);
                    if (i != -1) {
                        if (byteArrayOutputStream.size() + i > MAX_PROJECT_BYTES) {
                            throw new IOException("Document too large");
                        }
                        byteArrayOutputStream.write(bArr, 0, i);
                    } else {
                        String string = byteArrayOutputStream.toString("UTF-8");
                        if (string.startsWith("\ufeff")) {
                            string = string.substring(1);
                        }
                        byteArrayOutputStream.close();
                        if (inputStreamOpenInputStream != null) {
                            inputStreamOpenInputStream.close();
                        }
                        return string;
                    }
                }
            } finally {
            }
        } catch (Throwable th) {
            if (inputStreamOpenInputStream != null) {
                try {
                    inputStreamOpenInputStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private void writeDocument(Uri uri, String str) throws IOException {
        if (str == null) {
            throw new IOException("Missing document");
        }
        byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        if (bytes.length > MAX_PROJECT_BYTES) {
            throw new IOException("Document too large");
        }
        OutputStream outputStreamOpenOutputStream = getContentResolver().openOutputStream(uri, "wt");
        try {
            if (outputStreamOpenOutputStream == null) {
                throw new IOException("Unavailable document");
            }
            outputStreamOpenOutputStream.write(bytes);
            if (outputStreamOpenOutputStream != null) {
                outputStreamOpenOutputStream.close();
            }
        } catch (Throwable th) {
            if (outputStreamOpenOutputStream != null) {
                try {
                    outputStreamOpenOutputStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private void deliverDocumentError(String str, String str2) {
        deliverDocumentResult(str, "{\"ok\":false,\"message\":" + JSONObject.quote(str2) + "}");
    }

    private void deliverDocumentResult(final String str, final String str2) {
        runOnUiThread(new Runnable() { // from class: com.pianchang.lighting.MainActivity$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m91xd6ac6829(str, str2);
            }
        });
    }

    /* renamed from: lambda$deliverDocumentResult$2$com-pianchang-lighting-MainActivity, reason: not valid java name */
    /* synthetic */ void m91xd6ac6829(String str, String str2) {
        if (this.webView == null || isDestroyed()) {
            return;
        }
        this.webView.evaluateJavascript("if (typeof window.onLightingAndroidResult==='function')window.onLightingAndroidResult(" + JSONObject.quote(str) + "," + str2 + ");", null);
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        LightingBluetoothBridge lightingBluetoothBridge = this.bluetooth;
        if (lightingBluetoothBridge != null) {
            lightingBluetoothBridge.onRequestPermissionsResult(i, strArr, iArr);
        }
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        WebView webView = this.webView;
        if (webView == null) {
            super.onBackPressed();
        } else {
            webView.evaluateJavascript("(function(){var d=document.querySelector('dialog[open]');if(!d)return false;d.close();return true;})()", new ValueCallback() { // from class: com.pianchang.lighting.MainActivity$$ExternalSyntheticLambda2
                @Override // android.webkit.ValueCallback
                public final void onReceiveValue(Object obj) {
                    this.f$0.m93lambda$onBackPressed$3$compianchanglightingMainActivity((String) obj);
                }
            });
        }
    }

    /* renamed from: lambda$onBackPressed$3$com-pianchang-lighting-MainActivity, reason: not valid java name */
    /* synthetic */ void m93lambda$onBackPressed$3$compianchanglightingMainActivity(String str) {
        if ("true".equals(str)) {
            return;
        }
        finish();
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        AppUpdates appUpdates = this.appUpdates;
        if (appUpdates != null) {
            appUpdates.setForeground(true);
        }
    }

    @Override // android.app.Activity
    protected void onPause() {
        AppUpdates appUpdates = this.appUpdates;
        if (appUpdates != null) {
            appUpdates.setForeground(false);
        }
        super.onPause();
    }

    @Override // android.app.Activity
    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        AppUpdates appUpdates = this.appUpdates;
        if (appUpdates != null) {
            bundle.putBoolean(UPDATE_PERMISSION_KEY, appUpdates.isAwaitingPermission());
        }
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        ValueCallback<Uri[]> valueCallback = this.mediaSelection;
        if (valueCallback != null) {
            valueCallback.onReceiveValue(null);
            this.mediaSelection = null;
        }
        AppUpdates appUpdates = this.appUpdates;
        if (appUpdates != null) {
            appUpdates.close();
            this.appUpdates = null;
        }
        if (this.bilibiliAudio != null) {
            this.bilibiliAudio.close();
            this.bilibiliAudio = null;
        }
        TimelineSyncBridge timelineSyncBridge = this.timelineSync;
        if (timelineSyncBridge != null) {
            timelineSyncBridge.close();
            this.timelineSync = null;
        }
        LightingBluetoothBridge lightingBluetoothBridge = this.bluetooth;
        if (lightingBluetoothBridge != null) {
            lightingBluetoothBridge.close();
            this.bluetooth = null;
        }
        this.documents.shutdownNow();
        WebView webView = this.webView;
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidLighting");
            this.webView.removeJavascriptInterface("AndroidProject");
            this.webView.removeJavascriptInterface("AndroidTimelineSync");
            if (this.webView.getParent() instanceof ViewGroup) {
                ((ViewGroup) this.webView.getParent()).removeView(this.webView);
            }
            this.webView.destroy();
            this.webView = null;
        }
        super.onDestroy();
    }
}
