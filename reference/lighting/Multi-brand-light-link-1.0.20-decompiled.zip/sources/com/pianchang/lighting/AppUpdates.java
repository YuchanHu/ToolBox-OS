package com.pianchang.lighting;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.widget.Toast;
import com.pianchang.lighting.UpdateRelease;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.HashSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.BiConsumer;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONObject;

/* loaded from: classes.dex */
final class AppUpdates {
    private static final long DOWNLOAD_TIME_MS = 110000;
    static final int INSTALL_PERMISSION_REQUEST = 7403;
    private final Activity activity;
    private boolean awaitingPermission;
    private UpdateRelease checkedRelease;
    private final BiConsumer<String, String> deliver;
    private String downloadRequest;
    private boolean foreground;
    private boolean ready;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    AppUpdates(Activity activity, BiConsumer<String, String> biConsumer, boolean z) {
        this.activity = activity;
        this.deliver = biConsumer;
        this.awaitingPermission = z;
    }

    void check(final String str) {
        this.worker.execute(new Runnable() { // from class: com.pianchang.lighting.AppUpdates$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m0lambda$check$0$compianchanglightingAppUpdates(str);
            }
        });
    }

    /* renamed from: lambda$check$0$com-pianchang-lighting-AppUpdates, reason: not valid java name */
    /* synthetic */ void m0lambda$check$0$compianchanglightingAppUpdates(String str) {
        try {
            UpdateRelease updateReleaseCheck = UpdateRelease.check(installed(0).versionName);
            this.checkedRelease = updateReleaseCheck;
            if (updateReleaseCheck == null) {
                this.deliver.accept(str, "{\"ok\":true,\"available\":false}");
            } else {
                this.deliver.accept(str, new JSONObject().put("ok", true).put("available", true).put("version", updateReleaseCheck.version).put("releaseNotes", updateReleaseCheck.releaseNotes).put("downloadUrl", updateReleaseCheck.apkUrl.toASCIIString()).toString());
            }
        } catch (UpdateRelease.Failure e) {
            fail(str, e.getMessage());
        } catch (Exception unused) {
            fail(str, "无法检查更新，请确认网络可以访问 Gitee 或 GitHub 后重试。");
        }
    }

    void download(String str, final String str2) {
        if (this.downloadRequest != null || this.awaitingPermission) {
            fail(str, "已有更新操作正在进行。");
        } else {
            this.downloadRequest = str;
            this.worker.execute(new Runnable() { // from class: com.pianchang.lighting.AppUpdates$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m2lambda$download$2$compianchanglightingAppUpdates(str2);
                }
            });
        }
    }

    /* renamed from: lambda$download$2$com-pianchang-lighting-AppUpdates, reason: not valid java name */
    /* synthetic */ void m2lambda$download$2$compianchanglightingAppUpdates(String str) {
        UpdateRelease updateRelease;
        File fileCreateTempFile = null;
        try {
            try {
                updateRelease = this.checkedRelease;
            } catch (UpdateRelease.Failure e) {
                downloadFailed(e.getMessage());
                if (0 == 0) {
                    return;
                }
            } catch (Exception unused) {
                downloadFailed("无法下载更新，请检查网络后重试。");
                if (0 == 0) {
                    return;
                }
            }
            if (updateRelease == null || !updateRelease.apkUrl.toASCIIString().equals(str)) {
                throw new UpdateRelease.Failure("更新信息已失效，请重新检查更新。");
            }
            fileCreateTempFile = File.createTempFile("app-update-", ".apk", this.activity.getCacheDir());
            downloadApk(updateRelease, fileCreateTempFile);
            verifyApk(updateRelease, fileCreateTempFile);
            Files.move(fileCreateTempFile.toPath(), UpdateApkProvider.apkFile(this.activity).toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            this.activity.runOnUiThread(new Runnable() { // from class: com.pianchang.lighting.AppUpdates$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m1lambda$download$1$compianchanglightingAppUpdates();
                }
            });
            if (fileCreateTempFile != null) {
                fileCreateTempFile.delete();
            }
        } catch (Throwable th) {
            if (0 != 0) {
                fileCreateTempFile.delete();
            }
            throw th;
        }
    }

    /* renamed from: lambda$download$1$com-pianchang-lighting-AppUpdates, reason: not valid java name */
    /* synthetic */ void m1lambda$download$1$compianchanglightingAppUpdates() {
        if (this.activity.isFinishing() || this.activity.isDestroyed()) {
            return;
        }
        this.ready = true;
        openWhenReady();
    }

    private void downloadFailed(final String str) {
        this.activity.runOnUiThread(new Runnable() { // from class: com.pianchang.lighting.AppUpdates$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m3lambda$downloadFailed$3$compianchanglightingAppUpdates(str);
            }
        });
    }

    /* renamed from: lambda$downloadFailed$3$com-pianchang-lighting-AppUpdates, reason: not valid java name */
    /* synthetic */ void m3lambda$downloadFailed$3$compianchanglightingAppUpdates(String str) {
        String str2 = this.downloadRequest;
        this.downloadRequest = null;
        if (str2 != null) {
            fail(str2, str);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:25:0x0075, code lost:
    
        throw new java.io.IOException("Download did not complete");
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void downloadApk(com.pianchang.lighting.UpdateRelease r17, java.io.File r18) throws java.lang.Exception {
        /*
            Method dump skipped, instructions count: 257
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.pianchang.lighting.AppUpdates.downloadApk(com.pianchang.lighting.UpdateRelease, java.io.File):void");
    }

    private static HttpsURLConnection openAsset(UpdateRelease updateRelease) throws IOException {
        URI uriResolve = updateRelease.apkUrl;
        for (int i = 0; i < 4; i++) {
            HttpsURLConnection httpsURLConnectionConnect = UpdateRelease.connect(uriResolve);
            try {
                int responseCode = httpsURLConnectionConnect.getResponseCode();
                if (responseCode != 200) {
                    String headerField = httpsURLConnectionConnect.getHeaderField("Location");
                    if (responseCode >= 300 && responseCode < 400 && headerField != null) {
                        uriResolve = uriResolve.resolve(headerField);
                        if (updateRelease.isAssetRedirect(uriResolve)) {
                            httpsURLConnectionConnect.disconnect();
                        }
                    }
                    break;
                }
                return httpsURLConnectionConnect;
            } finally {
                httpsURLConnectionConnect.disconnect();
            }
        }
        throw new IOException("Release download is unavailable");
    }

    private void verifyApk(UpdateRelease updateRelease, File file) throws Exception {
        int i = Build.VERSION.SDK_INT >= 28 ? 134217728 : 64;
        PackageInfo packageInfoInstalled = installed(i);
        PackageInfo packageArchiveInfo = this.activity.getPackageManager().getPackageArchiveInfo(file.getAbsolutePath(), i);
        if (packageArchiveInfo == null || !packageInfoInstalled.packageName.equals(packageArchiveInfo.packageName) || versionCode(packageArchiveInfo) <= versionCode(packageInfoInstalled) || packageArchiveInfo.versionName == null || UpdateRelease.compareVersions(updateRelease.version, packageArchiveInfo.versionName) != 0) {
            throw new UpdateRelease.Failure("安装包与片场灯光台的更新版本不匹配。");
        }
        Signature[] signatureArrSigners = signers(packageInfoInstalled);
        Signature[] signatureArrSigners2 = signers(packageArchiveInfo);
        if (signatureArrSigners == null || signatureArrSigners2 == null || signatureArrSigners2.length == 0 || !new HashSet(Arrays.asList(signatureArrSigners)).equals(new HashSet(Arrays.asList(signatureArrSigners2)))) {
            throw new UpdateRelease.Failure("安装包的签名与当前应用不一致。");
        }
    }

    private PackageInfo installed(int i) throws PackageManager.NameNotFoundException {
        return this.activity.getPackageManager().getPackageInfo(this.activity.getPackageName(), i);
    }

    private static long versionCode(PackageInfo packageInfo) {
        return Build.VERSION.SDK_INT >= 28 ? packageInfo.getLongVersionCode() : packageInfo.versionCode;
    }

    private static Signature[] signers(PackageInfo packageInfo) {
        if (Build.VERSION.SDK_INT >= 28) {
            if (packageInfo.signingInfo == null) {
                return null;
            }
            return packageInfo.signingInfo.getApkContentsSigners();
        }
        return packageInfo.signatures;
    }

    void setForeground(boolean z) {
        this.foreground = z;
        openWhenReady();
    }

    boolean isAwaitingPermission() {
        return this.awaitingPermission;
    }

    private void openWhenReady() {
        if (!this.ready || !this.foreground || this.activity.isFinishing() || this.activity.isDestroyed()) {
            return;
        }
        String str = this.downloadRequest;
        this.ready = false;
        this.downloadRequest = null;
        try {
            if (this.activity.getPackageManager().canRequestPackageInstalls()) {
                openInstaller();
                this.deliver.accept(str, "{\"ok\":true}");
            } else {
                this.activity.startActivityForResult(new Intent("android.settings.MANAGE_UNKNOWN_APP_SOURCES", Uri.fromParts("package", this.activity.getPackageName(), null)), INSTALL_PERMISSION_REQUEST);
                this.awaitingPermission = true;
                this.deliver.accept(str, "{\"ok\":true,\"needsPermission\":true}");
            }
        } catch (RuntimeException unused) {
            fail(str, "无法打开系统安装界面。");
        }
    }

    void onPermissionResult() {
        if (this.awaitingPermission) {
            this.awaitingPermission = false;
            try {
                if (this.activity.getPackageManager().canRequestPackageInstalls()) {
                    openInstaller();
                } else {
                    Toast.makeText(this.activity, "未允许安装更新，可在「关于」中再次发起。", 1).show();
                }
            } catch (RuntimeException unused) {
                Toast.makeText(this.activity, "无法打开系统安装界面，请重试。", 1).show();
            }
        }
    }

    private void openInstaller() {
        if (!UpdateApkProvider.apkFile(this.activity).isFile()) {
            throw new IllegalStateException("Update APK missing");
        }
        Uri uriApkUri = UpdateApkProvider.apkUri(this.activity);
        Intent intent = new Intent("android.intent.action.INSTALL_PACKAGE", uriApkUri);
        intent.setClipData(ClipData.newRawUri("APK", uriApkUri));
        intent.addFlags(1);
        this.activity.startActivity(intent);
    }

    void close() {
        this.worker.shutdownNow();
    }

    private void fail(String str, String str2) {
        this.deliver.accept(str, "{\"ok\":false,\"message\":" + JSONObject.quote(str2) + "}");
    }
}
