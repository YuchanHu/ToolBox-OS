package com.pianchang.lighting;

import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* loaded from: classes.dex */
final class ZhiyunAdvertisement {
    static final int MANUFACTURER = 2309;
    private static final Pattern GENERATION_NAME = Pattern.compile("^(PL103|PL105)(?:[ _-][0-9A-F]{4,12})?$");
    private static final Pattern ADDRESS_SUFFIX = Pattern.compile("[ _-][0-9A-F]{4,12}$");
    private static final Pattern BRAND_PREFIX = Pattern.compile("^(?:ZHIYUN[ _-]+)?MOLUS[ _-]+");

    private ZhiyunAdvertisement() {
    }

    static String productCode(String str, byte[] bArr, boolean z) {
        if (bArr != null && bArr.length != 0) {
            int i = 0;
            while (i < bArr.length && bArr[i] != 0) {
                i++;
            }
            String upperCase = new String(bArr, 0, i, StandardCharsets.US_ASCII).toUpperCase(Locale.ROOT);
            if (upperCase.startsWith("PL")) {
                if (supported(upperCase)) {
                    return upperCase;
                }
                return null;
            }
        }
        if (str == null) {
            return null;
        }
        String upperCase2 = str.trim().toUpperCase(Locale.ROOT);
        Matcher matcher = GENERATION_NAME.matcher(upperCase2);
        if (matcher.matches()) {
            return matcher.group(1);
        }
        if (!z && bArr == null) {
            return null;
        }
        String strReplaceFirst = BRAND_PREFIX.matcher(ADDRESS_SUFFIX.matcher(upperCase2).replaceFirst("")).replaceFirst("");
        if ("G60".equals(strReplaceFirst)) {
            return "PL103";
        }
        if ("X100".equals(strReplaceFirst)) {
            return "PL105";
        }
        return null;
    }

    private static boolean supported(String str) {
        return "PL103".equals(str) || "PL105".equals(str);
    }
}
