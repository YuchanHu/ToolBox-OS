package com.pianchang.lighting;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import com.pianchang.lighting.LampGattTransport;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
final class LampGattTransport {
    private static final int ATT_OVERHEAD = 3;
    private static final int CONNECT_TIMEOUT = 14000;
    private static final int CONTROL_FRAME_TIMEOUT = 1200;
    private static final int MESH_RECONNECT_DELAY = 250;
    private static final int WRITE_TIMEOUT = 10000;
    private static final int XSJ_REQUESTED_MTU = 128;
    private final Context context;
    private final BiConsumer<String, JSONObject> deliver;
    private final Handler handler;
    private final Consumer<String> linkLost;
    private final BiConsumer<String, byte[]> notifyFrame;
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final UUID ULANZI_HANDSHAKE_SERVICE = UUID.fromString("f000ffc0-0451-4000-b000-000000000000");
    private static final UUID ULANZI_HANDSHAKE_WRITE = UUID.fromString("f000ffc1-0451-4000-b000-000000000000");
    private static final Pattern HEX_FRAME = Pattern.compile("(?:[0-9a-fA-F]{2}){1,24}");
    private final Map<String, Link> links = new HashMap();
    private final Map<String, BluetoothDevice> discovered = new HashMap();

    static /* synthetic */ Map access$1300(LampGattTransport lampGattTransport) {
        return lampGattTransport.links;
    }

    static /* synthetic */ Handler access$1400(LampGattTransport lampGattTransport) {
        return lampGattTransport.handler;
    }

    static /* synthetic */ UUID access$1500() {
        return ULANZI_HANDSHAKE_SERVICE;
    }

    static /* synthetic */ UUID access$1600() {
        return ULANZI_HANDSHAKE_WRITE;
    }

    static /* synthetic */ UUID access$1700() {
        return CCCD;
    }

    static /* synthetic */ BiConsumer access$1800(LampGattTransport lampGattTransport) {
        return lampGattTransport.deliver;
    }

    static /* synthetic */ Consumer access$1900(LampGattTransport lampGattTransport) {
        return lampGattTransport.linkLost;
    }

    static /* synthetic */ BiConsumer access$2000(LampGattTransport lampGattTransport) {
        return lampGattTransport.notifyFrame;
    }

    private enum Profile {
        NANLINK(20, true, "0003cdd2-0000-1000-8000-00805f9b0131", "0003cdd1-0000-1000-8000-00805f9b0131", "0003cdd0-0000-1000-8000-00805f9b0131"),
        XSJ(24, false, "0000ae01-0000-1000-8000-00805f9b34fb", "0000ae02-0000-1000-8000-00805f9b34fb", "0000ae30-0000-1000-8000-00805f9b34fb", "0000ae00-0000-1000-8000-00805f9b34fb"),
        YONGNUO(20, true, "f000aa61-0451-4000-b000-000000000000", "f000aa63-0451-4000-b000-000000000000", "f000aa60-0451-4000-b000-000000000000"),
        ULANZI(20, true, "0000fff2-0000-1000-8000-00805f9b34fb", "0000fff1-0000-1000-8000-00805f9b34fb", "0000fff0-0000-1000-8000-00805f9b34fb"),
        ZHIYUN(20, true, "d44bc439-abfd-45a2-b575-925416129600", "d44bc439-abfd-45a2-b575-925416129601", "0000fee9-0000-1000-8000-00805f9b34fb"),
        MESH_PROVISIONING(20, true, "00002adb-0000-1000-8000-00805f9b34fb", "00002adc-0000-1000-8000-00805f9b34fb", "00001827-0000-1000-8000-00805f9b34fb"),
        MESH_PROXY(20, true, "00002add-0000-1000-8000-00805f9b34fb", "00002ade-0000-1000-8000-00805f9b34fb", "00001828-0000-1000-8000-00805f9b34fb");

        final boolean notificationRequired;
        final UUID notify;
        final int payloadSize;
        final UUID[] services;
        final UUID write;

        Profile(int i, boolean z, String str, String str2, String... strArr) {
            this.payloadSize = i;
            this.notificationRequired = z;
            this.write = UUID.fromString(str);
            this.notify = UUID.fromString(str2);
            this.services = new UUID[strArr.length];
            for (int i2 = 0; i2 < strArr.length; i2++) {
                this.services[i2] = UUID.fromString(strArr[i2]);
            }
        }

        boolean matches(JSONArray jSONArray, String str, String str2, int i) throws JSONException {
            if (this.payloadSize != i || !this.write.toString().equalsIgnoreCase(str) || !this.notify.toString().equalsIgnoreCase(str2) || jSONArray.length() != this.services.length) {
                return false;
            }
            int i2 = 0;
            while (true) {
                UUID[] uuidArr = this.services;
                if (i2 >= uuidArr.length) {
                    return true;
                }
                if (!uuidArr[i2].toString().equalsIgnoreCase(jSONArray.getString(i2))) {
                    return false;
                }
                i2++;
            }
        }

        boolean isMesh() {
            return this == MESH_PROVISIONING || this == MESH_PROXY;
        }

        boolean reportsState() {
            return isMesh() || this == YONGNUO || this == ULANZI || this == ZHIYUN;
        }
    }

    LampGattTransport(Context context, Handler handler, BiConsumer<String, JSONObject> biConsumer, BiConsumer<String, byte[]> biConsumer2, Consumer<String> consumer) {
        this.context = context;
        this.handler = handler;
        this.deliver = biConsumer;
        this.notifyFrame = biConsumer2;
        this.linkLost = consumer;
    }

    void remember(String str, BluetoothDevice bluetoothDevice) {
        this.discovered.put(str, bluetoothDevice);
    }

    void connect(String str, final BluetoothAdapter bluetoothAdapter, String str2, String str3, String str4, String str5, int i) {
        if (!BluetoothAdapter.checkBluetoothAddress(str2)) {
            this.deliver.accept(str, LightingBluetoothBridge.error("InvalidAddress", "请先搜索并绑定此灯具。"));
            return;
        }
        Profile profile = null;
        if (str3 != null && str3.length() <= 128) {
            try {
                JSONArray jSONArray = new JSONArray(str3);
                for (Profile profile2 : Profile.values()) {
                    if (profile2.matches(jSONArray, str4, str5, i)) {
                        profile = profile2;
                    }
                }
            } catch (JSONException unused) {
            }
        }
        if (profile == null) {
            this.deliver.accept(str, LightingBluetoothBridge.error("NotSupportedError", "此灯具的蓝牙控制协议未受支持。"));
            return;
        }
        Link link = this.links.get(str2);
        if (link != null) {
            if (Link.access$000(link) == profile && Link.access$100(link)) {
                Link.access$200(link, str);
                return;
            }
            if (Link.access$000(link) != Profile.MESH_PROVISIONING || profile != Profile.MESH_PROXY || !Link.access$100(link) || Link.access$300(link) != null) {
                this.deliver.accept(str, LightingBluetoothBridge.error("Busy", "此灯具已有蓝牙连接，请断开后重试。"));
                return;
            }
            if (Link.access$400(link, str)) {
                return;
            }
            Link.access$500(link);
            final Link link2 = new Link(str2, profile, str);
            this.links.put(str2, link2);
            Link.access$602(link2, new Runnable() { // from class: com.pianchang.lighting.LampGattTransport$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m19lambda$connect$0$compianchanglightingLampGattTransport(link2, bluetoothAdapter);
                }
            });
            this.handler.postDelayed(Link.access$600(link2), 250L);
            return;
        }
        Link link3 = new Link(str2, profile, str);
        this.links.put(str2, link3);
        beginConnection(link3, bluetoothAdapter);
    }

    /* renamed from: lambda$connect$0$com-pianchang-lighting-LampGattTransport, reason: not valid java name */
    /* synthetic */ void m19lambda$connect$0$compianchanglightingLampGattTransport(Link link, BluetoothAdapter bluetoothAdapter) {
        beginConnection(link, bluetoothAdapter);
    }

    private void beginConnection(Link link, BluetoothAdapter bluetoothAdapter) {
        try {
            BluetoothDevice remoteDevice = this.discovered.get(Link.access$700(link));
            if (remoteDevice == null) {
                remoteDevice = bluetoothAdapter.getRemoteDevice(Link.access$700(link));
            }
            Link.access$802(link, remoteDevice.connectGatt(this.context, false, link, 2));
            if (Link.access$800(link) == null) {
                Link.access$900(link, "ConnectFailed", "无法连接灯具，请确认灯具已开机后重试。");
            } else {
                this.handler.postDelayed(Link.access$1000(link), 14000L);
            }
        } catch (RuntimeException unused) {
            Link.access$900(link, "ConnectFailed", "无法连接灯具，请检查蓝牙权限和灯具状态后重试。");
        }
    }

    void write(String str, String str2, String str3, int i) {
        Link link = this.links.get(str2);
        if (link == null || !Link.access$100(link)) {
            this.deliver.accept(str, LightingBluetoothBridge.error("Disconnected", "灯具已断开，请重新连接。"));
            return;
        }
        if (Link.access$300(link) != null) {
            this.deliver.accept(str, LightingBluetoothBridge.error("Busy", "请等待上一条灯具控制指令发送完成。"));
            return;
        }
        if (i >= 0 && i <= 100 && str3 != null) {
            try {
                if (str3.length() <= 1024) {
                    JSONArray jSONArray = new JSONArray(str3);
                    if (jSONArray.length() == 0 || jSONArray.length() > 16) {
                        throw new JSONException("Invalid frame count");
                    }
                    ArrayList arrayList = new ArrayList(jSONArray.length());
                    for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                        String string = jSONArray.getString(i2);
                        if (!HEX_FRAME.matcher(string).matches() || string.length() > Link.access$000(link).payloadSize * 2) {
                            throw new JSONException("Invalid frame");
                        }
                        int length = string.length() / 2;
                        byte[] bArr = new byte[length];
                        for (int i3 = 0; i3 < length; i3++) {
                            int i4 = i3 * 2;
                            bArr[i3] = (byte) Integer.parseInt(string.substring(i4, i4 + 2), 16);
                        }
                        arrayList.add(bArr);
                    }
                    Link.access$302(link, new WriteBatch(str, arrayList, i));
                    this.handler.postDelayed(Link.access$1100(link), 10000L);
                    Link.access$1200(link);
                    return;
                }
            } catch (JSONException unused) {
                this.deliver.accept(str, LightingBluetoothBridge.error("InvalidPayload", "蓝牙调光报文格式不正确。"));
                return;
            }
        }
        throw new JSONException("Invalid frame batch");
    }

    void disconnect(String str, String str2) {
        Link link = this.links.get(str2);
        if (link != null) {
            Link.access$900(link, "Cancelled", "已断开灯具蓝牙连接。");
        }
        this.deliver.accept(str, LightingBluetoothBridge.json("ok", true));
    }

    void close() {
        Iterator it = new ArrayList(this.links.values()).iterator();
        while (it.hasNext()) {
            Link.access$500((Link) it.next());
        }
        this.discovered.clear();
    }

    private static final class WriteBatch {
        final List<byte[]> frames;
        final String id;
        final int interval;
        int offset;

        WriteBatch(String str, List<byte[]> list, int i) {
            this.id = str;
            this.frames = list;
            this.interval = i;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    final class Link extends BluetoothGattCallback {
        private final String address;
        private boolean awaitingWrite;
        private WriteBatch batch;
        private String connectId;
        private Runnable delayedConnect;
        private BluetoothGatt gatt;
        private BluetoothGattCharacteristic handshakeWriter;
        private long nextWriteTime;
        private BluetoothGattDescriptor notificationDescriptor;
        private BluetoothGattCharacteristic notifier;
        private Profile profile;
        private boolean ready;
        private boolean waitingForMtu;
        private int writeType;
        private BluetoothGattCharacteristic writer;
        private int mtu = 23;
        private final Runnable connectTimeout = new Runnable() { // from class: com.pianchang.lighting.LampGattTransport$Link$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m20lambda$new$0$compianchanglightingLampGattTransport$Link();
            }
        };
        private final Runnable writeTimeout = new Runnable() { // from class: com.pianchang.lighting.LampGattTransport$Link$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m21lambda$new$1$compianchanglightingLampGattTransport$Link();
            }
        };
        private final Runnable frameTimeout = new Runnable() { // from class: com.pianchang.lighting.LampGattTransport$Link$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m22lambda$new$2$compianchanglightingLampGattTransport$Link();
            }
        };
        private final Runnable nextWrite = new Runnable() { // from class: com.pianchang.lighting.LampGattTransport$Link$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                LampGattTransport.Link.$r8$lambda$1VKT57vjsiLBXf8RWPF1zMxReMo(this.f$0);
            }
        };

        public static /* synthetic */ void $r8$lambda$1VKT57vjsiLBXf8RWPF1zMxReMo(Link link) {
            link.sendFrame();
        }

        static /* synthetic */ Profile access$000(Link link) {
            return link.profile;
        }

        static /* synthetic */ boolean access$100(Link link) {
            return link.ready;
        }

        static /* synthetic */ Runnable access$1000(Link link) {
            return link.connectTimeout;
        }

        static /* synthetic */ Runnable access$1100(Link link) {
            return link.writeTimeout;
        }

        static /* synthetic */ void access$1200(Link link) {
            link.scheduleWrite();
        }

        static /* synthetic */ void access$200(Link link, String str) {
            link.reportConnected(str);
        }

        static /* synthetic */ WriteBatch access$300(Link link) {
            return link.batch;
        }

        static /* synthetic */ WriteBatch access$302(Link link, WriteBatch writeBatch) {
            link.batch = writeBatch;
            return writeBatch;
        }

        static /* synthetic */ boolean access$400(Link link, String str) {
            return link.promoteToProxy(str);
        }

        static /* synthetic */ void access$500(Link link) {
            link.release();
        }

        static /* synthetic */ Runnable access$600(Link link) {
            return link.delayedConnect;
        }

        static /* synthetic */ Runnable access$602(Link link, Runnable runnable) {
            link.delayedConnect = runnable;
            return runnable;
        }

        static /* synthetic */ String access$700(Link link) {
            return link.address;
        }

        static /* synthetic */ BluetoothGatt access$800(Link link) {
            return link.gatt;
        }

        static /* synthetic */ BluetoothGatt access$802(Link link, BluetoothGatt bluetoothGatt) {
            link.gatt = bluetoothGatt;
            return bluetoothGatt;
        }

        static /* synthetic */ void access$900(Link link, String str, String str2) {
            link.fail(str, str2);
        }

        /* renamed from: lambda$new$0$com-pianchang-lighting-LampGattTransport$Link, reason: not valid java name */
        /* synthetic */ void m20lambda$new$0$compianchanglightingLampGattTransport$Link() {
            fail("Timeout", "连接灯具超时，请关闭占用此灯具的其他应用后重试。");
        }

        /* renamed from: lambda$new$1$com-pianchang-lighting-LampGattTransport$Link, reason: not valid java name */
        /* synthetic */ void m21lambda$new$1$compianchanglightingLampGattTransport$Link() {
            fail("Timeout", "蓝牙调光指令发送超时，请重新连接。");
        }

        /* renamed from: lambda$new$2$com-pianchang-lighting-LampGattTransport$Link, reason: not valid java name */
        /* synthetic */ void m22lambda$new$2$compianchanglightingLampGattTransport$Link() {
            fail("Timeout", "蓝牙调光指令未收到写入回调。");
        }

        Link(String str, Profile profile, String str2) {
            this.address = str;
            this.profile = profile;
            this.connectId = str2;
        }

        private boolean active(BluetoothGatt bluetoothGatt) {
            return this.gatt == bluetoothGatt && LampGattTransport.access$1300(LampGattTransport.this).get(this.address) == this;
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onConnectionStateChange(final BluetoothGatt bluetoothGatt, final int i, final int i2) {
            LampGattTransport.access$1400(LampGattTransport.this).post(new Runnable() { // from class: com.pianchang.lighting.LampGattTransport$Link$$ExternalSyntheticLambda8
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m24xbcc17250(bluetoothGatt, i, i2);
                }
            });
        }

        /* renamed from: lambda$onConnectionStateChange$3$com-pianchang-lighting-LampGattTransport$Link, reason: not valid java name */
        /* synthetic */ void m24xbcc17250(BluetoothGatt bluetoothGatt, int i, int i2) {
            if (active(bluetoothGatt)) {
                if (i != 0 || i2 == 0) {
                    fail("Disconnected", "灯具蓝牙连接已中断，请确认灯具开机并关闭原厂 App 后重试。");
                } else if (i2 == 2) {
                    try {
                        if (bluetoothGatt.discoverServices()) {
                            return;
                        }
                    } catch (RuntimeException unused) {
                    }
                    fail("DiscoveryFailed", "无法读取灯具的蓝牙服务，请重新连接。");
                }
            }
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onServicesDiscovered(final BluetoothGatt bluetoothGatt, final int i) {
            LampGattTransport.access$1400(LampGattTransport.this).post(new Runnable() { // from class: com.pianchang.lighting.LampGattTransport$Link$$ExternalSyntheticLambda6
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m27xb059896c(bluetoothGatt, i);
                }
            });
        }

        /* renamed from: lambda$onServicesDiscovered$4$com-pianchang-lighting-LampGattTransport$Link, reason: not valid java name */
        /* synthetic */ void m27xb059896c(BluetoothGatt bluetoothGatt, int i) {
            if (active(bluetoothGatt) && this.writer == null) {
                if (i != 0) {
                    fail("DiscoveryFailed", "无法读取灯具的蓝牙服务，请重新连接。");
                    return;
                }
                if (!selectCharacteristics(this.profile)) {
                    fail("NotSupportedError", "这盏灯未提供所需的蓝牙调光服务。");
                    return;
                }
                if (this.mtu >= this.profile.payloadSize + 3) {
                    prepareNotifications();
                    return;
                }
                try {
                    boolean zRequestMtu = bluetoothGatt.requestMtu(this.profile == Profile.XSJ ? 128 : this.profile.payloadSize + 3);
                    this.waitingForMtu = zRequestMtu;
                    if (zRequestMtu) {
                        return;
                    }
                } catch (RuntimeException unused) {
                }
                fail("MtuFailed", "当前蓝牙连接的报文空间不足，请关闭原厂 App 后重连。");
            }
        }

        private boolean selectCharacteristics(Profile profile) {
            BluetoothGattCharacteristic characteristic;
            for (UUID uuid : profile.services) {
                BluetoothGattService service = this.gatt.getService(uuid);
                if (service != null && (characteristic = service.getCharacteristic(profile.write)) != null) {
                    int properties = characteristic.getProperties();
                    BluetoothGattCharacteristic characteristic2 = service.getCharacteristic(profile.notify);
                    if (!profile.isMesh() || (characteristic2 != null && (characteristic2.getProperties() & 16) != 0)) {
                        if ((profile == Profile.NANLINK || profile == Profile.ULANZI || profile == Profile.ZHIYUN) && (properties & 8) != 0) {
                            this.writeType = 2;
                        } else if ((properties & 4) != 0) {
                            this.writeType = 1;
                        } else if (profile == Profile.YONGNUO && (properties & 8) != 0) {
                            this.writeType = 2;
                        }
                        this.writer = characteristic;
                        this.notifier = characteristic2;
                        return true;
                    }
                }
            }
            return false;
        }

        private boolean promoteToProxy(String str) {
            BluetoothGattCharacteristic bluetoothGattCharacteristic = this.notifier;
            if (!selectCharacteristics(Profile.MESH_PROXY)) {
                return false;
            }
            this.ready = false;
            this.profile = Profile.MESH_PROXY;
            this.connectId = str;
            this.notificationDescriptor = null;
            if (bluetoothGattCharacteristic != null) {
                try {
                    this.gatt.setCharacteristicNotification(bluetoothGattCharacteristic, false);
                } catch (RuntimeException unused) {
                }
            }
            LampGattTransport.access$1400(LampGattTransport.this).postDelayed(this.connectTimeout, 14000L);
            subscribe();
            return true;
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onMtuChanged(final BluetoothGatt bluetoothGatt, final int i, final int i2) {
            LampGattTransport.access$1400(LampGattTransport.this).post(new Runnable() { // from class: com.pianchang.lighting.LampGattTransport$Link$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m26x5ae5618d(bluetoothGatt, i2, i);
                }
            });
        }

        /* renamed from: lambda$onMtuChanged$5$com-pianchang-lighting-LampGattTransport$Link, reason: not valid java name */
        /* synthetic */ void m26x5ae5618d(BluetoothGatt bluetoothGatt, int i, int i2) {
            if (active(bluetoothGatt)) {
                if (i == 0) {
                    this.mtu = i2;
                }
                if (this.waitingForMtu) {
                    this.waitingForMtu = false;
                    if (this.mtu >= this.profile.payloadSize + 3) {
                        prepareNotifications();
                    } else {
                        fail("MtuFailed", "当前蓝牙连接的报文空间不足，请关闭原厂 App 后重连。");
                    }
                }
            }
        }

        private void prepareNotifications() {
            if (this.profile != Profile.ULANZI) {
                subscribe();
                return;
            }
            BluetoothGattService service = this.gatt.getService(LampGattTransport.access$1500());
            BluetoothGattCharacteristic characteristic = service == null ? null : service.getCharacteristic(LampGattTransport.access$1600());
            if (characteristic == null) {
                fail("HandshakeUnavailable", "这台 Ulanzi 设备未提供灯具握手服务。");
                return;
            }
            int properties = characteristic.getProperties();
            boolean z = (properties & 8) != 0;
            if (!z && (properties & 4) == 0) {
                fail("HandshakeUnavailable", "这台 Ulanzi 设备的握手通道不可写。");
                return;
            }
            if (!writeValue(characteristic, new byte[]{9}, z ? 2 : 1)) {
                fail("HandshakeFailed", "Ulanzi 灯具握手失败，请重新连接。");
            } else {
                this.handshakeWriter = characteristic;
            }
        }

        private void subscribe() {
            byte[] bArr;
            BluetoothGattCharacteristic bluetoothGattCharacteristic = this.notifier;
            if (bluetoothGattCharacteristic != null) {
                this.notificationDescriptor = bluetoothGattCharacteristic.getDescriptor(LampGattTransport.access$1700());
                int properties = this.notifier.getProperties();
                if ((properties & 16) != 0) {
                    bArr = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE;
                } else {
                    bArr = (properties & 32) != 0 ? BluetoothGattDescriptor.ENABLE_INDICATION_VALUE : null;
                }
                if (this.notificationDescriptor != null && bArr != null) {
                    try {
                        if (this.gatt.setCharacteristicNotification(this.notifier, true)) {
                            if (Build.VERSION.SDK_INT >= 33) {
                                if (this.gatt.writeDescriptor(this.notificationDescriptor, bArr) == 0) {
                                    return;
                                }
                            } else if (this.notificationDescriptor.setValue(bArr) && this.gatt.writeDescriptor(this.notificationDescriptor)) {
                                return;
                            }
                        }
                    } catch (RuntimeException unused) {
                    }
                }
            }
            finishSubscription(false);
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onDescriptorWrite(final BluetoothGatt bluetoothGatt, final BluetoothGattDescriptor bluetoothGattDescriptor, final int i) {
            LampGattTransport.access$1400(LampGattTransport.this).post(new Runnable() { // from class: com.pianchang.lighting.LampGattTransport$Link$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m25x9133e5e0(bluetoothGatt, bluetoothGattDescriptor, i);
                }
            });
        }

        /* renamed from: lambda$onDescriptorWrite$6$com-pianchang-lighting-LampGattTransport$Link, reason: not valid java name */
        /* synthetic */ void m25x9133e5e0(BluetoothGatt bluetoothGatt, BluetoothGattDescriptor bluetoothGattDescriptor, int i) {
            if (!active(bluetoothGatt) || this.connectId == null || this.ready || this.notificationDescriptor == null || !LampGattTransport.access$1700().equals(bluetoothGattDescriptor.getUuid()) || !this.profile.notify.equals(bluetoothGattDescriptor.getCharacteristic().getUuid())) {
                return;
            }
            finishSubscription(i == 0);
        }

        private void finishSubscription(boolean z) {
            if (!z && this.profile.notificationRequired) {
                fail("NotificationFailed", "无法订阅灯具的蓝牙通知，请重新连接。");
                return;
            }
            this.ready = true;
            LampGattTransport.access$1400(LampGattTransport.this).removeCallbacks(this.connectTimeout);
            String str = this.connectId;
            this.connectId = null;
            reportConnected(str);
        }

        private void reportConnected(String str) {
            LampGattTransport.access$1800(LampGattTransport.this).accept(str, LightingBluetoothBridge.json("ok", true, "maxWriteSize", Integer.valueOf(this.profile.payloadSize)));
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onCharacteristicChanged(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic bluetoothGattCharacteristic) {
            receiveNotification(bluetoothGatt, bluetoothGattCharacteristic, bluetoothGattCharacteristic.getValue());
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onCharacteristicChanged(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic bluetoothGattCharacteristic, byte[] bArr) {
            receiveNotification(bluetoothGatt, bluetoothGattCharacteristic, bArr);
        }

        private void receiveNotification(final BluetoothGatt bluetoothGatt, final BluetoothGattCharacteristic bluetoothGattCharacteristic, byte[] bArr) {
            if (bArr == null || bArr.length == 0 || bArr.length > 514) {
                return;
            }
            final byte[] bArr2 = (byte[]) bArr.clone();
            LampGattTransport.access$1400(LampGattTransport.this).post(new Runnable() { // from class: com.pianchang.lighting.LampGattTransport$Link$$ExternalSyntheticLambda7
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m28x2d3ed2fe(bluetoothGatt, bluetoothGattCharacteristic, bArr2);
                }
            });
        }

        /* renamed from: lambda$receiveNotification$7$com-pianchang-lighting-LampGattTransport$Link, reason: not valid java name */
        /* synthetic */ void m28x2d3ed2fe(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic bluetoothGattCharacteristic, byte[] bArr) {
            if (this.ready && active(bluetoothGatt) && this.profile.reportsState() && this.profile.notify.equals(bluetoothGattCharacteristic.getUuid())) {
                LampGattTransport.access$2000(LampGattTransport.this).accept(this.address, bArr);
            }
        }

        private void scheduleWrite() {
            LampGattTransport.access$1400(LampGattTransport.this).postAtTime(this.nextWrite, Math.max(SystemClock.uptimeMillis(), this.nextWriteTime));
        }

        private void sendFrame() {
            WriteBatch writeBatch;
            if (!this.ready || (writeBatch = this.batch) == null || this.awaitingWrite) {
                return;
            }
            if (writeValue(this.writer, writeBatch.frames.get(this.batch.offset), this.writeType)) {
                this.awaitingWrite = true;
                this.nextWriteTime = SystemClock.uptimeMillis() + this.batch.interval;
                if (this.profile.isMesh()) {
                    return;
                }
                LampGattTransport.access$1400(LampGattTransport.this).postDelayed(this.frameTimeout, 1200L);
                return;
            }
            fail("WriteFailed", "蓝牙调光指令发送失败，请重新连接灯具。");
        }

        private boolean writeValue(BluetoothGattCharacteristic bluetoothGattCharacteristic, byte[] bArr, int i) {
            try {
                if (Build.VERSION.SDK_INT >= 33) {
                    return this.gatt.writeCharacteristic(bluetoothGattCharacteristic, bArr, i) == 0;
                }
                bluetoothGattCharacteristic.setWriteType(i);
                return bluetoothGattCharacteristic.setValue(bArr) && this.gatt.writeCharacteristic(bluetoothGattCharacteristic);
            } catch (RuntimeException unused) {
                return false;
            }
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onCharacteristicWrite(final BluetoothGatt bluetoothGatt, final BluetoothGattCharacteristic bluetoothGattCharacteristic, final int i) {
            LampGattTransport.access$1400(LampGattTransport.this).post(new Runnable() { // from class: com.pianchang.lighting.LampGattTransport$Link$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m23xce1c25b6(bluetoothGatt, bluetoothGattCharacteristic, i);
                }
            });
        }

        /* renamed from: lambda$onCharacteristicWrite$8$com-pianchang-lighting-LampGattTransport$Link, reason: not valid java name */
        /* synthetic */ void m23xce1c25b6(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic bluetoothGattCharacteristic, int i) {
            if (active(bluetoothGatt)) {
                if (this.handshakeWriter == bluetoothGattCharacteristic) {
                    this.handshakeWriter = null;
                    if (i == 0) {
                        subscribe();
                        return;
                    } else {
                        fail("HandshakeFailed", "Ulanzi 灯具握手失败，请重新连接。");
                        return;
                    }
                }
                if (this.batch != null && this.awaitingWrite && bluetoothGattCharacteristic == this.writer) {
                    this.awaitingWrite = false;
                    LampGattTransport.access$1400(LampGattTransport.this).removeCallbacks(this.frameTimeout);
                    if (i != 0) {
                        fail("WriteFailed", "蓝牙调光指令发送失败，请重新连接灯具。");
                        return;
                    }
                    WriteBatch writeBatch = this.batch;
                    int i2 = writeBatch.offset + 1;
                    writeBatch.offset = i2;
                    if (i2 < this.batch.frames.size()) {
                        scheduleWrite();
                        return;
                    }
                    String str = this.batch.id;
                    this.batch = null;
                    LampGattTransport.access$1400(LampGattTransport.this).removeCallbacks(this.writeTimeout);
                    LampGattTransport.access$1800(LampGattTransport.this).accept(str, LightingBluetoothBridge.json("ok", true));
                }
            }
        }

        private void fail(String str, String str2) {
            String str3 = this.connectId;
            WriteBatch writeBatch = this.batch;
            String str4 = writeBatch == null ? null : writeBatch.id;
            boolean z = this.ready && !"Cancelled".equals(str);
            release();
            if (str3 != null) {
                LampGattTransport.access$1800(LampGattTransport.this).accept(str3, LightingBluetoothBridge.error(str, str2));
            }
            if (str4 != null) {
                LampGattTransport.access$1800(LampGattTransport.this).accept(str4, LightingBluetoothBridge.error(str, str2));
            }
            if (z) {
                LampGattTransport.access$1900(LampGattTransport.this).accept(this.address);
            }
        }

        private void release() {
            LampGattTransport.access$1300(LampGattTransport.this).remove(this.address, this);
            this.ready = false;
            this.connectId = null;
            this.batch = null;
            LampGattTransport.access$1400(LampGattTransport.this).removeCallbacks(this.connectTimeout);
            LampGattTransport.access$1400(LampGattTransport.this).removeCallbacks(this.writeTimeout);
            LampGattTransport.access$1400(LampGattTransport.this).removeCallbacks(this.frameTimeout);
            LampGattTransport.access$1400(LampGattTransport.this).removeCallbacks(this.nextWrite);
            if (this.delayedConnect != null) {
                LampGattTransport.access$1400(LampGattTransport.this).removeCallbacks(this.delayedConnect);
            }
            BluetoothGatt bluetoothGatt = this.gatt;
            this.gatt = null;
            if (bluetoothGatt != null) {
                try {
                    bluetoothGatt.disconnect();
                } catch (RuntimeException unused) {
                }
                try {
                    bluetoothGatt.close();
                } catch (RuntimeException unused2) {
                }
            }
        }
    }
}
