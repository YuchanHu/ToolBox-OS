package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class GattProxySetMessage extends ConfigMessage {
    public byte gattProxy;

    public GattProxySetMessage(int i) {
        super(i);
    }

    public static GattProxySetMessage getSimple(int i, byte b) {
        GattProxySetMessage gattProxySetMessage = new GattProxySetMessage(i);
        gattProxySetMessage.gattProxy = b;
        return gattProxySetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.CFG_GATT_PROXY_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_GATT_PROXY_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return new byte[]{this.gattProxy};
    }
}
