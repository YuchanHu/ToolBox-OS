package com.telink.ble.mesh.core.proxy;

/* loaded from: classes.dex */
public enum ProxyFilterType {
    WhiteList((byte) 0),
    BlackList((byte) 1);

    public final byte value;

    ProxyFilterType(byte b) {
        this.value = b;
    }
}
