package com.telink.ble.mesh.core.message;

import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class HeartbeatStatus {
    private int features;
    private int initTTL;
    private int rfu;

    public void parse(byte[] bArr) {
        byte b = bArr[0];
        this.rfu = (b & FUDistributor.UPDATE_TTL) >> 7;
        this.initTTL = b & 127;
        this.features = MeshUtils.bytes2Integer(new byte[]{bArr[1], bArr[2]}, ByteOrder.BIG_ENDIAN);
    }

    public int getRfu() {
        return this.rfu;
    }

    public int getInitTTL() {
        return this.initTTL;
    }

    public int getFeatures() {
        return this.features;
    }
}
