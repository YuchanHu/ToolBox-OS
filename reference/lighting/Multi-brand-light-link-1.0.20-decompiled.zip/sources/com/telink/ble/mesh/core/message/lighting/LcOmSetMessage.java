package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;

/* loaded from: classes.dex */
public class LcOmSetMessage extends GenericMessage {
    private boolean ack;
    private byte mode;

    public static LcOmSetMessage getSimple(int i, int i2, byte b, boolean z, int i3) {
        LcOmSetMessage lcOmSetMessage = new LcOmSetMessage(i, i2);
        lcOmSetMessage.mode = b;
        lcOmSetMessage.ack = z;
        lcOmSetMessage.setResponseMax(i3);
        return lcOmSetMessage;
    }

    public LcOmSetMessage(int i, int i2) {
        super(i, i2);
        this.ack = false;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return this.ack ? Opcode.LIGHT_LC_OM_STATUS.value : super.getResponseOpcode();
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.LIGHT_LC_OM_SET : Opcode.LIGHT_LC_OM_SET_NOACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return new byte[]{this.mode};
    }

    public void setMode(byte b) {
        this.mode = b;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }
}
