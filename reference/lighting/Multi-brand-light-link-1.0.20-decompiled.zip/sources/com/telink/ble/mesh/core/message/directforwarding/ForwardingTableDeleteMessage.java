package com.telink.ble.mesh.core.message.directforwarding;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.config.ConfigMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ForwardingTableDeleteMessage extends ConfigMessage {
    public int destination;
    public int netKeyIndex;
    public int pathOrigin;

    public static ForwardingTableDeleteMessage getSimple(int i, int i2) {
        ForwardingTableDeleteMessage forwardingTableDeleteMessage = new ForwardingTableDeleteMessage(i);
        forwardingTableDeleteMessage.setResponseMax(1);
        forwardingTableDeleteMessage.netKeyIndex = i2;
        return forwardingTableDeleteMessage;
    }

    public ForwardingTableDeleteMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FORWARDING_TABLE_DELETE.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FORWARDING_TABLE_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(6).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.netKeyIndex).putShort((short) this.pathOrigin).putShort((short) this.destination).array();
    }
}
