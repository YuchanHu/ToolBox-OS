package com.telink.ble.mesh.foundation.event;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.foundation.Event;

/* loaded from: classes.dex */
public class BluetoothEvent extends Event<String> implements Parcelable {
    public static final Parcelable.Creator<BluetoothEvent> CREATOR = new Parcelable.Creator<BluetoothEvent>() { // from class: com.telink.ble.mesh.foundation.event.BluetoothEvent.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BluetoothEvent createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BluetoothEvent[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BluetoothEvent createFromParcel(Parcel parcel) {
            return new BluetoothEvent(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BluetoothEvent[] newArray(int i) {
            return new BluetoothEvent[i];
        }
    };
    public static final String EVENT_TYPE_BLUETOOTH_STATE_CHANGE = "com.telink.ble.mesh.EVENT_TYPE_BLUETOOTH_STATE_CHANGE";
    private String desc;
    private int state;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public BluetoothEvent(Object obj, String str) {
        super(obj, str);
    }

    public int getState() {
        return this.state;
    }

    public void setState(int i) {
        this.state = i;
    }

    public String getDesc() {
        return this.desc;
    }

    public void setDesc(String str) {
        this.desc = str;
    }

    protected BluetoothEvent(Parcel parcel) {
        this.state = parcel.readInt();
        this.desc = parcel.readString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.state);
        parcel.writeString(this.desc);
    }
}
