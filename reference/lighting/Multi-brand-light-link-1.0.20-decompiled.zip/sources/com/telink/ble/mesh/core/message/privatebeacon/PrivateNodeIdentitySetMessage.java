package com.telink.ble.mesh.core.message.privatebeacon;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.config.ConfigMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class PrivateNodeIdentitySetMessage extends ConfigMessage {
    public int netKeyIndex;
    public byte privateIdentity;

    public PrivateNodeIdentitySetMessage(int i) {
        super(i);
    }

    public static PrivateNodeIdentitySetMessage getSimple(int i, int i2, byte b) {
        PrivateNodeIdentitySetMessage privateNodeIdentitySetMessage = new PrivateNodeIdentitySetMessage(i);
        privateNodeIdentitySetMessage.netKeyIndex = i2;
        privateNodeIdentitySetMessage.privateIdentity = b;
        return privateNodeIdentitySetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.PRIVATE_NODE_IDENTITY_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.PRIVATE_NODE_IDENTITY_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(3).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.netKeyIndex).put(this.privateIdentity).array();
    }
}
