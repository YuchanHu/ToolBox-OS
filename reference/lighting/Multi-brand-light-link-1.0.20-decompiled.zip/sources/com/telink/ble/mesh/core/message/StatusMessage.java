package com.telink.ble.mesh.core.message;

import android.os.Parcelable;
import com.telink.ble.mesh.core.message.MeshStatus;

/* loaded from: classes.dex */
public abstract class StatusMessage implements Parcelable {
    public abstract void parse(byte[] bArr);

    public static StatusMessage createByAccessMessage(int i, byte[] bArr) throws IllegalAccessException, InstantiationException {
        Class messageClass = MeshStatus.Container.getMessageClass(i);
        if (messageClass == null) {
            return null;
        }
        try {
            Object objNewInstance = messageClass.newInstance();
            if (!(objNewInstance instanceof StatusMessage)) {
                return null;
            }
            StatusMessage statusMessage = (StatusMessage) objNewInstance;
            if (bArr != null) {
                statusMessage.parse(bArr);
            }
            return statusMessage;
        } catch (IllegalAccessException | InstantiationException | RuntimeException e) {
            e.printStackTrace();
            return null;
        }
    }
}
