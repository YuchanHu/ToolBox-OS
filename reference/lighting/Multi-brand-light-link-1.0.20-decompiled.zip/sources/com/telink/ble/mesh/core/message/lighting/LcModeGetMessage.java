package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class LcModeGetMessage extends LightingMessage {
    public static LcModeGetMessage getSimple(int i, int i2, int i3) {
        LcModeGetMessage lcModeGetMessage = new LcModeGetMessage(i, i2);
        lcModeGetMessage.setResponseMax(i3);
        return lcModeGetMessage;
    }

    public LcModeGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.LIGHT_LC_MODE_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.LIGHT_LC_MODE_STATUS.value;
    }
}
