package com.telink.ble.mesh.core.message.ondmdpxy;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.config.ConfigMessage;

/* loaded from: classes.dex */
public class OnDemandPrivateProxySetMessage extends ConfigMessage {
    public byte privateProxy;

    public OnDemandPrivateProxySetMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.CFG_ON_DEMAND_PROXY_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_ON_DEMAND_PROXY_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return new byte[]{this.privateProxy};
    }
}
