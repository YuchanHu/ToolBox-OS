package com.telink.ble.mesh.foundation.event;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.entity.BindingDevice;
import com.telink.ble.mesh.foundation.Event;

/* loaded from: classes.dex */
public class BindingEvent extends Event<String> {
    public static final Parcelable.Creator<BindingEvent> CREATOR = new Parcelable.Creator<BindingEvent>() { // from class: com.telink.ble.mesh.foundation.event.BindingEvent.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BindingEvent createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BindingEvent[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BindingEvent createFromParcel(Parcel parcel) {
            return new BindingEvent(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BindingEvent[] newArray(int i) {
            return new BindingEvent[i];
        }
    };
    public static final String EVENT_TYPE_BIND_FAIL = "com.telink.ble.mesh.EVENT_TYPE_BIND_FAIL";
    public static final String EVENT_TYPE_BIND_SUCCESS = "com.telink.ble.mesh.EVENT_TYPE_BIND_SUCCESS";
    private BindingDevice bindingDevice;
    private String desc;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public BindingEvent(Object obj, String str, BindingDevice bindingDevice, String str2) {
        super(obj, str);
        this.bindingDevice = bindingDevice;
        this.desc = str2;
    }

    protected BindingEvent(Parcel parcel) {
        this.bindingDevice = (BindingDevice) parcel.readParcelable(BindingDevice.class.getClassLoader());
        this.desc = parcel.readString();
    }

    public String getDesc() {
        return this.desc;
    }

    public void setDesc(String str) {
        this.desc = str;
    }

    public BindingDevice getBindingDevice() {
        return this.bindingDevice;
    }

    public BindingEvent(Object obj, String str) {
        super(obj, str);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.bindingDevice, i);
        parcel.writeString(this.desc);
    }
}
