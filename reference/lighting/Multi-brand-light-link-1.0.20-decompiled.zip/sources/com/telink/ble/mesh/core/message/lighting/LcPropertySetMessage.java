package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class LcPropertySetMessage extends GenericMessage {
    private boolean ack;
    private int propertyID;
    private byte[] propertyValue;

    public static LcPropertySetMessage getSimple(int i, int i2, int i3, byte[] bArr, boolean z, int i4) {
        LcPropertySetMessage lcPropertySetMessage = new LcPropertySetMessage(i, i2);
        lcPropertySetMessage.propertyID = i3;
        lcPropertySetMessage.propertyValue = bArr;
        lcPropertySetMessage.ack = z;
        lcPropertySetMessage.setResponseMax(i4);
        return lcPropertySetMessage;
    }

    public LcPropertySetMessage(int i, int i2) {
        super(i, i2);
        this.ack = false;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return this.ack ? Opcode.LIGHT_LC_PROPERTY_STATUS.value : super.getResponseOpcode();
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.LIGHT_LC_PROPERTY_SET : Opcode.LIGHT_LC_PROPERTY_SET_NOACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(this.propertyValue.length + 2).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.propertyID).put(this.propertyValue).array();
    }

    public void setPropertyID(int i) {
        this.propertyID = i;
    }

    public void setPropertyValue(byte[] bArr) {
        this.propertyValue = bArr;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }
}
