package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class LightnessGetMessage extends LightingMessage {
    public static LightnessGetMessage getSimple(int i, int i2, int i3) {
        LightnessGetMessage lightnessGetMessage = new LightnessGetMessage(i, i2);
        lightnessGetMessage.setResponseMax(i3);
        return lightnessGetMessage;
    }

    public LightnessGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.LIGHTNESS_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.LIGHTNESS_STATUS.value;
    }
}
