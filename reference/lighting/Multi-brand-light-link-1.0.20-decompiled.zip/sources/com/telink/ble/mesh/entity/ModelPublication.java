package com.telink.ble.mesh.entity;

import android.os.Parcel;
import android.os.Parcelable;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public final class ModelPublication implements Serializable, Parcelable {
    public static final Parcelable.Creator<ModelPublication> CREATOR = new Parcelable.Creator<ModelPublication>() { // from class: com.telink.ble.mesh.entity.ModelPublication.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ModelPublication createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ModelPublication[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ModelPublication createFromParcel(Parcel parcel) {
            return new ModelPublication(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ModelPublication[] newArray(int i) {
            return new ModelPublication[i];
        }
    };
    public static final int CREDENTIAL_FLAG_DEFAULT = 0;
    public static final int RETRANSMIT_COUNT_DEFAULT = 5;
    public static final int RETRANSMIT_INTERVAL_STEP_DEFAULT = 0;
    public static final int RFU_DEFAULT = 0;
    public static final int TTL_DEFAULT = 255;
    public int appKeyIndex;
    public int credentialFlag;
    public int elementAddress;
    public int modelId;
    public byte period;
    public int publishAddress;
    public int retransmitCount;
    public int retransmitIntervalSteps;
    public int rfu;
    public boolean sig;
    public int ttl;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    protected ModelPublication(Parcel parcel) {
        this.credentialFlag = 0;
        this.rfu = 0;
        this.ttl = 255;
        this.retransmitCount = 5;
        this.retransmitIntervalSteps = 0;
        this.elementAddress = parcel.readInt();
        this.publishAddress = parcel.readInt();
        this.appKeyIndex = parcel.readInt();
        this.credentialFlag = parcel.readInt();
        this.rfu = parcel.readInt();
        this.ttl = parcel.readInt();
        this.period = parcel.readByte();
        this.retransmitCount = parcel.readInt();
        this.retransmitIntervalSteps = parcel.readInt();
        this.modelId = parcel.readInt();
        this.sig = parcel.readByte() != 0;
    }

    public ModelPublication() {
        this.credentialFlag = 0;
        this.rfu = 0;
        this.ttl = 255;
        this.retransmitCount = 5;
        this.retransmitIntervalSteps = 0;
    }

    public static ModelPublication createDefault(int i, int i2, int i3, long j, int i4, boolean z) {
        ModelPublication modelPublication = new ModelPublication();
        modelPublication.elementAddress = i;
        modelPublication.publishAddress = i2;
        modelPublication.appKeyIndex = i3;
        modelPublication.period = TransitionTime.fromTime(j).getValue();
        modelPublication.modelId = i4;
        modelPublication.sig = z;
        return modelPublication;
    }

    public byte[] toBytes() {
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(this.sig ? 11 : 13).order(ByteOrder.LITTLE_ENDIAN);
        byteBufferOrder.putShort((short) this.elementAddress).putShort((short) this.publishAddress).putShort((short) (((this.rfu & 7) << 13) | (this.appKeyIndex & 4095) | ((this.credentialFlag & 1) << 12))).put((byte) this.ttl).put(this.period).put((byte) ((this.retransmitCount & 7) | (this.retransmitIntervalSteps << 3)));
        if (this.sig) {
            byteBufferOrder.putShort((short) this.modelId);
        } else {
            byteBufferOrder.putInt(this.modelId);
        }
        return byteBufferOrder.array();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.elementAddress);
        parcel.writeInt(this.publishAddress);
        parcel.writeInt(this.appKeyIndex);
        parcel.writeInt(this.credentialFlag);
        parcel.writeInt(this.rfu);
        parcel.writeInt(this.ttl);
        parcel.writeByte(this.period);
        parcel.writeInt(this.retransmitCount);
        parcel.writeInt(this.retransmitIntervalSteps);
        parcel.writeInt(this.modelId);
        parcel.writeByte(this.sig ? (byte) 1 : (byte) 0);
    }
}
