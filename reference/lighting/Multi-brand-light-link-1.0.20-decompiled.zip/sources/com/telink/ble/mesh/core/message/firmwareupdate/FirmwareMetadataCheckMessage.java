package com.telink.ble.mesh.core.message.firmwareupdate;

import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class FirmwareMetadataCheckMessage extends UpdatingMessage {
    private byte[] incomingFirmwareMetadata;
    private int updateFirmwareImageIndex;

    public static FirmwareMetadataCheckMessage getSimple(int i, int i2, int i3, byte[] bArr) {
        FirmwareMetadataCheckMessage firmwareMetadataCheckMessage = new FirmwareMetadataCheckMessage(i, i2);
        firmwareMetadataCheckMessage.setResponseMax(1);
        firmwareMetadataCheckMessage.updateFirmwareImageIndex = i3;
        firmwareMetadataCheckMessage.incomingFirmwareMetadata = bArr;
        return firmwareMetadataCheckMessage;
    }

    public FirmwareMetadataCheckMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FIRMWARE_UPDATE_FIRMWARE_METADATA_CHECK.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FIRMWARE_UPDATE_FIRMWARE_METADATA_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        byte[] bArr = this.incomingFirmwareMetadata;
        int length = (bArr == null || bArr.length <= 0) ? 0 : bArr.length;
        ByteBuffer byteBufferPut = ByteBuffer.allocate(length + 1).order(ByteOrder.LITTLE_ENDIAN).put((byte) this.updateFirmwareImageIndex);
        if (length != 0) {
            byteBufferPut.put(this.incomingFirmwareMetadata);
        }
        return byteBufferPut.array();
    }

    public void setUpdateFirmwareImageIndex(int i) {
        this.updateFirmwareImageIndex = i;
    }

    public void setIncomingFirmwareMetadata(byte[] bArr) {
        this.incomingFirmwareMetadata = bArr;
    }
}
