package com.telink.ble.mesh.core.networking.beacon;

import com.telink.ble.mesh.core.Encipher;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.util.Arrays;
import com.telink.ble.mesh.util.MeshLogger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class SecureNetworkBeacon extends MeshBeaconPDU {
    private static final int LENGTH_PAYLOAD = 22;
    private static final int MASK_IV_UPDATE = 2;
    private static final int MASK_KEY_REFRESH = 1;
    private byte[] authenticationValue;
    private final byte beaconType = 1;
    private byte flags;
    private int ivIndex;
    private byte[] networkID;

    public byte getBeaconType() {
        return (byte) 1;
    }

    public boolean isKeyRefreshing() {
        return (this.flags & 1) != 0;
    }

    public boolean isIvUpdating() {
        return (this.flags & 2) != 0;
    }

    public static SecureNetworkBeacon from(byte[] bArr, byte[] bArr2) {
        if (bArr.length != 22 || bArr[0] != 1) {
            return null;
        }
        SecureNetworkBeacon secureNetworkBeacon = new SecureNetworkBeacon();
        secureNetworkBeacon.flags = bArr[1];
        byte[] bArr3 = new byte[8];
        secureNetworkBeacon.networkID = bArr3;
        System.arraycopy(bArr, 2, bArr3, 0, bArr3.length);
        int length = secureNetworkBeacon.networkID.length;
        secureNetworkBeacon.ivIndex = MeshUtils.bytes2Integer(bArr, 2 + length, 4, ByteOrder.BIG_ENDIAN);
        byte[] bArr4 = new byte[8];
        secureNetworkBeacon.authenticationValue = bArr4;
        System.arraycopy(bArr, length + 6, bArr4, 0, bArr4.length);
        if (Arrays.equals(generateAuthValue(secureNetworkBeacon, bArr2), secureNetworkBeacon.authenticationValue)) {
            return secureNetworkBeacon;
        }
        MeshLogger.w("network beacon check err");
        return null;
    }

    public static SecureNetworkBeacon createIvUpdatingBeacon(int i, byte[] bArr, byte[] bArr2, boolean z) {
        SecureNetworkBeacon secureNetworkBeacon = new SecureNetworkBeacon();
        secureNetworkBeacon.flags = (byte) (z ? 2 : 0);
        secureNetworkBeacon.networkID = bArr;
        if (z) {
            i++;
        }
        secureNetworkBeacon.ivIndex = i;
        secureNetworkBeacon.authenticationValue = generateAuthValue(secureNetworkBeacon, bArr2);
        return secureNetworkBeacon;
    }

    private static byte[] generateAuthValue(SecureNetworkBeacon secureNetworkBeacon, byte[] bArr) {
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(13).order(ByteOrder.BIG_ENDIAN);
        byteBufferOrder.put(secureNetworkBeacon.flags);
        byteBufferOrder.put(secureNetworkBeacon.networkID);
        byteBufferOrder.putInt(secureNetworkBeacon.ivIndex);
        byte[] bArrAesCmac = Encipher.aesCmac(byteBufferOrder.array(), bArr);
        byte[] bArr2 = new byte[8];
        System.arraycopy(bArrAesCmac, 0, bArr2, 0, 8);
        return bArr2;
    }

    public String toString() {
        return "SecureNetworkBeacon{beaconType=1, flags=" + ((int) this.flags) + ", networkID=" + Arrays.bytesToHexString(this.networkID, "") + ", ivIndex=0x" + String.format("%08X", Integer.valueOf(this.ivIndex)) + ", authenticationValue=" + Arrays.bytesToHexString(this.authenticationValue, "") + '}';
    }

    public byte getFlags() {
        return this.flags;
    }

    public void setFlags(byte b) {
        this.flags = b;
    }

    public byte[] getNetworkID() {
        return this.networkID;
    }

    public void setNetworkID(byte[] bArr) {
        this.networkID = bArr;
    }

    public int getIvIndex() {
        return this.ivIndex;
    }

    public void setIvIndex(int i) {
        this.ivIndex = i;
    }

    public byte[] getAuthenticationValue() {
        return this.authenticationValue;
    }

    public void setAuthenticationValue(byte[] bArr) {
        this.authenticationValue = bArr;
    }

    @Override // com.telink.ble.mesh.core.provisioning.pdu.PDU
    public byte[] toBytes() {
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(22).order(ByteOrder.BIG_ENDIAN);
        byteBufferOrder.put((byte) 1).put(this.flags).put(this.networkID).putInt(this.ivIndex).put(this.authenticationValue);
        return byteBufferOrder.array();
    }
}
