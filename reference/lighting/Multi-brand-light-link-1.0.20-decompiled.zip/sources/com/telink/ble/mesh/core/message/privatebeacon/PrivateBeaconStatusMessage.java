package com.telink.ble.mesh.core.message.privatebeacon;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class PrivateBeaconStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<PrivateBeaconStatusMessage> CREATOR = new Parcelable.Creator<PrivateBeaconStatusMessage>() { // from class: com.telink.ble.mesh.core.message.privatebeacon.PrivateBeaconStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ PrivateBeaconStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ PrivateBeaconStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public PrivateBeaconStatusMessage createFromParcel(Parcel parcel) {
            return new PrivateBeaconStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public PrivateBeaconStatusMessage[] newArray(int i) {
            return new PrivateBeaconStatusMessage[i];
        }
    };
    public boolean isComplete;
    public byte privateBeacon;
    public byte randomUpdateIntervalSteps;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public PrivateBeaconStatusMessage() {
        this.isComplete = false;
    }

    protected PrivateBeaconStatusMessage(Parcel parcel) {
        this.isComplete = false;
        this.privateBeacon = parcel.readByte();
        this.randomUpdateIntervalSteps = parcel.readByte();
        this.isComplete = parcel.readByte() != 0;
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.privateBeacon = bArr[0];
        if (bArr.length >= 2) {
            this.isComplete = true;
            this.randomUpdateIntervalSteps = bArr[1];
        }
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.privateBeacon);
        parcel.writeByte(this.randomUpdateIntervalSteps);
        parcel.writeByte(this.isComplete ? (byte) 1 : (byte) 0);
    }
}
