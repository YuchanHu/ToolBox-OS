package com.telink.ble.mesh.foundation;

import com.telink.ble.mesh.core.ble.GattConnection;
import java.util.function.IntSupplier;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes.dex */
public final /* synthetic */ class MeshController$$ExternalSyntheticLambda1 implements IntSupplier {
    public final /* synthetic */ GattConnection f$0;

    public /* synthetic */ MeshController$$ExternalSyntheticLambda1(GattConnection gattConnection) {
        this.f$0 = gattConnection;
    }

    @Override // java.util.function.IntSupplier
    public final int getAsInt() {
        return this.f$0.getMtu();
    }
}
