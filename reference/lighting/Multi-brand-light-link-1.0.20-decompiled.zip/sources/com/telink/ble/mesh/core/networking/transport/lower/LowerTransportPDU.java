package com.telink.ble.mesh.core.networking.transport.lower;

import com.telink.ble.mesh.core.networking.NetworkingPDU;

/* loaded from: classes.dex */
public abstract class LowerTransportPDU implements NetworkingPDU {
    public static int SEG_TYPE_SEGMENTED = 1;
    public static int SEG_TYPE_UNSEGMENTED = 0;
    public static int TYPE_SEGMENTED_ACCESS_MESSAGE = 2817;
    public static int TYPE_SEGMENTED_CONTROL_MESSAGE = 2833;
    public static int TYPE_UNSEGMENTED_ACCESS_MESSAGE = 2816;
    public static int TYPE_UNSEGMENTED_CONTROL_MESSAGE = 2832;
    protected int seg;

    public abstract int getType();

    public abstract boolean segmented();
}
