package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class AppKeyStatusMessage extends StatusMessage {
    public static final Parcelable.Creator<AppKeyStatusMessage> CREATOR = new Parcelable.Creator<AppKeyStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.AppKeyStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ AppKeyStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ AppKeyStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public AppKeyStatusMessage createFromParcel(Parcel parcel) {
            return new AppKeyStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public AppKeyStatusMessage[] newArray(int i) {
            return new AppKeyStatusMessage[i];
        }
    };
    private int appKeyIndex;
    private int netKeyIndex;
    private byte status;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public AppKeyStatusMessage() {
    }

    protected AppKeyStatusMessage(Parcel parcel) {
        this.status = parcel.readByte();
        this.netKeyIndex = parcel.readInt();
        this.appKeyIndex = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.status = bArr[0];
        int iBytes2Integer = MeshUtils.bytes2Integer(new byte[]{bArr[1], bArr[2], bArr[3]}, ByteOrder.LITTLE_ENDIAN);
        this.netKeyIndex = iBytes2Integer & 4095;
        this.appKeyIndex = (iBytes2Integer >> 12) & 4095;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.status);
        parcel.writeInt(this.netKeyIndex);
        parcel.writeInt(this.appKeyIndex);
    }

    public byte getStatus() {
        return this.status;
    }

    public int getNetKeyIndex() {
        return this.netKeyIndex;
    }

    public int getAppKeyIndex() {
        return this.appKeyIndex;
    }
}
