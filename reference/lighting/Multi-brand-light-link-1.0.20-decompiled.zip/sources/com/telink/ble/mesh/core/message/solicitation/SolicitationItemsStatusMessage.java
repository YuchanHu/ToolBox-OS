package com.telink.ble.mesh.core.message.solicitation;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class SolicitationItemsStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<SolicitationItemsStatusMessage> CREATOR = new Parcelable.Creator<SolicitationItemsStatusMessage>() { // from class: com.telink.ble.mesh.core.message.solicitation.SolicitationItemsStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SolicitationItemsStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SolicitationItemsStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SolicitationItemsStatusMessage createFromParcel(Parcel parcel) {
            return new SolicitationItemsStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SolicitationItemsStatusMessage[] newArray(int i) {
            return new SolicitationItemsStatusMessage[i];
        }
    };
    public byte privateProxy;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public SolicitationItemsStatusMessage() {
    }

    protected SolicitationItemsStatusMessage(Parcel parcel) {
        this.privateProxy = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.privateProxy = bArr[0];
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.privateProxy);
    }
}
