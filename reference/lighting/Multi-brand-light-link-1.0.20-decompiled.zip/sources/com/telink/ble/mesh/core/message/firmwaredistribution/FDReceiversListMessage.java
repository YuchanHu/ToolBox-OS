package com.telink.ble.mesh.core.message.firmwaredistribution;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class FDReceiversListMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<FDReceiversListMessage> CREATOR = new Parcelable.Creator<FDReceiversListMessage>() { // from class: com.telink.ble.mesh.core.message.firmwaredistribution.FDReceiversListMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FDReceiversListMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FDReceiversListMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FDReceiversListMessage createFromParcel(Parcel parcel) {
            return new FDReceiversListMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FDReceiversListMessage[] newArray(int i) {
            return new FDReceiversListMessage[i];
        }
    };
    private int firstIndex;
    private List<DistributionReceiver> receiversList;
    private int receiversListCount;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public FDReceiversListMessage() {
    }

    protected FDReceiversListMessage(Parcel parcel) {
        this.receiversListCount = parcel.readInt();
        this.firstIndex = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.receiversListCount = MeshUtils.bytes2Integer(bArr, 0, 2, ByteOrder.LITTLE_ENDIAN);
        this.firstIndex = MeshUtils.bytes2Integer(bArr, 2, 2, ByteOrder.LITTLE_ENDIAN);
        this.receiversList = new ArrayList();
        int i = 4;
        while (bArr.length - i >= 5) {
            DistributionReceiver distributionReceiver = new DistributionReceiver();
            int iBytes2Integer = MeshUtils.bytes2Integer(bArr, i, 4, ByteOrder.LITTLE_ENDIAN);
            distributionReceiver.address = iBytes2Integer & MeshUtils.UNICAST_ADDRESS_MAX;
            distributionReceiver.retrievedUpdatePhase = (byte) ((iBytes2Integer >> 15) & 15);
            distributionReceiver.updateStatus = (byte) ((iBytes2Integer >> 19) & 7);
            distributionReceiver.transferStatus = (byte) ((iBytes2Integer >> 22) & 15);
            distributionReceiver.transferProgress = (byte) ((iBytes2Integer >> 26) & 63);
            int i2 = i + 4;
            i += 5;
            distributionReceiver.imageIndex = bArr[i2];
            this.receiversList.add(distributionReceiver);
        }
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.receiversListCount);
        parcel.writeInt(this.firstIndex);
    }

    public int getReceiversListCount() {
        return this.receiversListCount;
    }

    public int getFirstIndex() {
        return this.firstIndex;
    }

    public List<DistributionReceiver> getReceiversList() {
        return this.receiversList;
    }

    public static class DistributionReceiver {
        public int address;
        public byte imageIndex;
        public byte retrievedUpdatePhase;
        public byte transferProgress;
        public byte transferStatus;
        public byte updateStatus;

        public String toString() {
            return "DistributionReceiver{address=" + this.address + ", retrievedUpdatePhase=" + ((int) this.retrievedUpdatePhase) + ", updateStatus=" + ((int) this.updateStatus) + ", transferStatus=" + ((int) this.transferStatus) + ", transferProgress=" + ((int) this.transferProgress) + ", imageIndex=" + ((int) this.imageIndex) + '}';
        }
    }
}
