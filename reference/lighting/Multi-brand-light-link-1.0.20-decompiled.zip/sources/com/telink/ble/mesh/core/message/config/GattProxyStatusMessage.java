package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class GattProxyStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<GattProxyStatusMessage> CREATOR = new Parcelable.Creator<GattProxyStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.GattProxyStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ GattProxyStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ GattProxyStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public GattProxyStatusMessage createFromParcel(Parcel parcel) {
            return new GattProxyStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public GattProxyStatusMessage[] newArray(int i) {
            return new GattProxyStatusMessage[i];
        }
    };
    public byte gattProxy;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public GattProxyStatusMessage() {
    }

    protected GattProxyStatusMessage(Parcel parcel) {
        this.gattProxy = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.gattProxy = bArr[0];
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.gattProxy);
    }
}
