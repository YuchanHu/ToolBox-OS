package com.telink.ble.mesh.foundation;

import android.os.Parcelable;

/* loaded from: classes.dex */
public abstract class Event<T> implements Parcelable {
    protected Object sender;
    protected ThreadMode threadMode;
    protected T type;

    public enum ThreadMode {
        Background,
        Main,
        Default
    }

    public Event() {
        this.threadMode = ThreadMode.Default;
    }

    public Event(Object obj, T t) {
        this(obj, t, ThreadMode.Default);
    }

    public Event(Object obj, T t, ThreadMode threadMode) {
        ThreadMode threadMode2 = ThreadMode.Default;
        this.sender = obj;
        this.type = t;
        this.threadMode = threadMode;
    }

    public Object getSender() {
        return this.sender;
    }

    public T getType() {
        return this.type;
    }

    public ThreadMode getThreadMode() {
        return this.threadMode;
    }

    public Event<T> setThreadMode(ThreadMode threadMode) {
        this.threadMode = threadMode;
        return this;
    }
}
