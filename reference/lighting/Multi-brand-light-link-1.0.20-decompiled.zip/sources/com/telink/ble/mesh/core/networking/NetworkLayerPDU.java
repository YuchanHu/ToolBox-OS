package com.telink.ble.mesh.core.networking;

import com.telink.ble.mesh.core.Encipher;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.util.Arrays;
import com.telink.ble.mesh.util.MeshLogger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import org.spongycastle.crypto.DataLengthException;

/* loaded from: classes.dex */
public class NetworkLayerPDU {
    private byte ctl;
    private int dst;
    protected NetworkEncryptionSuite encryptionSuite;
    private byte ivi;
    private byte nid;
    private int seq;
    private int src;
    private byte[] transportPDU;
    private byte ttl;

    public NetworkLayerPDU(NetworkEncryptionSuite networkEncryptionSuite) {
        this.encryptionSuite = networkEncryptionSuite;
    }

    public byte[] generateEncryptedPayload() {
        byte b = (byte) ((this.ivi << 7) | (this.nid & 127));
        byte b2 = (byte) ((this.ctl << 7) | (this.ttl & 127));
        byte[] bArrEncryptNetworkPduPayload = encryptNetworkPduPayload(this.transportPDU);
        byte[] bArrCreateObfuscatedNetworkHeader = createObfuscatedNetworkHeader(b2, this.seq, this.src, createPECB(createPrivacyRandom(bArrEncryptNetworkPduPayload)));
        return ByteBuffer.allocate(bArrCreateObfuscatedNetworkHeader.length + 1 + bArrEncryptNetworkPduPayload.length).order(ByteOrder.BIG_ENDIAN).put(b).put(bArrCreateObfuscatedNetworkHeader).put(bArrEncryptNetworkPduPayload).array();
    }

    private byte[] createObfuscatedNetworkHeader(byte b, int i, int i2, byte[] bArr) {
        byte[] bArrInteger2Bytes = MeshUtils.integer2Bytes(i, 3, ByteOrder.BIG_ENDIAN);
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(bArrInteger2Bytes.length + 3).order(ByteOrder.BIG_ENDIAN);
        byteBufferOrder.put(b);
        byteBufferOrder.put(bArrInteger2Bytes);
        byteBufferOrder.putShort((short) i2);
        byte[] bArrArray = byteBufferOrder.array();
        ByteBuffer.allocate(6).put(bArr, 0, 6);
        byte[] bArr2 = new byte[6];
        for (int i3 = 0; i3 < 6; i3++) {
            bArr2[i3] = (byte) (bArrArray[i3] ^ bArr[i3]);
        }
        return bArr2;
    }

    private byte[] createPECB(byte[] bArr) {
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(bArr.length + 9);
        byteBufferAllocate.order(ByteOrder.BIG_ENDIAN);
        byteBufferAllocate.put(new byte[]{0, 0, 0, 0, 0});
        byteBufferAllocate.putInt(this.encryptionSuite.ivIndex);
        byteBufferAllocate.put(bArr);
        return Encipher.aes(byteBufferAllocate.array(), this.encryptionSuite.privacyKey);
    }

    private byte[] createPrivacyRandom(byte[] bArr) {
        byte[] bArr2 = new byte[7];
        System.arraycopy(bArr, 0, bArr2, 0, 7);
        return bArr2;
    }

    private byte[] encryptNetworkPduPayload(byte[] bArr) {
        return Encipher.ccm(ByteBuffer.allocate(bArr.length + 2).order(ByteOrder.BIG_ENDIAN).putShort((short) this.dst).put(bArr).array(), this.encryptionSuite.encryptionKey, generateNonce(), getMicLen(), true);
    }

    protected byte[] generateNonce() {
        return NonceGenerator.generateNetworkNonce((byte) ((this.ctl << 7) | this.ttl), MeshUtils.integer2Bytes(this.seq, 3, ByteOrder.BIG_ENDIAN), this.src, this.encryptionSuite.ivIndex);
    }

    private int getMicLen() {
        return this.ctl == 0 ? 4 : 8;
    }

    public byte[] parseObfuscatedNetworkHeader(byte[] bArr) {
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(6);
        byteBufferAllocate.order(ByteOrder.BIG_ENDIAN);
        byteBufferAllocate.put(bArr, 1, 6);
        byte[] bArrArray = byteBufferAllocate.array();
        ByteBuffer byteBufferAllocate2 = ByteBuffer.allocate(7);
        byteBufferAllocate2.order(ByteOrder.BIG_ENDIAN);
        byteBufferAllocate2.put(bArr, 7, 7);
        byte[] bArrCreatePECB = createPECB(createPrivacyRandom(byteBufferAllocate2.array()));
        byte[] bArr2 = new byte[6];
        for (int i = 0; i < 6; i++) {
            bArr2[i] = (byte) (bArrArray[i] ^ bArrCreatePECB[i]);
        }
        return bArr2;
    }

    public boolean parse(byte[] bArr) throws IllegalStateException, DataLengthException, IllegalArgumentException {
        byte b = bArr[0];
        int i = (b & FUDistributor.UPDATE_TTL) >> 7;
        int i2 = b & 127;
        if (!validateNetworkPdu(i, i2)) {
            MeshLogger.i("ivi or nid invalid: ivi -- " + i + " nid -- " + i2 + " encryptSuit : ivi -- " + this.encryptionSuite.ivIndex + " nid -- " + this.encryptionSuite.nid);
            return false;
        }
        byte[] obfuscatedNetworkHeader = parseObfuscatedNetworkHeader(bArr);
        byte b2 = obfuscatedNetworkHeader[0];
        byte[] bArrArray = ByteBuffer.allocate(3).order(ByteOrder.BIG_ENDIAN).put(obfuscatedNetworkHeader, 1, 3).array();
        int i3 = ((obfuscatedNetworkHeader[4] & FUDistributor.UPDATE_TTL) << 8) + (obfuscatedNetworkHeader[5] & FUDistributor.UPDATE_TTL);
        setIvi((byte) i);
        setNid((byte) i2);
        setCtl((byte) ((b2 >> 7) & 1));
        setTtl((byte) (b2 & 127));
        setSeq(MeshUtils.bytes2Integer(bArrArray, ByteOrder.BIG_ENDIAN));
        setSrc(i3);
        byte[] bArrGenerateNonce = generateNonce();
        int length = bArr.length - (obfuscatedNetworkHeader.length + 1);
        byte[] bArr2 = new byte[length];
        System.arraycopy(bArr, 7, bArr2, 0, length);
        byte[] bArrCcm = Encipher.ccm(bArr2, this.encryptionSuite.encryptionKey, bArrGenerateNonce, getMicLen(), false);
        if (bArrCcm == null) {
            MeshLogger.i("network layer decrypt err");
            return false;
        }
        int i4 = ((bArrCcm[0] & FUDistributor.UPDATE_TTL) << 8) | (bArrCcm[1] & FUDistributor.UPDATE_TTL);
        int length2 = bArrCcm.length - 2;
        byte[] bArr3 = new byte[length2];
        System.arraycopy(bArrCcm, 2, bArr3, 0, length2);
        this.dst = i4;
        setTransportPDU(bArr3);
        return true;
    }

    private boolean validateNetworkPdu(int i, int i2) {
        return i2 == this.encryptionSuite.nid && i == (this.encryptionSuite.ivIndex & 1);
    }

    public byte getIvi() {
        return this.ivi;
    }

    public void setIvi(byte b) {
        this.ivi = b;
    }

    public byte getNid() {
        return this.nid;
    }

    public void setNid(byte b) {
        this.nid = b;
    }

    public byte getCtl() {
        return this.ctl;
    }

    public void setCtl(byte b) {
        this.ctl = b;
    }

    public byte getTtl() {
        return this.ttl;
    }

    public void setTtl(byte b) {
        this.ttl = b;
    }

    public int getSeq() {
        return this.seq;
    }

    public void setSeq(int i) {
        this.seq = i;
    }

    public int getSrc() {
        return this.src;
    }

    public void setSrc(int i) {
        this.src = i;
    }

    public int getDst() {
        return this.dst;
    }

    public void setDst(int i) {
        this.dst = i;
    }

    public byte[] getTransportPDU() {
        return this.transportPDU;
    }

    public void setTransportPDU(byte[] bArr) {
        this.transportPDU = bArr;
    }

    public static class NetworkEncryptionSuite {
        protected byte[] encryptionKey;
        public int ivIndex;
        protected int nid;
        protected byte[] privacyKey;

        public NetworkEncryptionSuite(int i, byte[] bArr, byte[] bArr2, int i2) {
            this.ivIndex = i;
            this.encryptionKey = bArr;
            this.privacyKey = bArr2;
            this.nid = i2;
        }
    }

    public String toString() {
        return "NetworkLayerPDU{ivi=" + ((int) this.ivi) + ", nid=" + ((int) this.nid) + ", ctl=" + ((int) this.ctl) + ", ttl=" + ((int) this.ttl) + ", seq=0x" + Integer.toHexString(this.seq) + ", src=" + this.src + ", dst=" + this.dst + ", transportPDU=" + Arrays.bytesToHexString(this.transportPDU) + '}';
    }
}
