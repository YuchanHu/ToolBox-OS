package com.telink.ble.mesh.foundation.parameter;

/* loaded from: classes.dex */
public enum AutoConnectFilterType {
    NODE_IDENTITY(true, false),
    NETWORK_ID(false, true),
    AUTO(true, true);

    public final boolean isNetworkIdSupport;
    public final boolean isNodeIdentitySupport;

    AutoConnectFilterType(boolean z, boolean z2) {
        this.isNodeIdentitySupport = z;
        this.isNetworkIdSupport = z2;
    }
}
