package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;
import com.telink.ble.mesh.entity.ModelPublication;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ModelPublicationStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<ModelPublicationStatusMessage> CREATOR = new Parcelable.Creator<ModelPublicationStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.ModelPublicationStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ModelPublicationStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ModelPublicationStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ModelPublicationStatusMessage createFromParcel(Parcel parcel) {
            return new ModelPublicationStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ModelPublicationStatusMessage[] newArray(int i) {
            return new ModelPublicationStatusMessage[i];
        }
    };
    private ModelPublication publication;
    private byte status;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public ModelPublicationStatusMessage() {
    }

    protected ModelPublicationStatusMessage(Parcel parcel) {
        this.status = parcel.readByte();
        this.publication = (ModelPublication) parcel.readParcelable(ModelPublication.class.getClassLoader());
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.status = bArr[0];
        ModelPublication modelPublication = new ModelPublication();
        modelPublication.elementAddress = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.LITTLE_ENDIAN);
        modelPublication.publishAddress = MeshUtils.bytes2Integer(bArr, 3, 2, ByteOrder.LITTLE_ENDIAN);
        modelPublication.appKeyIndex = (bArr[5] & FUDistributor.UPDATE_TTL) | ((bArr[6] & 15) << 8);
        modelPublication.credentialFlag = 1 & (bArr[6] >> 4);
        modelPublication.rfu = (bArr[6] >> 5) & 7;
        modelPublication.ttl = bArr[7];
        modelPublication.period = bArr[8];
        modelPublication.retransmitCount = (bArr[9] >> 5) & 7;
        modelPublication.retransmitIntervalSteps = bArr[9] & 31;
        modelPublication.modelId = (bArr[10] & FUDistributor.UPDATE_TTL) | ((bArr[11] & FUDistributor.UPDATE_TTL) << 8);
        if (14 <= bArr.length) {
            modelPublication.sig = false;
            modelPublication.modelId = ((bArr[13] & FUDistributor.UPDATE_TTL) << 24) | ((bArr[12] & FUDistributor.UPDATE_TTL) << 16) | modelPublication.modelId;
        }
        this.publication = modelPublication;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.status);
        parcel.writeParcelable(this.publication, i);
    }

    public byte getStatus() {
        return this.status;
    }

    public ModelPublication getPublication() {
        return this.publication;
    }
}
