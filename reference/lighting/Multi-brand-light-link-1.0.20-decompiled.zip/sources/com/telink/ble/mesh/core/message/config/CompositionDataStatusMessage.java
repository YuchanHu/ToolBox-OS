package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;
import com.telink.ble.mesh.entity.CompositionData;
import com.telink.ble.mesh.util.Arrays;
import com.telink.ble.mesh.util.MeshLogger;

/* loaded from: classes.dex */
public class CompositionDataStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<CompositionDataStatusMessage> CREATOR = new Parcelable.Creator<CompositionDataStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.CompositionDataStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ CompositionDataStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ CompositionDataStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public CompositionDataStatusMessage createFromParcel(Parcel parcel) {
            return new CompositionDataStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public CompositionDataStatusMessage[] newArray(int i) {
            return new CompositionDataStatusMessage[i];
        }
    };
    private CompositionData compositionData;
    private int page;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public CompositionDataStatusMessage() {
        this.page = -1;
    }

    protected CompositionDataStatusMessage(Parcel parcel) {
        this.page = -1;
        this.page = parcel.readInt();
        this.compositionData = (CompositionData) parcel.readParcelable(CompositionData.class.getClassLoader());
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.compositionData = null;
        int i = (bArr == null || bArr.length == 0) ? -1 : bArr[0] & FUDistributor.UPDATE_TTL;
        this.page = i;
        if (i < 0) {
            return;
        }
        int length = bArr.length - 1;
        byte[] bArr2 = new byte[length];
        System.arraycopy(bArr, 1, bArr2, 0, length);
        MeshLogger.d("cps data - " + Arrays.bytesToHexString(bArr2));
        this.compositionData = CompositionData.from(bArr2);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.page);
        parcel.writeParcelable(this.compositionData, i);
    }

    public byte getPage() {
        return (byte) this.page;
    }

    public int getPageNumber() {
        return this.page;
    }

    public CompositionData getCompositionData() {
        return this.compositionData;
    }
}
