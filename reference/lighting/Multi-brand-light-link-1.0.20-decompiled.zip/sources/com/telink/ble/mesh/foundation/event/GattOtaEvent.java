package com.telink.ble.mesh.foundation.event;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.foundation.Event;

/* loaded from: classes.dex */
public class GattOtaEvent extends Event<String> {
    public static final Parcelable.Creator<GattOtaEvent> CREATOR = new Parcelable.Creator<GattOtaEvent>() { // from class: com.telink.ble.mesh.foundation.event.GattOtaEvent.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ GattOtaEvent createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ GattOtaEvent[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public GattOtaEvent createFromParcel(Parcel parcel) {
            return new GattOtaEvent(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public GattOtaEvent[] newArray(int i) {
            return new GattOtaEvent[i];
        }
    };
    public static final String EVENT_TYPE_OTA_FAIL = "com.telink.sig.mesh.OTA_FAIL";
    public static final String EVENT_TYPE_OTA_PROGRESS = "com.telink.sig.mesh.OTA_PROGRESS";
    public static final String EVENT_TYPE_OTA_SUCCESS = "com.telink.sig.mesh.OTA_SUCCESS";
    private String desc;
    private int progress;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public GattOtaEvent(Object obj, String str, int i, String str2) {
        super(obj, str);
        this.progress = i;
        this.desc = str2;
    }

    protected GattOtaEvent(Parcel parcel) {
        this.progress = parcel.readInt();
        this.desc = parcel.readString();
    }

    public String getDesc() {
        return this.desc;
    }

    public int getProgress() {
        return this.progress;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.progress);
        parcel.writeString(this.desc);
    }
}
