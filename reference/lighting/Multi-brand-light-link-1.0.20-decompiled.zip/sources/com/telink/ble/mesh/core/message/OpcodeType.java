package com.telink.ble.mesh.core.message;

import com.telink.ble.mesh.core.MeshUtils;

/* loaded from: classes.dex */
public enum OpcodeType {
    SIG_1(1),
    SIG_2(2),
    VENDOR(3);

    public final int length;

    OpcodeType(int i) {
        this.length = i;
    }

    public static OpcodeType getByFirstByte(byte b) {
        if ((MeshUtils.bit(7) & b) != 0) {
            return (b & MeshUtils.bit(6)) != 0 ? VENDOR : SIG_2;
        }
        return SIG_1;
    }
}
