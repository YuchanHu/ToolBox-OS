package com.telink.ble.mesh.core.message.privatebeacon;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class PrivateNodeIdentityStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<PrivateNodeIdentityStatusMessage> CREATOR = new Parcelable.Creator<PrivateNodeIdentityStatusMessage>() { // from class: com.telink.ble.mesh.core.message.privatebeacon.PrivateNodeIdentityStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ PrivateNodeIdentityStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ PrivateNodeIdentityStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public PrivateNodeIdentityStatusMessage createFromParcel(Parcel parcel) {
            return new PrivateNodeIdentityStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public PrivateNodeIdentityStatusMessage[] newArray(int i) {
            return new PrivateNodeIdentityStatusMessage[i];
        }
    };
    public int netKeyIndex;
    public byte privateIdentity;
    public byte status;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public PrivateNodeIdentityStatusMessage() {
    }

    protected PrivateNodeIdentityStatusMessage(Parcel parcel) {
        this.status = parcel.readByte();
        this.netKeyIndex = parcel.readInt();
        this.privateIdentity = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.status = bArr[0];
        this.netKeyIndex = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.LITTLE_ENDIAN);
        this.privateIdentity = bArr[3];
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.status);
        parcel.writeInt(this.netKeyIndex);
        parcel.writeByte(this.privateIdentity);
    }
}
