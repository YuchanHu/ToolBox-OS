package com.telink.ble.mesh.core.networking;

/* loaded from: classes.dex */
public interface NetworkingBridge {
    void onCommandPrepared(byte b, byte[] bArr);

    void onHeartbeatMessageReceived(int i, int i2, byte[] bArr);

    void onMeshMessageReceived(int i, int i2, int i3, byte[] bArr);

    void onNetworkInfoUpdate(int i, int i2);

    void onProxyInitComplete(boolean z, int i);

    void onReliableMessageComplete(boolean z, int i, int i2, int i3, int i4, Integer[] numArr);

    void onSegmentMessageComplete(boolean z);
}
