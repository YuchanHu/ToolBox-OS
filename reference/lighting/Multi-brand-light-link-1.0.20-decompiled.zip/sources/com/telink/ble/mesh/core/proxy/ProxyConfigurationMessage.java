package com.telink.ble.mesh.core.proxy;

/* loaded from: classes.dex */
public abstract class ProxyConfigurationMessage {
    public static final byte OPCODE_ADD_ADDRESS = 1;
    public static final byte OPCODE_FILTER_STATUS = 3;
    public static final byte OPCODE_REMOVE_ADDRESS = 2;
    public static final byte OPCODE_SET_FILTER_TYPE = 0;

    public abstract byte getOpcode();

    public abstract byte[] toByteArray();
}
