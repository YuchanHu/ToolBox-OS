package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class FriendStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<FriendStatusMessage> CREATOR = new Parcelable.Creator<FriendStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.FriendStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FriendStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FriendStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FriendStatusMessage createFromParcel(Parcel parcel) {
            return new FriendStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FriendStatusMessage[] newArray(int i) {
            return new FriendStatusMessage[i];
        }
    };
    public byte friend;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public FriendStatusMessage() {
    }

    protected FriendStatusMessage(Parcel parcel) {
        this.friend = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.friend = bArr[0];
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.friend);
    }
}
