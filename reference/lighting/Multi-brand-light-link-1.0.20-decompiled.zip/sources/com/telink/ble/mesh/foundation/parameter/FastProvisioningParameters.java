package com.telink.ble.mesh.foundation.parameter;

import com.telink.ble.mesh.core.ble.UUIDInfo;
import com.telink.ble.mesh.entity.FastProvisioningConfiguration;

/* loaded from: classes.dex */
public class FastProvisioningParameters extends Parameters {
    public FastProvisioningParameters(FastProvisioningConfiguration fastProvisioningConfiguration) {
        setScanFilter(createScanFilter(UUIDInfo.SERVICE_PROVISION));
        set(Parameters.ACTION_FAST_PROVISION_CONFIG, fastProvisioningConfiguration);
        set(Parameters.COMMON_PROXY_FILTER_INIT_NEEDED, false);
    }
}
