package com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class BlobTransferStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<BlobTransferStatusMessage> CREATOR = new Parcelable.Creator<BlobTransferStatusMessage>() { // from class: com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobTransferStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BlobTransferStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BlobTransferStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BlobTransferStatusMessage createFromParcel(Parcel parcel) {
            return new BlobTransferStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BlobTransferStatusMessage[] newArray(int i) {
            return new BlobTransferStatusMessage[i];
        }
    };
    private long blobId;
    private int blobSize;
    private int blockSizeLog;
    private List<Integer> blocksNotReceived;
    private int status;
    private int transferMTUSize;
    private int transferMode;
    private byte transferPhase;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public BlobTransferStatusMessage() {
    }

    protected BlobTransferStatusMessage(Parcel parcel) {
        this.status = parcel.readInt();
        this.transferMode = parcel.readInt();
        this.transferPhase = parcel.readByte();
        this.blobId = parcel.readLong();
        this.blobSize = parcel.readInt();
        this.blockSizeLog = parcel.readInt();
        this.transferMTUSize = parcel.readInt();
        ArrayList arrayList = new ArrayList();
        this.blocksNotReceived = arrayList;
        parcel.readList(arrayList, null);
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        byte b = bArr[0];
        this.status = b & 15;
        this.transferMode = (b >> 6) & 3;
        this.transferPhase = bArr[1];
        if (bArr.length < 10) {
            return;
        }
        this.blobId = MeshUtils.bytes2Long(bArr, 2, 8, ByteOrder.LITTLE_ENDIAN);
        if (bArr.length == 10) {
            return;
        }
        this.blobSize = MeshUtils.bytes2Integer(bArr, 10, 4, ByteOrder.LITTLE_ENDIAN);
        this.blockSizeLog = bArr[14] & FUDistributor.UPDATE_TTL;
        this.transferMTUSize = MeshUtils.bytes2Integer(bArr, 15, 2, ByteOrder.LITTLE_ENDIAN);
        this.blocksNotReceived = MeshUtils.parseMissingBitField(bArr, 17);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.status);
        parcel.writeInt(this.transferMode);
        parcel.writeByte(this.transferPhase);
        parcel.writeLong(this.blobId);
        parcel.writeInt(this.blobSize);
        parcel.writeInt(this.blockSizeLog);
        parcel.writeInt(this.transferMTUSize);
        parcel.writeList(this.blocksNotReceived);
    }

    public int getStatus() {
        return this.status;
    }

    public int getTransferMode() {
        return this.transferMode;
    }

    public byte getTransferPhase() {
        return this.transferPhase;
    }

    public long getBlobId() {
        return this.blobId;
    }

    public int getBlobSize() {
        return this.blobSize;
    }

    public int getBlockSizeLog() {
        return this.blockSizeLog;
    }

    public int getTransferMTUSize() {
        return this.transferMTUSize;
    }

    public List<Integer> getBlocksNotReceived() {
        return this.blocksNotReceived;
    }

    public String toString() {
        return "BlobTransferStatusMessage{status=" + this.status + ", transferMode=" + this.transferMode + ", transferPhase=" + ((int) this.transferPhase) + ", blobId=0x" + Long.toHexString(this.blobId) + ", blobSize=" + this.blobSize + ", blockSizeLog=" + this.blockSizeLog + ", transferMTUSize=" + this.transferMTUSize + ", blocksNotReceived=" + this.blocksNotReceived + '}';
    }
}
