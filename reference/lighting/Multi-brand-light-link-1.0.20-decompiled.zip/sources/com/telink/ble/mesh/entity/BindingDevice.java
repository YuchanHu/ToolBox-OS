package com.telink.ble.mesh.entity;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.access.BindingBearer;
import java.util.List;
import java.util.function.Function;

/* loaded from: classes.dex */
public class BindingDevice implements Parcelable {
    public static final Parcelable.Creator<BindingDevice> CREATOR = new Parcelable.Creator<BindingDevice>() { // from class: com.telink.ble.mesh.entity.BindingDevice.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BindingDevice createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BindingDevice[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BindingDevice createFromParcel(Parcel parcel) {
            return new BindingDevice(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BindingDevice[] newArray(int i) {
            return new BindingDevice[i];
        }
    };
    private int appKeyIndex;
    private BindingBearer bearer;
    private CompositionData compositionData;
    private boolean defaultBound;
    private byte[] deviceUUID;
    private int meshAddress;
    private Function<CompositionData, List<ModelTarget>> modelSelector;
    private int[] models;
    private int netKeyIndex;
    private int receivedCompositionPage;
    private boolean requireConfirmedBinding;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public BindingDevice() {
        this.netKeyIndex = -1;
        this.bearer = BindingBearer.GattOnly;
        this.defaultBound = false;
        this.receivedCompositionPage = -1;
    }

    public BindingDevice(int i, byte[] bArr, int i2) {
        this.netKeyIndex = -1;
        this.bearer = BindingBearer.GattOnly;
        this.defaultBound = false;
        this.receivedCompositionPage = -1;
        this.meshAddress = i;
        this.deviceUUID = bArr;
        this.appKeyIndex = i2;
        this.models = null;
        this.bearer = BindingBearer.GattOnly;
    }

    public BindingDevice(int i, byte[] bArr, int i2, int[] iArr, BindingBearer bindingBearer) {
        this.netKeyIndex = -1;
        BindingBearer bindingBearer2 = BindingBearer.GattOnly;
        this.defaultBound = false;
        this.receivedCompositionPage = -1;
        this.meshAddress = i;
        this.deviceUUID = bArr;
        this.appKeyIndex = i2;
        this.models = iArr;
        this.bearer = bindingBearer;
    }

    protected BindingDevice(Parcel parcel) {
        this.netKeyIndex = -1;
        this.bearer = BindingBearer.GattOnly;
        this.defaultBound = false;
        this.receivedCompositionPage = -1;
        this.netKeyIndex = parcel.readInt();
        this.meshAddress = parcel.readInt();
        this.deviceUUID = parcel.createByteArray();
        this.appKeyIndex = parcel.readInt();
        this.models = parcel.createIntArray();
        this.defaultBound = parcel.readByte() != 0;
        this.compositionData = (CompositionData) parcel.readParcelable(CompositionData.class.getClassLoader());
        this.requireConfirmedBinding = parcel.readByte() != 0;
        this.receivedCompositionPage = parcel.readInt();
    }

    public int getNetKeyIndex() {
        return this.netKeyIndex;
    }

    public void setNetKeyIndex(int i) {
        this.netKeyIndex = i;
    }

    public int getMeshAddress() {
        return this.meshAddress;
    }

    public void setMeshAddress(int i) {
        this.meshAddress = i;
    }

    public byte[] getDeviceUUID() {
        return this.deviceUUID;
    }

    public void setDeviceUUID(byte[] bArr) {
        this.deviceUUID = bArr;
    }

    public int getAppKeyIndex() {
        return this.appKeyIndex;
    }

    public void setAppKeyIndex(int i) {
        this.appKeyIndex = i;
    }

    public int[] getModels() {
        return this.models;
    }

    public void setModels(int[] iArr) {
        this.models = iArr;
    }

    public BindingBearer getBearer() {
        return this.bearer;
    }

    public void setBearer(BindingBearer bindingBearer) {
        this.bearer = bindingBearer;
    }

    public boolean isDefaultBound() {
        return this.defaultBound;
    }

    public void setDefaultBound(boolean z) {
        this.defaultBound = z;
    }

    public CompositionData getCompositionData() {
        return this.compositionData;
    }

    public void setCompositionData(CompositionData compositionData) {
        this.compositionData = compositionData;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.netKeyIndex);
        parcel.writeInt(this.meshAddress);
        parcel.writeByteArray(this.deviceUUID);
        parcel.writeInt(this.appKeyIndex);
        parcel.writeIntArray(this.models);
        parcel.writeByte(this.defaultBound ? (byte) 1 : (byte) 0);
        parcel.writeParcelable(this.compositionData, i);
        parcel.writeByte(this.requireConfirmedBinding ? (byte) 1 : (byte) 0);
        parcel.writeInt(this.receivedCompositionPage);
    }

    public int getReceivedCompositionPage() {
        return this.receivedCompositionPage;
    }

    public void setReceivedCompositionPage(int i) {
        this.receivedCompositionPage = i;
    }

    public Function<CompositionData, List<ModelTarget>> getModelSelector() {
        return this.modelSelector;
    }

    public void setModelSelector(Function<CompositionData, List<ModelTarget>> function) {
        this.modelSelector = function;
    }

    public static final class ModelTarget {
        public final int elementOffset;
        public final int modelId;
        public final boolean sig;

        public ModelTarget(int i, int i2, boolean z) {
            this.elementOffset = i;
            this.modelId = i2;
            this.sig = z;
        }
    }

    public boolean requiresConfirmedBinding() {
        return this.requireConfirmedBinding;
    }

    public void setRequireConfirmedBinding(boolean z) {
        this.requireConfirmedBinding = z;
    }
}
