package com.telink.ble.mesh.core.message.lighting;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class CtlStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<CtlStatusMessage> CREATOR = new Parcelable.Creator<CtlStatusMessage>() { // from class: com.telink.ble.mesh.core.message.lighting.CtlStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ CtlStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ CtlStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public CtlStatusMessage createFromParcel(Parcel parcel) {
            return new CtlStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public CtlStatusMessage[] newArray(int i) {
            return new CtlStatusMessage[i];
        }
    };
    private static final int DATA_LEN_COMPLETE = 9;
    private boolean isComplete;
    private int presentLightness;
    private int presentTemperature;
    private byte remainingTime;
    private int targetLightness;
    private int targetTemperature;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public CtlStatusMessage() {
        this.isComplete = false;
    }

    protected CtlStatusMessage(Parcel parcel) {
        this.isComplete = false;
        this.presentLightness = parcel.readInt();
        this.presentTemperature = parcel.readInt();
        this.targetLightness = parcel.readInt();
        this.targetTemperature = parcel.readInt();
        this.remainingTime = parcel.readByte();
        this.isComplete = parcel.readByte() != 0;
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.presentLightness = MeshUtils.bytes2Integer(bArr, 0, 2, ByteOrder.LITTLE_ENDIAN);
        this.presentTemperature = MeshUtils.bytes2Integer(bArr, 2, 2, ByteOrder.LITTLE_ENDIAN);
        if (bArr.length >= 9) {
            this.isComplete = true;
            this.targetLightness = MeshUtils.bytes2Integer(bArr, 4, 2, ByteOrder.LITTLE_ENDIAN);
            this.targetTemperature = MeshUtils.bytes2Integer(bArr, 6, 2, ByteOrder.LITTLE_ENDIAN);
            this.remainingTime = bArr[8];
        }
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.presentLightness);
        parcel.writeInt(this.presentTemperature);
        parcel.writeInt(this.targetLightness);
        parcel.writeInt(this.targetTemperature);
        parcel.writeByte(this.remainingTime);
        parcel.writeByte(this.isComplete ? (byte) 1 : (byte) 0);
    }

    public int getPresentLightness() {
        return this.presentLightness;
    }

    public int getPresentTemperature() {
        return this.presentTemperature;
    }

    public int getTargetLightness() {
        return this.targetLightness;
    }

    public int getTargetTemperature() {
        return this.targetTemperature;
    }

    public byte getRemainingTime() {
        return this.remainingTime;
    }

    public boolean isComplete() {
        return this.isComplete;
    }

    public String toString() {
        return "CtlStatusMessage{presentLightness=" + this.presentLightness + ", presentTemperature=" + this.presentTemperature + ", targetLightness=" + this.targetLightness + ", targetTemperature=" + this.targetTemperature + ", remainingTime=" + ((int) this.remainingTime) + ", isComplete=" + this.isComplete + '}';
    }
}
