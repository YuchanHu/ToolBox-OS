package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class CompositionDataGetMessage extends ConfigMessage {
    private static final byte PAGE_ALL = -1;
    private final byte page;

    public CompositionDataGetMessage(int i) {
        this(i, (byte) -1);
    }

    public CompositionDataGetMessage(int i, byte b) {
        super(i);
        this.page = b;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.COMPOSITION_DATA_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.COMPOSITION_DATA_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return new byte[]{this.page};
    }
}
