package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class NodeResetMessage extends ConfigMessage {
    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return null;
    }

    public NodeResetMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.NODE_RESET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.NODE_RESET_STATUS.value;
    }
}
