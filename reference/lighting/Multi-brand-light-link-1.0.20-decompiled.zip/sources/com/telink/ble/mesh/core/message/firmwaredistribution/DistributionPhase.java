package com.telink.ble.mesh.core.message.firmwaredistribution;

/* loaded from: classes.dex */
public enum DistributionPhase {
    IDLE(0, "No firmware distribution is in progress."),
    TRANSFER_ACTIVE(1, "Firmware distribution is in progress."),
    TRANSFER_SUCCESS(2, "The Transfer BLOB procedure has completed successfully."),
    APPLYING_UPDATE(3, "The Apply Firmware on Updating Nodes procedure is being executed."),
    COMPLETED(4, "The Distribute Firmware procedure has completed successfully."),
    FAILED(5, "The Distribute Firmware procedure has failed."),
    CANCELING_UPDATE(6, "The Cancel Firmware Update procedure is being executed.");

    public final String desc;
    public final int value;

    DistributionPhase(int i, String str) {
        this.value = i;
        this.desc = str;
    }
}
