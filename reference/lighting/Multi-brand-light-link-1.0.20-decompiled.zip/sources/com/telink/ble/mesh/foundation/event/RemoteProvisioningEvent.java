package com.telink.ble.mesh.foundation.event;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.entity.RemoteProvisioningDevice;
import com.telink.ble.mesh.foundation.Event;

/* loaded from: classes.dex */
public class RemoteProvisioningEvent extends Event<String> {
    public static final Parcelable.Creator<RemoteProvisioningEvent> CREATOR = new Parcelable.Creator<RemoteProvisioningEvent>() { // from class: com.telink.ble.mesh.foundation.event.RemoteProvisioningEvent.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ RemoteProvisioningEvent createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ RemoteProvisioningEvent[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public RemoteProvisioningEvent createFromParcel(Parcel parcel) {
            return new RemoteProvisioningEvent(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public RemoteProvisioningEvent[] newArray(int i) {
            return new RemoteProvisioningEvent[i];
        }
    };
    public static final String EVENT_TYPE_REMOTE_CAPABILITY_RECEIVED = "com.telink.sig.mesh.EVENT_TYPE_REMOTE_CAPABILITY_RECEIVED";
    public static final String EVENT_TYPE_REMOTE_PROVISIONING_FAIL = "com.telink.sig.mesh.EVENT_TYPE_REMOTE_PROVISIONING_FAIL";
    public static final String EVENT_TYPE_REMOTE_PROVISIONING_SUCCESS = "com.telink.sig.mesh.EVENT_TYPE_REMOTE_PROVISIONING_SUCCESS";
    private String desc;
    private RemoteProvisioningDevice remoteProvisioningDevice;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public RemoteProvisioningEvent(Object obj, String str) {
        super(obj, str);
    }

    protected RemoteProvisioningEvent(Parcel parcel) {
        this.remoteProvisioningDevice = (RemoteProvisioningDevice) parcel.readParcelable(RemoteProvisioningDevice.class.getClassLoader());
        this.desc = parcel.readString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.remoteProvisioningDevice, i);
        parcel.writeString(this.desc);
    }

    public RemoteProvisioningDevice getRemoteProvisioningDevice() {
        return this.remoteProvisioningDevice;
    }

    public void setRemoteProvisioningDevice(RemoteProvisioningDevice remoteProvisioningDevice) {
        this.remoteProvisioningDevice = remoteProvisioningDevice;
    }

    public String getDesc() {
        return this.desc;
    }

    public void setDesc(String str) {
        this.desc = str;
    }
}
