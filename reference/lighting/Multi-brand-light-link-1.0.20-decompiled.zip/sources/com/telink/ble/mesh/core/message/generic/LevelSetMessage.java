package com.telink.ble.mesh.core.message.generic;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class LevelSetMessage extends GenericMessage {
    private boolean ack;
    private byte delay;
    private boolean isComplete;
    private int level;
    private byte tid;
    private byte transitionTime;

    public LevelSetMessage(int i, int i2) {
        super(i, i2);
        this.tid = (byte) 0;
        this.transitionTime = (byte) 0;
        this.delay = (byte) 0;
        this.ack = false;
        this.isComplete = false;
        setTidPosition(2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.G_LEVEL_SET : Opcode.G_LEVEL_SET_NOACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        if (this.isComplete) {
            int i = this.level;
            return new byte[]{(byte) i, (byte) (i >> 8), this.tid, this.transitionTime, this.delay};
        }
        int i2 = this.level;
        return new byte[]{(byte) i2, (byte) (i2 >> 8), this.tid};
    }

    public void setLevel(int i) {
        this.level = i;
    }

    public void setTid(byte b) {
        this.tid = b;
    }

    public void setTransitionTime(byte b) {
        this.transitionTime = b;
    }

    public void setDelay(byte b) {
        this.delay = b;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }

    public void setComplete(boolean z) {
        this.isComplete = z;
    }
}
