package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class HslSetMessage extends GenericMessage {
    private boolean ack;
    private byte delay;
    private int hue;
    private boolean isComplete;
    private int lightness;
    private int saturation;
    private byte tid;
    private byte transitionTime;

    public static HslSetMessage getSimple(int i, int i2, int i3, int i4, int i5, boolean z, int i6) {
        HslSetMessage hslSetMessage = new HslSetMessage(i, i2);
        hslSetMessage.lightness = i3;
        hslSetMessage.hue = i4;
        hslSetMessage.saturation = i5;
        hslSetMessage.ack = z;
        hslSetMessage.setResponseMax(i6);
        return hslSetMessage;
    }

    public HslSetMessage(int i, int i2) {
        super(i, i2);
        this.tid = (byte) 0;
        this.transitionTime = (byte) 0;
        this.delay = (byte) 0;
        this.ack = false;
        this.isComplete = false;
        setTidPosition(6);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return this.ack ? Opcode.LIGHT_HSL_STATUS.value : super.getResponseOpcode();
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.LIGHT_HSL_SET : Opcode.LIGHT_HSL_SET_NOACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        if (this.isComplete) {
            return ByteBuffer.allocate(9).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.lightness).putShort((short) this.hue).putShort((short) this.saturation).put(this.tid).put(this.transitionTime).put(this.delay).array();
        }
        return ByteBuffer.allocate(7).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.lightness).putShort((short) this.hue).putShort((short) this.saturation).put(this.tid).array();
    }

    public void setLightness(int i) {
        this.lightness = i;
    }

    public void setHue(int i) {
        this.hue = i;
    }

    public void setSaturation(int i) {
        this.saturation = i;
    }

    public void setTid(byte b) {
        this.tid = b;
    }

    public void setTransitionTime(byte b) {
        this.transitionTime = b;
    }

    public void setDelay(byte b) {
        this.delay = b;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }

    public void setComplete(boolean z) {
        this.isComplete = z;
    }
}
