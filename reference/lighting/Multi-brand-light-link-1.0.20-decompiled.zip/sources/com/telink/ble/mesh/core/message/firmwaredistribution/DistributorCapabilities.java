package com.telink.ble.mesh.core.message.firmwaredistribution;

/* loaded from: classes.dex */
public interface DistributorCapabilities {

    public enum OOBRetrievalSupported {
        SUPPORTED(1),
        NotSupported(0);

        final int value;

        OOBRetrievalSupported(int i) {
            this.value = i;
        }
    }
}
