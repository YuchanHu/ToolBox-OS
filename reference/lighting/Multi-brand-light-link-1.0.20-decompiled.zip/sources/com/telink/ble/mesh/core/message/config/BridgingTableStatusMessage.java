package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class BridgingTableStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<BridgingTableStatusMessage> CREATOR = new Parcelable.Creator<BridgingTableStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.BridgingTableStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BridgingTableStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BridgingTableStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BridgingTableStatusMessage createFromParcel(Parcel parcel) {
            return new BridgingTableStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BridgingTableStatusMessage[] newArray(int i) {
            return new BridgingTableStatusMessage[i];
        }
    };
    public int address1;
    public int address2;
    private byte currentDirections;
    public int netKeyIndex1;
    public int netKeyIndex2;
    private int status;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public BridgingTableStatusMessage() {
    }

    protected BridgingTableStatusMessage(Parcel parcel) {
        this.status = parcel.readInt();
        this.currentDirections = parcel.readByte();
        this.netKeyIndex1 = parcel.readInt();
        this.netKeyIndex2 = parcel.readInt();
        this.address1 = parcel.readInt();
        this.address2 = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.status = bArr[0] & FUDistributor.UPDATE_TTL;
        this.currentDirections = bArr[1];
        int iBytes2Integer = MeshUtils.bytes2Integer(new byte[]{bArr[2], bArr[3], bArr[4]}, ByteOrder.LITTLE_ENDIAN);
        this.netKeyIndex1 = iBytes2Integer & 4095;
        this.netKeyIndex2 = (iBytes2Integer >> 12) & 4095;
        this.address1 = MeshUtils.bytes2Integer(bArr, 5, 2, ByteOrder.LITTLE_ENDIAN);
        this.address2 = MeshUtils.bytes2Integer(bArr, 7, 2, ByteOrder.LITTLE_ENDIAN);
    }

    public int getStatus() {
        return this.status;
    }

    public byte getCurrentDirections() {
        return this.currentDirections;
    }

    public int getNetKeyIndex1() {
        return this.netKeyIndex1;
    }

    public int getNetKeyIndex2() {
        return this.netKeyIndex2;
    }

    public int getAddress1() {
        return this.address1;
    }

    public int getAddress2() {
        return this.address2;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.status);
        parcel.writeByte(this.currentDirections);
        parcel.writeInt(this.netKeyIndex1);
        parcel.writeInt(this.netKeyIndex2);
        parcel.writeInt(this.address1);
        parcel.writeInt(this.address2);
    }
}
