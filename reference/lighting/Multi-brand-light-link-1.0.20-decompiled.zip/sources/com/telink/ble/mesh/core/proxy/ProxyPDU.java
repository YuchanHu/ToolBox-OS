package com.telink.ble.mesh.core.proxy;

/* loaded from: classes.dex */
public abstract class ProxyPDU {
    public static final int MASK_SAR = 192;
    public static final int MASK_TYPE = 63;
    public static final byte SAR_COMPLETE = 0;
    public static final byte SAR_SEG_CONTINUE = -128;
    public static final byte SAR_SEG_FIRST = 64;
    public static final byte SAR_SEG_LAST = -64;
    public static final byte TYPE_MESH_BEACON = 1;
    public static final byte TYPE_NETWORK_PDU = 0;
    public static final byte TYPE_PROVISIONING_PDU = 3;
    public static final byte TYPE_PROXY_CONFIGURATION = 2;
    public byte[] data;
    public byte sar;
    public byte type;
}
