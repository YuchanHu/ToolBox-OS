package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class NodeIdentityStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<NodeIdentityStatusMessage> CREATOR = new Parcelable.Creator<NodeIdentityStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.NodeIdentityStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ NodeIdentityStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ NodeIdentityStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public NodeIdentityStatusMessage createFromParcel(Parcel parcel) {
            return new NodeIdentityStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public NodeIdentityStatusMessage[] newArray(int i) {
            return new NodeIdentityStatusMessage[i];
        }
    };
    public int identity;
    public int netKeyIndex;
    public int status;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public NodeIdentityStatusMessage() {
    }

    protected NodeIdentityStatusMessage(Parcel parcel) {
        this.status = parcel.readInt();
        this.netKeyIndex = parcel.readInt();
        this.identity = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.status = bArr[0] & FUDistributor.UPDATE_TTL;
        this.netKeyIndex = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.LITTLE_ENDIAN);
        this.identity = bArr[3] & FUDistributor.UPDATE_TTL;
    }

    public int getStatus() {
        return this.status;
    }

    public int getNetKeyIndex() {
        return this.netKeyIndex;
    }

    public int getIdentity() {
        return this.identity;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.status);
        parcel.writeInt(this.netKeyIndex);
        parcel.writeInt(this.identity);
    }
}
