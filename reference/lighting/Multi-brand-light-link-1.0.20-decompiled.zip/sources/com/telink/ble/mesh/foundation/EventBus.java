package com.telink.ble.mesh.foundation;

import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import com.telink.ble.mesh.foundation.Event;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: classes.dex */
public class EventBus<T> {
    private static final int CORE_POOL_SIZE;
    private static final int CPU_COUNT;
    private static final ExecutorService EXECUTOR_SERVICE;
    private static final int KEEP_ALIVE = 1;
    private static final int MAXIMUM_POOL_SIZE;
    private static final BlockingQueue<Runnable> sPoolWorkQueue;
    private static final ThreadFactory sThreadFactory;
    protected final Map<T, List<EventListener<T>>> mEventListeners = new ConcurrentHashMap();
    protected final Queue<Event<T>> mEventQueue = new ConcurrentLinkedQueue();
    protected final Handler mCurrentThreadHandler = new Handler(Looper.myLooper());
    protected final Handler mMainThreadHandler = new Handler(Looper.getMainLooper());
    private final Object mLock = new Object();
    protected boolean processing = false;
    private final Runnable task = new Runnable() { // from class: com.telink.ble.mesh.foundation.EventBus.1
        @Override // java.lang.Runnable
        public void run() {
            EventBus.access$000(EventBus.this);
        }
    };

    static /* synthetic */ void access$000(EventBus eventBus) {
        eventBus.processEvent();
    }

    static {
        int iAvailableProcessors = Runtime.getRuntime().availableProcessors();
        CPU_COUNT = iAvailableProcessors;
        int i = iAvailableProcessors + 1;
        CORE_POOL_SIZE = i;
        int i2 = (iAvailableProcessors * 2) + 1;
        MAXIMUM_POOL_SIZE = i2;
        LinkedBlockingQueue linkedBlockingQueue = new LinkedBlockingQueue(128);
        sPoolWorkQueue = linkedBlockingQueue;
        DefaultThreadFactory defaultThreadFactory = new DefaultThreadFactory();
        sThreadFactory = defaultThreadFactory;
        EXECUTOR_SERVICE = new ThreadPoolExecutor(i, i2, 1L, TimeUnit.SECONDS, linkedBlockingQueue, defaultThreadFactory);
    }

    public void addEventListener(T t, EventListener<T> eventListener) {
        List<EventListener<T>> list;
        synchronized (this.mEventListeners) {
            if (this.mEventListeners.containsKey(t)) {
                list = this.mEventListeners.get(t);
            } else {
                CopyOnWriteArrayList copyOnWriteArrayList = new CopyOnWriteArrayList();
                this.mEventListeners.put(t, copyOnWriteArrayList);
                list = copyOnWriteArrayList;
            }
            if (!list.contains(eventListener)) {
                list.add(eventListener);
            }
        }
    }

    public void removeEventListener(EventListener<T> eventListener) {
        synchronized (this.mEventListeners) {
            Iterator<T> it = this.mEventListeners.keySet().iterator();
            while (it.hasNext()) {
                removeEventListener(it.next(), eventListener);
            }
        }
    }

    public void removeEventListener(T t, EventListener<T> eventListener) {
        synchronized (this.mEventListeners) {
            if (this.mEventListeners.containsKey(t)) {
                this.mEventListeners.get(t).remove(eventListener);
            }
        }
    }

    public void removeEventListeners() {
        synchronized (this.mEventListeners) {
            for (T t : this.mEventListeners.keySet()) {
                this.mEventListeners.get(t).clear();
                this.mEventListeners.remove(t);
            }
        }
    }

    public void dispatchEvent(Event<T> event) {
        this.mEventQueue.add(event);
        synchronized (this.mLock) {
            if (!this.processing) {
                processOnThread();
            }
        }
    }

    private void processOnThread() {
        synchronized (this.mEventQueue) {
            Event<T> eventPeek = this.mEventQueue.peek();
            if (eventPeek == null) {
                return;
            }
            int i = AnonymousClass2.$SwitchMap$com$telink$ble$mesh$foundation$Event$ThreadMode[eventPeek.getThreadMode().ordinal()];
            if (i == 1) {
                EXECUTOR_SERVICE.execute(this.task);
            } else if (i == 2) {
                this.mMainThreadHandler.post(this.task);
            } else {
                if (i != 3) {
                    return;
                }
                this.mCurrentThreadHandler.post(this.task);
            }
        }
    }

    /* renamed from: com.telink.ble.mesh.foundation.EventBus$2, reason: invalid class name */
    static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] $SwitchMap$com$telink$ble$mesh$foundation$Event$ThreadMode;

        static {
            int[] iArr = new int[Event.ThreadMode.values().length];
            $SwitchMap$com$telink$ble$mesh$foundation$Event$ThreadMode = iArr;
            try {
                iArr[Event.ThreadMode.Background.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$foundation$Event$ThreadMode[Event.ThreadMode.Main.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$foundation$Event$ThreadMode[Event.ThreadMode.Default.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    private void processEvent() {
        List<EventListener<T>> list;
        synchronized (this.mEventQueue) {
            Event<T> eventPoll = this.mEventQueue.poll();
            if (eventPoll == null) {
                return;
            }
            T type = eventPoll.getType();
            synchronized (this.mEventListeners) {
                list = this.mEventListeners.containsKey(type) ? this.mEventListeners.get(type) : null;
            }
            if (list != null && !list.isEmpty()) {
                synchronized (this.mLock) {
                    this.processing = true;
                }
                for (EventListener<T> eventListener : list) {
                    if (eventListener != null) {
                        eventListener.performed(eventPoll);
                    }
                }
            }
            processEventCompleted();
        }
    }

    private void processEventCompleted() {
        synchronized (this.mLock) {
            this.processing = false;
        }
        if (this.mEventQueue.isEmpty()) {
            return;
        }
        processOnThread();
    }

    private static class DefaultThreadFactory implements ThreadFactory {
        private static final AtomicInteger POOL_NUMBER = new AtomicInteger(1);
        private final ThreadGroup group;
        private final String namePrefix;
        private final AtomicInteger threadNumber = new AtomicInteger(1);

        DefaultThreadFactory() {
            ThreadGroup threadGroup;
            SecurityManager securityManager = System.getSecurityManager();
            if (securityManager != null) {
                threadGroup = securityManager.getThreadGroup();
            } else {
                threadGroup = Thread.currentThread().getThreadGroup();
            }
            this.group = threadGroup;
            this.namePrefix = "pool-" + POOL_NUMBER.getAndIncrement() + "-thread-";
        }

        @Override // java.util.concurrent.ThreadFactory
        public Thread newThread(final Runnable runnable) {
            Runnable runnable2 = new Runnable() { // from class: com.telink.ble.mesh.foundation.EventBus.DefaultThreadFactory.1
                @Override // java.lang.Runnable
                public void run() throws SecurityException, IllegalArgumentException {
                    Process.setThreadPriority(10);
                    runnable.run();
                }
            };
            Thread thread = new Thread(this.group, runnable2, this.namePrefix + this.threadNumber.getAndIncrement(), 0L);
            if (thread.isDaemon()) {
                thread.setDaemon(false);
            }
            if (thread.getPriority() != 5) {
                thread.setPriority(5);
            }
            return thread;
        }
    }
}
