package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class KeyRefreshPhaseGetMessage extends ConfigMessage {
    public int netKeyIndex;

    public KeyRefreshPhaseGetMessage(int i) {
        super(i);
        this.netKeyIndex = 0;
    }

    public static KeyRefreshPhaseGetMessage getSimple(int i, int i2) {
        KeyRefreshPhaseGetMessage keyRefreshPhaseGetMessage = new KeyRefreshPhaseGetMessage(i);
        keyRefreshPhaseGetMessage.netKeyIndex = i2;
        return keyRefreshPhaseGetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.CFG_KEY_REFRESH_PHASE_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_KEY_REFRESH_PHASE_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.netKeyIndex).array();
    }
}
