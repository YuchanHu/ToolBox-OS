package com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;

/* loaded from: classes.dex */
public class BlobInfoGetMessage extends UpdatingMessage {
    public BlobInfoGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.BLOB_INFORMATION_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.BLOB_INFORMATION_STATUS.value;
    }

    public static BlobInfoGetMessage getSimple(int i, int i2) {
        BlobInfoGetMessage blobInfoGetMessage = new BlobInfoGetMessage(i, i2);
        blobInfoGetMessage.setResponseMax(1);
        return blobInfoGetMessage;
    }
}
