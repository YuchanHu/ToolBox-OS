package com.telink.ble.mesh.core.message.lighting;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class LightnessStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<LightnessStatusMessage> CREATOR = new Parcelable.Creator<LightnessStatusMessage>() { // from class: com.telink.ble.mesh.core.message.lighting.LightnessStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ LightnessStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ LightnessStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LightnessStatusMessage createFromParcel(Parcel parcel) {
            return new LightnessStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LightnessStatusMessage[] newArray(int i) {
            return new LightnessStatusMessage[i];
        }
    };
    private static final int DATA_LEN_COMPLETE = 5;
    private boolean isComplete;
    private int presentLightness;
    private byte remainingTime;
    private int targetLightness;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public LightnessStatusMessage() {
        this.isComplete = false;
    }

    protected LightnessStatusMessage(Parcel parcel) {
        this.isComplete = false;
        this.presentLightness = parcel.readInt();
        this.targetLightness = parcel.readInt();
        this.remainingTime = parcel.readByte();
        this.isComplete = parcel.readByte() != 0;
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.presentLightness = MeshUtils.bytes2Integer(bArr, 0, 2, ByteOrder.LITTLE_ENDIAN);
        if (bArr.length >= 5) {
            this.isComplete = true;
            this.targetLightness = MeshUtils.bytes2Integer(bArr, 2, 2, ByteOrder.LITTLE_ENDIAN);
            this.remainingTime = bArr[4];
        }
    }

    public int getPresentLightness() {
        return this.presentLightness;
    }

    public int getTargetLightness() {
        return this.targetLightness;
    }

    public byte getRemainingTime() {
        return this.remainingTime;
    }

    public boolean isComplete() {
        return this.isComplete;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.presentLightness);
        parcel.writeInt(this.targetLightness);
        parcel.writeByte(this.remainingTime);
        parcel.writeByte(this.isComplete ? (byte) 1 : (byte) 0);
    }
}
