package com.telink.ble.mesh.core.provisioning;

/* loaded from: classes.dex */
public interface ProvisioningBridge {
    void onCommandPrepared(byte b, byte[] bArr);

    void onProvisionStateChanged(int i, String str);
}
