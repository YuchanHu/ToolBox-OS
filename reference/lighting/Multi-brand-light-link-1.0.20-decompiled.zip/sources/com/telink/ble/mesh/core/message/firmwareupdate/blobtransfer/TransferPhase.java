package com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer;

/* loaded from: classes.dex */
public enum TransferPhase {
    INACTIVE(0, "The BLOB Transfer Server is awaiting configuration and cannot receive a BLOB."),
    WAITING_FOR_TRANSFER_START(1, "The BLOB Transfer Server is ready to receive the BLOB identified by the Expected BLOB ID."),
    WAITING_FOR_NEXT_BLOCK(2, "The BLOB Transfer Server is waiting for the next block of data."),
    WAITING_FOR_NEXT_CHUNK(3, "The BLOB Transfer Server is waiting for the next chunk of data."),
    COMPLETE(4, "The BLOB was transferred successfully."),
    SUSPENDED(5, "The Initialize and Receive BLOB procedure is paused."),
    UNKNOWN_ERROR(10, "unknown error");

    public final int code;
    public final String desc;

    TransferPhase(int i, String str) {
        this.code = i;
        this.desc = str;
    }

    public static TransferPhase valueOf(int i) {
        for (TransferPhase transferPhase : values()) {
            if (transferPhase.code == i) {
                return transferPhase;
            }
        }
        return UNKNOWN_ERROR;
    }
}
