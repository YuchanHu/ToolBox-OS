package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class BeaconGetMessage extends ConfigMessage {
    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return null;
    }

    public BeaconGetMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.CFG_BEACON_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_BEACON_STATUS.value;
    }
}
