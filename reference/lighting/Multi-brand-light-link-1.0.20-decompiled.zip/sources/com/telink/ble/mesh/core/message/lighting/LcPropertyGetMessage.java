package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class LcPropertyGetMessage extends LightingMessage {
    private int propertyID;

    public static LcPropertyGetMessage getSimple(int i, int i2, int i3, int i4) {
        LcPropertyGetMessage lcPropertyGetMessage = new LcPropertyGetMessage(i, i2);
        lcPropertyGetMessage.setResponseMax(i3);
        lcPropertyGetMessage.propertyID = i4;
        return lcPropertyGetMessage;
    }

    public LcPropertyGetMessage(int i, int i2) {
        super(i, i2);
    }

    public void setPropertyID(int i) {
        this.propertyID = i;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.LIGHT_LC_PROPERTY_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.LIGHT_LC_PROPERTY_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return MeshUtils.integer2Bytes(this.propertyID, 2, ByteOrder.LITTLE_ENDIAN);
    }
}
