package com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class BlobTransferCancelMessage extends UpdatingMessage {
    private long blobId;

    public BlobTransferCancelMessage(int i, int i2) {
        super(i, i2);
    }

    public static BlobTransferCancelMessage getSimple(int i, int i2, long j) {
        BlobTransferCancelMessage blobTransferCancelMessage = new BlobTransferCancelMessage(i, i2);
        blobTransferCancelMessage.setResponseMax(1);
        blobTransferCancelMessage.blobId = j;
        return blobTransferCancelMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.BLOB_TRANSFER_CANCEL.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.BLOB_TRANSFER_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN).putLong(this.blobId).array();
    }

    public void setBlobId(long j) {
        this.blobId = j;
    }
}
