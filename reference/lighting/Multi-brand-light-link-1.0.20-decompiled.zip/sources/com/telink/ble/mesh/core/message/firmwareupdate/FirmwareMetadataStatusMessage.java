package com.telink.ble.mesh.core.message.firmwareupdate;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class FirmwareMetadataStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<FirmwareMetadataStatusMessage> CREATOR = new Parcelable.Creator<FirmwareMetadataStatusMessage>() { // from class: com.telink.ble.mesh.core.message.firmwareupdate.FirmwareMetadataStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FirmwareMetadataStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FirmwareMetadataStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FirmwareMetadataStatusMessage createFromParcel(Parcel parcel) {
            return new FirmwareMetadataStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FirmwareMetadataStatusMessage[] newArray(int i) {
            return new FirmwareMetadataStatusMessage[i];
        }
    };
    private int additionalInformation;
    private int status;
    private int updateFirmwareImageIndex;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public FirmwareMetadataStatusMessage() {
    }

    protected FirmwareMetadataStatusMessage(Parcel parcel) {
        this.status = parcel.readInt();
        this.additionalInformation = parcel.readInt();
        this.updateFirmwareImageIndex = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        byte b = bArr[0];
        this.status = b & 7;
        this.additionalInformation = (b >> 3) & 31;
        this.updateFirmwareImageIndex = bArr[1] & FUDistributor.UPDATE_TTL;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.status);
        parcel.writeInt(this.additionalInformation);
        parcel.writeInt(this.updateFirmwareImageIndex);
    }

    public int getStatus() {
        return this.status;
    }

    public int getAdditionalInformation() {
        return this.additionalInformation;
    }

    public int getUpdateFirmwareImageIndex() {
        return this.updateFirmwareImageIndex;
    }
}
