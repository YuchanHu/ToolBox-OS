package com.telink.ble.mesh.core.networking.transport.lower;

/* loaded from: classes.dex */
public abstract class TransportControlMessagePDU extends LowerTransportPDU {
    public static final int CONTROL_MESSAGE_OPCODE_HEARTBEAT = 10;
    public static final int CONTROL_MESSAGE_OPCODE_SEG_ACK = 0;
}
