package com.telink.ble.mesh.core.message.scene;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.lighting.LightingMessage;

/* loaded from: classes.dex */
public class SceneRegisterGetMessage extends LightingMessage {
    public SceneRegisterGetMessage(int i, int i2) {
        super(i, i2);
    }

    public static SceneRegisterGetMessage getSimple(int i, int i2, int i3) {
        SceneRegisterGetMessage sceneRegisterGetMessage = new SceneRegisterGetMessage(i, i2);
        sceneRegisterGetMessage.setResponseMax(i3);
        return sceneRegisterGetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.SCENE_REG_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.SCENE_REG_STATUS.value;
    }
}
