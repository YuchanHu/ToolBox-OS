package com.telink.ble.mesh.core.message.time;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.lighting.LightingMessage;

/* loaded from: classes.dex */
public class TimeGetMessage extends LightingMessage {
    public TimeGetMessage(int i, int i2) {
        super(i, i2);
    }

    public static TimeGetMessage getSimple(int i, int i2, int i3) {
        TimeGetMessage timeGetMessage = new TimeGetMessage(i, i2);
        timeGetMessage.setResponseMax(i3);
        return timeGetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.TIME_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.TIME_STATUS.value;
    }
}
