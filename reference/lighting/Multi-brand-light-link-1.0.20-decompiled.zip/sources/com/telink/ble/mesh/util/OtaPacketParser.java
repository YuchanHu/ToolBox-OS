package com.telink.ble.mesh.util;

/* loaded from: classes.dex */
public class OtaPacketParser {
    private byte[] data;
    private int index = -1;
    private int progress;
    private int total;

    public void set(byte[] bArr) {
        clear();
        this.data = bArr;
        int length = bArr.length;
        if (length % 16 == 0) {
            this.total = length / 16;
        } else {
            this.total = (int) Math.floor((length / 16) + 1);
        }
    }

    public void clear() {
        this.progress = 0;
        this.total = 0;
        this.index = -1;
        this.data = null;
    }

    public boolean hasNextPacket() {
        int i = this.total;
        return i > 0 && this.index + 1 < i;
    }

    public boolean isLast() {
        return this.index + 1 == this.total;
    }

    public int getNextPacketIndex() {
        return this.index + 1;
    }

    public byte[] getNextPacket() {
        int nextPacketIndex = getNextPacketIndex();
        byte[] packet = getPacket(nextPacketIndex);
        this.index = nextPacketIndex;
        return packet;
    }

    public byte[] getPacket(int i) {
        int length = this.data.length;
        if (length > 16) {
            length = i + 1 == this.total ? length - (i * 16) : 16;
        }
        byte[] bArr = new byte[20];
        for (int i2 = 0; i2 < 20; i2++) {
            bArr[i2] = -1;
        }
        System.arraycopy(this.data, i * 16, bArr, 2, length);
        fillIndex(bArr, i);
        int iCrc16 = crc16(bArr);
        fillCrc(bArr, iCrc16);
        MeshLogger.log("ota packet ---> index : " + i + " total : " + this.total + " crc : " + iCrc16 + " content : " + Arrays.bytesToHexString(bArr, ":"));
        return bArr;
    }

    public byte[] getCheckPacket() {
        byte[] bArr = new byte[16];
        for (int i = 0; i < 16; i++) {
            bArr[i] = -1;
        }
        int nextPacketIndex = getNextPacketIndex();
        fillIndex(bArr, nextPacketIndex);
        int iCrc16 = crc16(bArr);
        fillCrc(bArr, iCrc16);
        MeshLogger.log("ota check packet ---> index : " + nextPacketIndex + " crc : " + iCrc16 + " content : " + Arrays.bytesToHexString(bArr, ":"));
        return bArr;
    }

    public void fillIndex(byte[] bArr, int i) {
        bArr[0] = (byte) (i & 255);
        bArr[1] = (byte) ((i >> 8) & 255);
    }

    public void fillCrc(byte[] bArr, int i) {
        int length = bArr.length;
        bArr[length - 2] = (byte) (i & 255);
        bArr[length - 1] = (byte) ((i >> 8) & 255);
    }

    public int crc16(byte[] bArr) {
        int length = bArr.length - 2;
        short[] sArr = {0, -24575};
        int i = 65535;
        for (int i2 = 0; i2 < length; i2++) {
            int i3 = bArr[i2];
            for (int i4 = 0; i4 < 8; i4++) {
                i = (sArr[(i ^ i3) & 1] & 65535) ^ (i >> 1);
                i3 >>= 1;
            }
        }
        return i;
    }

    public boolean invalidateProgress() {
        int iFloor = (int) Math.floor((getNextPacketIndex() / this.total) * 100.0f);
        if (iFloor == this.progress) {
            return false;
        }
        this.progress = iFloor;
        return true;
    }

    public int getProgress() {
        return this.progress;
    }

    public int getIndex() {
        return this.index;
    }
}
