package com.telink.ble.mesh.core.ble;

import com.telink.ble.mesh.util.Arrays;
import java.util.UUID;

/* loaded from: classes.dex */
public class GattRequest {
    public Callback callback;
    public UUID characteristicUUID;
    public byte[] data;
    public int delay;
    public UUID descriptorUUID;
    public int mtu;
    public UUID serviceUUID;
    public Object tag;
    public RequestType type;

    public interface Callback {
        void error(GattRequest gattRequest, String str);

        void success(GattRequest gattRequest, Object obj);

        boolean timeout(GattRequest gattRequest);
    }

    public enum RequestType {
        READ,
        READ_DESCRIPTOR,
        WRITE,
        WRITE_NO_RESPONSE,
        WRITE_DESCRIPTOR,
        ENABLE_NOTIFY,
        DISABLE_NOTIFY,
        REQUEST_MTU
    }

    public GattRequest() {
        this(null, null, RequestType.WRITE);
    }

    public GattRequest(UUID uuid, UUID uuid2, RequestType requestType) {
        this(uuid, uuid2, requestType, null);
    }

    public GattRequest(UUID uuid, UUID uuid2, RequestType requestType, byte[] bArr) {
        this(uuid, uuid2, requestType, bArr, null);
    }

    public GattRequest(UUID uuid, UUID uuid2, RequestType requestType, byte[] bArr, Object obj) {
        this.serviceUUID = uuid;
        this.characteristicUUID = uuid2;
        this.type = requestType;
        this.data = bArr;
        this.tag = obj;
    }

    public static GattRequest newInstance() {
        return new GattRequest();
    }

    public void clear() {
        this.serviceUUID = null;
        this.characteristicUUID = null;
        this.descriptorUUID = null;
        this.data = null;
    }

    public String toString() {
        String strBytesToHexString;
        byte[] bArr = this.data;
        if (bArr != null) {
            strBytesToHexString = Arrays.bytesToHexString(bArr);
        } else {
            strBytesToHexString = "null";
        }
        return "{ tag : " + this.tag + ", type : " + this.type + " CHARACTERISTIC_UUID :" + this.characteristicUUID.toString() + " data: " + strBytesToHexString + " delay :" + this.delay + "}";
    }
}
