package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class NetworkTransmitSetMessage extends ConfigMessage {
    public int count;
    public int intervalSteps;

    public NetworkTransmitSetMessage(int i) {
        super(i);
    }

    public static NetworkTransmitSetMessage getSimple(int i, int i2, int i3) {
        NetworkTransmitSetMessage networkTransmitSetMessage = new NetworkTransmitSetMessage(i);
        networkTransmitSetMessage.count = i2;
        networkTransmitSetMessage.intervalSteps = i3;
        return networkTransmitSetMessage;
    }

    public void setCount(int i) {
        this.count = i;
    }

    public void setIntervalSteps(int i) {
        this.intervalSteps = i;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.CFG_NW_TRANSMIT_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_NW_TRANSMIT_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return new byte[]{(byte) ((this.count & 7) | (this.intervalSteps << 3))};
    }
}
