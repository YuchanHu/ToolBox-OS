package com.telink.ble.mesh.core.message.firmwaredistribution;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class FDReceiversStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<FDReceiversStatusMessage> CREATOR = new Parcelable.Creator<FDReceiversStatusMessage>() { // from class: com.telink.ble.mesh.core.message.firmwaredistribution.FDReceiversStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FDReceiversStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FDReceiversStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FDReceiversStatusMessage createFromParcel(Parcel parcel) {
            return new FDReceiversStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FDReceiversStatusMessage[] newArray(int i) {
            return new FDReceiversStatusMessage[i];
        }
    };
    private int receiversListCount;
    private int status;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public FDReceiversStatusMessage() {
    }

    protected FDReceiversStatusMessage(Parcel parcel) {
        this.status = parcel.readInt();
        this.receiversListCount = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.status = bArr[0] & FUDistributor.UPDATE_TTL;
        this.receiversListCount = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.LITTLE_ENDIAN);
    }

    public int getStatus() {
        return this.status;
    }

    public int getReceiversListCount() {
        return this.receiversListCount;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.status);
        parcel.writeInt(this.receiversListCount);
    }

    public String toString() {
        return "FirmwareDistributionReceiversStatus{status=" + this.status + ", receiversListCount=" + this.receiversListCount + '}';
    }
}
