package com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class BlobInfoStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<BlobInfoStatusMessage> CREATOR = new Parcelable.Creator<BlobInfoStatusMessage>() { // from class: com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobInfoStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BlobInfoStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BlobInfoStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BlobInfoStatusMessage createFromParcel(Parcel parcel) {
            return new BlobInfoStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BlobInfoStatusMessage[] newArray(int i) {
            return new BlobInfoStatusMessage[i];
        }
    };
    private int maxBLOBSize;
    private int maxBlockSizeLog;
    private int maxChunkSize;
    private int maxTotalChunks;
    private int minBlockSizeLog;
    private int serverMTUSize;
    private int supportedTransferMode;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public BlobInfoStatusMessage() {
    }

    protected BlobInfoStatusMessage(Parcel parcel) {
        this.minBlockSizeLog = parcel.readInt();
        this.maxBlockSizeLog = parcel.readInt();
        this.maxTotalChunks = parcel.readInt();
        this.maxChunkSize = parcel.readInt();
        this.maxBLOBSize = parcel.readInt();
        this.serverMTUSize = parcel.readInt();
        this.supportedTransferMode = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.minBlockSizeLog = bArr[0] & FUDistributor.UPDATE_TTL;
        this.maxBlockSizeLog = bArr[1] & FUDistributor.UPDATE_TTL;
        this.maxTotalChunks = MeshUtils.bytes2Integer(bArr, 2, 2, ByteOrder.LITTLE_ENDIAN);
        this.maxChunkSize = MeshUtils.bytes2Integer(bArr, 4, 2, ByteOrder.LITTLE_ENDIAN);
        this.maxBLOBSize = MeshUtils.bytes2Integer(bArr, 6, 4, ByteOrder.LITTLE_ENDIAN);
        this.serverMTUSize = MeshUtils.bytes2Integer(bArr, 10, 2, ByteOrder.LITTLE_ENDIAN);
        this.supportedTransferMode = bArr[12];
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.minBlockSizeLog);
        parcel.writeInt(this.maxBlockSizeLog);
        parcel.writeInt(this.maxTotalChunks);
        parcel.writeInt(this.maxChunkSize);
        parcel.writeInt(this.maxBLOBSize);
        parcel.writeInt(this.serverMTUSize);
        parcel.writeInt(this.supportedTransferMode);
    }

    public int getMinBlockSizeLog() {
        return this.minBlockSizeLog;
    }

    public int getMaxBlockSizeLog() {
        return this.maxBlockSizeLog;
    }

    public int getMaxTotalChunks() {
        return this.maxTotalChunks;
    }

    public int getMaxChunkSize() {
        return this.maxChunkSize;
    }

    public int getMaxBLOBSize() {
        return this.maxBLOBSize;
    }

    public int getServerMTUSize() {
        return this.serverMTUSize;
    }

    public int getSupportedTransferMode() {
        return this.supportedTransferMode;
    }

    public void setMinBlockSizeLog(int i) {
        this.minBlockSizeLog = i;
    }

    public void setMaxBlockSizeLog(int i) {
        this.maxBlockSizeLog = i;
    }

    public void setMaxTotalChunks(int i) {
        this.maxTotalChunks = i;
    }

    public void setMaxChunkSize(int i) {
        this.maxChunkSize = i;
    }

    public void setMaxBLOBSize(int i) {
        this.maxBLOBSize = i;
    }

    public void setServerMTUSize(int i) {
        this.serverMTUSize = i;
    }

    public void setSupportedTransferMode(int i) {
        this.supportedTransferMode = i;
    }

    public boolean isPushModeSupported() {
        return (this.supportedTransferMode & TransferMode.PUSH.value) != 0;
    }

    public boolean isPullModeSupported() {
        return (this.supportedTransferMode & TransferMode.PULL.value) != 0;
    }

    public String toString() {
        return "BlobInfoStatusMessage{minBlockSizeLog=" + this.minBlockSizeLog + ", maxBlockSizeLog=" + this.maxBlockSizeLog + ", maxTotalChunks=" + this.maxTotalChunks + ", maxChunkSize=" + this.maxChunkSize + ", maxBLOBSize=" + this.maxBLOBSize + ", serverMTUSize=" + this.serverMTUSize + ", supportedTransferMode=" + this.supportedTransferMode + ", isPushModeSupported=" + isPushModeSupported() + ", isPullModeSupported=" + isPullModeSupported() + '}';
    }
}
