package com.telink.ble.mesh.core.access.fu;

/* loaded from: classes.dex */
public enum DistributorType {
    PHONE,
    DEVICE
}
