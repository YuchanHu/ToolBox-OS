package com.telink.ble.mesh.core.provisioning.pdu;

import com.telink.ble.mesh.core.MeshUtils;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class ProvisioningRecordsListPDU implements ProvisioningStatePDU {
    public int provisioningExtensions;
    public byte[] rawData;
    public List<Integer> recordsList;

    @Override // com.telink.ble.mesh.core.provisioning.pdu.ProvisioningStatePDU
    public byte getState() {
        return ProvisioningPDU.TYPE_RECORDS_LIST;
    }

    public static ProvisioningRecordsListPDU fromBytes(byte[] bArr) {
        ProvisioningRecordsListPDU provisioningRecordsListPDU = new ProvisioningRecordsListPDU();
        provisioningRecordsListPDU.rawData = bArr;
        provisioningRecordsListPDU.provisioningExtensions = MeshUtils.bytes2Integer(bArr, 0, 2, ByteOrder.BIG_ENDIAN);
        if (bArr.length > 2) {
            int length = (bArr.length - 2) / 2;
            provisioningRecordsListPDU.recordsList = new ArrayList(length);
            int i = 2;
            for (int i2 = 0; i2 < length; i2++) {
                provisioningRecordsListPDU.recordsList.add(Integer.valueOf(MeshUtils.bytes2Integer(bArr, i, 2, ByteOrder.BIG_ENDIAN)));
                i += 2;
            }
        }
        return provisioningRecordsListPDU;
    }

    @Override // com.telink.ble.mesh.core.provisioning.pdu.PDU
    public byte[] toBytes() {
        return this.rawData;
    }
}
