package com.telink.ble.mesh.core.message.sensor;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;
import com.telink.ble.mesh.entity.SensorCadence;

/* loaded from: classes.dex */
public class SensorCadenceStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<SensorCadenceStatusMessage> CREATOR = new Parcelable.Creator<SensorCadenceStatusMessage>() { // from class: com.telink.ble.mesh.core.message.sensor.SensorCadenceStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SensorCadenceStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SensorCadenceStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SensorCadenceStatusMessage createFromParcel(Parcel parcel) {
            return new SensorCadenceStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SensorCadenceStatusMessage[] newArray(int i) {
            return new SensorCadenceStatusMessage[i];
        }
    };
    public SensorCadence cadence;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public SensorCadenceStatusMessage() {
    }

    protected SensorCadenceStatusMessage(Parcel parcel) {
        this.cadence = (SensorCadence) parcel.readParcelable(SensorCadence.class.getClassLoader());
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.cadence = SensorCadence.fromBytes(bArr);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.cadence, i);
    }
}
