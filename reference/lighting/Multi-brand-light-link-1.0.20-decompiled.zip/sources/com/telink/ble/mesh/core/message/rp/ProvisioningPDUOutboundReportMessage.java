package com.telink.ble.mesh.core.message.rp;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class ProvisioningPDUOutboundReportMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<ProvisioningPDUOutboundReportMessage> CREATOR = new Parcelable.Creator<ProvisioningPDUOutboundReportMessage>() { // from class: com.telink.ble.mesh.core.message.rp.ProvisioningPDUOutboundReportMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ProvisioningPDUOutboundReportMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ProvisioningPDUOutboundReportMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ProvisioningPDUOutboundReportMessage createFromParcel(Parcel parcel) {
            return new ProvisioningPDUOutboundReportMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ProvisioningPDUOutboundReportMessage[] newArray(int i) {
            return new ProvisioningPDUOutboundReportMessage[i];
        }
    };
    private byte outboundPDUNumber;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public ProvisioningPDUOutboundReportMessage() {
    }

    protected ProvisioningPDUOutboundReportMessage(Parcel parcel) {
        this.outboundPDUNumber = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.outboundPDUNumber = bArr[0];
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.outboundPDUNumber);
    }

    public byte getOutboundPDUNumber() {
        return this.outboundPDUNumber;
    }
}
