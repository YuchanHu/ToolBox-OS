package com.telink.ble.mesh.util;

import android.content.Context;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
public class ContextUtil {
    public static final int SDK_VERSION = Build.VERSION.SDK_INT;

    public static boolean isLocationEnable(Context context) {
        LocationManager locationManager = (LocationManager) context.getSystemService("location");
        if (locationManager == null) {
            return false;
        }
        return locationManager.isProviderEnabled("gps") || locationManager.isProviderEnabled("network");
    }

    public static boolean versionAboveL() {
        return SDK_VERSION >= 21;
    }

    public static boolean versionAboveN() {
        return SDK_VERSION >= 24;
    }

    public static boolean versionIsN() {
        return SDK_VERSION == 24;
    }

    public static void skipReflectWarning() {
        if (Build.VERSION.SDK_INT < 28) {
            return;
        }
        try {
            Method declaredMethod = Class.class.getDeclaredMethod("forName", String.class);
            Method declaredMethod2 = Class.class.getDeclaredMethod("getDeclaredMethod", String.class, Class[].class);
            Class cls = (Class) declaredMethod.invoke(null, "dalvik.system.VMRuntime");
            ((Method) declaredMethod2.invoke(cls, "setHiddenApiExemptions", new Class[]{String[].class})).invoke(((Method) declaredMethod2.invoke(cls, "getRuntime", null)).invoke(null, null), new String[]{"L"});
        } catch (Throwable th) {
            th.printStackTrace();
            MeshLogger.e("reflect bootstrap failed:");
        }
    }

    public static int dpToPx(Context context, float f) {
        return (int) (f * (context.getResources().getDisplayMetrics().densityDpi / 160.0f));
    }

    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        NetworkCapabilities networkCapabilities = connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
        return networkCapabilities != null && networkCapabilities.hasCapability(12);
    }

    public static boolean isHarmonyOS() {
        return Build.MANUFACTURER.toUpperCase().contains("HUAWEI");
    }
}
