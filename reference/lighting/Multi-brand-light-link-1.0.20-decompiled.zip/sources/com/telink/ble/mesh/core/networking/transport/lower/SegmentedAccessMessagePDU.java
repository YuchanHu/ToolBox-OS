package com.telink.ble.mesh.core.networking.transport.lower;

import com.telink.ble.mesh.core.networking.NetworkLayerPDU;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import org.spongycastle.asn1.eac.CertificateBody;

/* loaded from: classes.dex */
public class SegmentedAccessMessagePDU extends LowerTransportPDU {
    private byte aid;
    private byte akf;
    private final byte seg = 1;
    private int segN;
    private int segO;
    private byte[] segmentM;
    private int seqZero;
    private int szmic;

    public byte getSeg() {
        return (byte) 1;
    }

    @Override // com.telink.ble.mesh.core.networking.transport.lower.LowerTransportPDU
    public boolean segmented() {
        return true;
    }

    @Override // com.telink.ble.mesh.core.networking.transport.lower.LowerTransportPDU
    public int getType() {
        return TYPE_SEGMENTED_ACCESS_MESSAGE;
    }

    @Override // com.telink.ble.mesh.core.networking.NetworkingPDU
    public byte[] toByteArray() {
        int i = (this.akf << 6) | this.aid;
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(this.segmentM.length + 4).order(ByteOrder.BIG_ENDIAN);
        byteBufferOrder.put((byte) (i | 128));
        byteBufferOrder.put((byte) ((this.szmic << 7) | ((this.seqZero >> 6) & CertificateBody.profileType)));
        byteBufferOrder.put((byte) (((this.seqZero << 2) & 252) | ((this.segO >> 3) & 3)));
        byteBufferOrder.put((byte) (((this.segO << 5) & 224) | (this.segN & 31)));
        byteBufferOrder.put(this.segmentM);
        return byteBufferOrder.array();
    }

    public boolean parse(NetworkLayerPDU networkLayerPDU) {
        byte[] transportPDU = networkLayerPDU.getTransportPDU();
        byte b = transportPDU[0];
        this.akf = (byte) ((b >> 6) & 1);
        this.aid = (byte) (b & 63);
        byte b2 = transportPDU[1];
        this.szmic = (b2 >> 7) & 1;
        byte b3 = transportPDU[2];
        this.seqZero = ((b2 & 127) << 6) | ((b3 & 252) >> 2);
        byte b4 = transportPDU[3];
        this.segO = ((b3 & 3) << 3) | ((b4 & 224) >> 5);
        this.segN = b4 & 31;
        byte[] bArr = new byte[transportPDU.length - 4];
        this.segmentM = bArr;
        System.arraycopy(transportPDU, 4, bArr, 0, bArr.length);
        byte[] bArr2 = this.segmentM;
        return bArr2 != null && bArr2.length >= 1;
    }

    public byte getAkf() {
        return this.akf;
    }

    public void setAkf(byte b) {
        this.akf = b;
    }

    public byte getAid() {
        return this.aid;
    }

    public void setAid(byte b) {
        this.aid = b;
    }

    public int getSzmic() {
        return this.szmic;
    }

    public void setSzmic(int i) {
        this.szmic = i;
    }

    public int getSeqZero() {
        return this.seqZero;
    }

    public void setSeqZero(int i) {
        this.seqZero = i;
    }

    public int getSegO() {
        return this.segO;
    }

    public void setSegO(int i) {
        this.segO = i;
    }

    public int getSegN() {
        return this.segN;
    }

    public void setSegN(int i) {
        this.segN = i;
    }

    public byte[] getSegmentM() {
        return this.segmentM;
    }

    public void setSegmentM(byte[] bArr) {
        this.segmentM = bArr;
    }
}
