package com.telink.ble.mesh.foundation.event;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.NotificationMessage;
import com.telink.ble.mesh.foundation.Event;

/* loaded from: classes.dex */
public class StatusNotificationEvent extends Event<String> implements Parcelable {
    public static final Parcelable.Creator<StatusNotificationEvent> CREATOR = new Parcelable.Creator<StatusNotificationEvent>() { // from class: com.telink.ble.mesh.foundation.event.StatusNotificationEvent.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ StatusNotificationEvent createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ StatusNotificationEvent[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public StatusNotificationEvent createFromParcel(Parcel parcel) {
            return new StatusNotificationEvent(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public StatusNotificationEvent[] newArray(int i) {
            return new StatusNotificationEvent[i];
        }
    };
    public static final String EVENT_TYPE_NOTIFICATION_MESSAGE_UNKNOWN = "com.telink.ble.mesh.EVENT_TYPE_NOTIFICATION_MESSAGE_UNKNOWN";
    private NotificationMessage notificationMessage;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public StatusNotificationEvent(Object obj, String str, NotificationMessage notificationMessage) {
        super(obj, str);
        this.notificationMessage = notificationMessage;
    }

    protected StatusNotificationEvent(Parcel parcel) {
        this.notificationMessage = (NotificationMessage) parcel.readParcelable(NotificationMessage.class.getClassLoader());
    }

    public NotificationMessage getNotificationMessage() {
        return this.notificationMessage;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.notificationMessage, i);
    }
}
