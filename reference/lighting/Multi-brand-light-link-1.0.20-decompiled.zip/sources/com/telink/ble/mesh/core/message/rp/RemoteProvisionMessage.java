package com.telink.ble.mesh.core.message.rp;

import com.telink.ble.mesh.core.message.config.ConfigMessage;

/* loaded from: classes.dex */
public class RemoteProvisionMessage extends ConfigMessage {
    public RemoteProvisionMessage(int i) {
        super(i);
    }
}
