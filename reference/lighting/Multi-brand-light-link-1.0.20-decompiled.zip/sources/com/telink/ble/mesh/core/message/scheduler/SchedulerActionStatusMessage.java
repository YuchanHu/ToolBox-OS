package com.telink.ble.mesh.core.message.scheduler;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class SchedulerActionStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<SchedulerActionStatusMessage> CREATOR = new Parcelable.Creator<SchedulerActionStatusMessage>() { // from class: com.telink.ble.mesh.core.message.scheduler.SchedulerActionStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SchedulerActionStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SchedulerActionStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SchedulerActionStatusMessage createFromParcel(Parcel parcel) {
            return new SchedulerActionStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SchedulerActionStatusMessage[] newArray(int i) {
            return new SchedulerActionStatusMessage[i];
        }
    };
    private byte[] schedulerParams;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public SchedulerActionStatusMessage() {
    }

    protected SchedulerActionStatusMessage(Parcel parcel) {
        this.schedulerParams = parcel.createByteArray();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.schedulerParams = bArr;
    }

    public byte[] getSchedulerParams() {
        return this.schedulerParams;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByteArray(this.schedulerParams);
    }
}
