package com.telink.ble.mesh.core.message.sarconfig;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.config.ConfigMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class SarTransmitSetMessage extends ConfigMessage {
    public int multicastRetransCnt;
    public int multicastRetransInterval;
    public int rfu;
    public int segmentIntervalStep;
    public int unicastRetransCnt;
    public int unicastRetransIntervalIncrement;
    public int unicastRetransIntervalStep;
    public int unicastRetransWithoutProgCnt;

    public SarTransmitSetMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.CFG_SAR_TRANSMITTER_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_SAR_TRANSMITTER_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).put((byte) (this.segmentIntervalStep | (this.unicastRetransCnt << 4))).put((byte) (this.unicastRetransWithoutProgCnt | (this.unicastRetransIntervalStep << 4))).put((byte) (this.unicastRetransIntervalIncrement | (this.multicastRetransCnt << 4))).put((byte) ((this.rfu << 4) | this.multicastRetransInterval)).array();
    }
}
