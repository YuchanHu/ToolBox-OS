package com.telink.ble.mesh.core.access.fu;

import android.os.Handler;
import android.os.HandlerThread;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.MeshFirmwareParser;
import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.NotificationMessage;
import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdateStatus;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobBlockGetMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobBlockStartMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobBlockStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobChunkTransferMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobInfoGetMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobInfoStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobPartialBlockReportMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobTransferGetMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobTransferStartMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobTransferStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.TransferMode;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.TransferStatus;
import com.telink.ble.mesh.core.networking.ExtendBearerMode;
import com.telink.ble.mesh.core.networking.NetworkingController;
import com.telink.ble.mesh.entity.FirmwareUpdateConfiguration;
import com.telink.ble.mesh.entity.MeshUpdatingDevice;
import com.telink.ble.mesh.foundation.MulticastMessageBroker;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.function.IntSupplier;

/* loaded from: classes.dex */
class BlobTransfer {
    private static final long PARTIAL_WAITING_TIMEOUT = 68000;
    private static final int STEP_BLOB_BLOCK_GET = 10;
    private static final int STEP_BLOB_BLOCK_START = 8;
    private static final int STEP_BLOB_CHUNK_SENDING = 9;
    private static final int STEP_BLOB_INFO_GET = 6;
    private static final int STEP_BLOB_TRANSFER_GET = 5;
    private static final int STEP_BLOB_TRANSFER_START = 7;
    private static final int STEP_IDLE = 0;
    private int appKeyIndex;
    private long blobId;
    private Handler delayHandler;
    private ExtendBearerMode extendBearerMode;
    byte[] firmwareData;
    private final IntSupplier gattMtu;
    private int groupAddress;
    private long networkInterval;
    private int nodeIndex;
    private int pullMaxChunkNumber;
    private BlobTransferCallback transferCallback;
    private final String LOG_TAG = "BlobTransfer";
    private int step = 0;
    private List<Integer> missingNodes = new ArrayList();
    private ArrayList<Integer> missingChunks = new ArrayList<>();
    private BlobTransferType transferType = BlobTransferType.LOCAL_INIT;
    private MeshFirmwareParser firmwareParser = new MeshFirmwareParser();
    List<TargetDevice> targetDevices = new ArrayList();
    private int missingChunkIndex = 0;
    private int mixedFormat = -1;
    private int pullProgress = -1;
    private TransferMode transferMode = TransferMode.PUSH;
    private final Runnable ACTION_TASK = new Runnable() { // from class: com.telink.ble.mesh.core.access.fu.BlobTransfer.1
        @Override // java.lang.Runnable
        public void run() {
            if (BlobTransfer.access$000(BlobTransfer.this) == 8 && BlobTransfer.access$100(BlobTransfer.this) == TransferMode.PUSH) {
                if (BlobTransfer.access$200(BlobTransfer.this).hasNextBlock()) {
                    BlobTransfer.access$200(BlobTransfer.this).nextBlock();
                    BlobTransfer.access$300(BlobTransfer.this, "(push)next block: " + BlobTransfer.access$200(BlobTransfer.this).currentBlockIndex());
                    BlobBlockStartMessage simple = BlobBlockStartMessage.getSimple(BlobTransfer.access$500(BlobTransfer.this), BlobTransfer.access$600(BlobTransfer.this), BlobTransfer.access$200(BlobTransfer.this).currentBlockIndex(), BlobTransfer.access$200(BlobTransfer.this).getChunkSize());
                    if (BlobTransfer.access$700(BlobTransfer.this) == BlobTransferType.LOCAL_INIT) {
                        simple.setDestinationAddress(0);
                    } else if (BlobTransfer.access$700(BlobTransfer.this) == BlobTransferType.GATT_INIT) {
                        if (BlobTransfer.this.targetDevices.size() == 0) {
                            BlobTransfer.access$400(BlobTransfer.this, false, "target device size error");
                            return;
                        }
                        simple.setDestinationAddress(TargetDevice.access$800(BlobTransfer.this.targetDevices.get(0)));
                    } else {
                        ArrayList arrayList = new ArrayList();
                        Iterator<TargetDevice> it = BlobTransfer.this.targetDevices.iterator();
                        while (it.hasNext()) {
                            arrayList.add(Integer.valueOf(TargetDevice.access$800(it.next())));
                        }
                        simple.setBrokerConfig(new MulticastMessageBroker.Config(arrayList));
                        simple.setResponseMax(arrayList.size());
                    }
                    BlobTransfer.access$900(BlobTransfer.this, simple);
                }
                BlobTransfer.access$300(BlobTransfer.this, "(push)all blocks sent complete at: block -- " + BlobTransfer.access$200(BlobTransfer.this).currentBlockIndex());
                BlobTransfer.access$400(BlobTransfer.this, true, "success");
                return;
            }
            if (BlobTransfer.access$000(BlobTransfer.this) == 10) {
                int iAccess$1000 = BlobTransfer.access$1000(BlobTransfer.this);
                if (iAccess$1000 == -1) {
                    BlobTransfer.access$002(BlobTransfer.this, 8);
                    BlobTransfer.access$1102(BlobTransfer.this, 0);
                    BlobTransfer.access$1200(BlobTransfer.this);
                    return;
                } else {
                    BlobTransfer blobTransfer = BlobTransfer.this;
                    BlobTransfer.access$900(blobTransfer, BlobBlockGetMessage.getSimple(iAccess$1000, BlobTransfer.access$600(blobTransfer)));
                    return;
                }
            }
            if (BlobTransfer.access$1300(BlobTransfer.this) >= BlobTransfer.this.targetDevices.size()) {
                BlobTransfer blobTransfer2 = BlobTransfer.this;
                StringBuilder sb = new StringBuilder("current step complete: ");
                BlobTransfer blobTransfer3 = BlobTransfer.this;
                sb.append(BlobTransfer.access$1400(blobTransfer3, BlobTransfer.access$000(blobTransfer3)));
                BlobTransfer.access$300(blobTransfer2, sb.toString());
                BlobTransfer.access$1500(BlobTransfer.this);
                BlobTransfer.access$300(BlobTransfer.this, "remaining device count : " + BlobTransfer.this.targetDevices.size());
                if (BlobTransfer.this.targetDevices.size() != 0) {
                    BlobTransfer.access$1302(BlobTransfer.this, 0);
                    BlobTransfer blobTransfer4 = BlobTransfer.this;
                    StringBuilder sb2 = new StringBuilder("next step: ");
                    BlobTransfer blobTransfer5 = BlobTransfer.this;
                    sb2.append(BlobTransfer.access$1400(blobTransfer5, BlobTransfer.access$000(blobTransfer5) + 1));
                    BlobTransfer.access$300(blobTransfer4, sb2.toString());
                    BlobTransfer.access$008(BlobTransfer.this);
                    BlobTransfer.access$1200(BlobTransfer.this);
                    return;
                }
                BlobTransfer.access$400(BlobTransfer.this, false, "all nodes failed when executing action");
                return;
            }
            int iAccess$800 = TargetDevice.access$800(BlobTransfer.this.targetDevices.get(BlobTransfer.access$1300(BlobTransfer.this)));
            BlobTransfer blobTransfer6 = BlobTransfer.this;
            StringBuilder sb3 = new StringBuilder("action executing: ");
            BlobTransfer blobTransfer7 = BlobTransfer.this;
            sb3.append(BlobTransfer.access$1400(blobTransfer7, BlobTransfer.access$000(blobTransfer7)));
            sb3.append(" -- %04X");
            BlobTransfer.access$300(blobTransfer6, String.format(sb3.toString(), Integer.valueOf(iAccess$800)));
            switch (BlobTransfer.access$000(BlobTransfer.this)) {
                case 5:
                    BlobTransfer blobTransfer8 = BlobTransfer.this;
                    BlobTransfer.access$900(blobTransfer8, BlobTransferGetMessage.getSimple(iAccess$800, BlobTransfer.access$600(blobTransfer8)));
                    break;
                case 6:
                    BlobTransfer blobTransfer9 = BlobTransfer.this;
                    BlobTransfer.access$900(blobTransfer9, BlobInfoGetMessage.getSimple(iAccess$800, BlobTransfer.access$600(blobTransfer9)));
                    break;
                case 7:
                    if (BlobTransfer.access$1300(BlobTransfer.this) == 0) {
                        BlobTransfer.access$1600(BlobTransfer.this).onTransferStart(BlobTransfer.access$100(BlobTransfer.this));
                    }
                    BlobTransferStartMessage simple2 = BlobTransferStartMessage.getSimple(iAccess$800, BlobTransfer.access$600(BlobTransfer.this), BlobTransfer.access$1700(BlobTransfer.this), BlobTransfer.access$200(BlobTransfer.this).getObjectSize(), (byte) MeshUtils.mathLog2(BlobTransfer.access$200(BlobTransfer.this).getBlockSize()), 380);
                    simple2.setTransferMode(BlobTransfer.access$100(BlobTransfer.this));
                    BlobTransfer.access$900(BlobTransfer.this, simple2);
                    break;
                case 8:
                    if (BlobTransfer.access$1300(BlobTransfer.this) == 0) {
                        if (BlobTransfer.access$200(BlobTransfer.this).hasNextBlock()) {
                            BlobTransfer.access$200(BlobTransfer.this).nextBlock();
                            BlobTransfer.access$300(BlobTransfer.this, "(pull)next block: " + BlobTransfer.access$200(BlobTransfer.this).currentBlockIndex());
                        } else {
                            BlobTransfer.access$300(BlobTransfer.this, "(pull)all blocks sent complete at: block -- " + BlobTransfer.access$200(BlobTransfer.this).currentBlockIndex());
                            BlobTransfer.access$400(BlobTransfer.this, true, "success");
                            break;
                        }
                    }
                    int iCurrentBlockIndex = BlobTransfer.access$200(BlobTransfer.this).currentBlockIndex();
                    int chunkSize = BlobTransfer.access$200(BlobTransfer.this).getChunkSize();
                    BlobTransfer blobTransfer10 = BlobTransfer.this;
                    BlobTransfer.access$900(blobTransfer10, BlobBlockStartMessage.getSimple(iAccess$800, BlobTransfer.access$600(blobTransfer10), iCurrentBlockIndex, chunkSize));
                    break;
                case 9:
                    if (BlobTransfer.access$100(BlobTransfer.this) == TransferMode.PUSH) {
                        BlobTransfer.access$1800(BlobTransfer.this);
                        break;
                    } else {
                        BlobTransfer.access$1900(BlobTransfer.this);
                        BlobTransfer.access$300(BlobTransfer.this, "waiting for pull request");
                        BlobTransfer.access$2000(BlobTransfer.this);
                        break;
                    }
                case 10:
                    BlobTransfer blobTransfer11 = BlobTransfer.this;
                    BlobTransfer.access$900(blobTransfer11, BlobBlockGetMessage.getSimple(iAccess$800, BlobTransfer.access$600(blobTransfer11)));
                    break;
            }
        }
    };
    private final Runnable PARTIAL_REPORT_WAITING_TASK = new Runnable() { // from class: com.telink.ble.mesh.core.access.fu.BlobTransfer$$ExternalSyntheticLambda0
        @Override // java.lang.Runnable
        public final void run() {
            this.f$0.m104lambda$new$0$comtelinkblemeshcoreaccessfuBlobTransfer();
        }
    };
    private Runnable missingChunkSendingTask = new Runnable() { // from class: com.telink.ble.mesh.core.access.fu.BlobTransfer.2
        @Override // java.lang.Runnable
        public void run() {
            BlobTransfer.access$2208(BlobTransfer.this);
            BlobTransfer.access$1900(BlobTransfer.this);
        }
    };
    private Runnable chunkSendingTask = new Runnable() { // from class: com.telink.ble.mesh.core.access.fu.BlobTransfer.3
        @Override // java.lang.Runnable
        public void run() {
            BlobTransfer.access$1800(BlobTransfer.this);
        }
    };

    static /* synthetic */ int access$000(BlobTransfer blobTransfer) {
        return blobTransfer.step;
    }

    static /* synthetic */ int access$002(BlobTransfer blobTransfer, int i) {
        blobTransfer.step = i;
        return i;
    }

    static /* synthetic */ int access$008(BlobTransfer blobTransfer) {
        int i = blobTransfer.step;
        blobTransfer.step = i + 1;
        return i;
    }

    static /* synthetic */ TransferMode access$100(BlobTransfer blobTransfer) {
        return blobTransfer.transferMode;
    }

    static /* synthetic */ int access$1000(BlobTransfer blobTransfer) {
        return blobTransfer.getMissingNodeAdr();
    }

    static /* synthetic */ int access$1102(BlobTransfer blobTransfer, int i) {
        blobTransfer.pullMaxChunkNumber = i;
        return i;
    }

    static /* synthetic */ void access$1200(BlobTransfer blobTransfer) {
        blobTransfer.nextAction();
    }

    static /* synthetic */ int access$1300(BlobTransfer blobTransfer) {
        return blobTransfer.nodeIndex;
    }

    static /* synthetic */ int access$1302(BlobTransfer blobTransfer, int i) {
        blobTransfer.nodeIndex = i;
        return i;
    }

    static /* synthetic */ String access$1400(BlobTransfer blobTransfer, int i) {
        return blobTransfer.getStepDesc(i);
    }

    static /* synthetic */ void access$1500(BlobTransfer blobTransfer) {
        blobTransfer.removeFailedDevices();
    }

    static /* synthetic */ BlobTransferCallback access$1600(BlobTransfer blobTransfer) {
        return blobTransfer.transferCallback;
    }

    static /* synthetic */ long access$1700(BlobTransfer blobTransfer) {
        return blobTransfer.blobId;
    }

    static /* synthetic */ void access$1800(BlobTransfer blobTransfer) {
        blobTransfer.sendChunks();
    }

    static /* synthetic */ void access$1900(BlobTransfer blobTransfer) {
        blobTransfer.sendMissingChunks();
    }

    static /* synthetic */ MeshFirmwareParser access$200(BlobTransfer blobTransfer) {
        return blobTransfer.firmwareParser;
    }

    static /* synthetic */ void access$2000(BlobTransfer blobTransfer) {
        blobTransfer.restartParRptWaiting();
    }

    static /* synthetic */ int access$2208(BlobTransfer blobTransfer) {
        int i = blobTransfer.missingChunkIndex;
        blobTransfer.missingChunkIndex = i + 1;
        return i;
    }

    static /* synthetic */ void access$300(BlobTransfer blobTransfer, String str) {
        blobTransfer.log(str);
    }

    static /* synthetic */ void access$400(BlobTransfer blobTransfer, boolean z, String str) {
        blobTransfer.onTransferComplete(z, str);
    }

    static /* synthetic */ int access$500(BlobTransfer blobTransfer) {
        return blobTransfer.groupAddress;
    }

    static /* synthetic */ int access$600(BlobTransfer blobTransfer) {
        return blobTransfer.appKeyIndex;
    }

    static /* synthetic */ BlobTransferType access$700(BlobTransfer blobTransfer) {
        return blobTransfer.transferType;
    }

    static /* synthetic */ void access$900(BlobTransfer blobTransfer, MeshMessage meshMessage) {
        blobTransfer.onTransferMessagePrepared(meshMessage);
    }

    public BlobTransfer(HandlerThread handlerThread, BlobTransferCallback blobTransferCallback, IntSupplier intSupplier) {
        this.gattMtu = intSupplier;
        this.delayHandler = new Handler(handlerThread.getLooper());
        this.transferCallback = blobTransferCallback;
    }

    public void resetParams(FirmwareUpdateConfiguration firmwareUpdateConfiguration, BlobTransferType blobTransferType, int i) {
        this.firmwareData = firmwareUpdateConfiguration.getFirmwareData();
        this.extendBearerMode = firmwareUpdateConfiguration.getExtendBearerMode();
        this.blobId = firmwareUpdateConfiguration.getBlobId();
        this.appKeyIndex = firmwareUpdateConfiguration.getAppKeyIndex();
        this.groupAddress = firmwareUpdateConfiguration.getGroupAddress();
        this.networkInterval = firmwareUpdateConfiguration.getNetworkInterval();
        this.targetDevices.clear();
        this.transferType = blobTransferType;
        log("transfer begin: " + blobTransferType);
        this.missingNodes.clear();
        this.mixedFormat = -1;
        if (blobTransferType == BlobTransferType.LOCAL_INIT || blobTransferType == BlobTransferType.GATT_INIT) {
            this.targetDevices.add(new TargetDevice(i));
            this.missingNodes.add(Integer.valueOf(i));
            return;
        }
        for (MeshUpdatingDevice meshUpdatingDevice : firmwareUpdateConfiguration.getUpdatingDevices()) {
            this.targetDevices.add(new TargetDevice(meshUpdatingDevice.meshAddress));
            this.missingNodes.add(Integer.valueOf(meshUpdatingDevice.meshAddress));
        }
    }

    public void begin(boolean z) {
        log(String.format(Locale.getDefault(), "blob transfer begin : continue-%b step-%02d ", Boolean.valueOf(z), Integer.valueOf(this.step)));
        NetworkingController.netPktSendInterval = this.networkInterval;
        log("network transmit changed : " + this.networkInterval);
        if (z) {
            log("blob transfer continue");
            nextAction();
            return;
        }
        log("blob transfer continue: block--chunk " + this.firmwareParser.currentBlockIndex() + " -- " + this.firmwareParser.currentChunkIndex());
        this.step = 5;
        this.pullProgress = -1;
        nextAction();
    }

    void clear() {
        NetworkingController.netPktSendInterval = 240L;
        log("network transmit revert : 240");
        this.step = 0;
        this.delayHandler.removeCallbacksAndMessages(null);
    }

    void hold() {
        this.delayHandler.removeCallbacksAndMessages(null);
    }

    private void restartParRptWaiting() {
        this.delayHandler.removeCallbacks(this.PARTIAL_REPORT_WAITING_TASK);
        this.delayHandler.postDelayed(this.PARTIAL_REPORT_WAITING_TASK, PARTIAL_WAITING_TIMEOUT);
    }

    private void stopParRptWaiting() {
        this.delayHandler.removeCallbacks(this.PARTIAL_REPORT_WAITING_TASK);
    }

    /* renamed from: lambda$new$0$com-telink-ble-mesh-core-access-fu-BlobTransfer, reason: not valid java name */
    /* synthetic */ void m104lambda$new$0$comtelinkblemeshcoreaccessfuBlobTransfer() {
        onTransferComplete(false, "partial report waiting timeout");
    }

    private void nextAction() {
        int i = (this.transferType == BlobTransferType.LOCAL_INIT || this.transferType == BlobTransferType.GATT_DIST) ? 0 : 300;
        log("action: " + getStepDesc(this.step) + " -- node index -- " + this.nodeIndex);
        this.delayHandler.removeCallbacks(this.ACTION_TASK);
        this.delayHandler.postDelayed(this.ACTION_TASK, (long) i);
    }

    private void onGetBlobBlockComplete() {
        log("onGetBlobBlockComplete : " + this.mixedFormat + " -- " + this.missingChunks.size());
        int i = this.mixedFormat;
        if (i == 0) {
            log("get blob block complete -> all chunks missing", 3);
            this.step = 9;
            this.firmwareParser.resetBlock();
            nextAction();
        } else {
            if (i == 1) {
                log("get blob block complete -> no chunks missing", 3);
            } else if (i == 2 || i == 3) {
                if (this.missingChunks.size() == 0) {
                    log("get blob block complete -> missing chunks size 0", 3);
                } else {
                    log("get blob block complete -> resend missing chunks , size=" + this.missingChunks.size(), 3);
                    printMissingChunkNumber("mixed missing chunks : ", this.missingChunks);
                    this.missingChunkIndex = 0;
                    sendMissingChunks();
                }
            }
            if (this.missingNodes.size() > 0) {
                this.missingNodes.remove(0);
            }
            this.step = 10;
            nextAction();
            return;
        }
        log("block not complete : ");
    }

    private void printMissingChunkNumber(String str, List<Integer> list) {
        StringBuilder sb = new StringBuilder(str);
        for (Integer num : list) {
            num.intValue();
            sb.append(String.format("%04X  ", num));
        }
        log(sb.toString(), 3);
    }

    private void removeFailedDevices() {
        Iterator<TargetDevice> it = this.targetDevices.iterator();
        while (it.hasNext()) {
            TargetDevice next = it.next();
            if (TargetDevice.access$2100(next) == 2) {
                if (this.missingNodes.contains(Integer.valueOf(TargetDevice.access$800(next)))) {
                    this.missingNodes.remove(Integer.valueOf(TargetDevice.access$800(next)));
                }
                it.remove();
            }
        }
    }

    private void onTransferMessagePrepared(MeshMessage meshMessage) {
        if (meshMessage.getOpcode() == Opcode.BLOB_BLOCK_GET.value) {
            meshMessage.setRetryCnt(30);
        } else {
            meshMessage.setRetryCnt(10);
        }
        log("mesh message prepared: " + meshMessage.getClass().getSimpleName() + String.format(" opcode: 0x%04X -- dst: 0x%04X", Integer.valueOf(meshMessage.getOpcode()), Integer.valueOf(meshMessage.getDestinationAddress())));
        BlobTransferCallback blobTransferCallback = this.transferCallback;
        if (blobTransferCallback == null || blobTransferCallback.onMeshMessagePrepared(meshMessage)) {
            return;
        }
        if (meshMessage instanceof BlobChunkTransferMessage) {
            onTransferComplete(false, "chunk transfer message sent error");
            return;
        }
        int size = this.targetDevices.size();
        int i = this.nodeIndex;
        if (size > i) {
            onDeviceFail(this.targetDevices.get(i), String.format("mesh message sent error -- opcode: 0x%04X", Integer.valueOf(meshMessage.getOpcode())));
        }
    }

    private void onDeviceFail(TargetDevice targetDevice, String str) {
        log(String.format("node updating fail(A): %04X -- " + str, Integer.valueOf(TargetDevice.access$800(targetDevice))));
        TargetDevice.access$2102(targetDevice, 2);
        BlobTransferCallback blobTransferCallback = this.transferCallback;
        if (blobTransferCallback != null) {
            blobTransferCallback.onTransferringDeviceFail(TargetDevice.access$800(targetDevice), String.format("node updating fail: %04X -- " + str, Integer.valueOf(TargetDevice.access$800(targetDevice))));
        }
    }

    private void onDeviceFail(int i, String str) {
        TargetDevice next;
        log(String.format("node updating fail: %04X -- " + str, Integer.valueOf(i)));
        Iterator<TargetDevice> it = this.targetDevices.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            } else {
                next = it.next();
                if (TargetDevice.access$800(next) == i) {
                    break;
                }
            }
        }
        if (next == null) {
            log("device not found in target list ");
            return;
        }
        TargetDevice.access$2102(next, 2);
        BlobTransferCallback blobTransferCallback = this.transferCallback;
        if (blobTransferCallback != null) {
            blobTransferCallback.onTransferringDeviceFail(i, String.format("node updating fail: %04X -- " + str, Integer.valueOf(i)));
        }
    }

    private void onTransferComplete(boolean z, String str) {
        log("blob transfer complete:  -- " + str, 3);
        clear();
        BlobTransferCallback blobTransferCallback = this.transferCallback;
        if (blobTransferCallback != null) {
            blobTransferCallback.onTransferComplete(z, str);
        }
    }

    public void onTransferCommandFail(int i) {
        log("transfer command fail");
        if ((this.step == 5 && i == Opcode.BLOB_TRANSFER_GET.value) || ((this.step == 6 && i == Opcode.BLOB_INFORMATION_GET.value) || ((this.step == 7 && i == Opcode.BLOB_TRANSFER_START.value) || ((this.step == 8 && i == Opcode.BLOB_BLOCK_START.value) || (this.step == 10 && i == Opcode.BLOB_BLOCK_GET.value))))) {
            onDeviceFail(this.targetDevices.get(this.nodeIndex), "device transfer command send fail");
            this.nodeIndex++;
            nextAction();
        } else if (this.step == 9 && i == Opcode.BLOB_CHUNK_TRANSFER.value) {
            onTransferComplete(false, "chunk transfer command send fail");
        }
    }

    public void onTransferSegmentComplete(boolean z) {
        if ((this.transferType == BlobTransferType.GATT_INIT || this.transferType == BlobTransferType.GATT_DIST) && this.step == 9) {
            if (z) {
                if (this.transferMode == TransferMode.PUSH) {
                    sendChunks();
                    return;
                }
                return;
            }
            onTransferComplete(false, "chunk send fail -- segment message send fail");
        }
    }

    public void onMulticastMessageComplete(int i) {
        if (this.step != 8 || this.transferMode != TransferMode.PUSH) {
            log("multi complete -> distributor -> blob transfer -> not at blob transfer start");
        } else {
            this.step++;
            nextAction();
        }
    }

    public void onTransferNotification(NotificationMessage notificationMessage) {
        Opcode opcodeValueOf = Opcode.valueOf(notificationMessage.getOpcode());
        log("message notification: " + opcodeValueOf);
        if (this.step == 0) {
            log("notification when idle");
            return;
        }
        if (opcodeValueOf == null) {
            return;
        }
        int src = notificationMessage.getSrc();
        if (opcodeValueOf == Opcode.BLOB_INFORMATION_STATUS || opcodeValueOf == Opcode.BLOB_TRANSFER_STATUS || opcodeValueOf == Opcode.BLOB_PARTIAL_BLOCK_REPORT) {
            int size = this.targetDevices.size();
            int i = this.nodeIndex;
            if (size <= i) {
                log("node index overflow", 3);
                return;
            } else if (TargetDevice.access$800(this.targetDevices.get(i)) != src) {
                log("blob transfer unexpected notification src");
                return;
            }
        }
        int i2 = AnonymousClass4.$SwitchMap$com$telink$ble$mesh$core$message$Opcode[opcodeValueOf.ordinal()];
        if (i2 == 1) {
            onBlobInfoStatus((BlobInfoStatusMessage) notificationMessage.getStatusMessage());
            return;
        }
        if (i2 == 2) {
            onBlobTransferStatus((BlobTransferStatusMessage) notificationMessage.getStatusMessage());
        } else if (i2 == 3) {
            onBlobBlockStatus(notificationMessage);
        } else {
            if (i2 != 4) {
                return;
            }
            onBlobPartialBlockReport((BlobPartialBlockReportMessage) notificationMessage.getStatusMessage());
        }
    }

    /* renamed from: com.telink.ble.mesh.core.access.fu.BlobTransfer$4, reason: invalid class name */
    static /* synthetic */ class AnonymousClass4 {
        static final /* synthetic */ int[] $SwitchMap$com$telink$ble$mesh$core$message$Opcode;

        static {
            int[] iArr = new int[Opcode.values().length];
            $SwitchMap$com$telink$ble$mesh$core$message$Opcode = iArr;
            try {
                iArr[Opcode.BLOB_INFORMATION_STATUS.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$message$Opcode[Opcode.BLOB_TRANSFER_STATUS.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$message$Opcode[Opcode.BLOB_BLOCK_STATUS.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$message$Opcode[Opcode.BLOB_PARTIAL_BLOCK_REPORT.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    private void sendChunks() {
        byte[] bArrNextChunk = this.firmwareParser.nextChunk();
        int iCurrentChunkIndex = this.firmwareParser.currentChunkIndex();
        if (bArrNextChunk != null) {
            validateUpdatingProgress();
            BlobChunkTransferMessage blobChunkTransferMessageGenerateChunkTransferMessage = generateChunkTransferMessage(iCurrentChunkIndex, bArrNextChunk);
            log("next chunk transfer msg: " + blobChunkTransferMessageGenerateChunkTransferMessage.toString() + " - extendBearerMode - " + this.extendBearerMode);
            onTransferMessagePrepared(blobChunkTransferMessageGenerateChunkTransferMessage);
            if (this.transferType == BlobTransferType.GATT_INIT || this.transferType == BlobTransferType.GATT_DIST) {
                if (bArrNextChunk.length + 3 > getSegmentLen()) {
                    return;
                }
                sendChunks();
                return;
            }
            this.delayHandler.postDelayed(this.chunkSendingTask, getChunkSendingInterval());
            return;
        }
        log("chunks sent complete at: block -- " + this.firmwareParser.currentBlockIndex() + " chunk -- " + this.firmwareParser.currentChunkIndex());
        checkMissingChunks();
    }

    private int getSegmentLen() {
        int i = 11;
        if (this.gattMtu.getAsInt() >= 225 && (this.transferType == BlobTransferType.GATT_INIT || this.transferType == BlobTransferType.GATT_DIST || this.extendBearerMode != ExtendBearerMode.NONE)) {
            i = 225;
        }
        log("segment len: " + i);
        return i;
    }

    private void validateUpdatingProgress() {
        if (this.transferMode == TransferMode.PUSH) {
            if (this.firmwareParser.validateProgress()) {
                int progress = this.firmwareParser.getProgress();
                log("chunk sending progress: " + progress);
                this.transferCallback.onTransferProgressUpdate(progress, this.transferType);
                return;
            }
            return;
        }
        if (this.transferMode == TransferMode.PULL) {
            MeshFirmwareParser meshFirmwareParser = this.firmwareParser;
            int progressAt = meshFirmwareParser.getProgressAt(meshFirmwareParser.currentBlockIndex(), this.pullMaxChunkNumber);
            if (this.pullProgress != progressAt) {
                this.pullProgress = progressAt;
                this.transferCallback.onTransferProgressUpdate(progressAt, this.transferType);
            }
        }
    }

    private void checkMissingChunks() {
        log("check missing chunks (get blob block)", 3);
        this.missingChunks.clear();
        this.mixedFormat = -1;
        this.step = 10;
        this.nodeIndex = 0;
        nextAction();
    }

    private int getMissingNodeAdr() {
        if (this.missingNodes.size() == 0) {
            return -1;
        }
        return this.missingNodes.get(0).intValue();
    }

    private void sendMissingChunks() {
        if (this.missingChunkIndex >= this.missingChunks.size()) {
            log("all missing chunks sent complete: " + this.missingChunkIndex);
            if (this.transferMode == TransferMode.PUSH) {
                checkMissingChunks();
                return;
            }
            return;
        }
        int iIntValue = this.missingChunks.get(this.missingChunkIndex).intValue();
        log("send missing chunk at : " + this.firmwareParser.currentBlockIndex() + " - " + iIntValue);
        byte[] bArrChunkAt = this.firmwareParser.chunkAt(iIntValue);
        if (bArrChunkAt == null) {
            log("chunk index overflow when resending chunk: " + iIntValue);
            return;
        }
        if (this.transferMode == TransferMode.PULL) {
            if (this.pullMaxChunkNumber < iIntValue) {
                this.pullMaxChunkNumber = iIntValue;
            }
            validateUpdatingProgress();
        }
        onTransferMessagePrepared(generateChunkTransferMessage(iIntValue, bArrChunkAt));
        this.delayHandler.removeCallbacks(this.missingChunkSendingTask);
        this.delayHandler.postDelayed(this.missingChunkSendingTask, getChunkSendingInterval());
    }

    private void mixMissingChunks(List<Integer> list) {
        if (this.mixedFormat == 0 || list == null) {
            return;
        }
        for (Integer num : list) {
            num.intValue();
            if (!this.missingChunks.contains(num)) {
                this.missingChunks.add(num);
            }
        }
    }

    private void mixFormat(int i) {
        int i2 = this.mixedFormat;
        if (i2 == 0) {
            return;
        }
        if (i2 == -1) {
            this.mixedFormat = i;
        } else {
            if (i2 == i || i == 1) {
                return;
            }
            this.mixedFormat = i;
        }
    }

    private long getChunkSendingInterval() {
        long jMax;
        if (this.transferType == BlobTransferType.LOCAL_INIT) {
            jMax = 1;
        } else if (this.transferType == BlobTransferType.GATT_INIT || this.transferType == BlobTransferType.GATT_DIST) {
            TransferMode transferMode = TransferMode.PULL;
            jMax = 10;
        } else if (this.transferMode == TransferMode.PULL) {
            jMax = 120;
        } else {
            int i = 1;
            int chunkSize = this.firmwareParser.getChunkSize() + 1;
            int segmentLen = getSegmentLen();
            int i2 = segmentLen + 1;
            if (chunkSize != segmentLen) {
                i = chunkSize % i2 == 0 ? chunkSize / i2 : 1 + (chunkSize / i2);
            }
            jMax = Math.max(segmentLen == 11 ? 3000L : 300L, (i * NetworkingController.netPktSendInterval) + 100);
        }
        log("chunk sending interval: " + jMax);
        return jMax;
    }

    private BlobChunkTransferMessage generateChunkTransferMessage(int i, byte[] bArr) {
        int iAccess$800;
        if (this.transferType == BlobTransferType.LOCAL_INIT || this.transferType == BlobTransferType.GATT_INIT || this.transferType == BlobTransferType.GATT_DIST) {
            iAccess$800 = TargetDevice.access$800(this.targetDevices.get(0));
        } else if ((this.firmwareParser.getChunkSize() <= 8 && this.targetDevices.size() == 1) || this.transferMode == TransferMode.PULL) {
            iAccess$800 = TargetDevice.access$800(this.targetDevices.get(0));
        } else {
            iAccess$800 = this.groupAddress;
        }
        return BlobChunkTransferMessage.getSimple(iAccess$800, this.appKeyIndex, i, bArr);
    }

    private void onBlobTransferStatus(BlobTransferStatusMessage blobTransferStatusMessage) {
        log("blob transfer status: " + blobTransferStatusMessage.toString());
        int i = this.step;
        if (i == 7 || i == 5) {
            if (UpdateStatus.valueOf(blobTransferStatusMessage.getStatus()) != UpdateStatus.SUCCESS) {
                onDeviceFail(this.targetDevices.get(this.nodeIndex), "object transfer status err");
            }
            this.nodeIndex++;
            nextAction();
        }
    }

    private void onBlobBlockStatus(NotificationMessage notificationMessage) {
        int i = this.step;
        if (i == 10 || i == 8) {
            BlobBlockStatusMessage blobBlockStatusMessage = (BlobBlockStatusMessage) notificationMessage.getStatusMessage();
            log("block status: " + blobBlockStatusMessage.toString());
            int src = notificationMessage.getSrc();
            if (TransferStatus.valueOf(blobBlockStatusMessage.getStatus() & 255) != TransferStatus.SUCCESS) {
                onDeviceFail(src, "block status err");
            } else {
                int i2 = this.step;
                if (i2 == 10 || (i2 == 8 && this.transferMode == TransferMode.PULL)) {
                    int format = blobBlockStatusMessage.getFormat();
                    log("block status: 1 ");
                    mixFormat(format);
                    log("block status: 2 - mix " + this.mixedFormat);
                    if (format == 0) {
                        log(String.format("all chunks missing: %04X", Integer.valueOf(src)), 3);
                    } else if (format == 1) {
                        log(String.format("no chunks missing: %04X", Integer.valueOf(src)), 3);
                    } else if (format == 2) {
                        mixMissingChunks(blobBlockStatusMessage.getMissingChunks());
                        printMissingChunkNumber(String.format("missing chunks(some) at %04X : ", Integer.valueOf(src)), blobBlockStatusMessage.getMissingChunks());
                    } else if (format == 3) {
                        mixMissingChunks(blobBlockStatusMessage.getEncodedMissingChunks());
                        printMissingChunkNumber(String.format("missing chunks(encoded) at %04X : ", Integer.valueOf(src)), blobBlockStatusMessage.getEncodedMissingChunks());
                    }
                    if (this.step == 8) {
                        this.nodeIndex++;
                        nextAction();
                        return;
                    }
                } else {
                    log("block status: 3 - step = " + this.step + " -- mode " + this.transferMode);
                    if (this.transferType == BlobTransferType.LOCAL_INIT || this.transferType == BlobTransferType.GATT_INIT) {
                        this.step++;
                        nextAction();
                        return;
                    }
                }
            }
            onGetBlobBlockComplete();
        }
    }

    private void onBlobPartialBlockReport(BlobPartialBlockReportMessage blobPartialBlockReportMessage) {
        if (this.step != 9) {
            log("partial report not at chunk sending");
            return;
        }
        ArrayList<Integer> encodedMissingChunks = blobPartialBlockReportMessage.getEncodedMissingChunks();
        if (encodedMissingChunks.size() == 0) {
            log("no missing chunks in PartialBlockReport ");
            stopParRptWaiting();
            this.pullMaxChunkNumber = 0;
            checkMissingChunks();
            return;
        }
        restartParRptWaiting();
        StringBuilder sb = new StringBuilder();
        Iterator<Integer> it = encodedMissingChunks.iterator();
        while (it.hasNext()) {
            sb.append(it.next().intValue());
            sb.append(",");
        }
        log(String.format(Locale.getDefault(), "PartialBlockReport:blockIndex=%d, missingChunkSize=%d, detail=%s ", Integer.valueOf(this.firmwareParser.currentBlockIndex()), Integer.valueOf(encodedMissingChunks.size()), sb), 3);
        this.delayHandler.removeCallbacks(this.missingChunkSendingTask);
        this.missingChunks = encodedMissingChunks;
        this.missingChunkIndex = 0;
        this.mixedFormat = 3;
        sendMissingChunks();
    }

    private void onBlobInfoStatus(BlobInfoStatusMessage blobInfoStatusMessage) {
        log("object info status: " + blobInfoStatusMessage.toString());
        if (this.step != 6) {
            log("not at STEP_GET_BLOB_INFO");
            return;
        }
        int iPow = (int) Math.pow(2.0d, blobInfoStatusMessage.getMaxBlockSizeLog());
        int maxChunkSize = blobInfoStatusMessage.getMaxChunkSize();
        boolean zIsPushModeSupported = blobInfoStatusMessage.isPushModeSupported();
        boolean zIsPullModeSupported = blobInfoStatusMessage.isPullModeSupported();
        boolean z = this.transferType == BlobTransferType.GATT_DIST || this.transferType == BlobTransferType.GATT_INIT;
        log("blob info: pushSupported - " + zIsPushModeSupported + " -- pullSupported: " + zIsPullModeSupported + " -- gattTransfer: " + z);
        if (zIsPullModeSupported) {
            if (zIsPushModeSupported) {
                this.transferMode = z ? TransferMode.PUSH : TransferMode.PULL;
            } else {
                this.transferMode = TransferMode.PULL;
            }
        } else if (zIsPushModeSupported) {
            this.transferMode = TransferMode.PUSH;
        }
        log("refresh transfer mode: " + this.transferMode);
        if (zIsPullModeSupported && zIsPushModeSupported && this.transferMode == TransferMode.PUSH) {
            maxChunkSize = 208;
        }
        log("chunk size : " + maxChunkSize + " block size: " + iPow);
        this.firmwareParser.reset(this.firmwareData, iPow, maxChunkSize);
        this.nodeIndex = this.nodeIndex + 1;
        nextAction();
    }

    private String getStepDesc(int i) {
        switch (i) {
            case 5:
                return "blob-transfer-get";
            case 6:
                return "get-blob-info";
            case 7:
                return "blob-transfer-start";
            case 8:
                return "blob-block-transfer-start";
            case 9:
                return "blob-chunk-sending";
            case 10:
                return "get-blob-block";
            default:
                return "unknown";
        }
    }

    private void log(String str) {
        log(str, 1);
    }

    private void log(String str, int i) {
        this.transferCallback.onTransferLog("BlobTransfer", str, i);
    }

    public static class TargetDevice {
        private static final int STATE_FAIL = 2;
        private static final int STATE_INITIAL = 0;
        private static final int STATE_SUCCESS = 1;
        private int address;
        private int state = 0;

        static /* synthetic */ int access$2100(TargetDevice targetDevice) {
            return targetDevice.state;
        }

        static /* synthetic */ int access$2102(TargetDevice targetDevice, int i) {
            targetDevice.state = i;
            return i;
        }

        static /* synthetic */ int access$800(TargetDevice targetDevice) {
            return targetDevice.address;
        }

        public TargetDevice(int i) {
            this.address = i;
        }
    }
}
