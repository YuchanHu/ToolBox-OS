package com.telink.ble.mesh.core.networking.transport.lower;

import com.telink.ble.mesh.core.networking.NetworkLayerPDU;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import org.spongycastle.asn1.eac.CertificateBody;

/* loaded from: classes.dex */
public class SegmentedControlMessagePDU extends LowerTransportPDU {
    private int opcode;
    private int segN;
    private int segO;
    private byte[] segmentM;
    private int seqZero;
    private final byte seg = 1;
    private int RFU = 0;

    @Override // com.telink.ble.mesh.core.networking.transport.lower.LowerTransportPDU
    public boolean segmented() {
        return true;
    }

    @Override // com.telink.ble.mesh.core.networking.transport.lower.LowerTransportPDU
    public int getType() {
        return TYPE_SEGMENTED_ACCESS_MESSAGE;
    }

    @Override // com.telink.ble.mesh.core.networking.NetworkingPDU
    public byte[] toByteArray() {
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(this.segmentM.length + 4).order(ByteOrder.BIG_ENDIAN);
        byteBufferOrder.put((byte) (this.opcode | 128));
        byteBufferOrder.put((byte) ((this.RFU << 7) | ((this.seqZero >> 6) & CertificateBody.profileType)));
        byteBufferOrder.put((byte) (((this.seqZero << 2) & 252) | ((this.segO >> 3) & 3)));
        byteBufferOrder.put((byte) (((this.segO << 5) & 224) | (this.segN & 31)));
        byteBufferOrder.put(this.segmentM);
        return byteBufferOrder.array();
    }

    public boolean parse(NetworkLayerPDU networkLayerPDU) {
        byte[] transportPDU = networkLayerPDU.getTransportPDU();
        this.opcode = (byte) (transportPDU[0] & 127);
        byte b = transportPDU[1];
        this.RFU = (b >> 7) & 1;
        byte b2 = transportPDU[2];
        this.seqZero = ((b & 127) << 6) | ((b2 & 252) >> 2);
        byte b3 = transportPDU[3];
        this.segO = ((b2 & 3) << 3) | ((b3 & 224) >> 5);
        this.segN = b3 & 31;
        byte[] bArr = new byte[transportPDU.length - 4];
        this.segmentM = bArr;
        System.arraycopy(transportPDU, 4, bArr, 0, bArr.length);
        byte[] bArr2 = this.segmentM;
        return bArr2 != null || bArr2.length >= 1;
    }
}
