package com.telink.ble.mesh.core.message;

import com.telink.ble.mesh.core.message.firmwaredistribution.FDCapabilitiesStatusMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDReceiversStatusMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDStatusMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDUploadStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.DistributionStatus;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobBlockStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobInfoStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobTransferStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.TransferStatus;

/* loaded from: classes.dex */
public class MessageResponder {
    public static NotificationMessage responseMessage(MeshMessage meshMessage) {
        NotificationMessage notificationMessage = new NotificationMessage(0, 0, meshMessage.getResponseOpcode(), null);
        notificationMessage.setStatusMessage(generateStatusMessage(meshMessage));
        return notificationMessage;
    }

    public static StatusMessage generateStatusMessage(MeshMessage meshMessage) {
        int responseOpcode = meshMessage.getResponseOpcode();
        if (responseOpcode == Opcode.FD_CAPABILITIES_STATUS.value) {
            return new FDCapabilitiesStatusMessage();
        }
        if (responseOpcode == Opcode.FD_RECEIVERS_STATUS.value) {
            return new FDReceiversStatusMessage();
        }
        if (responseOpcode == Opcode.FD_UPLOAD_STATUS.value) {
            return new FDUploadStatusMessage();
        }
        if (responseOpcode == Opcode.BLOB_INFORMATION_STATUS.value) {
            BlobInfoStatusMessage blobInfoStatusMessage = new BlobInfoStatusMessage();
            blobInfoStatusMessage.setMinBlockSizeLog(18);
            blobInfoStatusMessage.setMaxBlockSizeLog(18);
            blobInfoStatusMessage.setMaxTotalChunks(1261);
            blobInfoStatusMessage.setMaxChunkSize(208);
            blobInfoStatusMessage.setMaxBLOBSize(3);
            blobInfoStatusMessage.setServerMTUSize(380);
            blobInfoStatusMessage.setSupportedTransferMode(1);
            return blobInfoStatusMessage;
        }
        if (responseOpcode == Opcode.BLOB_TRANSFER_STATUS.value) {
            return new BlobTransferStatusMessage();
        }
        if (responseOpcode == Opcode.BLOB_BLOCK_STATUS.value) {
            BlobBlockStatusMessage blobBlockStatusMessage = new BlobBlockStatusMessage();
            blobBlockStatusMessage.setStatus(TransferStatus.SUCCESS.code);
            blobBlockStatusMessage.setFormat(1);
            return blobBlockStatusMessage;
        }
        if (responseOpcode != Opcode.FD_STATUS.value) {
            return null;
        }
        FDStatusMessage fDStatusMessage = new FDStatusMessage();
        fDStatusMessage.status = DistributionStatus.SUCCESS.code;
        return fDStatusMessage;
    }
}
