package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class SubnetBridgeGetMessage extends ConfigMessage {
    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return null;
    }

    public SubnetBridgeGetMessage(int i) {
        super(i);
    }

    public SubnetBridgeGetMessage(int i, byte b) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.SUBNET_BRIDGE_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.SUBNET_BRIDGE_STATUS.value;
    }
}
