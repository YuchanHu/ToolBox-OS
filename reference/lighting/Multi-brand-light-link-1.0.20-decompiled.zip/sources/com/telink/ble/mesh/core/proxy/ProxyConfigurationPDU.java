package com.telink.ble.mesh.core.proxy;

import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.networking.NetworkLayerPDU;
import com.telink.ble.mesh.core.networking.NonceGenerator;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ProxyConfigurationPDU extends NetworkLayerPDU {
    public static final byte ctl = 1;
    public static final byte dst = 0;
    public static final byte ttl = 0;

    public ProxyConfigurationPDU(NetworkLayerPDU.NetworkEncryptionSuite networkEncryptionSuite) {
        super(networkEncryptionSuite);
    }

    @Override // com.telink.ble.mesh.core.networking.NetworkLayerPDU
    protected byte[] generateNonce() {
        return NonceGenerator.generateProxyNonce(MeshUtils.integer2Bytes(getSeq(), 3, ByteOrder.BIG_ENDIAN), getSrc(), this.encryptionSuite.ivIndex);
    }
}
