package com.telink.ble.mesh.core.access;

import android.os.Handler;
import android.os.HandlerThread;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.MeshSigModel;
import com.telink.ble.mesh.core.message.NotificationMessage;
import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.StatusMessage;
import com.telink.ble.mesh.core.message.aggregator.OpcodeAggregatorSequenceMessage;
import com.telink.ble.mesh.core.message.aggregator.OpcodeAggregatorStatusMessage;
import com.telink.ble.mesh.core.message.config.AppKeyAddMessage;
import com.telink.ble.mesh.core.message.config.AppKeyStatusMessage;
import com.telink.ble.mesh.core.message.config.CompositionDataGetMessage;
import com.telink.ble.mesh.core.message.config.CompositionDataStatusMessage;
import com.telink.ble.mesh.core.message.config.ModelAppBindMessage;
import com.telink.ble.mesh.core.message.config.ModelAppStatusMessage;
import com.telink.ble.mesh.core.networking.AccessType;
import com.telink.ble.mesh.entity.BindingDevice;
import com.telink.ble.mesh.entity.CompositionData;
import com.telink.ble.mesh.entity.Element;
import com.telink.ble.mesh.util.MeshLogger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
public class BindingController {
    private static final long BINDING_TIMEOUT_ADV = 60000;
    private static final long BINDING_TIMEOUT_GATT = 30000;
    public static final int STATE_FAIL = 0;
    public static final int STATE_SUCCESS = 1;
    private static final int STEP_APP_KEY_ADD = 2;
    private static final int STEP_APP_KEY_BIND = 3;
    private static final int STEP_GET_CPS = 1;
    private static final int STEP_INIT = 0;
    private static final int STEP_SEND_OP_AGG = 4;
    private AccessBridge accessBridge;
    private byte[] appKey;
    private BindingDevice bindingDevice;
    private Handler delayHandler;
    private int netKeyIndex;
    private final String LOG_TAG = "Binding";
    private int step = 0;
    private int modelIndex = 0;
    private List<BindingModel> bindingModels = new ArrayList();
    private boolean isAggSupported = false;
    private Runnable bindingTimeoutTask = new Runnable() { // from class: com.telink.ble.mesh.core.access.BindingController.1
        @Override // java.lang.Runnable
        public void run() {
            BindingController bindingController = BindingController.this;
            BindingController.access$100(bindingController, BindingController.access$000(bindingController, "binding timeout"));
        }
    };

    static /* synthetic */ String access$000(BindingController bindingController, String str) {
        return bindingController.bindingFailureDetail(str);
    }

    static /* synthetic */ void access$100(BindingController bindingController, String str) {
        bindingController.onBindFail(str);
    }

    public BindingController(HandlerThread handlerThread) {
        this.delayHandler = new Handler(handlerThread.getLooper());
    }

    public void register(AccessBridge accessBridge) {
        this.accessBridge = accessBridge;
    }

    public BindingDevice getBindingDevice() {
        return this.bindingDevice;
    }

    public void begin(int i, byte[] bArr, BindingDevice bindingDevice) {
        this.netKeyIndex = i;
        this.bindingDevice = bindingDevice;
        this.appKey = bArr;
        this.bindingModels.clear();
        this.modelIndex = 0;
        this.delayHandler.removeCallbacks(this.bindingTimeoutTask);
        this.delayHandler.postDelayed(this.bindingTimeoutTask, isGattBearer() ? BINDING_TIMEOUT_GATT : BINDING_TIMEOUT_ADV);
        log("binding begin: defaultBound? " + bindingDevice.isDefaultBound());
        if (this.bindingDevice.requiresConfirmedBinding()) {
            this.bindingDevice.setReceivedCompositionPage(-1);
            this.bindingDevice.setCompositionData(null);
            getCompositionData();
        } else if (this.bindingDevice.getCompositionData() == null) {
            getCompositionData();
        } else if (this.bindingDevice.isDefaultBound()) {
            addAppKey();
        } else {
            onCompositionDataReceived(this.bindingDevice.getCompositionData());
        }
    }

    public void clear() {
        Handler handler = this.delayHandler;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
        this.modelIndex = 0;
        this.step = 0;
        this.bindingModels.clear();
    }

    private boolean isGattBearer() {
        BindingDevice bindingDevice = this.bindingDevice;
        return bindingDevice != null && bindingDevice.getBearer() == BindingBearer.GattOnly;
    }

    private void getCompositionData() {
        CompositionDataGetMessage compositionDataGetMessage;
        updateStep(1);
        int meshAddress = this.bindingDevice.getMeshAddress();
        if (this.bindingDevice.requiresConfirmedBinding()) {
            compositionDataGetMessage = new CompositionDataGetMessage(meshAddress, (byte) 0);
        } else {
            compositionDataGetMessage = new CompositionDataGetMessage(meshAddress);
        }
        onMeshMessagePrepared(compositionDataGetMessage);
    }

    private void addAppKey() {
        log("add app key");
        updateStep(2);
        AppKeyAddMessage appKeyAddMessage = new AppKeyAddMessage(this.bindingDevice.getMeshAddress());
        appKeyAddMessage.setNetKeyIndex(this.netKeyIndex);
        appKeyAddMessage.setAppKeyIndex(this.bindingDevice.getAppKeyIndex());
        appKeyAddMessage.setAppKey(this.appKey);
        onMeshMessagePrepared(appKeyAddMessage);
    }

    private void onMeshMessagePrepared(MeshMessage meshMessage) {
        if (this.accessBridge != null) {
            if (!isGattBearer()) {
                meshMessage.setRetryCnt(8);
            }
            if (this.accessBridge.onAccessMessagePrepared(meshMessage, 1)) {
                return;
            }
            onBindFail(bindingFailureDetail("binding message sent error"));
        }
    }

    private void bindNextModel() {
        int size = this.bindingModels.size();
        int i = this.modelIndex;
        if (size > i) {
            BindingModel bindingModel = this.bindingModels.get(i);
            int i2 = bindingModel.modelId;
            ModelAppBindMessage modelAppBindMessage = new ModelAppBindMessage(this.bindingDevice.getMeshAddress());
            int meshAddress = this.bindingDevice.getMeshAddress() + bindingModel.elementOffset;
            modelAppBindMessage.setElementAddress(meshAddress);
            modelAppBindMessage.setAppKeyIndex(this.bindingDevice.getAppKeyIndex());
            modelAppBindMessage.setSigModel(bindingModel.sig);
            modelAppBindMessage.setModelIdentifier(i2);
            log("bind next model: " + Integer.toHexString(i2) + " at: " + Integer.toHexString(meshAddress));
            onMeshMessagePrepared(modelAppBindMessage);
            return;
        }
        onBindSuccess();
    }

    private void updateStep(int i) {
        log("update bind step: " + i);
        this.step = i;
    }

    private void onCompositionDataReceived(CompositionData compositionData) {
        this.bindingDevice.setCompositionData(compositionData);
        if (compositionData == null || compositionData.elements == null || compositionData.elements.isEmpty()) {
            onBindFail("invalid composition data");
            return;
        }
        List<BindingModel> allModels = getAllModels(compositionData);
        if (allModels.isEmpty()) {
            onBindFail("no models in composition data");
            return;
        }
        this.bindingModels.clear();
        this.modelIndex = 0;
        if (this.bindingDevice.getModelSelector() != null) {
            if (!selectBindingModels(compositionData, allModels)) {
                return;
            }
        } else if (this.bindingDevice.getModels() == null) {
            if (!this.bindingDevice.requiresConfirmedBinding()) {
                this.bindingModels.addAll(allModels);
            }
        } else {
            for (BindingModel bindingModel : allModels) {
                int[] models = this.bindingDevice.getModels();
                int length = models.length;
                int i = 0;
                while (true) {
                    if (i < length) {
                        if (bindingModel.modelId == models[i]) {
                            this.bindingModels.add(bindingModel);
                            break;
                        }
                        i++;
                    }
                }
            }
        }
        if (this.bindingModels.size() == 0) {
            onBindFail("no target models found");
            return;
        }
        log("models prepared: " + this.bindingModels.size());
        if (this.isAggSupported && !this.bindingDevice.requiresConfirmedBinding()) {
            log("bind app key by opcode-aggregator");
            sendOpAggMessage();
        } else {
            addAppKey();
        }
    }

    private boolean selectBindingModels(CompositionData compositionData, List<BindingModel> list) {
        BindingModel next;
        try {
            List<BindingDevice.ModelTarget> listApply = this.bindingDevice.getModelSelector().apply(compositionData);
            if (listApply == null) {
                onBindFail("model selection failed");
                return false;
            }
            for (BindingDevice.ModelTarget modelTarget : listApply) {
                if (modelTarget != null) {
                    Iterator<BindingModel> it = list.iterator();
                    while (it.hasNext()) {
                        next = it.next();
                        if (next.modelId == modelTarget.modelId && next.elementOffset == modelTarget.elementOffset && next.sig == modelTarget.sig) {
                            break;
                        }
                    }
                    next = null;
                } else {
                    next = null;
                }
                if (next == null || !MeshUtils.validUnicastAddress(this.bindingDevice.getMeshAddress() + next.elementOffset)) {
                    onBindFail("selected model not found in composition data");
                    return false;
                }
                if (!this.bindingModels.contains(next)) {
                    this.bindingModels.add(next);
                }
            }
            return true;
        } catch (RuntimeException unused) {
            onBindFail("model selection failed");
            return false;
        }
    }

    private void sendOpAggMessage() {
        updateStep(4);
        ArrayList arrayList = new ArrayList();
        AppKeyAddMessage appKeyAddMessage = new AppKeyAddMessage(this.bindingDevice.getMeshAddress());
        appKeyAddMessage.setNetKeyIndex(this.netKeyIndex);
        appKeyAddMessage.setAppKeyIndex(this.bindingDevice.getAppKeyIndex());
        appKeyAddMessage.setAppKey(this.appKey);
        arrayList.add(appKeyAddMessage);
        for (BindingModel bindingModel : this.bindingModels) {
            int i = bindingModel.modelId;
            ModelAppBindMessage modelAppBindMessage = new ModelAppBindMessage(this.bindingDevice.getMeshAddress());
            modelAppBindMessage.setElementAddress(this.bindingDevice.getMeshAddress() + bindingModel.elementOffset);
            modelAppBindMessage.setAppKeyIndex(this.bindingDevice.getAppKeyIndex());
            modelAppBindMessage.setSigModel(bindingModel.sig);
            modelAppBindMessage.setModelIdentifier(i);
            arrayList.add(modelAppBindMessage);
        }
        onMeshMessagePrepared(new OpcodeAggregatorSequenceMessage(this.bindingDevice.getMeshAddress(), AccessType.DEVICE, this.bindingDevice.getAppKeyIndex(), MeshUtils.aggregateMessages(this.bindingDevice.getMeshAddress(), arrayList)));
    }

    private List<BindingModel> getAllModels(CompositionData compositionData) {
        ArrayList arrayList = new ArrayList();
        this.isAggSupported = false;
        int i = 0;
        for (Element element : compositionData.elements) {
            if (element.sigModels != null) {
                Iterator<Integer> it = element.sigModels.iterator();
                while (it.hasNext()) {
                    int iIntValue = it.next().intValue();
                    if (!MeshSigModel.useDeviceKeyForEnc(iIntValue)) {
                        arrayList.add(new BindingModel(iIntValue, i, true));
                    }
                    if (iIntValue == MeshSigModel.SIG_MD_CFG_OP_AGG_S.modelId) {
                        this.isAggSupported = true;
                    }
                }
            }
            if (element.vendorModels != null) {
                Iterator<Integer> it2 = element.vendorModels.iterator();
                while (it2.hasNext()) {
                    arrayList.add(new BindingModel(it2.next().intValue(), i, false));
                }
            }
            i++;
        }
        return arrayList;
    }

    public void onMessageNotification(NotificationMessage notificationMessage) {
        BindingDevice bindingDevice;
        Opcode opcodeValueOf;
        if (this.step == 0 || (bindingDevice = this.bindingDevice) == null) {
            return;
        }
        if ((!bindingDevice.requiresConfirmedBinding() || notificationMessage.getSrc() == this.bindingDevice.getMeshAddress()) && (opcodeValueOf = Opcode.valueOf(notificationMessage.getOpcode())) != null) {
            int i = AnonymousClass2.$SwitchMap$com$telink$ble$mesh$core$message$Opcode[opcodeValueOf.ordinal()];
            if (i == 1) {
                if (this.step != 1) {
                    log("step not getting cps");
                    return;
                }
                CompositionDataStatusMessage compositionDataStatusMessage = (CompositionDataStatusMessage) notificationMessage.getStatusMessage();
                if (this.bindingDevice.requiresConfirmedBinding()) {
                    int pageNumber = compositionDataStatusMessage == null ? -1 : compositionDataStatusMessage.getPageNumber();
                    this.bindingDevice.setReceivedCompositionPage(pageNumber);
                    if (pageNumber < 0) {
                        onBindFail("invalid composition data");
                        return;
                    } else if (pageNumber != 0) {
                        onBindFail("unexpected composition data page");
                        return;
                    }
                }
                onCompositionDataReceived(compositionDataStatusMessage == null ? null : compositionDataStatusMessage.getCompositionData());
                return;
            }
            if (i == 2) {
                if (this.step != 2) {
                    log("step not app key adding");
                    return;
                }
                AppKeyStatusMessage appKeyStatusMessage = (AppKeyStatusMessage) notificationMessage.getStatusMessage();
                if (appKeyStatusMessage != null) {
                    onAppKeyStatus(appKeyStatusMessage);
                    return;
                }
                return;
            }
            if (i == 3) {
                if (this.step != 3) {
                    log("step not app key binding");
                    return;
                }
                ModelAppStatusMessage modelAppStatusMessage = (ModelAppStatusMessage) notificationMessage.getStatusMessage();
                if (modelAppStatusMessage != null) {
                    if (!this.bindingDevice.requiresConfirmedBinding() || modelAppStatusMessage.hasValidParams()) {
                        onModelAppStatus(modelAppStatusMessage);
                        return;
                    }
                    return;
                }
                return;
            }
            if (i != 4) {
                return;
            }
            if (this.step != 4) {
                log("step not at sending op agg");
                return;
            }
            OpcodeAggregatorStatusMessage opcodeAggregatorStatusMessage = (OpcodeAggregatorStatusMessage) notificationMessage.getStatusMessage();
            if (opcodeAggregatorStatusMessage.status != 0) {
                onBindFail("opcode aggregator status error: " + ((int) opcodeAggregatorStatusMessage.status));
                return;
            }
            List<StatusMessage> opcodeAggregatorStatus = MeshUtils.parseOpcodeAggregatorStatus(opcodeAggregatorStatusMessage);
            if (opcodeAggregatorStatus == null || opcodeAggregatorStatus.size() == 0) {
                onBindFail("opcode agg status parse error");
                return;
            }
            for (int i2 = 0; i2 < opcodeAggregatorStatus.size(); i2++) {
                StatusMessage statusMessage = opcodeAggregatorStatus.get(i2);
                if (statusMessage instanceof AppKeyStatusMessage) {
                    if (((AppKeyStatusMessage) statusMessage).getStatus() == 0) {
                        log("app key add success (op agg)");
                    } else {
                        onBindFail("app key status error (op agg)");
                        return;
                    }
                } else if (statusMessage instanceof ModelAppStatusMessage) {
                    ModelAppStatusMessage modelAppStatusMessage2 = (ModelAppStatusMessage) statusMessage;
                    int modelIdentifier = modelAppStatusMessage2.getModelIdentifier();
                    boolean zIsSigModel = isSigModel(modelIdentifier);
                    if (!zIsSigModel || modelAppStatusMessage2.getStatus() == 0) {
                        log(String.format("model bind success (op agg) modelId-%06X isSig-%b", Integer.valueOf(modelIdentifier), Boolean.valueOf(zIsSigModel)));
                    } else {
                        onBindFail("mode app status error (op agg)");
                        return;
                    }
                } else {
                    continue;
                }
            }
            log("bind complete by op agg");
            onBindSuccess();
        }
    }

    /* renamed from: com.telink.ble.mesh.core.access.BindingController$2, reason: invalid class name */
    static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] $SwitchMap$com$telink$ble$mesh$core$message$Opcode;

        static {
            int[] iArr = new int[Opcode.values().length];
            $SwitchMap$com$telink$ble$mesh$core$message$Opcode = iArr;
            try {
                iArr[Opcode.COMPOSITION_DATA_STATUS.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$message$Opcode[Opcode.APPKEY_STATUS.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$message$Opcode[Opcode.MODE_APP_STATUS.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$message$Opcode[Opcode.CFG_OP_AGG_STATUS.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    private boolean isSigModel(int i) {
        for (BindingModel bindingModel : this.bindingModels) {
            if (bindingModel.modelId == i) {
                return bindingModel.sig;
            }
        }
        return false;
    }

    private void onAppKeyStatus(AppKeyStatusMessage appKeyStatusMessage) {
        String str;
        if (!this.bindingDevice.requiresConfirmedBinding() || (appKeyStatusMessage.getNetKeyIndex() == this.netKeyIndex && appKeyStatusMessage.getAppKeyIndex() == this.bindingDevice.getAppKeyIndex())) {
            if (appKeyStatusMessage.getStatus() == 0) {
                log("app key add success");
                if (this.bindingDevice.isDefaultBound() && !this.bindingDevice.requiresConfirmedBinding()) {
                    log("default bound complete");
                    onBindSuccess();
                    return;
                } else {
                    updateStep(3);
                    bindNextModel();
                    return;
                }
            }
            if (this.bindingDevice.requiresConfirmedBinding()) {
                str = "app key rejected: " + (appKeyStatusMessage.getStatus() & FUDistributor.UPDATE_TTL);
            } else {
                str = "app key status error";
            }
            onBindFail(str);
        }
    }

    private void onModelAppStatus(ModelAppStatusMessage modelAppStatusMessage) {
        int size = this.bindingModels.size();
        int i = this.modelIndex;
        if (size > i) {
            BindingModel bindingModel = this.bindingModels.get(i);
            int i2 = bindingModel.modelId;
            boolean z = bindingModel.sig;
            if (this.bindingDevice.requiresConfirmedBinding()) {
                if (i2 != modelAppStatusMessage.getModelIdentifier() || z != modelAppStatusMessage.isSigModel() || this.bindingDevice.getMeshAddress() + bindingModel.elementOffset != modelAppStatusMessage.getElementAddress() || this.bindingDevice.getAppKeyIndex() != modelAppStatusMessage.getAppKeyIndex()) {
                    return;
                }
                if (modelAppStatusMessage.getStatus() != 0) {
                    onBindFail("model binding rejected: " + (modelAppStatusMessage.getStatus() & FUDistributor.UPDATE_TTL));
                    return;
                }
            }
            if (i2 == modelAppStatusMessage.getModelIdentifier()) {
                if (!z || modelAppStatusMessage.getStatus() == 0) {
                    this.modelIndex++;
                    bindNextModel();
                    return;
                } else {
                    onBindFail("mode app status error");
                    return;
                }
            }
            log("model id error");
            this.modelIndex++;
            bindNextModel();
        }
    }

    public void onBindingCommandComplete(boolean z, int i, int i2, int i3) {
        if (z || this.step == 0) {
            return;
        }
        onBindFail(bindingFailureDetail("binding command send fail"));
    }

    private String bindingFailureDetail(String str) {
        BindingDevice bindingDevice = this.bindingDevice;
        if (bindingDevice == null || !bindingDevice.requiresConfirmedBinding()) {
            return str;
        }
        int i = this.step;
        if (i == 1) {
            return "composition response missing";
        }
        if (i != 2) {
            return i != 3 ? str : "model binding confirmation missing";
        }
        return "app key confirmation missing";
    }

    private void onBindFail(String str) {
        log("binding fail: " + str);
        onBindingComplete();
        onBindState(0, str);
    }

    private void onBindSuccess() {
        onBindingComplete();
        onBindState(1, "binding success");
    }

    private void onBindingComplete() {
        clear();
    }

    private void onBindState(int i, String str) {
        AccessBridge accessBridge = this.accessBridge;
        if (accessBridge != null) {
            accessBridge.onAccessStateChanged(i, str, 1, null);
        }
    }

    private class BindingModel {
        int elementOffset;
        int modelId;
        boolean sig;

        public BindingModel(int i, int i2, boolean z) {
            this.modelId = i;
            this.elementOffset = i2;
            this.sig = z;
        }
    }

    private void log(String str) {
        log(str, 1);
    }

    private void log(String str, int i) {
        MeshLogger.log(str, "Binding", i);
    }
}
