package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;

/* loaded from: classes.dex */
public class LcModeSetMessage extends GenericMessage {
    private boolean ack;
    private byte mode;

    public static LcModeSetMessage getSimple(int i, int i2, byte b, boolean z, int i3) {
        LcModeSetMessage lcModeSetMessage = new LcModeSetMessage(i, i2);
        lcModeSetMessage.mode = b;
        lcModeSetMessage.ack = z;
        lcModeSetMessage.setResponseMax(i3);
        return lcModeSetMessage;
    }

    public LcModeSetMessage(int i, int i2) {
        super(i, i2);
        this.ack = false;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return this.ack ? Opcode.LIGHT_LC_MODE_STATUS.value : super.getResponseOpcode();
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.LIGHT_LC_MODE_SET : Opcode.LIGHT_LC_MODE_SET_NOACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return new byte[]{this.mode};
    }

    public void setMode(byte b) {
        this.mode = b;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }
}
