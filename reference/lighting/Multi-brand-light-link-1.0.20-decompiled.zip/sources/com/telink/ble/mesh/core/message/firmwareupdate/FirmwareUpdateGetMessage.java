package com.telink.ble.mesh.core.message.firmwareupdate;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class FirmwareUpdateGetMessage extends UpdatingMessage {
    public static FirmwareUpdateGetMessage getSimple(int i, int i2) {
        FirmwareUpdateGetMessage firmwareUpdateGetMessage = new FirmwareUpdateGetMessage(i, i2);
        firmwareUpdateGetMessage.setResponseMax(1);
        return firmwareUpdateGetMessage;
    }

    public FirmwareUpdateGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FIRMWARE_UPDATE_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FIRMWARE_UPDATE_STATUS.value;
    }
}
