package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class HeartbeatPublicationSetMessage extends ConfigMessage {
    private byte countLog;
    private int destination;
    private int features;
    private byte hbTtl;
    private int netKeyIndex;
    private byte periodLog;

    public HeartbeatPublicationSetMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.HEARTBEAT_PUB_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(9).order(ByteOrder.LITTLE_ENDIAN);
        byteBufferOrder.putShort((short) this.destination).put(this.countLog).put(this.periodLog).put(this.hbTtl).putShort((short) this.features).putShort((short) this.netKeyIndex);
        return byteBufferOrder.array();
    }

    public void setDestination(int i) {
        this.destination = i;
    }

    public void setCountLog(byte b) {
        this.countLog = b;
    }

    public void setPeriodLog(byte b) {
        this.periodLog = b;
    }

    public void setHbTtl(byte b) {
        this.hbTtl = b;
    }

    public void setFeatures(int i) {
        this.features = i;
    }

    public void setNetKeyIndex(int i) {
        this.netKeyIndex = i;
    }
}
