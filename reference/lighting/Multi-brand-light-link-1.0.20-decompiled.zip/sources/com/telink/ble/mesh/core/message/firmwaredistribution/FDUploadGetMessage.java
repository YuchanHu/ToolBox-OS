package com.telink.ble.mesh.core.message.firmwaredistribution;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;

/* loaded from: classes.dex */
public class FDUploadGetMessage extends UpdatingMessage {
    public FDUploadGetMessage(int i, int i2) {
        super(i, i2);
    }

    public static FDUploadGetMessage getSimple(int i, int i2) {
        FDUploadGetMessage fDUploadGetMessage = new FDUploadGetMessage(i, i2);
        fDUploadGetMessage.setResponseMax(1);
        return fDUploadGetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FD_UPLOAD_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FD_UPLOAD_STATUS.value;
    }
}
