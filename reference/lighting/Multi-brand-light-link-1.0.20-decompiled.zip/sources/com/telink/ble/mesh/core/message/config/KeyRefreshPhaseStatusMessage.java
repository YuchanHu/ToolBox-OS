package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class KeyRefreshPhaseStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<KeyRefreshPhaseStatusMessage> CREATOR = new Parcelable.Creator<KeyRefreshPhaseStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.KeyRefreshPhaseStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ KeyRefreshPhaseStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ KeyRefreshPhaseStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public KeyRefreshPhaseStatusMessage createFromParcel(Parcel parcel) {
            return new KeyRefreshPhaseStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public KeyRefreshPhaseStatusMessage[] newArray(int i) {
            return new KeyRefreshPhaseStatusMessage[i];
        }
    };
    public int netKeyIndex;
    public byte phase;
    public byte status;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public KeyRefreshPhaseStatusMessage() {
    }

    protected KeyRefreshPhaseStatusMessage(Parcel parcel) {
        this.status = parcel.readByte();
        this.netKeyIndex = parcel.readInt();
        this.phase = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.status = bArr[0];
        this.netKeyIndex = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.LITTLE_ENDIAN);
        this.phase = bArr[3];
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.status);
        parcel.writeInt(this.netKeyIndex);
        parcel.writeByte(this.phase);
    }
}
