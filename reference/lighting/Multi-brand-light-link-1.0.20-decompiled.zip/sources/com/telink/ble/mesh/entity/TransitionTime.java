package com.telink.ble.mesh.entity;

/* loaded from: classes.dex */
public class TransitionTime {
    private static final int MAX_STEP_VALUE = 63;
    private static final int PERIOD_STEP_100_MILL = 100;
    private static final int PERIOD_STEP_10_MINUTE = 600000;
    private static final int PERIOD_STEP_10_SECOND = 10000;
    private static final int PERIOD_STEP_1_SECOND = 1000;
    private static final byte STEP_RESOLUTION_100_MILL = 0;
    private static final byte STEP_RESOLUTION_10_MINUTE = 3;
    private static final byte STEP_RESOLUTION_10_SECOND = 2;
    private static final byte STEP_RESOLUTION_1_SECOND = 1;
    private byte number;
    private byte step;

    public static int getResolution(int i) {
        if (i == 0) {
            return PERIOD_STEP_100_MILL;
        }
        if (i == 1) {
            return PERIOD_STEP_1_SECOND;
        }
        if (i == 2) {
            return PERIOD_STEP_10_SECOND;
        }
        if (i != 3) {
            return 0;
        }
        return PERIOD_STEP_10_MINUTE;
    }

    public TransitionTime(byte b, byte b2) {
        this.number = b;
        this.step = b2;
    }

    /* JADX WARN: Removed duplicated region for block: B:4:0x0007  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static com.telink.ble.mesh.entity.TransitionTime fromTime(long r5) {
        /*
            r0 = 0
            int r0 = (r5 > r0 ? 1 : (r5 == r0 ? 0 : -1))
            r1 = 0
            if (r0 > 0) goto L9
        L7:
            r5 = r1
            goto L42
        L9:
            r2 = 6300(0x189c, double:3.1126E-320)
            int r0 = (r5 > r2 ? 1 : (r5 == r2 ? 0 : -1))
            if (r0 > 0) goto L18
            r2 = 100
            long r5 = r5 / r2
            int r5 = (int) r5
            byte r5 = (byte) r5
            r4 = r1
            r1 = r5
            r5 = r4
            goto L42
        L18:
            r2 = 63000(0xf618, double:3.1126E-319)
            int r0 = (r5 > r2 ? 1 : (r5 == r2 ? 0 : -1))
            if (r0 > 0) goto L26
            r0 = 1000(0x3e8, double:4.94E-321)
            long r5 = r5 / r0
            int r5 = (int) r5
            byte r1 = (byte) r5
            r5 = 1
            goto L42
        L26:
            r2 = 630000(0x99cf0, double:3.112614E-318)
            int r0 = (r5 > r2 ? 1 : (r5 == r2 ? 0 : -1))
            if (r0 > 0) goto L34
            r0 = 10000(0x2710, double:4.9407E-320)
            long r5 = r5 / r0
            int r5 = (int) r5
            byte r1 = (byte) r5
            r5 = 2
            goto L42
        L34:
            r2 = 37800000(0x240c840, double:1.86756814E-316)
            int r0 = (r5 > r2 ? 1 : (r5 == r2 ? 0 : -1))
            if (r0 > 0) goto L7
            r0 = 600000(0x927c0, double:2.964394E-318)
            long r5 = r5 / r0
            int r5 = (int) r5
            byte r1 = (byte) r5
            r5 = 3
        L42:
            com.telink.ble.mesh.entity.TransitionTime r6 = new com.telink.ble.mesh.entity.TransitionTime
            r6.<init>(r1, r5)
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.telink.ble.mesh.entity.TransitionTime.fromTime(long):com.telink.ble.mesh.entity.TransitionTime");
    }

    public byte getValue() {
        return (byte) ((this.step << 6) | this.number);
    }

    public byte getNumber() {
        return this.number;
    }

    public byte getStep() {
        return this.step;
    }

    public int getResolution() {
        byte b = this.step;
        if (b == 0) {
            return PERIOD_STEP_100_MILL;
        }
        if (b == 1) {
            return PERIOD_STEP_1_SECOND;
        }
        if (b == 2) {
            return PERIOD_STEP_10_SECOND;
        }
        if (b != 3) {
            return 0;
        }
        return PERIOD_STEP_10_MINUTE;
    }

    public static int getTimeMilliseconds(int i) {
        return getResolution(i >> 6) * (i & 63);
    }
}
