package com.telink.ble.mesh.core.message.lighting;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class HslTargetStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<HslTargetStatusMessage> CREATOR = new Parcelable.Creator<HslTargetStatusMessage>() { // from class: com.telink.ble.mesh.core.message.lighting.HslTargetStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ HslTargetStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ HslTargetStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public HslTargetStatusMessage createFromParcel(Parcel parcel) {
            return new HslTargetStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public HslTargetStatusMessage[] newArray(int i) {
            return new HslTargetStatusMessage[i];
        }
    };
    private static final int DATA_LEN_COMPLETE = 7;
    private boolean isComplete;
    private byte remainingTime;
    private int targetHue;
    private int targetLightness;
    private int targetSaturation;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public HslTargetStatusMessage() {
        this.isComplete = false;
    }

    protected HslTargetStatusMessage(Parcel parcel) {
        this.isComplete = false;
        this.targetLightness = parcel.readInt();
        this.targetHue = parcel.readInt();
        this.targetSaturation = parcel.readInt();
        this.remainingTime = parcel.readByte();
        this.isComplete = parcel.readByte() != 0;
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.targetLightness = MeshUtils.bytes2Integer(bArr, 0, 2, ByteOrder.LITTLE_ENDIAN);
        this.targetHue = MeshUtils.bytes2Integer(bArr, 2, 2, ByteOrder.LITTLE_ENDIAN);
        this.targetSaturation = MeshUtils.bytes2Integer(bArr, 4, 2, ByteOrder.LITTLE_ENDIAN);
        if (bArr.length >= 7) {
            this.isComplete = true;
            this.remainingTime = bArr[6];
        }
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.targetLightness);
        parcel.writeInt(this.targetHue);
        parcel.writeInt(this.targetSaturation);
        parcel.writeByte(this.remainingTime);
        parcel.writeByte(this.isComplete ? (byte) 1 : (byte) 0);
    }

    public int getTargetLightness() {
        return this.targetLightness;
    }

    public int getTargetHue() {
        return this.targetHue;
    }

    public int getTargetSaturation() {
        return this.targetSaturation;
    }

    public byte getRemainingTime() {
        return this.remainingTime;
    }

    public boolean isComplete() {
        return this.isComplete;
    }
}
