package com.telink.ble.mesh.core.message.firmwaredistribution;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class FDStartMessage extends UpdatingMessage {
    public int RFU;
    public int distributionAppKeyIndex;
    public int distributionImageIndex;
    public int distributionMulticastAddress;
    public int distributionTTL;
    public int distributionTimeoutBase;
    public int distributionTransferMode;
    public int updatePolicy;

    public FDStartMessage(int i, int i2) {
        super(i, i2);
        this.RFU = 0;
    }

    public static FDStartMessage getSimple(int i, int i2) {
        FDStartMessage fDStartMessage = new FDStartMessage(i, i2);
        fDStartMessage.setResponseMax(1);
        return fDStartMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FD_START.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FD_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(10).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.distributionAppKeyIndex).put((byte) this.distributionTTL).putShort((short) this.distributionTimeoutBase).put((byte) ((this.distributionTransferMode & 3) | ((this.updatePolicy & 1) << 2))).putShort((short) this.distributionImageIndex).putShort((short) this.distributionMulticastAddress).array();
    }
}
