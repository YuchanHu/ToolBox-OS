package com.telink.ble.mesh.core.message.fastpv;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;

/* loaded from: classes.dex */
public class MeshConfirmRequestMessage extends GenericMessage {
    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return null;
    }

    public static MeshConfirmRequestMessage getSimple(int i, int i2) {
        MeshConfirmRequestMessage meshConfirmRequestMessage = new MeshConfirmRequestMessage(i, i2);
        meshConfirmRequestMessage.setResponseMax(0);
        meshConfirmRequestMessage.setRetryCnt(1);
        return meshConfirmRequestMessage;
    }

    public MeshConfirmRequestMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.VD_MESH_PROV_CONFIRM.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.VD_MESH_PROV_CONFIRM_STS.value;
    }
}
