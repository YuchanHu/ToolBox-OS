package com.telink.ble.mesh.core.proxy;

/* loaded from: classes.dex */
public class ProxySetFilterTypeMessage extends ProxyConfigurationMessage {
    private byte filterType;

    @Override // com.telink.ble.mesh.core.proxy.ProxyConfigurationMessage
    public byte getOpcode() {
        return (byte) 0;
    }

    public ProxySetFilterTypeMessage(byte b) {
        this.filterType = b;
    }

    @Override // com.telink.ble.mesh.core.proxy.ProxyConfigurationMessage
    public byte[] toByteArray() {
        return new byte[]{getOpcode(), this.filterType};
    }
}
