package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ModelSubscriptionSetMessage extends ConfigMessage {
    public static final int MODE_ADD = 0;
    public static final int MODE_DELETE = 1;
    private static final int PARAM_LEN_SIG = 6;
    private static final int PARAM_LEN_VENDOR = 8;
    private int address;
    private int elementAddress;
    private boolean isSig;
    private int mode;
    private int modelIdentifier;

    public ModelSubscriptionSetMessage(int i) {
        super(i);
        this.mode = 0;
        this.isSig = true;
    }

    public static ModelSubscriptionSetMessage getSimple(int i, int i2, int i3, int i4, int i5, boolean z) {
        ModelSubscriptionSetMessage modelSubscriptionSetMessage = new ModelSubscriptionSetMessage(i);
        modelSubscriptionSetMessage.mode = i2;
        modelSubscriptionSetMessage.elementAddress = i3;
        modelSubscriptionSetMessage.address = i4;
        modelSubscriptionSetMessage.modelIdentifier = i5;
        modelSubscriptionSetMessage.isSig = z;
        return modelSubscriptionSetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.mode == 0 ? Opcode.CFG_MODEL_SUB_ADD : Opcode.CFG_MODEL_SUB_DEL).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_MODEL_SUB_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        if (this.isSig) {
            return ByteBuffer.allocate(6).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.elementAddress).putShort((short) this.address).putShort((short) this.modelIdentifier).array();
        }
        return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.elementAddress).putShort((short) this.address).putInt(this.modelIdentifier).array();
    }

    public void setMode(int i) {
        this.mode = i;
    }

    public void setElementAddress(int i) {
        this.elementAddress = i;
    }

    public void setAddress(int i) {
        this.address = i;
    }

    public void setModelIdentifier(int i) {
        this.modelIdentifier = i;
    }

    public void setSig(boolean z) {
        this.isSig = z;
    }
}
