package com.telink.ble.mesh.core.message.sarconfig;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.config.ConfigMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class SarReceiverSetMessage extends ConfigMessage {
    public int ackDelayIncrement;
    public int ackRetransCount;
    public int discardTimeout;
    public int receiverSegmentIntervalStep;
    public int rfu;
    public int segmentsThreshold;

    public SarReceiverSetMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.CFG_SAR_RECEIVER_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_SAR_RECEIVER_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).put((byte) (this.segmentsThreshold | (this.ackDelayIncrement << 5))).put((byte) ((this.receiverSegmentIntervalStep << 4) | this.discardTimeout)).put((byte) (this.ackRetransCount | (this.rfu << 2))).array();
    }
}
