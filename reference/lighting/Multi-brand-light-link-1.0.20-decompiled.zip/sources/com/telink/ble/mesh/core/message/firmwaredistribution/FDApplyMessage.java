package com.telink.ble.mesh.core.message.firmwaredistribution;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;

/* loaded from: classes.dex */
public class FDApplyMessage extends UpdatingMessage {
    public FDApplyMessage(int i, int i2) {
        super(i, i2);
    }

    public static FDApplyMessage getSimple(int i, int i2) {
        FDApplyMessage fDApplyMessage = new FDApplyMessage(i, i2);
        fDApplyMessage.setResponseMax(1);
        return fDApplyMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FD_APPLY.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FD_STATUS.value;
    }
}
