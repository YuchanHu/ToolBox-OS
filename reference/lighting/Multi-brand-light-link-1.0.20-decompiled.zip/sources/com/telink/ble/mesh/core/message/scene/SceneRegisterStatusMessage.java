package com.telink.ble.mesh.core.message.scene;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class SceneRegisterStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<SceneRegisterStatusMessage> CREATOR = new Parcelable.Creator<SceneRegisterStatusMessage>() { // from class: com.telink.ble.mesh.core.message.scene.SceneRegisterStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SceneRegisterStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SceneRegisterStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SceneRegisterStatusMessage createFromParcel(Parcel parcel) {
            return new SceneRegisterStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SceneRegisterStatusMessage[] newArray(int i) {
            return new SceneRegisterStatusMessage[i];
        }
    };
    private int currentScene;
    private int[] scenes;
    private byte statusCode;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public SceneRegisterStatusMessage() {
    }

    protected SceneRegisterStatusMessage(Parcel parcel) {
        this.statusCode = parcel.readByte();
        this.currentScene = parcel.readInt();
        this.scenes = parcel.createIntArray();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        int i = 0;
        this.statusCode = bArr[0];
        this.currentScene = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.LITTLE_ENDIAN);
        int i2 = 3;
        int length = bArr.length - 3;
        if (length <= 0 || length % 2 != 0) {
            return;
        }
        this.scenes = new int[length / 2];
        while (true) {
            int[] iArr = this.scenes;
            if (i >= iArr.length) {
                return;
            }
            iArr[i] = MeshUtils.bytes2Integer(bArr, i2, 2, ByteOrder.LITTLE_ENDIAN);
            i2 += 2;
            i++;
        }
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.statusCode);
        parcel.writeInt(this.currentScene);
        parcel.writeIntArray(this.scenes);
    }

    public byte getStatusCode() {
        return this.statusCode;
    }

    public int getCurrentScene() {
        return this.currentScene;
    }

    public int[] getScenes() {
        return this.scenes;
    }
}
