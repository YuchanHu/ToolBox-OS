package com.telink.ble.mesh.core.message.rp;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class LinkStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<LinkStatusMessage> CREATOR = new Parcelable.Creator<LinkStatusMessage>() { // from class: com.telink.ble.mesh.core.message.rp.LinkStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ LinkStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ LinkStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LinkStatusMessage createFromParcel(Parcel parcel) {
            return new LinkStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LinkStatusMessage[] newArray(int i) {
            return new LinkStatusMessage[i];
        }
    };
    private byte rpState;
    private byte status;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public LinkStatusMessage() {
    }

    protected LinkStatusMessage(Parcel parcel) {
        this.status = parcel.readByte();
        this.rpState = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.status = bArr[0];
        this.rpState = bArr[1];
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.status);
        parcel.writeByte(this.rpState);
    }

    public byte getRpState() {
        return this.rpState;
    }

    public byte getStatus() {
        return this.status;
    }

    public String toString() {
        return "LinkStatusMessage{status=" + ((int) this.status) + ", rpState=" + ((int) this.rpState) + '}';
    }
}
