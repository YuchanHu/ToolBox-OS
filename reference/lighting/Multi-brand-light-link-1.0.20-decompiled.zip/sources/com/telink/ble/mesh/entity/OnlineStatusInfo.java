package com.telink.ble.mesh.entity;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public class OnlineStatusInfo implements Parcelable {
    public static final Parcelable.Creator<OnlineStatusInfo> CREATOR = new Parcelable.Creator<OnlineStatusInfo>() { // from class: com.telink.ble.mesh.entity.OnlineStatusInfo.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ OnlineStatusInfo createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ OnlineStatusInfo[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public OnlineStatusInfo createFromParcel(Parcel parcel) {
            return new OnlineStatusInfo(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public OnlineStatusInfo[] newArray(int i) {
            return new OnlineStatusInfo[i];
        }
    };
    public int address;
    public byte sn;
    public byte[] status;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public OnlineStatusInfo() {
    }

    protected OnlineStatusInfo(Parcel parcel) {
        this.address = parcel.readInt();
        this.sn = parcel.readByte();
        this.status = parcel.createByteArray();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.address);
        parcel.writeByte(this.sn);
        parcel.writeByteArray(this.status);
    }
}
