package com.telink.ble.mesh.core.message.firmwaredistribution;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;

/* loaded from: classes.dex */
public class FDFirmwareDeleteMessage extends UpdatingMessage {
    public int firmwareID;

    public FDFirmwareDeleteMessage(int i, int i2) {
        super(i, i2);
    }

    public static FDFirmwareDeleteMessage getSimple(int i, int i2) {
        FDFirmwareDeleteMessage fDFirmwareDeleteMessage = new FDFirmwareDeleteMessage(i, i2);
        fDFirmwareDeleteMessage.setResponseMax(1);
        return fDFirmwareDeleteMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FD_FIRMWARE_DELETE.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FD_UPLOAD_STATUS.value;
    }
}
