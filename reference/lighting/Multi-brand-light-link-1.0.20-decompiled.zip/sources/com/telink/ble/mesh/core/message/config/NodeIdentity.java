package com.telink.ble.mesh.core.message.config;

/* loaded from: classes.dex */
public enum NodeIdentity {
    STOPPED((byte) 0, "Node Identity for a subnet is stopped"),
    RUNNING((byte) 1, "Node Identity for a subnet is running"),
    UNSUPPORTED((byte) 2, "Node Identity is not supported"),
    UNKNOWN_ERROR((byte) -1, "unknown error");

    public final byte code;
    public final String desc;

    NodeIdentity(byte b, String str) {
        this.code = b;
        this.desc = str;
    }

    public static NodeIdentity valueOf(int i) {
        for (NodeIdentity nodeIdentity : values()) {
            if (nodeIdentity.code == i) {
                return nodeIdentity;
            }
        }
        return UNKNOWN_ERROR;
    }
}
