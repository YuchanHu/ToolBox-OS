package com.telink.ble.mesh.core.access.fu;

/* loaded from: classes.dex */
public enum FUAction {
    INITIATE,
    DISTRIBUTE,
    DISTRIBUTE_ASSIST
}
