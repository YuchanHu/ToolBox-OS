package com.telink.ble.mesh.core.message.firmwaredistribution;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;

/* loaded from: classes.dex */
public class FDCapabilitiesGetMessage extends UpdatingMessage {
    public FDCapabilitiesGetMessage(int i, int i2) {
        super(i, i2);
    }

    public static FDCapabilitiesGetMessage getSimple(int i, int i2) {
        FDCapabilitiesGetMessage fDCapabilitiesGetMessage = new FDCapabilitiesGetMessage(i, i2);
        fDCapabilitiesGetMessage.setResponseMax(1);
        return fDCapabilitiesGetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FD_CAPABILITIES_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FD_CAPABILITIES_STATUS.value;
    }
}
