package com.telink.ble.mesh.core.provisioning.pdu;

/* loaded from: classes.dex */
public class ProvisioningRandomPDU implements ProvisioningStatePDU {
    public byte[] random;

    @Override // com.telink.ble.mesh.core.provisioning.pdu.ProvisioningStatePDU
    public byte getState() {
        return (byte) 6;
    }

    public ProvisioningRandomPDU(byte[] bArr) {
        this.random = bArr;
    }

    @Override // com.telink.ble.mesh.core.provisioning.pdu.PDU
    public byte[] toBytes() {
        return this.random;
    }
}
