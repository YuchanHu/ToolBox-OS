package com.telink.ble.mesh.core.message.directforwarding;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class DirectedControlStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<DirectedControlStatusMessage> CREATOR = new Parcelable.Creator<DirectedControlStatusMessage>() { // from class: com.telink.ble.mesh.core.message.directforwarding.DirectedControlStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ DirectedControlStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ DirectedControlStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public DirectedControlStatusMessage createFromParcel(Parcel parcel) {
            return new DirectedControlStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public DirectedControlStatusMessage[] newArray(int i) {
            return new DirectedControlStatusMessage[i];
        }
    };
    public byte directedForwarding;
    public byte directedFriend;
    public byte directedProxy;
    public byte directedProxyUseDirectedDefault;
    public byte directedRelay;
    public int netKeyIndex;
    public int status;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public DirectedControlStatusMessage() {
    }

    protected DirectedControlStatusMessage(Parcel parcel) {
        this.status = parcel.readInt();
        this.netKeyIndex = parcel.readInt();
        this.directedForwarding = parcel.readByte();
        this.directedRelay = parcel.readByte();
        this.directedProxy = parcel.readByte();
        this.directedProxyUseDirectedDefault = parcel.readByte();
        this.directedFriend = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.status = bArr[0];
        this.netKeyIndex = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.LITTLE_ENDIAN);
        this.directedForwarding = bArr[3];
        this.directedRelay = bArr[4];
        this.directedProxy = bArr[5];
        this.directedProxyUseDirectedDefault = bArr[6];
        this.directedFriend = bArr[7];
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.status);
        parcel.writeInt(this.netKeyIndex);
        parcel.writeByte(this.directedForwarding);
        parcel.writeByte(this.directedRelay);
        parcel.writeByte(this.directedProxy);
        parcel.writeByte(this.directedProxyUseDirectedDefault);
        parcel.writeByte(this.directedFriend);
    }

    public String toString() {
        return "DirectedControlStatusMessage{status=" + this.status + ", netKeyIndex=" + this.netKeyIndex + ", directedForwarding=" + ((int) this.directedForwarding) + ", directedRelay=" + ((int) this.directedRelay) + ", directedProxy=" + ((int) this.directedProxy) + ", directedProxyUseDirectedDefault=" + ((int) this.directedProxyUseDirectedDefault) + ", directedFriend=" + ((int) this.directedFriend) + '}';
    }
}
