package com.telink.ble.mesh.core.access.fu;

import java.io.Serializable;

/* loaded from: classes.dex */
public enum UpdatePolicy implements Serializable {
    VerifyOnly(0, "The Firmware Distribution Server verifies that firmware image distribution completed successfully but does not apply the update. The Initiator (the Firmware Distribution Client) initiates firmware image application"),
    VerifyAndApply(1, "The Firmware Distribution Server verifies that firmware image distribution completed successfully and then applies the firmware update");

    final String desc;
    final int value;

    UpdatePolicy(int i, String str) {
        this.value = i;
        this.desc = str;
    }
}
