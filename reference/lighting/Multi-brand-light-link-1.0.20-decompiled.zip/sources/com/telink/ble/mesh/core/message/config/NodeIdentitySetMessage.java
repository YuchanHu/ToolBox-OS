package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class NodeIdentitySetMessage extends ConfigMessage {
    public byte identity;
    public int netKeyIndex;

    public NodeIdentitySetMessage(int i) {
        super(i);
    }

    public static NodeIdentitySetMessage getSimple(int i, int i2, byte b) {
        NodeIdentitySetMessage nodeIdentitySetMessage = new NodeIdentitySetMessage(i);
        nodeIdentitySetMessage.netKeyIndex = i2;
        nodeIdentitySetMessage.identity = b;
        return nodeIdentitySetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.NODE_ID_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.NODE_ID_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(3).order(ByteOrder.LITTLE_ENDIAN).putShort((short) (this.netKeyIndex & 4095)).put(this.identity).array();
    }

    public void setNetKeyIndex(int i) {
        this.netKeyIndex = i;
    }

    public void setIdentity(byte b) {
        this.identity = b;
    }
}
