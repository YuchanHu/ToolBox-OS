package com.telink.ble.mesh.core.message.firmwaredistribution;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;

/* loaded from: classes.dex */
public class FDGetMessage extends UpdatingMessage {
    public FDGetMessage(int i, int i2) {
        super(i, i2);
    }

    public static FDGetMessage getSimple(int i, int i2) {
        FDGetMessage fDGetMessage = new FDGetMessage(i, i2);
        fDGetMessage.setResponseMax(1);
        return fDGetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FD_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FD_STATUS.value;
    }
}
