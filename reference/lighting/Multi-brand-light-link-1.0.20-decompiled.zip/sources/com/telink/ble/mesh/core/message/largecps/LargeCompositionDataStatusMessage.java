package com.telink.ble.mesh.core.message.largecps;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import com.telink.ble.mesh.entity.CompositionData;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class LargeCompositionDataStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<LargeCompositionDataStatusMessage> CREATOR = new Parcelable.Creator<LargeCompositionDataStatusMessage>() { // from class: com.telink.ble.mesh.core.message.largecps.LargeCompositionDataStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ LargeCompositionDataStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ LargeCompositionDataStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LargeCompositionDataStatusMessage createFromParcel(Parcel parcel) {
            return new LargeCompositionDataStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LargeCompositionDataStatusMessage[] newArray(int i) {
            return new LargeCompositionDataStatusMessage[i];
        }
    };
    private CompositionData compositionData;
    private int offset;
    private byte page;
    private int totalSize;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public LargeCompositionDataStatusMessage() {
    }

    protected LargeCompositionDataStatusMessage(Parcel parcel) {
        this.page = parcel.readByte();
        this.compositionData = (CompositionData) parcel.readParcelable(CompositionData.class.getClassLoader());
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.page = bArr[0];
        this.offset = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.LITTLE_ENDIAN);
        this.totalSize = MeshUtils.bytes2Integer(bArr, 3, 2, ByteOrder.LITTLE_ENDIAN);
        int length = bArr.length - 1;
        byte[] bArr2 = new byte[length];
        System.arraycopy(bArr, 5, bArr2, 0, length);
        this.compositionData = CompositionData.from(bArr2);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.page);
        parcel.writeParcelable(this.compositionData, i);
    }

    public byte getPage() {
        return this.page;
    }

    public CompositionData getCompositionData() {
        return this.compositionData;
    }

    public int getOffset() {
        return this.offset;
    }

    public int getTotalSize() {
        return this.totalSize;
    }
}
