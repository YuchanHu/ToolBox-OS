package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class BeaconSetMessage extends ConfigMessage {
    public byte beacon;

    public BeaconSetMessage(int i) {
        super(i);
    }

    public static BeaconSetMessage getSimple(int i, byte b) {
        BeaconSetMessage beaconSetMessage = new BeaconSetMessage(i);
        beaconSetMessage.beacon = b;
        return beaconSetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.CFG_BEACON_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_BEACON_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return new byte[]{this.beacon};
    }
}
