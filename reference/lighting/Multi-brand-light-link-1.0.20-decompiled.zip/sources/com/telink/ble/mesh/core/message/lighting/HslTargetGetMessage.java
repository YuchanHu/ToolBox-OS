package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class HslTargetGetMessage extends LightingMessage {
    public static HslTargetGetMessage getSimple(int i, int i2, int i3) {
        HslTargetGetMessage hslTargetGetMessage = new HslTargetGetMessage(i, i2);
        hslTargetGetMessage.setResponseMax(i3);
        return hslTargetGetMessage;
    }

    public HslTargetGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.LIGHT_HSL_TARGET_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.LIGHT_HSL_TARGET_STATUS.value;
    }
}
