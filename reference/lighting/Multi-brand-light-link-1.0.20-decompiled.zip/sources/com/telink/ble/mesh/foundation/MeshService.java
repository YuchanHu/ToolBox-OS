package com.telink.ble.mesh.foundation;

import android.content.Context;
import com.telink.ble.mesh.core.ble.GattRequest;
import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.networking.ExtendBearerMode;
import com.telink.ble.mesh.entity.RemoteProvisioningDevice;
import com.telink.ble.mesh.foundation.MeshController;
import com.telink.ble.mesh.foundation.parameter.AutoConnectParameters;
import com.telink.ble.mesh.foundation.parameter.BindingParameters;
import com.telink.ble.mesh.foundation.parameter.FastProvisioningParameters;
import com.telink.ble.mesh.foundation.parameter.GattConnectionParameters;
import com.telink.ble.mesh.foundation.parameter.GattOtaParameters;
import com.telink.ble.mesh.foundation.parameter.MeshOtaParameters;
import com.telink.ble.mesh.foundation.parameter.ProvisioningParameters;
import com.telink.ble.mesh.foundation.parameter.ScanParameters;
import com.telink.ble.mesh.util.MeshLogger;
import java.security.Security;
import org.spongycastle.jce.provider.BouncyCastleProvider;

/* loaded from: classes.dex */
public class MeshService implements MeshController.EventCallback {
    private static MeshService mThis;
    private MeshController mController;
    private EventHandler mEventHandler;

    static {
        Security.insertProviderAt(new BouncyCastleProvider(), 1);
        mThis = new MeshService();
    }

    public static MeshService getInstance() {
        return mThis;
    }

    public void init(Context context, EventHandler eventHandler) {
        init(context, eventHandler, false);
    }

    public void init(Context context, EventHandler eventHandler, boolean z) {
        MeshLogger.log("MeshService#init");
        if (this.mController == null) {
            this.mController = new MeshController();
        }
        this.mController.setEventCallback(this);
        this.mController.start(context, z);
        this.mEventHandler = eventHandler;
    }

    public void clear() {
        MeshLogger.log("MeshService#clear");
        MeshController meshController = this.mController;
        if (meshController != null) {
            meshController.stop();
        }
    }

    public void clearNetworkCache() {
        MeshLogger.log("MeshService#clearNetworkCache");
        MeshController meshController = this.mController;
        if (meshController != null) {
            meshController.clearNetworkCache();
        }
    }

    public void setupMeshNetwork(MeshConfiguration meshConfiguration) {
        this.mController.setupMeshNetwork(meshConfiguration);
    }

    public void checkBluetoothState() {
        this.mController.checkBluetoothState();
    }

    public boolean isProxyLogin() {
        return this.mController.isProxyLogin();
    }

    public int getDirectConnectedNodeAddress() {
        return this.mController.getDirectNodeAddress();
    }

    public void removeDevice(int i) {
        this.mController.removeDevice(i);
    }

    public MeshController.Mode getCurrentMode() {
        return this.mController.getMode();
    }

    public void startScan(ScanParameters scanParameters) {
        this.mController.startScan(scanParameters);
    }

    public void stopScan() {
        this.mController.stopScan();
    }

    public boolean startProvisioning(ProvisioningParameters provisioningParameters) {
        return this.mController.startProvisioning(provisioningParameters);
    }

    public boolean continueProvision(int i) {
        return this.mController.continueProvision(i);
    }

    public void startBinding(BindingParameters bindingParameters) {
        this.mController.startBinding(bindingParameters);
    }

    public void autoConnect(AutoConnectParameters autoConnectParameters) {
        this.mController.autoConnect(autoConnectParameters);
    }

    public void startGattOta(GattOtaParameters gattOtaParameters) {
        this.mController.startGattOta(gattOtaParameters);
    }

    public void startMeshOta(MeshOtaParameters meshOtaParameters) {
        this.mController.startMeshOTA(meshOtaParameters);
    }

    public void stopMeshOta() {
        this.mController.stopMeshOta();
    }

    public void startRemoteProvisioning(RemoteProvisioningDevice remoteProvisioningDevice) {
        this.mController.startRemoteProvision(remoteProvisioningDevice);
    }

    public boolean continueRemoteProvision(int i) {
        return this.mController.continueRemoteProvision(i);
    }

    public void startFastProvision(FastProvisioningParameters fastProvisioningParameters) {
        this.mController.startFastProvision(fastProvisioningParameters);
    }

    public void idle(boolean z) {
        this.mController.idle(z);
    }

    public void disconnect() {
        this.mController.disconnect();
    }

    public void startGattConnection(GattConnectionParameters gattConnectionParameters) {
        this.mController.startGattConnection(gattConnectionParameters);
    }

    public boolean sendGattRequest(GattRequest gattRequest) {
        return this.mController.sendGattRequest(gattRequest);
    }

    public int getMtu() {
        return this.mController.getMtu();
    }

    public boolean sendMeshMessage(MeshMessage meshMessage) {
        if (meshMessage == null) {
            return false;
        }
        return this.mController.sendMeshMessage(meshMessage);
    }

    public boolean getOnlineStatus() {
        return this.mController.getOnlineStatus();
    }

    public void resetExtendBearerMode(ExtendBearerMode extendBearerMode) {
        this.mController.resetExtendBearerMode(extendBearerMode);
    }

    public boolean isBluetoothEnabled() {
        return this.mController.isBluetoothEnabled();
    }

    public void enableBluetooth() {
        this.mController.enableBluetooth();
    }

    public String getCurDeviceMac() {
        return this.mController.getCurDeviceMac();
    }

    @Override // com.telink.ble.mesh.foundation.MeshController.EventCallback
    public void onEventPrepared(Event<String> event) {
        EventHandler eventHandler = this.mEventHandler;
        if (eventHandler != null) {
            eventHandler.onEventHandle(event);
        }
    }
}
