package com.telink.ble.mesh.entity;

import android.os.Parcel;
import android.os.Parcelable;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
public class Element implements Serializable, Parcelable {
    public static final Parcelable.Creator<Element> CREATOR = new Parcelable.Creator<Element>() { // from class: com.telink.ble.mesh.entity.Element.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ Element createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ Element[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public Element createFromParcel(Parcel parcel) {
            return new Element(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public Element[] newArray(int i) {
            return new Element[i];
        }
    };
    public int location;
    public boolean selected;
    public List<Integer> sigModels;
    public int sigNum;
    public List<Integer> vendorModels;
    public int vendorNum;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public Element() {
    }

    protected Element(Parcel parcel) {
        this.location = parcel.readInt();
        this.sigNum = parcel.readInt();
        this.vendorNum = parcel.readInt();
    }

    public boolean containModel(int i) {
        List<Integer> list = this.sigModels;
        if (list != null && list.size() != 0) {
            Iterator<Integer> it = this.sigModels.iterator();
            while (it.hasNext()) {
                if (i == it.next().intValue()) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.location);
        parcel.writeInt(this.sigNum);
        parcel.writeInt(this.vendorNum);
    }
}
