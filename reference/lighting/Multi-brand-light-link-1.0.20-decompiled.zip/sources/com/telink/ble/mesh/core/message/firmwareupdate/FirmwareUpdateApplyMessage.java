package com.telink.ble.mesh.core.message.firmwareupdate;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class FirmwareUpdateApplyMessage extends UpdatingMessage {
    public static FirmwareUpdateApplyMessage getSimple(int i, int i2) {
        FirmwareUpdateApplyMessage firmwareUpdateApplyMessage = new FirmwareUpdateApplyMessage(i, i2);
        firmwareUpdateApplyMessage.setResponseMax(1);
        return firmwareUpdateApplyMessage;
    }

    public FirmwareUpdateApplyMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FIRMWARE_UPDATE_APPLY.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FIRMWARE_UPDATE_STATUS.value;
    }
}
