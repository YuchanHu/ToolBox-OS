package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ModelSubscriptionStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<ModelSubscriptionStatusMessage> CREATOR = new Parcelable.Creator<ModelSubscriptionStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.ModelSubscriptionStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ModelSubscriptionStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ModelSubscriptionStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ModelSubscriptionStatusMessage createFromParcel(Parcel parcel) {
            return new ModelSubscriptionStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ModelSubscriptionStatusMessage[] newArray(int i) {
            return new ModelSubscriptionStatusMessage[i];
        }
    };
    private static final int DATA_LEN_SIG = 7;
    private static final int DATA_LEN_VENDOR = 9;
    private int address;
    private int elementAddress;
    private boolean isSig;
    private int modelIdentifier;
    private byte status;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public ModelSubscriptionStatusMessage() {
        this.isSig = true;
    }

    protected ModelSubscriptionStatusMessage(Parcel parcel) {
        this.isSig = true;
        this.status = parcel.readByte();
        this.elementAddress = parcel.readInt();
        this.address = parcel.readInt();
        this.modelIdentifier = parcel.readInt();
        this.isSig = parcel.readByte() != 0;
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.isSig = bArr.length == 7;
        this.status = bArr[0];
        this.elementAddress = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.LITTLE_ENDIAN);
        this.address = MeshUtils.bytes2Integer(bArr, 3, 2, ByteOrder.LITTLE_ENDIAN);
        this.modelIdentifier = MeshUtils.bytes2Integer(bArr, 5, this.isSig ? 2 : 4, ByteOrder.LITTLE_ENDIAN);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.status);
        parcel.writeInt(this.elementAddress);
        parcel.writeInt(this.address);
        parcel.writeInt(this.modelIdentifier);
        parcel.writeByte(this.isSig ? (byte) 1 : (byte) 0);
    }

    public byte getStatus() {
        return this.status;
    }

    public int getElementAddress() {
        return this.elementAddress;
    }

    public int getAddress() {
        return this.address;
    }

    public int getModelIdentifier() {
        return this.modelIdentifier;
    }

    public boolean isSig() {
        return this.isSig;
    }

    public String toString() {
        return "ModelSubscriptionStatusMessage{status=" + ((int) this.status) + ", elementAddress=" + this.elementAddress + ", address=" + this.address + ", modelIdentifier=" + this.modelIdentifier + ", isSig=" + this.isSig + '}';
    }
}
