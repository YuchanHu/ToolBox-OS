package com.telink.ble.mesh.entity;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.Arrays;

/* loaded from: classes.dex */
public class RemoteProvisioningDevice extends ProvisioningDevice {
    public static final Parcelable.Creator<RemoteProvisioningDevice> CREATOR = new Parcelable.Creator<RemoteProvisioningDevice>() { // from class: com.telink.ble.mesh.entity.RemoteProvisioningDevice.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ RemoteProvisioningDevice createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ RemoteProvisioningDevice[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public RemoteProvisioningDevice createFromParcel(Parcel parcel) {
            return new RemoteProvisioningDevice(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public RemoteProvisioningDevice[] newArray(int i) {
            return new RemoteProvisioningDevice[i];
        }
    };
    private byte rssi;
    private int serverAddress;
    private byte[] uuid;

    @Override // com.telink.ble.mesh.entity.ProvisioningDevice, android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public RemoteProvisioningDevice(byte b, byte[] bArr, int i) {
        this.rssi = b;
        this.uuid = bArr;
        this.serverAddress = i;
    }

    protected RemoteProvisioningDevice(Parcel parcel) {
        super(parcel);
        this.uuid = null;
        this.rssi = parcel.readByte();
        this.uuid = parcel.createByteArray();
        this.serverAddress = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.entity.ProvisioningDevice, android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeByte(this.rssi);
        parcel.writeByteArray(this.uuid);
        parcel.writeInt(this.serverAddress);
    }

    public byte getRssi() {
        return this.rssi;
    }

    public byte[] getUuid() {
        return this.uuid;
    }

    public int getServerAddress() {
        return this.serverAddress;
    }

    public void setRssi(byte b) {
        this.rssi = b;
    }

    public void setUuid(byte[] bArr) {
        this.uuid = bArr;
    }

    public void setServerAddress(int i) {
        this.serverAddress = i;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Arrays.equals(this.uuid, ((RemoteProvisioningDevice) obj).uuid);
    }

    public int hashCode() {
        return Arrays.hashCode(this.uuid);
    }
}
