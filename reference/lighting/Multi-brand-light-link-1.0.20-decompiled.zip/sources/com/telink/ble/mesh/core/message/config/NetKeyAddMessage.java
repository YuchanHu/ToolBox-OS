package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class NetKeyAddMessage extends ConfigMessage {
    public byte[] netKey;
    public int netKeyIndex;

    public NetKeyAddMessage(int i) {
        super(i);
    }

    public NetKeyAddMessage(int i, int i2, byte[] bArr) {
        super(i);
        this.netKeyIndex = i2;
        this.netKey = bArr;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.NETKEY_ADD.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.NETKEY_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(18).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.netKeyIndex).put(this.netKey).array();
    }
}
