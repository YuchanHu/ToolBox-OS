package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class NodeResetStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<NodeResetStatusMessage> CREATOR = new Parcelable.Creator<NodeResetStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.NodeResetStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ NodeResetStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ NodeResetStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public NodeResetStatusMessage createFromParcel(Parcel parcel) {
            return new NodeResetStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public NodeResetStatusMessage[] newArray(int i) {
            return new NodeResetStatusMessage[i];
        }
    };

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
    }

    public NodeResetStatusMessage() {
    }

    protected NodeResetStatusMessage(Parcel parcel) {
    }
}
