package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class FriendSetMessage extends ConfigMessage {
    public byte friend;

    public FriendSetMessage(int i) {
        super(i);
    }

    public static FriendSetMessage getSimple(int i, byte b) {
        FriendSetMessage friendSetMessage = new FriendSetMessage(i);
        friendSetMessage.friend = b;
        return friendSetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.CFG_FRIEND_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_FRIEND_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return new byte[]{this.friend};
    }
}
