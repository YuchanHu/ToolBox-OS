package com.telink.ble.mesh.core.message.generic;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class OnOffStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<OnOffStatusMessage> CREATOR = new Parcelable.Creator<OnOffStatusMessage>() { // from class: com.telink.ble.mesh.core.message.generic.OnOffStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ OnOffStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ OnOffStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public OnOffStatusMessage createFromParcel(Parcel parcel) {
            return new OnOffStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public OnOffStatusMessage[] newArray(int i) {
            return new OnOffStatusMessage[i];
        }
    };
    private static final int DATA_LEN_COMPLETE = 3;
    private boolean isComplete;
    private byte presentOnOff;
    private byte remainingTime;
    private byte targetOnOff;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public OnOffStatusMessage() {
        this.isComplete = false;
    }

    protected OnOffStatusMessage(Parcel parcel) {
        this.isComplete = false;
        this.presentOnOff = parcel.readByte();
        this.targetOnOff = parcel.readByte();
        this.remainingTime = parcel.readByte();
        this.isComplete = parcel.readByte() != 0;
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.presentOnOff = bArr[0];
        if (bArr.length >= 3) {
            this.isComplete = true;
            this.targetOnOff = bArr[1];
            this.remainingTime = bArr[2];
        }
    }

    public byte getPresentOnOff() {
        return this.presentOnOff;
    }

    public byte getTargetOnOff() {
        return this.targetOnOff;
    }

    public byte getRemainingTime() {
        return this.remainingTime;
    }

    public boolean isComplete() {
        return this.isComplete;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.presentOnOff);
        parcel.writeByte(this.targetOnOff);
        parcel.writeByte(this.remainingTime);
        parcel.writeByte(this.isComplete ? (byte) 1 : (byte) 0);
    }
}
