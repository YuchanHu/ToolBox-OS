package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class LcOmGetMessage extends LightingMessage {
    public static LcOmGetMessage getSimple(int i, int i2, int i3) {
        LcOmGetMessage lcOmGetMessage = new LcOmGetMessage(i, i2);
        lcOmGetMessage.setResponseMax(i3);
        return lcOmGetMessage;
    }

    public LcOmGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.LIGHT_LC_OM_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.LIGHT_LC_OM_STATUS.value;
    }
}
