package com.telink.ble.mesh.core.ble;

import java.util.UUID;

/* loaded from: classes.dex */
public class LeScanFilter {
    public UUID[] uuidInclude = null;
    public String[] macInclude = null;
    public String[] macExclude = null;
    public String[] nameInclude = null;
}
