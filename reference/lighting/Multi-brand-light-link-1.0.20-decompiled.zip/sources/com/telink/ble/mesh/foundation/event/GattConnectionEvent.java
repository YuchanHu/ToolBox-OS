package com.telink.ble.mesh.foundation.event;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.foundation.Event;

/* loaded from: classes.dex */
public class GattConnectionEvent extends Event<String> {
    public static final Parcelable.Creator<GattConnectionEvent> CREATOR = new Parcelable.Creator<GattConnectionEvent>() { // from class: com.telink.ble.mesh.foundation.event.GattConnectionEvent.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ GattConnectionEvent createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ GattConnectionEvent[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public GattConnectionEvent createFromParcel(Parcel parcel) {
            return new GattConnectionEvent(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public GattConnectionEvent[] newArray(int i) {
            return new GattConnectionEvent[i];
        }
    };
    public static final String EVENT_TYPE_CONNECT_FAIL = "com.telink.sig.mesh.CONNECT_FAIL";
    public static final String EVENT_TYPE_CONNECT_SUCCESS = "com.telink.sig.mesh.CONNECT_SUCCESS";
    private String desc;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public GattConnectionEvent(Object obj, String str, String str2) {
        super(obj, str);
        this.desc = str2;
    }

    protected GattConnectionEvent(Parcel parcel) {
        this.desc = parcel.readString();
    }

    public String getDesc() {
        return this.desc;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.desc);
    }
}
