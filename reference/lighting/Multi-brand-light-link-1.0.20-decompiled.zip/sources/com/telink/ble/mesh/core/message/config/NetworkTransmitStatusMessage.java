package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class NetworkTransmitStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<NetworkTransmitStatusMessage> CREATOR = new Parcelable.Creator<NetworkTransmitStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.NetworkTransmitStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ NetworkTransmitStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ NetworkTransmitStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public NetworkTransmitStatusMessage createFromParcel(Parcel parcel) {
            return new NetworkTransmitStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public NetworkTransmitStatusMessage[] newArray(int i) {
            return new NetworkTransmitStatusMessage[i];
        }
    };
    public int count;
    public int intervalSteps;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public NetworkTransmitStatusMessage() {
    }

    protected NetworkTransmitStatusMessage(Parcel parcel) {
        this.count = parcel.readInt();
        this.intervalSteps = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        byte b = bArr[0];
        this.count = b & 7;
        this.intervalSteps = (b & FUDistributor.UPDATE_TTL) >> 3;
    }

    public int getCount() {
        return this.count;
    }

    public int getIntervalSteps() {
        return this.intervalSteps;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.count);
        parcel.writeInt(this.intervalSteps);
    }
}
