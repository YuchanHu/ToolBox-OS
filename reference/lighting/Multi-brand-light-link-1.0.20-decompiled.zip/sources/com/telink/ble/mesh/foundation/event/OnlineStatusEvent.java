package com.telink.ble.mesh.foundation.event;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.entity.OnlineStatusInfo;
import com.telink.ble.mesh.foundation.Event;
import java.util.List;

/* loaded from: classes.dex */
public class OnlineStatusEvent extends Event<String> implements Parcelable {
    public static final Parcelable.Creator<OnlineStatusEvent> CREATOR = new Parcelable.Creator<OnlineStatusEvent>() { // from class: com.telink.ble.mesh.foundation.event.OnlineStatusEvent.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ OnlineStatusEvent createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ OnlineStatusEvent[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public OnlineStatusEvent createFromParcel(Parcel parcel) {
            return new OnlineStatusEvent(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public OnlineStatusEvent[] newArray(int i) {
            return new OnlineStatusEvent[i];
        }
    };
    public static final String EVENT_TYPE_ONLINE_STATUS_NOTIFY = "com.telink.ble.mesh.EVENT_TYPE_ONLINE_STATUS_NOTIFY";
    private List<OnlineStatusInfo> onlineStatusInfoList;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public OnlineStatusEvent(Object obj, byte[] bArr) {
        this(obj, EVENT_TYPE_ONLINE_STATUS_NOTIFY);
        this.onlineStatusInfoList = parseOnlineStatusData(bArr);
    }

    protected OnlineStatusEvent(Parcel parcel) {
        this.onlineStatusInfoList = parcel.createTypedArrayList(OnlineStatusInfo.CREATOR);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: SimplifyVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v3 int, still in use, count: 1, list:
          (r4v3 int) from 0x0021: ARITH (r2v1 int) + (r4v3 int) A[WRAPPED]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.unbindArgUsage(InsnRemover.java:174)
        	at jadx.core.utils.InsnRemover.unbindAllArgs(InsnRemover.java:106)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:90)
        	at jadx.core.utils.InsnRemover.unbindArgUsage(InsnRemover.java:174)
        	at jadx.core.dex.instructions.args.InsnArg.wrapInstruction(InsnArg.java:141)
        	at jadx.core.dex.visitors.SimplifyVisitor.simplifyArgs(SimplifyVisitor.java:116)
        	at jadx.core.dex.visitors.SimplifyVisitor.simplifyInsn(SimplifyVisitor.java:132)
        	at jadx.core.dex.visitors.SimplifyVisitor.simplifyBlock(SimplifyVisitor.java:86)
        	at jadx.core.dex.visitors.SimplifyVisitor.visit(SimplifyVisitor.java:71)
        */
    private java.util.List<com.telink.ble.mesh.entity.OnlineStatusInfo> parseOnlineStatusData(byte[] r11) {
        /*
            r10 = this;
            r0 = 0
            if (r11 == 0) goto L57
            int r1 = r11.length
            r2 = 4
            if (r1 >= r2) goto L8
            goto L57
        L8:
            int r1 = r11.length
            r3 = 0
            r4 = r11[r3]
            r5 = 98
            if (r4 == r5) goto L11
            return r0
        L11:
            r4 = 1
            r4 = r11[r4]
            r4 = r4 & 15
            int r5 = r4 + (-3)
            if (r5 > 0) goto L1b
            return r0
        L1b:
            r6 = 2
            r6 = r11[r6]
            r6 = 3
            r6 = r11[r6]
        L21:
            int r6 = r2 + r4
            if (r6 > r1) goto L57
            int r6 = r2 + 1
            r7 = r11[r2]
            r7 = r7 & 255(0xff, float:3.57E-43)
            int r8 = r2 + 2
            r6 = r11[r6]
            r6 = r6 & 127(0x7f, float:1.78E-43)
            int r6 = r6 << 8
            r6 = r6 | r7
            int r2 = r2 + 3
            r7 = r11[r8]
            byte[] r8 = new byte[r5]
            java.lang.System.arraycopy(r11, r2, r8, r3, r5)
            int r2 = r2 + r5
            if (r6 != 0) goto L41
            goto L57
        L41:
            com.telink.ble.mesh.entity.OnlineStatusInfo r9 = new com.telink.ble.mesh.entity.OnlineStatusInfo
            r9.<init>()
            r9.address = r6
            r9.sn = r7
            r9.status = r8
            if (r0 != 0) goto L53
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
        L53:
            r0.add(r9)
            goto L21
        L57:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.telink.ble.mesh.foundation.event.OnlineStatusEvent.parseOnlineStatusData(byte[]):java.util.List");
    }

    public OnlineStatusEvent(Object obj, String str) {
        super(obj, str);
    }

    public List<OnlineStatusInfo> getOnlineStatusInfoList() {
        return this.onlineStatusInfoList;
    }

    public void setOnlineStatusInfoList(List<OnlineStatusInfo> list) {
        this.onlineStatusInfoList = list;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedList(this.onlineStatusInfoList);
    }
}
