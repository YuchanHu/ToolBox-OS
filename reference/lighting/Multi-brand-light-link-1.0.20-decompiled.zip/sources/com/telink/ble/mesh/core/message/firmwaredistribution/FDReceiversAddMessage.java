package com.telink.ble.mesh.core.message.firmwaredistribution;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;

/* loaded from: classes.dex */
public class FDReceiversAddMessage extends UpdatingMessage {
    public List<ReceiverEntry> entries;

    public FDReceiversAddMessage(int i, int i2) {
        super(i, i2);
    }

    public static FDReceiversAddMessage getSimple(int i, int i2, List<ReceiverEntry> list) {
        FDReceiversAddMessage fDReceiversAddMessage = new FDReceiversAddMessage(i, i2);
        fDReceiversAddMessage.entries = list;
        fDReceiversAddMessage.setResponseMax(1);
        return fDReceiversAddMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FD_RECEIVERS_ADD.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FD_RECEIVERS_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        List<ReceiverEntry> list = this.entries;
        if (list == null || list.size() == 0) {
            return null;
        }
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(this.entries.size() * 3).order(ByteOrder.LITTLE_ENDIAN);
        for (ReceiverEntry receiverEntry : this.entries) {
            byteBufferOrder.putShort((short) receiverEntry.address).put((byte) receiverEntry.imageIndex);
        }
        return byteBufferOrder.array();
    }

    public static class ReceiverEntry {
        public int address;
        public int imageIndex;

        public ReceiverEntry(int i, int i2) {
            this.address = i;
            this.imageIndex = i2;
        }
    }
}
