package com.telink.ble.mesh.core.message.sarconfig;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class SarReceiverStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<SarReceiverStatusMessage> CREATOR = new Parcelable.Creator<SarReceiverStatusMessage>() { // from class: com.telink.ble.mesh.core.message.sarconfig.SarReceiverStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SarReceiverStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SarReceiverStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SarReceiverStatusMessage createFromParcel(Parcel parcel) {
            return new SarReceiverStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SarReceiverStatusMessage[] newArray(int i) {
            return new SarReceiverStatusMessage[i];
        }
    };
    public int ackDelayIncrement;
    public int ackRetransCount;
    public int discardTimeout;
    public int receiverSegmentIntervalStep;
    public int rfu;
    public int segmentsThreshold;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public SarReceiverStatusMessage() {
    }

    protected SarReceiverStatusMessage(Parcel parcel) {
        this.segmentsThreshold = parcel.readInt();
        this.ackDelayIncrement = parcel.readInt();
        this.discardTimeout = parcel.readInt();
        this.receiverSegmentIntervalStep = parcel.readInt();
        this.ackRetransCount = parcel.readInt();
        this.rfu = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        byte b = bArr[0];
        this.segmentsThreshold = b & FUDistributor.UPDATE_TTL;
        this.ackDelayIncrement = (b & FUDistributor.UPDATE_TTL) >> 5;
        byte b2 = bArr[1];
        this.discardTimeout = b2 & FUDistributor.UPDATE_TTL;
        this.receiverSegmentIntervalStep = (b2 & FUDistributor.UPDATE_TTL) >> 4;
        byte b3 = bArr[2];
        this.ackRetransCount = b3 & FUDistributor.UPDATE_TTL;
        this.rfu = (b3 & FUDistributor.UPDATE_TTL) >> 2;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.segmentsThreshold);
        parcel.writeInt(this.ackDelayIncrement);
        parcel.writeInt(this.discardTimeout);
        parcel.writeInt(this.receiverSegmentIntervalStep);
        parcel.writeInt(this.ackRetransCount);
        parcel.writeInt(this.rfu);
    }
}
