package com.telink.ble.mesh.core.message.rp;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ScanReportStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<ScanReportStatusMessage> CREATOR = new Parcelable.Creator<ScanReportStatusMessage>() { // from class: com.telink.ble.mesh.core.message.rp.ScanReportStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ScanReportStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ScanReportStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ScanReportStatusMessage createFromParcel(Parcel parcel) {
            return new ScanReportStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ScanReportStatusMessage[] newArray(int i) {
            return new ScanReportStatusMessage[i];
        }
    };
    private int oob;
    private byte rssi;
    private byte[] uuid;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public ScanReportStatusMessage() {
    }

    protected ScanReportStatusMessage(Parcel parcel) {
        this.rssi = parcel.readByte();
        this.uuid = parcel.createByteArray();
        this.oob = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.rssi = bArr[0];
        byte[] bArr2 = new byte[16];
        this.uuid = bArr2;
        System.arraycopy(bArr, 1, bArr2, 0, bArr2.length);
        this.oob = MeshUtils.bytes2Integer(bArr, 1 + this.uuid.length, 2, ByteOrder.LITTLE_ENDIAN);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.rssi);
        parcel.writeByteArray(this.uuid);
        parcel.writeInt(this.oob);
    }

    public byte getRssi() {
        return this.rssi;
    }

    public byte[] getUuid() {
        return this.uuid;
    }

    public int getOob() {
        return this.oob;
    }
}
