package com.telink.ble.mesh.core.message.directforwarding;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ForwardingTableStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<ForwardingTableStatusMessage> CREATOR = new Parcelable.Creator<ForwardingTableStatusMessage>() { // from class: com.telink.ble.mesh.core.message.directforwarding.ForwardingTableStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ForwardingTableStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ForwardingTableStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ForwardingTableStatusMessage createFromParcel(Parcel parcel) {
            return new ForwardingTableStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ForwardingTableStatusMessage[] newArray(int i) {
            return new ForwardingTableStatusMessage[i];
        }
    };
    public int destination;
    public int netKeyIndex;
    public int pathOrigin;
    public int status;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public ForwardingTableStatusMessage() {
    }

    protected ForwardingTableStatusMessage(Parcel parcel) {
        this.status = parcel.readInt();
        this.netKeyIndex = parcel.readInt();
        this.pathOrigin = parcel.readInt();
        this.destination = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.status = bArr[0];
        this.netKeyIndex = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.LITTLE_ENDIAN);
        this.pathOrigin = MeshUtils.bytes2Integer(bArr, 3, 2, ByteOrder.LITTLE_ENDIAN);
        this.destination = MeshUtils.bytes2Integer(bArr, 5, 2, ByteOrder.LITTLE_ENDIAN);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.status);
        parcel.writeInt(this.netKeyIndex);
        parcel.writeInt(this.pathOrigin);
        parcel.writeInt(this.destination);
    }

    public String toString() {
        return "ForwardingTableStatusMessage{status=" + this.status + ", netKeyIndex=" + this.netKeyIndex + ", pathOrigin=" + this.pathOrigin + ", destination=" + this.destination + '}';
    }
}
