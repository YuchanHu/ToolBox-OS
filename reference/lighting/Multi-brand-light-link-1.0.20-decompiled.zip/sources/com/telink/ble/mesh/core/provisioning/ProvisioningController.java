package com.telink.ble.mesh.core.provisioning;

import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.SparseArray;
import com.telink.ble.mesh.core.Encipher;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.provisioning.pdu.ProvisioningCapabilityPDU;
import com.telink.ble.mesh.core.provisioning.pdu.ProvisioningConfirmPDU;
import com.telink.ble.mesh.core.provisioning.pdu.ProvisioningDataPDU;
import com.telink.ble.mesh.core.provisioning.pdu.ProvisioningInvitePDU;
import com.telink.ble.mesh.core.provisioning.pdu.ProvisioningPubKeyPDU;
import com.telink.ble.mesh.core.provisioning.pdu.ProvisioningRandomPDU;
import com.telink.ble.mesh.core.provisioning.pdu.ProvisioningRecordRequestPDU;
import com.telink.ble.mesh.core.provisioning.pdu.ProvisioningRecordResponsePDU;
import com.telink.ble.mesh.core.provisioning.pdu.ProvisioningRecordsGetPDU;
import com.telink.ble.mesh.core.provisioning.pdu.ProvisioningRecordsListPDU;
import com.telink.ble.mesh.core.provisioning.pdu.ProvisioningStartPDU;
import com.telink.ble.mesh.core.provisioning.pdu.ProvisioningStatePDU;
import com.telink.ble.mesh.entity.ProvisioningDevice;
import com.telink.ble.mesh.util.Arrays;
import com.telink.ble.mesh.util.MeshLogger;
import java.nio.ByteBuffer;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import org.spongycastle.crypto.DataLengthException;
import org.spongycastle.jcajce.provider.asymmetric.ec.BCECPublicKey;

/* loaded from: classes.dex */
public class ProvisioningController {
    private static final int MAX_FRAGMENT_SIZE = 20;
    private static final int RECORD_ID_DEVICE = 1;
    private static final int RECORD_ID_INTERMEDIATE = 2;
    private static final int RECORD_ID_URI = 0;
    public static final int STATE_CAPABILITY = 4098;
    public static final int STATE_COMPLETE = 4107;
    public static final int STATE_CONFIRM_RECEIVED = 4103;
    public static final int STATE_CONFIRM_SENT = 4102;
    public static final int STATE_DATA = 4106;
    public static final int STATE_FAILED = 4108;
    public static final int STATE_IDLE = 4096;
    public static final int STATE_INVITE = 4097;
    public static final int STATE_PUB_KEY_RECEIVED = 4101;
    public static final int STATE_PUB_KEY_SENT = 4100;
    public static final int STATE_RANDOM_RECEIVED = 4105;
    public static final int STATE_RANDOM_SENT = 4104;
    public static final int STATE_RECORDS_GET = 16;
    public static final int STATE_RECORD_REQUEST = 17;
    public static final int STATE_START = 4099;
    private static final long TIMEOUT_PROVISIONING = 60000;
    private Handler delayHandler;
    private byte[] deviceConfirm;
    private byte[] deviceECDHSecret;
    private ProvisioningPubKeyPDU devicePubKeyPDU;
    private byte[] deviceRandom;
    private ProvisioningInvitePDU invitePDU;
    private ProvisioningBridge mProvisioningBridge;
    private ProvisioningDevice mProvisioningDevice;
    private byte[] provisionerConfirm;
    private KeyPair provisionerKeyPair;
    private ProvisioningPubKeyPDU provisionerPubKeyPDU;
    private byte[] provisionerRandom;
    private ProvisioningCapabilityPDU pvCapability;
    private byte[] recordData;
    private byte[] recordPubKey;
    private ProvisioningRecordsListPDU recordsListPDU;
    private ProvisioningStartPDU startPDU;
    private static final byte[] AUTH_NO_OOB = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    private static final byte[] AUTH_NO_OOB_EPA = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    public static final byte[] ROOT_CERT_IN_PTS = Arrays.hexToBytes("308202873082022EA003020102020101300A06082A8648CE3D04030230819D310B30090603550406130255533113301106035504080C0A57617368696E67746F6E31163014060355040A0C0D426C7565746F6F746820534947310C300A060355040B0C03505453312D302B06035504030C2430303142444330382D313032312D304230452D304130432D3030304230453041304330303124302206092A864886F70D0109011615737570706F727440626C7565746F6F74682E636F6D301E170D3139303731383138353533365A170D3330313030343138353533365A30819D310B30090603550406130255533113301106035504080C0A57617368696E67746F6E31163014060355040A0C0D426C7565746F6F746820534947310C300A060355040B0C03505453312D302B06035504030C2430303142444330382D313032312D304230452D304130432D3030304230453041304330303124302206092A864886F70D0109011615737570706F727440626C7565746F6F74682E636F6D3059301306072A8648CE3D020106082A8648CE3D03010703420004D183194D0257D2141D3C5566639B4F7AF0834945349B7207DDDA730693FD2B56B8A83AC49FD22517D28D0EED9AE3F1D43A221FE37919B66E9418FF9618C2081EA35D305B301D0603551D0E041604142556CB5D177EFA709C7E05CCB7418A3B714C0A77301F0603551D230418301680142556CB5D177EFA709C7E05CCB7418A3B714C0A77300C0603551D13040530030101FF300B0603551D0F040403020106300A06082A8648CE3D040302034700304402207C9696D079CB866BEA5EAAC230FB52EB5BC8EFC72F46E25F7B1E7990401BC74202206B6FD9F0DBAC54D4121045FD0E4AC06D5F3306BF8DCAF32F2D701C1445A62EF8");
    private final String LOG_TAG = "Provisioning";
    private int state = 4096;
    private int recordId = -1;
    private int recordIndex = -1;
    private SparseArray<byte[]> recordContents = new SparseArray<>();
    private int fragmentOffset = 0;
    private byte[] rootCert = ROOT_CERT_IN_PTS;
    private Runnable provisioningTimeoutTask = new Runnable() { // from class: com.telink.ble.mesh.core.provisioning.ProvisioningController.1
        @Override // java.lang.Runnable
        public void run() {
            ProvisioningController.access$000(ProvisioningController.this, "provisioning timeout");
        }
    };

    static /* synthetic */ void access$000(ProvisioningController provisioningController, String str) {
        provisioningController.onProvisionFail(str);
    }

    public ProvisioningController(HandlerThread handlerThread) {
        this.delayHandler = new Handler(handlerThread.getLooper());
    }

    public void setProvisioningBridge(ProvisioningBridge provisioningBridge) {
        this.mProvisioningBridge = provisioningBridge;
    }

    public ProvisioningDevice getProvisioningDevice() {
        return this.mProvisioningDevice;
    }

    public void begin(ProvisioningDevice provisioningDevice) {
        log("begin -- " + Arrays.bytesToHexString(provisioningDevice.getDeviceUUID()));
        this.mProvisioningDevice = provisioningDevice;
        if (provisioningDevice.getRootCert() != null) {
            this.rootCert = provisioningDevice.getRootCert();
        } else {
            this.rootCert = ROOT_CERT_IN_PTS;
        }
        this.delayHandler.removeCallbacks(this.provisioningTimeoutTask);
        this.delayHandler.postDelayed(this.provisioningTimeoutTask, TIMEOUT_PROVISIONING);
        int oobInfo = provisioningDevice.getOobInfo();
        if (MeshUtils.isCertSupported(oobInfo) && MeshUtils.isPvRecordSupported(oobInfo)) {
            provisionRecordsGet();
        } else {
            provisionInvite();
        }
    }

    public void clear() {
        Handler handler = this.delayHandler;
        if (handler != null) {
            handler.removeCallbacks(this.provisioningTimeoutTask);
        }
        this.state = 4096;
    }

    public void pushNotification(byte[] bArr) throws IllegalStateException, NoSuchAlgorithmException, SignatureException, InvalidKeyException, CertificateException, NoSuchProviderException, InvalidAlgorithmParameterException {
        if (this.state == 4096) {
            log("received notification when idle", 3);
            return;
        }
        log("provisioning pdu received: " + Arrays.bytesToHexString(bArr, ""));
        byte b = bArr[0];
        int length = bArr.length - 1;
        byte[] bArr2 = new byte[length];
        System.arraycopy(bArr, 1, bArr2, 0, length);
        if (b == 1) {
            onCapabilityReceived(bArr2);
            return;
        }
        if (b == 3) {
            onPubKeyReceived(bArr2);
            return;
        }
        if (b == 11) {
            onRecordResponse(bArr2);
            return;
        }
        if (b == 13) {
            onRecordListReceived(bArr2);
            return;
        }
        if (b == 5) {
            onConfirmReceived(bArr2);
            return;
        }
        if (b == 6) {
            onRandomReceived(bArr2);
        } else if (b == 8) {
            onProvisionSuccess();
        } else {
            if (b != 9) {
                return;
            }
            onProvisionFail("failed notification received");
        }
    }

    private void onProvisionSuccess() {
        updateProvisioningState(STATE_COMPLETE, "Provision Success");
        onProvisionComplete();
    }

    private void onProvisionComplete() {
        this.state = 4096;
        this.delayHandler.removeCallbacks(this.provisioningTimeoutTask);
    }

    private byte[] getAuthValue() {
        byte[] authValue = this.mProvisioningDevice.getAuthValue();
        if (this.pvCapability.isStaticOOBSupported() && authValue != null) {
            return (this.pvCapability.isHMacAlgorithmSupported() || authValue.length != 32) ? authValue : ByteBuffer.allocate(16).put(authValue, 0, 16).array();
        }
        if (this.pvCapability.isHMacAlgorithmSupported()) {
            return AUTH_NO_OOB_EPA;
        }
        return AUTH_NO_OOB;
    }

    private void updateProvisioningState(int i, String str) {
        log("provisioning state update: state -- " + i + " desc -- " + str);
        this.state = i;
        ProvisioningBridge provisioningBridge = this.mProvisioningBridge;
        if (provisioningBridge != null) {
            provisioningBridge.onProvisionStateChanged(i, str);
        }
    }

    private void provisionRecordsGet() {
        updateProvisioningState(16, "Records Get");
        sendProvisionPDU(new ProvisioningRecordsGetPDU());
    }

    private void provisionRecordRequest() {
        log(String.format("Record Request recordID=%04X offset=%04X", Integer.valueOf(this.recordId), Integer.valueOf(this.fragmentOffset)));
        sendProvisionPDU(new ProvisioningRecordRequestPDU(this.recordId, this.fragmentOffset, 20));
    }

    private void provisionInvite() {
        this.invitePDU = new ProvisioningInvitePDU(this.mProvisioningDevice.getAttentionDuration());
        updateProvisioningState(STATE_INVITE, "Invite");
        sendProvisionPDU(this.invitePDU);
    }

    private void provisionStart(boolean z) {
        boolean z2 = false;
        ProvisioningStartPDU simple = ProvisioningStartPDU.getSimple(this.recordPubKey != null, z);
        this.startPDU = simple;
        if (this.pvCapability.publicKeyType == 1 && this.recordPubKey != null) {
            z2 = true;
        }
        simple.setPublicKey(z2);
        byte supportAlg = getSupportAlg();
        this.startPDU.setAlgorithm(supportAlg);
        updateProvisioningState(STATE_START, "Start - use static oob?" + z + " - algo:" + ((int) supportAlg));
        sendProvisionPDU(this.startPDU);
    }

    private byte getSupportAlg() {
        if (!this.pvCapability.isHMacAlgorithmSupported()) {
            return (byte) 0;
        }
        byte[] authValue = this.mProvisioningDevice.getAuthValue();
        return (authValue == null || authValue.length != 16) ? (byte) 1 : (byte) 0;
    }

    private void provisionSendPubKey() throws NoSuchAlgorithmException, NoSuchProviderException, InvalidAlgorithmParameterException {
        ProvisioningPubKeyPDU publicKey = getPublicKey();
        updateProvisioningState(STATE_PUB_KEY_SENT, "Send Public Key");
        sendProvisionPDU(publicKey);
    }

    public void onCapabilityReceived(byte[] bArr) throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, InvalidAlgorithmParameterException {
        if (this.state != 4097) {
            log(" capability received when not inviting", 3);
            return;
        }
        ProvisioningCapabilityPDU provisioningCapabilityPDUFromBytes = ProvisioningCapabilityPDU.fromBytes(bArr);
        this.pvCapability = provisioningCapabilityPDUFromBytes;
        this.mProvisioningDevice.setDeviceCapability(provisioningCapabilityPDUFromBytes);
        updateProvisioningState(STATE_CAPABILITY, "Capability Received: " + this.pvCapability.toString());
        if (this.mProvisioningDevice.isAutoStart()) {
            continueProvision(this.mProvisioningDevice.getUnicastAddress());
        }
    }

    public void continueProvision(int i) throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, InvalidAlgorithmParameterException {
        byte[] bArr;
        boolean zIsStaticOOBSupported = this.pvCapability.isStaticOOBSupported();
        this.mProvisioningDevice.setUnicastAddress(i);
        if (zIsStaticOOBSupported && this.mProvisioningDevice.getAuthValue() == null) {
            if (!this.mProvisioningDevice.isAutoUseNoOOB()) {
                onProvisionFail("authValue not found when device static oob supported!");
                return;
            }
            zIsStaticOOBSupported = false;
        }
        provisionStart(zIsStaticOOBSupported);
        provisionSendPubKey();
        if (this.pvCapability.publicKeyType != 1 || (bArr = this.recordPubKey) == null) {
            return;
        }
        onPubKeyReceived(bArr);
    }

    private void onPubKeyReceived(byte[] bArr) throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException {
        if (this.state != 4100) {
            log(" pub key received when not pub key sent", 3);
            return;
        }
        updateProvisioningState(STATE_PUB_KEY_RECEIVED, "Public Key received");
        log("pub key received: " + Arrays.bytesToHexString(bArr, ""));
        this.devicePubKeyPDU = ProvisioningPubKeyPDU.fromBytes(bArr);
        byte[] bArrGenerateECDH = Encipher.generateECDH(bArr, this.provisionerKeyPair.getPrivate());
        this.deviceECDHSecret = bArrGenerateECDH;
        if (bArrGenerateECDH == null) {
            onProvisionFail("invalid public key");
            return;
        }
        log("get secret: " + Arrays.bytesToHexString(this.deviceECDHSecret, ""));
        sendConfirm();
    }

    private void sendConfirm() {
        byte[] confirm = getConfirm();
        log("provisioner confirm - " + Arrays.bytesToHexString(confirm));
        this.provisionerConfirm = confirm;
        ProvisioningConfirmPDU provisioningConfirmPDU = new ProvisioningConfirmPDU(confirm);
        updateProvisioningState(STATE_CONFIRM_SENT, "Send confirm");
        sendProvisionPDU(provisioningConfirmPDU);
    }

    private byte[] getConfirm() {
        byte[] bArrConfirmAssembly = confirmAssembly();
        byte[] authValue = getAuthValue();
        if (isHmac()) {
            byte[] bArrK5 = Encipher.k5(ByteBuffer.allocate(this.deviceECDHSecret.length + authValue.length).put(this.deviceECDHSecret).put(authValue).array(), Encipher.s2(bArrConfirmAssembly), Encipher.PRCK256);
            byte[] bArrGenerateRandom = Arrays.generateRandom(32);
            this.provisionerRandom = bArrGenerateRandom;
            return Encipher.hMacSha256(bArrGenerateRandom, bArrK5);
        }
        byte[] bArrK1 = Encipher.k1(this.deviceECDHSecret, Encipher.generateSalt(bArrConfirmAssembly), Encipher.PRCK);
        byte[] bArrGenerateRandom2 = Arrays.generateRandom(16);
        this.provisionerRandom = bArrGenerateRandom2;
        byte[] bArr = new byte[bArrGenerateRandom2.length + authValue.length];
        System.arraycopy(bArrGenerateRandom2, 0, bArr, 0, bArrGenerateRandom2.length);
        System.arraycopy(authValue, 0, bArr, this.provisionerRandom.length, authValue.length);
        return Encipher.aesCmac(bArr, bArrK1);
    }

    private boolean isHmac() {
        return this.pvCapability != null && getSupportAlg() == 1;
    }

    private void onConfirmReceived(byte[] bArr) {
        if (this.state != 4102) {
            log(" confirm received when not confirm sent", 3);
            return;
        }
        updateProvisioningState(STATE_CONFIRM_RECEIVED, "Confirm received");
        this.deviceConfirm = bArr;
        if (Arrays.equals(this.provisionerConfirm, bArr)) {
            onProvisionFail("received the same confirm as local");
        } else {
            sendRandom();
        }
    }

    private void onRandomReceived(byte[] bArr) {
        if (this.state != 4104) {
            log(" random received when not random sent", 3);
            return;
        }
        updateProvisioningState(STATE_RANDOM_RECEIVED, "Random received");
        this.deviceRandom = bArr;
        if (Arrays.equals(this.provisionerRandom, bArr)) {
            onProvisionFail("received the same random as local");
        } else if (checkDeviceConfirm(bArr)) {
            sendProvisionData();
        } else {
            onProvisionFail("device confirm check err!");
        }
    }

    private void onRecordListReceived(byte[] bArr) throws NoSuchAlgorithmException, SignatureException, InvalidKeyException, CertificateException, NoSuchProviderException {
        if (this.state != 16) {
            log("record list received when not record list get", 3);
            return;
        }
        ProvisioningRecordsListPDU provisioningRecordsListPDUFromBytes = ProvisioningRecordsListPDU.fromBytes(bArr);
        this.recordsListPDU = provisioningRecordsListPDUFromBytes;
        if (provisioningRecordsListPDUFromBytes.recordsList.size() == 0) {
            onProvisionFail("Device Certificate not found");
            return;
        }
        this.recordIndex = 0;
        this.recordContents.clear();
        getNextRecord();
    }

    private void getNextRecord() throws NoSuchAlgorithmException, SignatureException, InvalidKeyException, CertificateException, NoSuchProviderException {
        log("get next record");
        if (this.recordIndex >= this.recordsListPDU.recordsList.size()) {
            onAllRecordsComplete();
            return;
        }
        this.recordId = this.recordsListPDU.recordsList.get(this.recordIndex).intValue();
        this.fragmentOffset = 0;
        this.recordData = null;
        this.recordPubKey = null;
        updateProvisioningState(17, "Record Request");
        provisionRecordRequest();
    }

    private void onRecordResponse(byte[] bArr) throws NoSuchAlgorithmException, SignatureException, InvalidKeyException, CertificateException, NoSuchProviderException {
        if (this.state != 17) {
            log("record response received when not record request", 3);
            return;
        }
        ProvisioningRecordResponsePDU provisioningRecordResponsePDUFromBytes = ProvisioningRecordResponsePDU.fromBytes(bArr);
        log(provisioningRecordResponsePDUFromBytes.toString());
        if (provisioningRecordResponsePDUFromBytes.status != 0 || provisioningRecordResponsePDUFromBytes.data == null) {
            onProvisionFail("record response error");
            return;
        }
        compositeResponseData(provisioningRecordResponsePDUFromBytes.data);
        if (this.recordData.length >= provisioningRecordResponsePDUFromBytes.totalLength) {
            onRecordResponseComplete();
        } else {
            this.fragmentOffset += provisioningRecordResponsePDUFromBytes.data.length;
            provisionRecordRequest();
        }
    }

    private void compositeResponseData(byte[] bArr) {
        byte[] bArr2 = this.recordData;
        if (bArr2 == null) {
            this.recordData = bArr;
            return;
        }
        byte[] bArr3 = new byte[bArr2.length + bArr.length];
        System.arraycopy(bArr2, 0, bArr3, 0, bArr2.length);
        System.arraycopy(bArr, 0, bArr3, this.recordData.length, bArr.length);
        this.recordData = bArr3;
    }

    private void onRecordResponseComplete() throws NoSuchAlgorithmException, SignatureException, InvalidKeyException, CertificateException, NoSuchProviderException {
        log("complete record: " + this.recordId + " -- " + Arrays.bytesToHexString(this.recordData));
        this.recordContents.put(this.recordId, (byte[]) this.recordData.clone());
        this.recordIndex = this.recordIndex + 1;
        getNextRecord();
    }

    private void onAllRecordsComplete() throws NoSuchAlgorithmException, SignatureException, InvalidKeyException, CertificateException, NoSuchProviderException {
        if (this.recordContents.size() == 0) {
            onProvisionFail("no records found");
            return;
        }
        if (this.recordContents.keyAt(0) == 0) {
            String str = new String(this.recordContents.get(0));
            log("Certificate-based Provisioning URI found: ".concat(str));
            Uri.parse(str);
            byte[] bArrHexToBytes = Arrays.hexToBytes("308202873082022EA003020102020101300A06082A8648CE3D04030230819D310B30090603550406130255533113301106035504080C0A57617368696E67746F6E31163014060355040A0C0D426C7565746F6F746820534947310C300A060355040B0C03505453312D302B06035504030C2430303142444330382D313032312D304230452D304130432D3030304230453041304330303124302206092A864886F70D0109011615737570706F727440626C7565746F6F74682E636F6D301E170D3139303731383138353533365A170D3330313030343138353533365A30819D310B30090603550406130255533113301106035504080C0A57617368696E67746F6E31163014060355040A0C0D426C7565746F6F746820534947310C300A060355040B0C03505453312D302B06035504030C2430303142444330382D313032312D304230452D304130432D3030304230453041304330303124302206092A864886F70D0109011615737570706F727440626C7565746F6F74682E636F6D3059301306072A8648CE3D020106082A8648CE3D03010703420004D183194D0257D2141D3C5566639B4F7AF0834945349B7207DDDA730693FD2B56B8A83AC49FD22517D28D0EED9AE3F1D43A221FE37919B66E9418FF9618C2081EA35D305B301D0603551D0E041604142556CB5D177EFA709C7E05CCB7418A3B714C0A77301F0603551D230418301680142556CB5D177EFA709C7E05CCB7418A3B714C0A77300C0603551D13040530030101FF300B0603551D0F040403020106300A06082A8648CE3D040302034700304402207C9696D079CB866BEA5EAAC230FB52EB5BC8EFC72F46E25F7B1E7990401BC74202206B6FD9F0DBAC54D4121045FD0E4AC06D5F3306BF8DCAF32F2D701C1445A62EF8");
            byte[] bArrHexToBytes2 = Arrays.hexToBytes("30820250308201F6A003020102020104300A06082A8648CE3D04030230818F310B30090603550406130255533113301106035504080C0A57617368696E67746F6E31163014060355040A0C0D426C7565746F6F746820534947310C300A060355040B0C03505453311F301D06035504030C16496E7465726D65646961746520417574686F726974793124302206092A864886F70D0109011615737570706F727440626C7565746F6F74682E636F6D301E170D3139303731383138353533375A170D3330313030343138353533375A3077310B30090603550406130255533113301106035504080C0A57617368696E67746F6E31163014060355040A0C0D426C7565746F6F746820534947310C300A060355040B0C03505453312D302B06035504030C2430303142444330382D313032312D304230452D304130432D3030304230453041304330303059301306072A8648CE3D020106082A8648CE3D03010703420004F465E43FF23D3F1B9DC7DFC04DA8758184DBC966204796ECCF0D6CF5E16500CC0201D048BCBBD899EEEFC424164E33C201C2B010CA6B4D43A8A155CAD8ECB279A35A305830090603551D1304023000300B0603551D0F040403020308301D0603551D0E04160414E262F3584AB688EC882EA528ED8E5C442A71369F301F0603551D230418301680144ABE293903A8BB49FF1D327CFEB80985F4109C21300A06082A8648CE3D0403020348003045022100E029814E909DD3D81C1DC4843FD27A56209212818765356699912382EFF9F46102201BE5E9E8801C868F7C44574F3AB7056C42B8083D6A39D519FD92FA4C17D81D52");
            byte[] bArrHexToBytes3 = Arrays.hexToBytes("3082027F30820224A003020102020103300A06082A8648CE3D04030230818F310B30090603550406130255533113301106035504080C0A57617368696E67746F6E31163014060355040A0C0D426C7565746F6F746820534947310C300A060355040B0C03505453311F301D06035504030C16496E7465726D65646961746520417574686F726974793124302206092A864886F70D0109011615737570706F727440626C7565746F6F74682E636F6D301E170D3139303731383138353533365A170D3330313030343138353533365A3077310B30090603550406130255533113301106035504080C0A57617368696E67746F6E31163014060355040A0C0D426C7565746F6F746820534947310C300A060355040B0C03505453312D302B06035504030C2430303142444330382D313032312D304230452D304130432D3030304230453041304330303059301306072A8648CE3D020106082A8648CE3D03010703420004F465E43FF23D3F1B9DC7DFC04DA8758184DBC966204796ECCF0D6CF5E16500CC0201D048BCBBD899EEEFC424164E33C201C2B010CA6B4D43A8A155CAD8ECB279A3818730818430090603551D1304023000300B0603551D0F040403020308301D0603551D0E04160414E262F3584AB688EC882EA528ED8E5C442A71369F301F0603551D230418301680144ABE293903A8BB49FF1D327CFEB80985F4109C21302A06146982E19DE491EAC0C283999CAA83FD8CC3D0D3670412041000000000000000000102030405060708300A06082A8648CE3D0403020349003046022100F7B504477EC2E5796644A0C5A95D864BF001CF96A5A180E243432CCE28FC5F9E0221008D816BEE11C36CDC1890189EDB85DF9A26998063EAC8EA55330B7F75003FEB98");
            byte[] bArrHexToBytes4 = Arrays.hexToBytes("3082027A30820220A003020102020102300A06082A8648CE3D04030230819D310B30090603550406130255533113301106035504080C0A57617368696E67746F6E31163014060355040A0C0D426C7565746F6F746820534947310C300A060355040B0C03505453312D302B06035504030C2430303142444330382D313032312D304230452D304130432D3030304230453041304330303124302206092A864886F70D0109011615737570706F727440626C7565746F6F74682E636F6D301E170D3139303731383138353533365A170D3330313030343138353533365A30818F310B30090603550406130255533113301106035504080C0A57617368696E67746F6E31163014060355040A0C0D426C7565746F6F746820534947310C300A060355040B0C03505453311F301D06035504030C16496E7465726D65646961746520417574686F726974793124302206092A864886F70D0109011615737570706F727440626C7565746F6F74682E636F6D3059301306072A8648CE3D020106082A8648CE3D030107034200045463155F21C616953E8FAE69A9BCE445BE4FC8A3EB3412E7B2E7539D1CDBD86C64465F8F40A0A770A63C2AD1A51717DDE536F17865663252AB06B629E6BAE17EA35D305B301D0603551D0E041604144ABE293903A8BB49FF1D327CFEB80985F4109C21301F0603551D230418301680142556CB5D177EFA709C7E05CCB7418A3B714C0A77300C0603551D13040530030101FF300B0603551D0F040403020106300A06082A8648CE3D040302034800304502205C224FE15E7EE0FD2E499EC019D930950FF190E0E384D9B2FAB6259522E3EDF0022100D8846CC82D72EE1387875BB2B95C347776A2950F29A17E7863117203EEF0F5FE");
            if (!str.endsWith("a")) {
                bArrHexToBytes2 = bArrHexToBytes3;
            }
            validateDeviceCert(bArrHexToBytes2, bArrHexToBytes4, bArrHexToBytes);
            return;
        }
        byte[] bArr = this.recordContents.get(1);
        byte[] bArr2 = this.recordContents.get(2);
        if (bArr == null) {
            onProvisionFail("device cert not found");
            return;
        }
        if (bArr2 == null) {
            log("check single device cert");
            validateDeviceCert(bArr);
            return;
        }
        byte[] bArr3 = this.rootCert;
        if (bArr3 == null) {
            onProvisionFail("root cert not found");
        } else {
            validateDeviceCert(bArr, bArr2, bArr3);
        }
    }

    private void validateDeviceCert(byte[] bArr) throws NoSuchAlgorithmException, SignatureException, CertificateNotYetValidException, CertificateParsingException, InvalidKeyException, NoSuchProviderException, CertificateExpiredException {
        X509Certificate x509CertificateCheckCertificate = Encipher.checkCertificate(bArr);
        if (x509CertificateCheckCertificate == null) {
            onProvisionFail("device cert verify fail");
            return;
        }
        this.recordPubKey = Encipher.getPublicKeyInCert(x509CertificateCheckCertificate);
        this.mProvisioningDevice.setAuthValue(Encipher.getStaticOOBInCert(x509CertificateCheckCertificate));
        log("public key in record: " + Arrays.bytesToHexString(this.recordPubKey));
        provisionInvite();
    }

    private void validateDeviceCert(byte[] bArr, byte[] bArr2, byte[] bArr3) throws CertificateException {
        if (Encipher.checkCertificateByCa(bArr2, bArr3) == null) {
            onProvisionFail("intermediate cert verify fail");
            return;
        }
        X509Certificate x509CertificateCheckCertificateByCa = Encipher.checkCertificateByCa(bArr, bArr2);
        if (x509CertificateCheckCertificateByCa == null) {
            onProvisionFail("device cert verify fail");
            return;
        }
        this.recordPubKey = Encipher.getPublicKeyInCert(x509CertificateCheckCertificateByCa);
        this.mProvisioningDevice.setAuthValue(Encipher.getStaticOOBInCert(x509CertificateCheckCertificateByCa));
        log("public key in record - 1 : " + Arrays.bytesToHexString(this.recordPubKey));
        provisionInvite();
    }

    private void onProvisionFail(String str) {
        updateProvisioningState(STATE_FAILED, str);
        onProvisionComplete();
    }

    private void sendProvisionData() {
        ProvisioningDataPDU provisioningDataPDU = new ProvisioningDataPDU(createProvisioningData());
        updateProvisioningState(STATE_DATA, "Send provisioning data");
        sendProvisionPDU(provisioningDataPDU);
    }

    private void sendRandom() {
        ProvisioningRandomPDU provisioningRandomPDU = new ProvisioningRandomPDU(this.provisionerRandom);
        updateProvisioningState(STATE_RANDOM_SENT, "Send random");
        sendProvisionPDU(provisioningRandomPDU);
    }

    private ProvisioningPubKeyPDU getPublicKey() throws NoSuchAlgorithmException, NoSuchProviderException, InvalidAlgorithmParameterException {
        KeyPair keyPairGenerateKeyPair = Encipher.generateKeyPair();
        this.provisionerKeyPair = keyPairGenerateKeyPair;
        if (keyPairGenerateKeyPair != null) {
            BCECPublicKey bCECPublicKey = (BCECPublicKey) keyPairGenerateKeyPair.getPublic();
            byte[] encoded = bCECPublicKey.getQ().getXCoord().getEncoded();
            byte[] encoded2 = bCECPublicKey.getQ().getYCoord().getEncoded();
            ProvisioningPubKeyPDU provisioningPubKeyPDU = new ProvisioningPubKeyPDU();
            this.provisionerPubKeyPDU = provisioningPubKeyPDU;
            provisioningPubKeyPDU.x = encoded;
            this.provisionerPubKeyPDU.y = encoded2;
            log("get key x: " + Arrays.bytesToHexString(encoded, ":"));
            log("get key y: " + Arrays.bytesToHexString(encoded2, ":"));
            return this.provisionerPubKeyPDU;
        }
        throw new RuntimeException("key pair generate err");
    }

    public byte[] confirmAssembly() {
        byte[] bytes = this.invitePDU.toBytes();
        byte[] bytes2 = this.pvCapability.toBytes();
        byte[] bytes3 = this.startPDU.toBytes();
        byte[] bytes4 = this.provisionerPubKeyPDU.toBytes();
        byte[] bytes5 = this.devicePubKeyPDU.toBytes();
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(bytes.length + bytes2.length + bytes3.length + bytes4.length + bytes5.length);
        byteBufferAllocate.put(bytes).put(bytes2).put(bytes3).put(bytes4).put(bytes5);
        return byteBufferAllocate.array();
    }

    private boolean checkDeviceConfirm(byte[] bArr) throws NoSuchAlgorithmException, InvalidKeyException {
        byte[] bArrAesCmac;
        byte[] bArrConfirmAssembly = confirmAssembly();
        byte[] authValue = getAuthValue();
        if (isHmac()) {
            bArrAesCmac = Encipher.hMacSha256(this.deviceRandom, Encipher.k5(ByteBuffer.allocate(this.deviceECDHSecret.length + authValue.length).put(this.deviceECDHSecret).put(authValue).array(), Encipher.s2(bArrConfirmAssembly), Encipher.PRCK256));
        } else {
            byte[] bArrK1 = Encipher.k1(this.deviceECDHSecret, Encipher.generateSalt(bArrConfirmAssembly), Encipher.PRCK);
            ByteBuffer byteBufferAllocate = ByteBuffer.allocate(bArr.length + authValue.length);
            byteBufferAllocate.put(bArr);
            byteBufferAllocate.put(authValue);
            bArrAesCmac = Encipher.aesCmac(byteBufferAllocate.array(), bArrK1);
        }
        if (java.util.Arrays.equals(bArrAesCmac, this.deviceConfirm)) {
            log("Confirmation values check pass");
            return true;
        }
        log("Confirmation values check err", 3);
        return false;
    }

    private byte[] createProvisioningData() throws IllegalStateException, DataLengthException, IllegalArgumentException {
        byte[] bArrGenerateSalt;
        byte[] bArrConfirmAssembly = confirmAssembly();
        if (isHmac()) {
            bArrGenerateSalt = Encipher.s2(bArrConfirmAssembly);
        } else {
            bArrGenerateSalt = Encipher.generateSalt(bArrConfirmAssembly);
        }
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(bArrGenerateSalt.length + this.provisionerRandom.length + this.deviceRandom.length);
        byteBufferAllocate.put(bArrGenerateSalt);
        byteBufferAllocate.put(this.provisionerRandom);
        byteBufferAllocate.put(this.deviceRandom);
        byte[] bArrGenerateSalt2 = Encipher.generateSalt(byteBufferAllocate.array());
        byte[] bArrK1 = Encipher.k1(this.deviceECDHSecret, bArrGenerateSalt2, Encipher.PRSK);
        byte[] bArrK12 = Encipher.k1(this.deviceECDHSecret, bArrGenerateSalt2, Encipher.PRSN);
        ByteBuffer byteBufferAllocate2 = ByteBuffer.allocate(bArrK12.length - 3);
        byteBufferAllocate2.put(bArrK12, 3, byteBufferAllocate2.limit());
        byte[] bArrArray = byteBufferAllocate2.array();
        byte[] bArrK13 = Encipher.k1(this.deviceECDHSecret, bArrGenerateSalt2, Encipher.PRDK);
        this.mProvisioningDevice.setDeviceKey(bArrK13);
        log("device key: " + Arrays.bytesToHexString(bArrK13, ""));
        log("provisioning data prepare: " + this.mProvisioningDevice.toString());
        byte[] bArrGenerateProvisioningData = this.mProvisioningDevice.generateProvisioningData();
        log("unencrypted provision data: " + Arrays.bytesToHexString(bArrGenerateProvisioningData, ""));
        byte[] bArrCcm = Encipher.ccm(bArrGenerateProvisioningData, bArrK1, bArrArray, 8, true);
        log("encrypted provision data: " + Arrays.bytesToHexString(bArrCcm, ""));
        return bArrCcm;
    }

    private void sendProvisionPDU(ProvisioningStatePDU provisioningStatePDU) {
        byte[] bArr;
        byte[] bytes = provisioningStatePDU.toBytes();
        if (bytes == null || bytes.length == 0) {
            bArr = new byte[]{provisioningStatePDU.getState()};
        } else {
            bArr = new byte[bytes.length + 1];
            bArr[0] = provisioningStatePDU.getState();
            System.arraycopy(bytes, 0, bArr, 1, bytes.length);
        }
        if (this.mProvisioningBridge != null) {
            log("pdu prepared: " + Arrays.bytesToHexString(bytes, ":"));
            this.mProvisioningBridge.onCommandPrepared((byte) 3, bArr);
        }
    }

    private void log(String str) {
        log(str, 1);
    }

    private void log(String str, int i) {
        MeshLogger.log(str, "Provisioning", i);
    }
}
