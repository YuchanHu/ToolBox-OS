package com.telink.ble.mesh.core.provisioning.pdu;

/* loaded from: classes.dex */
public interface PDU {
    byte[] toBytes();
}
