package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.entity.ModelPublication;

/* loaded from: classes.dex */
public class ModelPublicationSetMessage extends ConfigMessage {
    private ModelPublication modelPublication;

    public ModelPublicationSetMessage(int i, ModelPublication modelPublication) {
        super(i);
        this.modelPublication = modelPublication;
        this.responseOpcode = Opcode.CFG_MODEL_PUB_STATUS.value;
        this.responseMax = 1;
    }

    public ModelPublicationSetMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.CFG_MODEL_PUB_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_MODEL_PUB_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return this.modelPublication.toBytes();
    }

    public void setModelPublication(ModelPublication modelPublication) {
        this.modelPublication = modelPublication;
    }
}
