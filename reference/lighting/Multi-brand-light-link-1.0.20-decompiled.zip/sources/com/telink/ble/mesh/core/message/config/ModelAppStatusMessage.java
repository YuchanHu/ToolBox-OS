package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ModelAppStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<ModelAppStatusMessage> CREATOR = new Parcelable.Creator<ModelAppStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.ModelAppStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ModelAppStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ModelAppStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ModelAppStatusMessage createFromParcel(Parcel parcel) {
            return new ModelAppStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ModelAppStatusMessage[] newArray(int i) {
            return new ModelAppStatusMessage[i];
        }
    };
    private static final int MODEL_STATUS_SIG_LEN = 7;
    private static final int MODEL_STATUS_VENDOR_LEN = 9;
    private int appKeyIndex;
    private int elementAddress;
    private int modelIdentifier;
    private boolean sigModel;
    private byte status;
    private boolean validParams;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public ModelAppStatusMessage() {
    }

    protected ModelAppStatusMessage(Parcel parcel) {
        this.status = parcel.readByte();
        this.elementAddress = parcel.readInt();
        this.appKeyIndex = parcel.readInt();
        this.modelIdentifier = parcel.readInt();
        this.sigModel = parcel.readByte() != 0;
        this.validParams = parcel.readByte() != 0;
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.status = bArr[0];
        this.elementAddress = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.LITTLE_ENDIAN);
        this.appKeyIndex = MeshUtils.bytes2Integer(bArr, 3, 2, ByteOrder.LITTLE_ENDIAN);
        boolean z = bArr.length == 7;
        this.sigModel = z;
        this.validParams = z || bArr.length == 9;
        this.modelIdentifier = MeshUtils.bytes2Integer(bArr, 5, z ? 2 : 4, ByteOrder.LITTLE_ENDIAN);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.status);
        parcel.writeInt(this.elementAddress);
        parcel.writeInt(this.appKeyIndex);
        parcel.writeInt(this.modelIdentifier);
        parcel.writeByte(this.sigModel ? (byte) 1 : (byte) 0);
        parcel.writeByte(this.validParams ? (byte) 1 : (byte) 0);
    }

    public byte getStatus() {
        return this.status;
    }

    public int getElementAddress() {
        return this.elementAddress;
    }

    public int getAppKeyIndex() {
        return this.appKeyIndex;
    }

    public boolean isSigModel() {
        return this.sigModel;
    }

    public boolean hasValidParams() {
        return this.validParams;
    }

    public int getModelIdentifier() {
        return this.modelIdentifier;
    }
}
