package com.telink.ble.mesh.core.message.lighting;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class LcModeStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<LcModeStatusMessage> CREATOR = new Parcelable.Creator<LcModeStatusMessage>() { // from class: com.telink.ble.mesh.core.message.lighting.LcModeStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ LcModeStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ LcModeStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LcModeStatusMessage createFromParcel(Parcel parcel) {
            return new LcModeStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LcModeStatusMessage[] newArray(int i) {
            return new LcModeStatusMessage[i];
        }
    };
    private byte mode;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public LcModeStatusMessage() {
    }

    protected LcModeStatusMessage(Parcel parcel) {
        this.mode = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.mode = bArr[0];
    }

    public byte getMode() {
        return this.mode;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.mode);
    }
}
