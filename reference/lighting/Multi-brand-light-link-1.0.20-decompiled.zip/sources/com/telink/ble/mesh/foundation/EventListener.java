package com.telink.ble.mesh.foundation;

/* loaded from: classes.dex */
public interface EventListener<T> {
    void performed(Event<T> event);
}
