package com.telink.ble.mesh.core.message.firmwareupdate;

/* loaded from: classes.dex */
public enum UpdateStatus {
    SUCCESS(0, "The message was processed successfully"),
    INSUFFICIENT_RESOURCES(1, "Insufficient resources on the node"),
    WRONG_PHASE(2, "The operation cannot be performed while the server is in the current phase."),
    INTERNAL_ERROR(3, "An internal error occurred on the node."),
    WRONG_FIRMWARE_INDEX(4, "The message contains a firmware index value that is not expected."),
    METADATA_CHECK_FAILED(5, "The metadata check failed."),
    TEMPORARILY_UNAVAILABLE(6, "The server cannot start a firmware update."),
    BLOB_TRANSFER_BUSY(7, "Another BLOB transfer is in progress."),
    UNKNOWN_ERROR(255, "unknown error");

    public final int code;
    public final String desc;

    UpdateStatus(int i, String str) {
        this.code = i;
        this.desc = str;
    }

    public static UpdateStatus valueOf(int i) {
        for (UpdateStatus updateStatus : values()) {
            if (updateStatus.code == i) {
                return updateStatus;
            }
        }
        return UNKNOWN_ERROR;
    }
}
