package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class NetKeyDeleteMessage extends ConfigMessage {
    public int netKeyIndex;

    public NetKeyDeleteMessage(int i) {
        super(i);
    }

    public NetKeyDeleteMessage(int i, int i2) {
        super(i);
        this.netKeyIndex = i2;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.NETKEY_DEL.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.NETKEY_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.netKeyIndex).array();
    }
}
