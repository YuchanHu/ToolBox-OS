package com.telink.ble.mesh.core.message.firmwaredistribution;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;

/* loaded from: classes.dex */
public class FDCancelMessage extends UpdatingMessage {
    private boolean ack;

    public FDCancelMessage(int i, int i2) {
        super(i, i2);
        this.ack = true;
    }

    public static FDCancelMessage getSimple(int i, int i2) {
        FDCancelMessage fDCancelMessage = new FDCancelMessage(i, i2);
        fDCancelMessage.setResponseMax(1);
        return fDCancelMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FD_CANCEL.value;
    }

    public boolean isAck() {
        return this.ack;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        if (this.ack) {
            return Opcode.FD_STATUS.value;
        }
        return -1;
    }
}
