package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ModelAppBindMessage extends ConfigMessage {
    private int appKeyIndex;
    private int elementAddress;
    private boolean isSigModel;
    private int modelIdentifier;

    public ModelAppBindMessage(int i) {
        super(i);
        this.isSigModel = true;
    }

    public void setElementAddress(int i) {
        this.elementAddress = i;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public void setAppKeyIndex(int i) {
        this.appKeyIndex = i;
    }

    public void setModelIdentifier(int i) {
        this.modelIdentifier = i;
    }

    public void setSigModel(boolean z) {
        this.isSigModel = z;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.MODE_APP_BIND.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.MODE_APP_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        ByteBuffer byteBufferPutShort = ByteBuffer.allocate(this.isSigModel ? 6 : 8).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.elementAddress).putShort((short) this.appKeyIndex);
        if (this.isSigModel) {
            byteBufferPutShort.putShort((short) this.modelIdentifier);
        } else {
            byteBufferPutShort.putInt(this.modelIdentifier);
        }
        return byteBufferPutShort.array();
    }
}
