package com.telink.ble.mesh.core.access;

import com.telink.ble.mesh.core.message.MeshMessage;

/* loaded from: classes.dex */
public interface AccessBridge {
    public static final int MODE_BINDING = 1;
    public static final int MODE_FAST_PROVISION = 4;
    public static final int MODE_FIRMWARE_UPDATING = 2;
    public static final int MODE_MSG_BROKER = 5;
    public static final int MODE_REMOTE_PROVISIONING = 3;

    boolean onAccessMessagePrepared(MeshMessage meshMessage, int i);

    void onAccessStateChanged(int i, String str, int i2, Object obj);
}
