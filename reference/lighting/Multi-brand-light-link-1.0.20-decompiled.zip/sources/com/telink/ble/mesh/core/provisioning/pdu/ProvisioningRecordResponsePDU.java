package com.telink.ble.mesh.core.provisioning.pdu;

import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.util.Arrays;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ProvisioningRecordResponsePDU implements ProvisioningStatePDU {
    public static final byte STATUS_OFFSET_OUT_OF_BOUNDS = 2;
    public static final byte STATUS_RECORD_NOT_PRESENT = 1;
    public static final byte STATUS_SUCCESS = 0;
    public byte[] data;
    public int fragmentOffset;
    public byte[] rawData;
    public int recordID;
    public byte status;
    public int totalLength;

    @Override // com.telink.ble.mesh.core.provisioning.pdu.ProvisioningStatePDU
    public byte getState() {
        return (byte) 11;
    }

    public static ProvisioningRecordResponsePDU fromBytes(byte[] bArr) {
        ProvisioningRecordResponsePDU provisioningRecordResponsePDU = new ProvisioningRecordResponsePDU();
        provisioningRecordResponsePDU.rawData = bArr;
        provisioningRecordResponsePDU.status = bArr[0];
        provisioningRecordResponsePDU.recordID = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.BIG_ENDIAN);
        provisioningRecordResponsePDU.fragmentOffset = MeshUtils.bytes2Integer(bArr, 3, 2, ByteOrder.BIG_ENDIAN);
        provisioningRecordResponsePDU.totalLength = MeshUtils.bytes2Integer(bArr, 5, 2, ByteOrder.BIG_ENDIAN);
        byte[] bArr2 = new byte[bArr.length - 7];
        provisioningRecordResponsePDU.data = bArr2;
        System.arraycopy(bArr, 7, bArr2, 0, bArr2.length);
        return provisioningRecordResponsePDU;
    }

    @Override // com.telink.ble.mesh.core.provisioning.pdu.PDU
    public byte[] toBytes() {
        return this.rawData;
    }

    public String toString() {
        return "ProvisioningRecordResponsePDU{status=" + ((int) this.status) + ", recordID=" + this.recordID + ", fragmentOffset=" + this.fragmentOffset + ", totalLength=" + this.totalLength + ", data=" + Arrays.bytesToHexString(this.data) + '}';
    }
}
