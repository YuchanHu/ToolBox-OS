package com.telink.ble.mesh.core.provisioning.pdu;

/* loaded from: classes.dex */
public class ProvisioningRecordsGetPDU implements ProvisioningStatePDU {
    @Override // com.telink.ble.mesh.core.provisioning.pdu.ProvisioningStatePDU
    public byte getState() {
        return (byte) 12;
    }

    @Override // com.telink.ble.mesh.core.provisioning.pdu.PDU
    public byte[] toBytes() {
        return null;
    }
}
