package com.telink.ble.mesh.core.ble;

import android.os.Handler;
import com.telink.ble.mesh.core.ble.GattRequest;
import com.telink.ble.mesh.util.ContextUtil;
import com.telink.ble.mesh.util.MeshLogger;
import com.telink.ble.mesh.util.OtaPacketParser;

/* loaded from: classes.dex */
public class GattOtaController {
    private static final int DEFAULT_READ_INTERVAL = 8;
    private static final int OTA_END = 65282;
    private static final int OTA_PREPARE = 65280;
    private static final int OTA_START = 65281;
    public static final int OTA_STATE_FAILURE = 0;
    public static final int OTA_STATE_PROGRESS = 2;
    public static final int OTA_STATE_SUCCESS = 1;
    private static final int TAG_OTA_END = 8;
    private static final int TAG_OTA_LAST = 3;
    private static final int TAG_OTA_PREPARE = 6;
    private static final int TAG_OTA_READ = 2;
    private static final int TAG_OTA_START = 7;
    private static final int TAG_OTA_START_READ = 13;
    private static final int TAG_OTA_WRITE = 1;
    private GattOtaCallback mCallback;
    private GattConnection mConnection;
    private final String LOG_TAG = "GATT-OTA";
    private final OtaPacketParser mOtaParser = new OtaPacketParser();
    private int readCnt = 0;
    private int readInterval = 8;
    private GattRequest.Callback mOtaRequestCallback = new GattRequest.Callback() { // from class: com.telink.ble.mesh.core.ble.GattOtaController.1
        @Override // com.telink.ble.mesh.core.ble.GattRequest.Callback
        public void success(GattRequest gattRequest, Object obj) {
            GattOtaController.access$000(GattOtaController.this, gattRequest, obj);
        }

        @Override // com.telink.ble.mesh.core.ble.GattRequest.Callback
        public void error(GattRequest gattRequest, String str) {
            GattOtaController.access$100(GattOtaController.this, gattRequest);
        }

        @Override // com.telink.ble.mesh.core.ble.GattRequest.Callback
        public boolean timeout(GattRequest gattRequest) {
            GattOtaController.access$200(GattOtaController.this, gattRequest);
            return false;
        }
    };
    protected Handler mTimeoutHandler = new Handler();

    public interface GattOtaCallback {
        void onOtaStateChanged(int i);
    }

    static /* synthetic */ void access$000(GattOtaController gattOtaController, GattRequest gattRequest, Object obj) {
        gattOtaController.onOTACmdSuccess(gattRequest, obj);
    }

    static /* synthetic */ void access$100(GattOtaController gattOtaController, GattRequest gattRequest) {
        gattOtaController.onOtaCmdError(gattRequest);
    }

    static /* synthetic */ void access$200(GattOtaController gattOtaController, GattRequest gattRequest) {
        gattOtaController.onOtaCmdTimeout(gattRequest);
    }

    public GattOtaController(GattConnection gattConnection) {
        this.mConnection = gattConnection;
    }

    public void setCallback(GattOtaCallback gattOtaCallback) {
        this.mCallback = gattOtaCallback;
    }

    public void begin(byte[] bArr) {
        begin(bArr, 8);
    }

    public void begin(byte[] bArr, int i) {
        log("Start OTA");
        clear();
        this.mOtaParser.set(bArr);
        this.readInterval = i;
        sendOTAPrepareCommand();
    }

    private void clear() {
        this.readCnt = 0;
        this.mOtaParser.clear();
    }

    private void sendRequest(GattRequest gattRequest) {
        GattConnection gattConnection = this.mConnection;
        if (gattConnection != null) {
            gattConnection.sendRequest(gattRequest);
        }
    }

    public void otaWriteData(byte[] bArr, int i) {
        GattRequest gattRequestNewInstance = GattRequest.newInstance();
        gattRequestNewInstance.characteristicUUID = UUIDInfo.CHARACTERISTIC_UUID_OTA;
        gattRequestNewInstance.serviceUUID = UUIDInfo.SERVICE_UUID_OTA;
        gattRequestNewInstance.data = (byte[]) bArr.clone();
        gattRequestNewInstance.tag = Integer.valueOf(i);
        gattRequestNewInstance.type = GattRequest.RequestType.WRITE_NO_RESPONSE;
        gattRequestNewInstance.callback = this.mOtaRequestCallback;
        sendRequest(gattRequestNewInstance);
    }

    public int getOtaProgress() {
        return this.mOtaParser.getProgress();
    }

    private void setOtaProgressChanged() {
        if (this.mOtaParser.invalidateProgress()) {
            onOtaProgress();
        }
    }

    private void onOtaSuccess() {
        GattOtaCallback gattOtaCallback = this.mCallback;
        if (gattOtaCallback != null) {
            gattOtaCallback.onOtaStateChanged(1);
        }
    }

    private void onOtaFailure() {
        GattOtaCallback gattOtaCallback = this.mCallback;
        if (gattOtaCallback != null) {
            gattOtaCallback.onOtaStateChanged(0);
        }
    }

    private void onOtaProgress() {
        GattOtaCallback gattOtaCallback = this.mCallback;
        if (gattOtaCallback != null) {
            gattOtaCallback.onOtaStateChanged(2);
        }
    }

    private void sendOTAPrepareCommand() {
        otaWriteData(new byte[]{0, -1}, 6);
    }

    private void sendOtaStartCommand() {
        otaWriteData(new byte[]{1, -1}, 7);
    }

    private void sendOtaStartReadCmd() {
        GattRequest gattRequestNewInstance = GattRequest.newInstance();
        gattRequestNewInstance.serviceUUID = UUIDInfo.SERVICE_UUID_OTA;
        gattRequestNewInstance.characteristicUUID = UUIDInfo.CHARACTERISTIC_UUID_OTA;
        gattRequestNewInstance.type = GattRequest.RequestType.READ;
        gattRequestNewInstance.tag = 13;
        gattRequestNewInstance.callback = this.mOtaRequestCallback;
        sendRequest(gattRequestNewInstance);
    }

    private void sendOtaEndCommand() {
        int index = this.mOtaParser.getIndex();
        byte b = (byte) (index & 255);
        byte b2 = (byte) ((index >> 8) & 255);
        int i = ~index;
        otaWriteData(new byte[]{2, -1, b, b2, (byte) (i & 255), (byte) ((i >> 8) & 255)}, 8);
    }

    private void sendNextOtaPacketCommand() {
        if (this.mOtaParser.hasNextPacket()) {
            otaWriteData(this.mOtaParser.getNextPacket(), this.mOtaParser.isLast() ? 3 : 1);
        }
    }

    private boolean validateOta() {
        int i;
        if (!ContextUtil.isHarmonyOS() || (i = this.readInterval) <= 0) {
            return false;
        }
        int i2 = i * 16;
        int nextPacketIndex = this.mOtaParser.getNextPacketIndex() * 16;
        if (nextPacketIndex <= 0 || nextPacketIndex % i2 != 0) {
            return false;
        }
        log("onCommandSampled ota read packet " + this.mOtaParser.getNextPacketIndex(), 0);
        GattRequest gattRequestNewInstance = GattRequest.newInstance();
        gattRequestNewInstance.serviceUUID = UUIDInfo.SERVICE_UUID_OTA;
        gattRequestNewInstance.characteristicUUID = UUIDInfo.CHARACTERISTIC_UUID_OTA;
        gattRequestNewInstance.type = GattRequest.RequestType.READ;
        gattRequestNewInstance.tag = 2;
        gattRequestNewInstance.callback = this.mOtaRequestCallback;
        this.readCnt++;
        log("cur read count: " + this.readCnt);
        sendRequest(gattRequestNewInstance);
        return true;
    }

    private void onOTACmdSuccess(GattRequest gattRequest, Object obj) {
        if (gattRequest.tag.equals(6)) {
            sendOtaStartCommand();
            return;
        }
        if (gattRequest.tag.equals(7)) {
            sendOtaStartReadCmd();
            return;
        }
        if (gattRequest.tag.equals(8)) {
            setOtaProgressChanged();
            clear();
            onOtaSuccess();
        } else {
            if (gattRequest.tag.equals(3)) {
                sendOtaEndCommand();
                return;
            }
            if (gattRequest.tag.equals(1)) {
                if (!validateOta()) {
                    sendNextOtaPacketCommand();
                }
                setOtaProgressChanged();
            } else if (gattRequest.tag.equals(2)) {
                sendNextOtaPacketCommand();
            } else if (gattRequest.tag.equals(13)) {
                sendNextOtaPacketCommand();
            }
        }
    }

    private void onOtaCmdError(GattRequest gattRequest) {
        if (gattRequest.tag.equals(8)) {
            setOtaProgressChanged();
            clear();
            onOtaSuccess();
        } else {
            clear();
            onOtaFailure();
        }
    }

    private void onOtaCmdTimeout(GattRequest gattRequest) {
        if (gattRequest.tag.equals(8)) {
            setOtaProgressChanged();
            clear();
            onOtaSuccess();
        } else {
            clear();
            onOtaFailure();
        }
    }

    private void log(String str) {
        log(str, 1);
    }

    private void log(String str, int i) {
        MeshLogger.log(str, "GATT-OTA", i);
    }
}
