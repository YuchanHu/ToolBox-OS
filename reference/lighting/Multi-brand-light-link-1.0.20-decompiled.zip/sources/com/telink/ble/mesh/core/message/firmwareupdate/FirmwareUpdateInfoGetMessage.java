package com.telink.ble.mesh.core.message.firmwareupdate;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class FirmwareUpdateInfoGetMessage extends UpdatingMessage {
    private byte entriesLimit;
    private byte firstIndex;

    public FirmwareUpdateInfoGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FIRMWARE_UPDATE_INFORMATION_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FIRMWARE_UPDATE_INFORMATION_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return new byte[]{this.firstIndex, this.entriesLimit};
    }

    public void setFirstIndex(byte b) {
        this.firstIndex = b;
    }

    public void setEntriesLimit(byte b) {
        this.entriesLimit = b;
    }

    public static FirmwareUpdateInfoGetMessage getSimple(int i, int i2) {
        FirmwareUpdateInfoGetMessage firmwareUpdateInfoGetMessage = new FirmwareUpdateInfoGetMessage(i, i2);
        firmwareUpdateInfoGetMessage.setResponseMax(1);
        firmwareUpdateInfoGetMessage.firstIndex = (byte) 0;
        firmwareUpdateInfoGetMessage.entriesLimit = (byte) 1;
        return firmwareUpdateInfoGetMessage;
    }
}
