package com.telink.ble.mesh.core.provisioning;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ProvisioningParams {
    private static final int DATA_PDU_LEN = 25;
    private int ivIndex;
    private byte ivUpdateFlag;
    private byte keyRefreshFlag;
    private byte[] networkKey;
    private int networkKeyIndex;
    private int unicastAddress;

    public static ProvisioningParams getDefault(byte[] bArr, int i, int i2, int i3) {
        ProvisioningParams provisioningParams = new ProvisioningParams();
        provisioningParams.networkKey = bArr;
        provisioningParams.networkKeyIndex = i;
        provisioningParams.keyRefreshFlag = (byte) 0;
        provisioningParams.ivUpdateFlag = (byte) 0;
        provisioningParams.ivIndex = i2;
        provisioningParams.unicastAddress = i3;
        return provisioningParams;
    }

    public static ProvisioningParams getSimple(byte[] bArr, int i) {
        ProvisioningParams provisioningParams = new ProvisioningParams();
        provisioningParams.networkKey = bArr;
        provisioningParams.networkKeyIndex = 0;
        provisioningParams.keyRefreshFlag = (byte) 0;
        provisioningParams.ivUpdateFlag = (byte) 0;
        provisioningParams.ivIndex = 0;
        provisioningParams.unicastAddress = i;
        return provisioningParams;
    }

    public byte[] toProvisioningData() {
        byte b = (byte) ((this.keyRefreshFlag & 1) | (this.ivUpdateFlag & 2));
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(25).order(ByteOrder.BIG_ENDIAN);
        byteBufferOrder.put(this.networkKey).putShort((short) this.networkKeyIndex).put(b).putInt(this.ivIndex).putShort((short) this.unicastAddress);
        return byteBufferOrder.array();
    }

    public byte[] getNetworkKey() {
        return this.networkKey;
    }

    public void setNetworkKey(byte[] bArr) {
        this.networkKey = bArr;
    }

    public int getNetworkKeyIndex() {
        return this.networkKeyIndex;
    }

    public void setNetworkKeyIndex(int i) {
        this.networkKeyIndex = i;
    }

    public byte getKeyRefreshFlag() {
        return this.keyRefreshFlag;
    }

    public void setKeyRefreshFlag(byte b) {
        this.keyRefreshFlag = b;
    }

    public byte getIvUpdateFlag() {
        return this.ivUpdateFlag;
    }

    public void setIvUpdateFlag(byte b) {
        this.ivUpdateFlag = b;
    }

    public int getIvIndex() {
        return this.ivIndex;
    }

    public void setIvIndex(int i) {
        this.ivIndex = i;
    }

    public int getUnicastAddress() {
        return this.unicastAddress;
    }

    public void setUnicastAddress(int i) {
        this.unicastAddress = i;
    }
}
