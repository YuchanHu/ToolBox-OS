package com.telink.ble.mesh.core.provisioning.pdu;

/* loaded from: classes.dex */
public class ProvisioningConfirmPDU implements ProvisioningStatePDU {
    public byte[] confirm;

    @Override // com.telink.ble.mesh.core.provisioning.pdu.ProvisioningStatePDU
    public byte getState() {
        return (byte) 5;
    }

    public ProvisioningConfirmPDU(byte[] bArr) {
        this.confirm = bArr;
    }

    @Override // com.telink.ble.mesh.core.provisioning.pdu.PDU
    public byte[] toBytes() {
        return this.confirm;
    }
}
