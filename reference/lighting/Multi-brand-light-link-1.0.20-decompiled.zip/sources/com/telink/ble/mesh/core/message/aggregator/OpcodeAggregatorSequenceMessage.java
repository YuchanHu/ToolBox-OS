package com.telink.ble.mesh.core.message.aggregator;

import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.networking.AccessType;

/* loaded from: classes.dex */
public class OpcodeAggregatorSequenceMessage extends MeshMessage {
    public OpcodeAggregatorSequenceMessage(int i, AccessType accessType, int i2, byte[] bArr) {
        this.destinationAddress = i;
        this.accessType = accessType;
        this.appKeyIndex = i2;
        this.params = bArr;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.CFG_OP_AGG_SEQ.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_OP_AGG_STATUS.value;
    }
}
