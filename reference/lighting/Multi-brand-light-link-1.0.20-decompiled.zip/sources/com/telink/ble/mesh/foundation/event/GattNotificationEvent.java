package com.telink.ble.mesh.foundation.event;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.foundation.Event;
import java.util.UUID;

/* loaded from: classes.dex */
public class GattNotificationEvent extends Event<String> implements Parcelable {
    public static final Parcelable.Creator<GattNotificationEvent> CREATOR = new Parcelable.Creator<GattNotificationEvent>() { // from class: com.telink.ble.mesh.foundation.event.GattNotificationEvent.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ GattNotificationEvent createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ GattNotificationEvent[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public GattNotificationEvent createFromParcel(Parcel parcel) {
            return new GattNotificationEvent(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public GattNotificationEvent[] newArray(int i) {
            return new GattNotificationEvent[i];
        }
    };
    public static final String EVENT_TYPE_UNEXPECTED_NOTIFY = "com.telink.ble.mesh.EVENT_TYPE_UNEXPECTED_NOTIFY";
    private UUID characteristicUUID;
    private byte[] data;
    private UUID serviceUUID;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public GattNotificationEvent(Object obj, String str, UUID uuid, UUID uuid2, byte[] bArr) {
        super(obj, str);
        this.serviceUUID = uuid;
        this.characteristicUUID = uuid2;
        this.data = bArr;
    }

    protected GattNotificationEvent(Parcel parcel) {
        this.serviceUUID = UUID.fromString(parcel.readString());
        this.characteristicUUID = UUID.fromString(parcel.readString());
        this.data = parcel.createByteArray();
    }

    public UUID getServiceUUID() {
        return this.serviceUUID;
    }

    public UUID getCharacteristicUUID() {
        return this.characteristicUUID;
    }

    public byte[] getData() {
        return this.data;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.serviceUUID.toString());
        parcel.writeString(this.characteristicUUID.toString());
        parcel.writeByteArray(this.data);
    }
}
