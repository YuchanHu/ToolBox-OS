package com.telink.ble.mesh.foundation;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.ParcelUuid;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.SparseArray;
import com.telink.ble.mesh.core.Encipher;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.AccessBridge;
import com.telink.ble.mesh.core.access.BindingBearer;
import com.telink.ble.mesh.core.access.BindingController;
import com.telink.ble.mesh.core.access.FastProvisioningController;
import com.telink.ble.mesh.core.access.RemoteProvisioningController;
import com.telink.ble.mesh.core.access.fu.DistributorType;
import com.telink.ble.mesh.core.access.fu.FUController;
import com.telink.ble.mesh.core.access.fu.FUState;
import com.telink.ble.mesh.core.ble.BleScanner;
import com.telink.ble.mesh.core.ble.GattConnection;
import com.telink.ble.mesh.core.ble.GattOtaController;
import com.telink.ble.mesh.core.ble.GattRequest;
import com.telink.ble.mesh.core.ble.LeScanFilter;
import com.telink.ble.mesh.core.ble.LeScanSetting;
import com.telink.ble.mesh.core.ble.MeshScanRecord;
import com.telink.ble.mesh.core.ble.UUIDInfo;
import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.MessageResponder;
import com.telink.ble.mesh.core.message.NotificationMessage;
import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.StatusMessage;
import com.telink.ble.mesh.core.message.config.NodeIdentity;
import com.telink.ble.mesh.core.message.config.NodeIdentitySetMessage;
import com.telink.ble.mesh.core.message.config.NodeIdentityStatusMessage;
import com.telink.ble.mesh.core.networking.ExtendBearerMode;
import com.telink.ble.mesh.core.networking.NetworkingBridge;
import com.telink.ble.mesh.core.networking.NetworkingController;
import com.telink.ble.mesh.core.provisioning.ProvisioningBridge;
import com.telink.ble.mesh.core.provisioning.ProvisioningController;
import com.telink.ble.mesh.entity.AdvertisingDevice;
import com.telink.ble.mesh.entity.BindingDevice;
import com.telink.ble.mesh.entity.ConnectionFilter;
import com.telink.ble.mesh.entity.FastProvisioningConfiguration;
import com.telink.ble.mesh.entity.FastProvisioningDevice;
import com.telink.ble.mesh.entity.FirmwareUpdateConfiguration;
import com.telink.ble.mesh.entity.MeshAdvFilter;
import com.telink.ble.mesh.entity.MeshUpdatingDevice;
import com.telink.ble.mesh.entity.ProvisioningDevice;
import com.telink.ble.mesh.entity.RemoteProvisioningDevice;
import com.telink.ble.mesh.foundation.MulticastMessageBroker;
import com.telink.ble.mesh.foundation.event.AutoConnectEvent;
import com.telink.ble.mesh.foundation.event.BindingEvent;
import com.telink.ble.mesh.foundation.event.BluetoothEvent;
import com.telink.ble.mesh.foundation.event.FastProvisioningEvent;
import com.telink.ble.mesh.foundation.event.GattConnectionEvent;
import com.telink.ble.mesh.foundation.event.GattNotificationEvent;
import com.telink.ble.mesh.foundation.event.GattOtaEvent;
import com.telink.ble.mesh.foundation.event.MeshEvent;
import com.telink.ble.mesh.foundation.event.NetworkInfoUpdateEvent;
import com.telink.ble.mesh.foundation.event.OnlineStatusEvent;
import com.telink.ble.mesh.foundation.event.ProvisioningEvent;
import com.telink.ble.mesh.foundation.event.ReliableMessageProcessEvent;
import com.telink.ble.mesh.foundation.event.RemoteProvisioningEvent;
import com.telink.ble.mesh.foundation.event.ScanEvent;
import com.telink.ble.mesh.foundation.event.StatusNotificationEvent;
import com.telink.ble.mesh.foundation.parameter.AutoConnectParameters;
import com.telink.ble.mesh.foundation.parameter.BindingParameters;
import com.telink.ble.mesh.foundation.parameter.FastProvisioningParameters;
import com.telink.ble.mesh.foundation.parameter.GattConnectionParameters;
import com.telink.ble.mesh.foundation.parameter.GattOtaParameters;
import com.telink.ble.mesh.foundation.parameter.MeshOtaParameters;
import com.telink.ble.mesh.foundation.parameter.Parameters;
import com.telink.ble.mesh.foundation.parameter.ProvisioningParameters;
import com.telink.ble.mesh.foundation.parameter.ScanParameters;
import com.telink.ble.mesh.util.Arrays;
import com.telink.ble.mesh.util.ContextUtil;
import com.telink.ble.mesh.util.MeshLogger;
import java.nio.ByteBuffer;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/* loaded from: classes.dex */
public final class MeshController implements ProvisioningBridge, NetworkingBridge, AccessBridge {
    private static final long BINDING_NODE_IDENTITY_SCAN_PERIOD = 8000;
    private static final String LOG_TAG = "MeshController";
    private static final int MAX_CONNECT_RETRY = 3;
    private static final int MAX_PROXY_ATTEMPTS = 3;
    private static final int MAX_PROXY_CANDIDATES = 24;
    private static final int PROXY_ADV_TYPE_NETWORK_ID = 0;
    private static final int PROXY_ADV_TYPE_NODE_IDENTITY = 1;
    private static final int PROXY_ADV_TYPE_PRIVATE_NETWORK_ID = 2;
    private static final int PROXY_ADV_TYPE_PRIVATE_NODE_IDENTITY = 3;
    private static final long PROXY_ATTEMPT_TIMEOUT_MS = 6500;
    private static final long PROXY_LAST_SUCCESS_WINDOW_MS = 120000;
    private static final long PROXY_SEARCH_TIMEOUT_MS = 18000;
    private static final long PROXY_SELECTION_WINDOW_MS = 450;
    private static final long TARGET_PROXY_CONNECT_TIMEOUT = 60000;
    private EventCallback eventCallback;
    private FUController fuController;
    private HandlerThread handlerThread;
    private volatile ProxySuccess lastProxySuccess;
    private volatile Parameters mActionParams;
    private BindingController mBindingController;
    private BleScanner mBleScanner;
    private Context mContext;
    private Handler mDelayHandler;
    private FastProvisioningController mFastProvisioningController;
    private GattConnection mGattConnection;
    private GattOtaController mGattOtaController;
    private MulticastMessageBroker mMulticastMessageBroker;
    private NetworkingController mNetworkingController;
    private ProvisioningController mProvisioningController;
    private RemoteProvisioningController mRemoteProvisioningController;
    private MeshConfiguration meshConfiguration;
    private boolean preferReachableProxies;
    private Handler proxyHandler;
    private volatile ProxySearch proxySearch;
    private BluetoothDevice reconnectTarget;
    private volatile Mode actionMode = Mode.IDLE;
    private boolean isDisconnectWaiting = false;
    private final Object SCAN_LOCK = new Object();
    private volatile boolean isScanning = false;
    private Set<AdvertisingDevice> advDevices = new LinkedHashSet();
    private byte[] networkId = null;
    private byte[] networkIdentityKey = null;
    private byte[] networkBeaconKey = null;
    private byte[] privateBeaconKey = null;
    private volatile boolean isLogin = false;
    private boolean isActionStarted = false;
    private int connectRetry = 0;
    private int directDeviceAddress = 0;
    private boolean isProxyReconnect = false;
    private long lastNodeSetTimestamp = 0;
    private long bindingStartTick = 0;
    private BroadcastReceiver mBluetoothReceiver = new BroadcastReceiver() { // from class: com.telink.ble.mesh.foundation.MeshController.1
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) throws NoSuchMethodException, SecurityException {
            String action = intent.getAction();
            if (action != null && "android.bluetooth.adapter.action.STATE_CHANGED".equals(action)) {
                MeshController.access$000(MeshController.this, intent.getIntExtra("android.bluetooth.adapter.extra.STATE", 0));
            }
        }
    };
    private final Runnable DISCONNECTION_TASK = new Runnable() { // from class: com.telink.ble.mesh.foundation.MeshController.3
        @Override // java.lang.Runnable
        public void run() throws NoSuchMethodException, SecurityException {
            if (MeshController.access$700(MeshController.this)) {
                ProxySearch proxySearchAccess$800 = MeshController.access$800(MeshController.this);
                if (proxySearchAccess$800 != null) {
                    if (MeshController.access$900(MeshController.this).isDisconnected()) {
                        MeshController.access$1000(MeshController.this, proxySearchAccess$800);
                        return;
                    }
                    return;
                } else if (MeshController.access$100(MeshController.this) == Mode.MODE_BIND && MeshController.access$1100(MeshController.this)) {
                    MeshController.access$1200(MeshController.this);
                    return;
                } else {
                    MeshController.access$1300(MeshController.this);
                    return;
                }
            }
            if (MeshController.access$100(MeshController.this) == Mode.SCAN || MeshController.access$100(MeshController.this) == Mode.AUTO_CONNECT || (MeshController.access$100(MeshController.this) == Mode.MESH_OTA && MeshController.access$1400(MeshController.this).needAutoConnect())) {
                MeshController.access$1500(MeshController.this);
                return;
            }
            if (MeshController.access$100(MeshController.this) == Mode.REMOTE_PROVISION) {
                RemoteProvisioningDevice provisioningDevice = MeshController.access$1600(MeshController.this).getProvisioningDevice();
                MeshController.access$1600(MeshController.this).clear();
                MeshController.access$1700(MeshController.this, RemoteProvisioningEvent.EVENT_TYPE_REMOTE_PROVISIONING_FAIL, provisioningDevice, "connection interrupt");
                return;
            }
            if (MeshController.access$100(MeshController.this) == Mode.MESH_OTA) {
                MeshController.access$1800(MeshController.this, false, "device disconnected");
                return;
            }
            if (MeshController.access$100(MeshController.this) == Mode.PROVISION || MeshController.access$100(MeshController.this) == Mode.MODE_BIND || MeshController.access$100(MeshController.this) == Mode.GATT_OTA || MeshController.access$100(MeshController.this) == Mode.GATT_CONNECTION || MeshController.access$100(MeshController.this) == Mode.FAST_PROVISION) {
                if (MeshController.access$100(MeshController.this) == Mode.GATT_OTA && MeshController.access$1900(MeshController.this)) {
                    MeshController.access$2000(MeshController.this);
                    return;
                }
                if (MeshController.access$1100(MeshController.this)) {
                    MeshController.access$1200(MeshController.this);
                    return;
                }
                MeshController.access$2108(MeshController.this);
                if (MeshController.access$2100(MeshController.this) >= 3) {
                    MeshController.access$2200(MeshController.this);
                    return;
                }
                if (MeshController.access$100(MeshController.this) == Mode.PROVISION) {
                    ProvisioningDevice provisioningDevice2 = (ProvisioningDevice) MeshController.access$200(MeshController.this).get(Parameters.ACTION_PROVISIONING_TARGET);
                    MeshController.access$2300(MeshController.this, "provisioning connect retry: " + MeshController.access$2100(MeshController.this));
                    MeshController.this.connect(provisioningDevice2.getBluetoothDevice());
                    return;
                }
                if (MeshController.access$100(MeshController.this) == Mode.MODE_BIND || MeshController.access$100(MeshController.this) == Mode.GATT_CONNECTION || MeshController.access$100(MeshController.this) == Mode.GATT_OTA) {
                    BluetoothDevice bluetoothDeviceAccess$2400 = MeshController.access$2400(MeshController.this);
                    if (bluetoothDeviceAccess$2400 != null) {
                        MeshController.this.connect(bluetoothDeviceAccess$2400);
                        return;
                    } else {
                        MeshController.access$1500(MeshController.this);
                        return;
                    }
                }
                MeshController.access$1500(MeshController.this);
            }
        }
    };
    private boolean isGattOtaDisconnectWaiting = false;
    private Runnable GATT_OTA_SUCCESS_TASK = new Runnable() { // from class: com.telink.ble.mesh.foundation.MeshController.4
        @Override // java.lang.Runnable
        public void run() {
            MeshController.access$2000(MeshController.this);
        }
    };
    private GattConnection.ConnectionCallback GATT_CONNECTION_CB = new AnonymousClass5();
    private GattOtaController.GattOtaCallback GATT_OTA_CB = new GattOtaController.GattOtaCallback() { // from class: com.telink.ble.mesh.foundation.MeshController.6
        @Override // com.telink.ble.mesh.core.ble.GattOtaController.GattOtaCallback
        public void onOtaStateChanged(int i) {
            if (i == 0) {
                MeshController.access$3500(MeshController.this, false, "gatt command fail");
                return;
            }
            if (i == 1) {
                MeshController.access$3500(MeshController.this, true, "ota complete");
            } else {
                if (i != 2) {
                    return;
                }
                MeshController meshController = MeshController.this;
                MeshController.access$3700(meshController, MeshController.access$3600(meshController).getOtaProgress());
            }
        }
    };
    private final Runnable restartScanTask = new Runnable() { // from class: com.telink.ble.mesh.foundation.MeshController.7
        @Override // java.lang.Runnable
        public void run() {
            if (MeshController.access$100(MeshController.this) == Mode.AUTO_CONNECT || MeshController.access$100(MeshController.this) == Mode.MESH_OTA) {
                MeshController.access$1500(MeshController.this);
            }
        }
    };
    private BleScanner.ScannerCallback scanCallback = new BleScanner.ScannerCallback() { // from class: com.telink.ble.mesh.foundation.MeshController.8
        @Override // com.telink.ble.mesh.core.ble.BleScanner.ScannerCallback
        public void onStoppedScan() {
        }

        @Override // com.telink.ble.mesh.core.ble.BleScanner.ScannerCallback
        public void onLeScan(BluetoothDevice bluetoothDevice, int i, byte[] bArr) {
            MeshController.access$2300(MeshController.this, "scan:" + bluetoothDevice.getName() + " --mac: " + bluetoothDevice.getAddress() + " --record: " + Arrays.bytesToHexString(bArr, ":"));
            MeshController.access$3800(MeshController.this, bluetoothDevice, i, bArr);
        }

        @Override // com.telink.ble.mesh.core.ble.BleScanner.ScannerCallback
        public void onScanFail(int i) {
            MeshController.access$3902(MeshController.this, false);
            MeshController.access$4000(MeshController.this);
        }

        @Override // com.telink.ble.mesh.core.ble.BleScanner.ScannerCallback
        public void onStartedScan() {
            MeshController.access$3902(MeshController.this, true);
        }

        @Override // com.telink.ble.mesh.core.ble.BleScanner.ScannerCallback
        public void onScanTimeout(boolean z) throws NoSuchMethodException, SecurityException {
            MeshController.access$4100(MeshController.this, z);
        }
    };

    interface EventCallback {
        void onEventPrepared(Event<String> event);
    }

    public enum Mode {
        IDLE,
        SCAN,
        PROVISION,
        AUTO_CONNECT,
        GATT_OTA,
        MODE_BIND,
        REMOTE_PROVISION,
        REMOTE_BIND,
        FAST_PROVISION,
        MESH_OTA,
        GATT_CONNECTION
    }

    @Override // com.telink.ble.mesh.core.networking.NetworkingBridge
    public void onHeartbeatMessageReceived(int i, int i2, byte[] bArr) {
    }

    static /* synthetic */ void access$000(MeshController meshController, int i) throws NoSuchMethodException, SecurityException {
        meshController.onBluetoothStateUpdate(i);
    }

    static /* synthetic */ Mode access$100(MeshController meshController) {
        return meshController.actionMode;
    }

    static /* synthetic */ void access$1000(MeshController meshController, ProxySearch proxySearch) throws NoSuchMethodException, SecurityException {
        meshController.proxyCandidateDisconnected(proxySearch);
    }

    static /* synthetic */ boolean access$1100(MeshController meshController) {
        return meshController.isActionStarted;
    }

    static /* synthetic */ void access$1200(MeshController meshController) {
        meshController.onConnectionInterrupt();
    }

    static /* synthetic */ void access$1300(MeshController meshController) {
        meshController.beginProxySearch();
    }

    static /* synthetic */ FUController access$1400(MeshController meshController) {
        return meshController.fuController;
    }

    static /* synthetic */ void access$1500(MeshController meshController) {
        meshController.startScan();
    }

    static /* synthetic */ RemoteProvisioningController access$1600(MeshController meshController) {
        return meshController.mRemoteProvisioningController;
    }

    static /* synthetic */ void access$1700(MeshController meshController, String str, RemoteProvisioningDevice remoteProvisioningDevice, String str2) {
        meshController.onRemoteProvisioningComplete(str, remoteProvisioningDevice, str2);
    }

    static /* synthetic */ void access$1800(MeshController meshController, boolean z, String str) {
        meshController.dispatchFUState(z, str);
    }

    static /* synthetic */ boolean access$1900(MeshController meshController) {
        return meshController.isGattOtaDisconnectWaiting;
    }

    static /* synthetic */ Parameters access$200(MeshController meshController) {
        return meshController.mActionParams;
    }

    static /* synthetic */ void access$2000(MeshController meshController) {
        meshController.onOtaSuccess();
    }

    static /* synthetic */ int access$2100(MeshController meshController) {
        return meshController.connectRetry;
    }

    static /* synthetic */ int access$2108(MeshController meshController) {
        int i = meshController.connectRetry;
        meshController.connectRetry = i + 1;
        return i;
    }

    static /* synthetic */ void access$2200(MeshController meshController) {
        meshController.onConnectionFail();
    }

    static /* synthetic */ void access$2300(MeshController meshController, String str) {
        meshController.log(str);
    }

    static /* synthetic */ BluetoothDevice access$2400(MeshController meshController) {
        return meshController.reconnectTarget;
    }

    static /* synthetic */ void access$2500(MeshController meshController) {
        meshController.onGattDisconnected();
    }

    static /* synthetic */ Handler access$2600(MeshController meshController) {
        return meshController.mDelayHandler;
    }

    static /* synthetic */ void access$2700(MeshController meshController, ProxySearch proxySearch) throws NoSuchMethodException, SecurityException {
        meshController.proxyCandidateFailed(proxySearch);
    }

    static /* synthetic */ byte[] access$2800(MeshController meshController) {
        return meshController.networkId;
    }

    static /* synthetic */ byte[] access$2900(MeshController meshController) {
        return meshController.networkBeaconKey;
    }

    static /* synthetic */ void access$300(MeshController meshController) {
        meshController.onActionStart();
    }

    static /* synthetic */ NetworkingController access$3000(MeshController meshController) {
        return meshController.mNetworkingController;
    }

    static /* synthetic */ void access$3100(MeshController meshController) {
        meshController.onConnectSuccess();
    }

    static /* synthetic */ void access$3200(MeshController meshController, byte[] bArr) {
        meshController.onOnlineStatusNotify(bArr);
    }

    static /* synthetic */ void access$3300(MeshController meshController, byte[] bArr) throws IllegalStateException, NoSuchAlgorithmException, SignatureException, InvalidKeyException, CertificateException, NoSuchProviderException, InvalidAlgorithmParameterException {
        meshController.onGattNotification(bArr);
    }

    static /* synthetic */ void access$3400(MeshController meshController, UUID uuid, UUID uuid2, byte[] bArr) {
        meshController.onUnexpectedNotify(uuid, uuid2, bArr);
    }

    static /* synthetic */ void access$3500(MeshController meshController, boolean z, String str) {
        meshController.onOtaComplete(z, str);
    }

    static /* synthetic */ GattOtaController access$3600(MeshController meshController) {
        return meshController.mGattOtaController;
    }

    static /* synthetic */ void access$3700(MeshController meshController, int i) {
        meshController.onOtaProgress(i);
    }

    static /* synthetic */ void access$3800(MeshController meshController, BluetoothDevice bluetoothDevice, int i, byte[] bArr) {
        meshController.onScanFilter(bluetoothDevice, i, bArr);
    }

    static /* synthetic */ boolean access$3902(MeshController meshController, boolean z) {
        meshController.isScanning = z;
        return z;
    }

    static /* synthetic */ MeshConfiguration access$400(MeshController meshController) {
        return meshController.meshConfiguration;
    }

    static /* synthetic */ void access$4000(MeshController meshController) {
        meshController.onScanFail();
    }

    static /* synthetic */ void access$4100(MeshController meshController, boolean z) throws NoSuchMethodException, SecurityException {
        meshController.onScanTimeout(z);
    }

    static /* synthetic */ BindingController access$500(MeshController meshController) {
        return meshController.mBindingController;
    }

    static /* synthetic */ boolean access$700(MeshController meshController) {
        return meshController.useProxySelection();
    }

    static /* synthetic */ ProxySearch access$800(MeshController meshController) {
        return meshController.proxySearch;
    }

    static /* synthetic */ GattConnection access$900(MeshController meshController) {
        return meshController.mGattConnection;
    }

    void start(Context context, boolean z) {
        HandlerThread handlerThread = new HandlerThread("Mesh-Controller");
        this.handlerThread = handlerThread;
        handlerThread.start();
        this.mDelayHandler = new Handler(this.handlerThread.getLooper());
        this.preferReachableProxies = z;
        this.proxyHandler = new Handler(this.handlerThread.getLooper());
        this.mContext = context.getApplicationContext();
        initScanningController(this.handlerThread, z);
        initGattConnection(this.handlerThread);
        initGattOtaController();
        initProvisioningController(this.handlerThread);
        initNetworkingController(this.handlerThread);
        initAccessController(this.handlerThread);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.bluetooth.adapter.action.STATE_CHANGED");
        this.mContext.registerReceiver(this.mBluetoothReceiver, intentFilter);
    }

    void clearNetworkCache() {
        NetworkingController networkingController = this.mNetworkingController;
        if (networkingController != null) {
            networkingController.clear();
        }
    }

    void stop() {
        cancelProxySearch();
        this.lastProxySuccess = null;
        this.actionMode = Mode.IDLE;
        this.directDeviceAddress = 0;
        this.isLogin = false;
        stopScan();
        Set<AdvertisingDevice> set = this.advDevices;
        if (set != null) {
            set.clear();
        }
        GattConnection gattConnection = this.mGattConnection;
        if (gattConnection != null) {
            gattConnection.disconnect();
            this.mGattConnection.setConnectionCallback(null);
            this.mGattConnection = null;
        }
        ProvisioningController provisioningController = this.mProvisioningController;
        if (provisioningController != null) {
            provisioningController.clear();
            this.mProvisioningController = null;
        }
        NetworkingController networkingController = this.mNetworkingController;
        if (networkingController != null) {
            networkingController.clear();
            this.mNetworkingController.resetDirectAddress();
            this.mNetworkingController = null;
        }
        BindingController bindingController = this.mBindingController;
        if (bindingController != null) {
            bindingController.clear();
            this.mBindingController = null;
        }
        Handler handler = this.mDelayHandler;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
            this.mDelayHandler = null;
        }
        HandlerThread handlerThread = this.handlerThread;
        if (handlerThread != null) {
            handlerThread.quitSafely();
            this.handlerThread = null;
        }
        this.mContext.unregisterReceiver(this.mBluetoothReceiver);
    }

    Mode getMode() {
        return this.actionMode;
    }

    void checkBluetoothState() {
        onBluetoothStateUpdate(BluetoothAdapter.getDefaultAdapter().getState());
    }

    private void onBluetoothStateUpdate(int i) throws NoSuchMethodException, SecurityException {
        String str;
        switch (i) {
            case 10:
                GattConnection gattConnection = this.mGattConnection;
                if (gattConnection != null) {
                    gattConnection.disconnect();
                }
                str = "bluetooth disabled";
                break;
            case 11:
                str = "bluetooth turning on";
                break;
            case 12:
                str = "bluetooth enabled";
                break;
            case 13:
                str = "bluetooth turning off";
                break;
            default:
                str = "unknown";
                break;
        }
        onBluetoothEvent(i, str);
    }

    void setupMeshNetwork(MeshConfiguration meshConfiguration) {
        cancelProxySearch();
        if (this.preferReachableProxies) {
            this.lastProxySuccess = null;
            this.isLogin = false;
        }
        this.meshConfiguration = meshConfiguration;
        this.networkId = Encipher.k3(meshConfiguration.networkKey);
        this.networkIdentityKey = Encipher.generateIdentityKey(meshConfiguration.networkKey);
        this.networkBeaconKey = Encipher.generateBeaconKey(meshConfiguration.networkKey);
        this.privateBeaconKey = Encipher.generatePrivateBeaconKey(meshConfiguration.networkKey);
        this.mNetworkingController.setup(meshConfiguration);
    }

    void removeDevice(int i) {
        this.meshConfiguration.deviceKeyMap.remove(i);
        this.mNetworkingController.removeDeviceKey(i);
        if (this.actionMode == Mode.AUTO_CONNECT) {
            validateAutoConnectTargets();
        }
    }

    private void initScanningController(HandlerThread handlerThread, boolean z) {
        BluetoothAdapter defaultAdapter = BluetoothAdapter.getDefaultAdapter();
        boolean z2 = z && ContextUtil.SDK_VERSION >= 26 && defaultAdapter != null && defaultAdapter.isLeExtendedAdvertisingSupported();
        BleScanner bleScanner = new BleScanner(z2 ? BleScanner.ScannerType.Lollipop : BleScanner.ScannerType.DEFAULT, handlerThread, z2);
        this.mBleScanner = bleScanner;
        bleScanner.setScannerCallback(this.scanCallback);
    }

    private void initGattConnection(HandlerThread handlerThread) {
        GattConnection gattConnection = new GattConnection(this.mContext, handlerThread, this.preferReachableProxies);
        this.mGattConnection = gattConnection;
        gattConnection.setConnectionCallback(this.GATT_CONNECTION_CB);
    }

    private void initGattOtaController() {
        GattOtaController gattOtaController = new GattOtaController(this.mGattConnection);
        this.mGattOtaController = gattOtaController;
        gattOtaController.setCallback(this.GATT_OTA_CB);
    }

    private void initProvisioningController(HandlerThread handlerThread) {
        ProvisioningController provisioningController = new ProvisioningController(handlerThread);
        this.mProvisioningController = provisioningController;
        provisioningController.setProvisioningBridge(this);
    }

    private void initNetworkingController(HandlerThread handlerThread) {
        GattConnection gattConnection = this.mGattConnection;
        Objects.requireNonNull(gattConnection);
        NetworkingController networkingController = new NetworkingController(handlerThread, new MeshController$$ExternalSyntheticLambda1(gattConnection));
        this.mNetworkingController = networkingController;
        networkingController.setNetworkingBridge(this);
    }

    private void initAccessController(HandlerThread handlerThread) {
        BindingController bindingController = new BindingController(handlerThread);
        this.mBindingController = bindingController;
        bindingController.register(this);
        GattConnection gattConnection = this.mGattConnection;
        Objects.requireNonNull(gattConnection);
        FUController fUController = new FUController(handlerThread, new MeshController$$ExternalSyntheticLambda1(gattConnection));
        this.fuController = fUController;
        fUController.register(this);
        RemoteProvisioningController remoteProvisioningController = new RemoteProvisioningController(handlerThread);
        this.mRemoteProvisioningController = remoteProvisioningController;
        remoteProvisioningController.register(this);
        FastProvisioningController fastProvisioningController = new FastProvisioningController(handlerThread);
        this.mFastProvisioningController = fastProvisioningController;
        fastProvisioningController.register(this);
        MulticastMessageBroker multicastMessageBroker = new MulticastMessageBroker(handlerThread);
        this.mMulticastMessageBroker = multicastMessageBroker;
        multicastMessageBroker.register(this);
    }

    boolean isProxyLogin() {
        GattConnection gattConnection;
        return this.isLogin && (gattConnection = this.mGattConnection) != null && gattConnection.isProxyNodeConnected();
    }

    int getDirectNodeAddress() {
        return this.directDeviceAddress;
    }

    public void idle(boolean z) {
        log("---idle--- " + z);
        cancelProxySearch();
        this.mDelayHandler.removeCallbacksAndMessages(null);
        validateActionMode(Mode.IDLE);
        clearNetworkCache();
        if (z) {
            this.mGattConnection.disconnect();
        }
        stopScan();
    }

    public boolean isBluetoothEnabled() {
        return BluetoothAdapter.getDefaultAdapter().isEnabled();
    }

    public void enableBluetooth() {
        BluetoothAdapter.getDefaultAdapter().enable();
    }

    public String getCurDeviceMac() {
        if (this.mGattConnection.isConnected()) {
            return this.mGattConnection.getMacAddress();
        }
        return null;
    }

    public void stopScan() {
        this.isScanning = false;
        this.mBleScanner.stopScan();
    }

    public void connect(BluetoothDevice bluetoothDevice) {
        stopScan();
        this.mGattConnection.connect(bluetoothDevice);
    }

    public void disconnect() {
        this.mGattConnection.disconnect();
    }

    public void startScan(ScanParameters scanParameters) {
        if (validateActionMode(Mode.SCAN)) {
            this.mDelayHandler.removeCallbacksAndMessages(null);
            this.actionMode = Mode.SCAN;
            this.advDevices.clear();
            this.mActionParams = scanParameters;
            resetAction();
            if (!this.mGattConnection.disconnect()) {
                startScan();
            } else {
                log("waiting for disconnect...");
            }
        }
    }

    private void startScan() {
        log("start scan: " + this.actionMode);
        this.mBleScanner.startScan(useProxySelection() ? null : (LeScanFilter) this.mActionParams.get(Parameters.SCAN_FILTERS), new LeScanSetting(this.mActionParams.getLong(Parameters.COMMON_SCAN_MIN_SPACING, 500L), this.mActionParams.getLong(Parameters.COMMON_SCAN_TIMEOUT, 10000L)));
    }

    boolean startProvisioning(ProvisioningParameters provisioningParameters) {
        log("start provision");
        if (!validateActionMode(Mode.PROVISION)) {
            return false;
        }
        this.mDelayHandler.removeCallbacksAndMessages(null);
        this.actionMode = Mode.PROVISION;
        this.mProvisioningController.setProvisioningBridge(this);
        this.mActionParams = provisioningParameters;
        resetAction();
        ProvisioningDevice provisioningDevice = (ProvisioningDevice) provisioningParameters.get(Parameters.ACTION_PROVISIONING_TARGET);
        rebuildProvisioningDevice(provisioningDevice);
        if (this.mGattConnection.disconnect()) {
            this.isDisconnectWaiting = true;
        } else {
            connect(provisioningDevice.getBluetoothDevice());
        }
        return true;
    }

    boolean continueProvision(int i) throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, InvalidAlgorithmParameterException {
        if (this.actionMode != Mode.PROVISION) {
            MeshLogger.d("continue provision fail : not in provision action -> " + this.actionMode);
            return false;
        }
        log(String.format("continue provision : %04X", Integer.valueOf(i)));
        this.mProvisioningController.continueProvision(i);
        return true;
    }

    boolean continueRemoteProvision(int i) throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, InvalidAlgorithmParameterException {
        if (this.actionMode != Mode.REMOTE_PROVISION) {
            return false;
        }
        this.mRemoteProvisioningController.continueProvision(i);
        return true;
    }

    private void rebuildProvisioningDevice(ProvisioningDevice provisioningDevice) {
        provisioningDevice.setIvIndex(this.meshConfiguration.ivIndex);
        provisioningDevice.setNetworkKey(this.meshConfiguration.networkKey);
        provisioningDevice.setNetworkKeyIndex(this.meshConfiguration.netKeyIndex);
        provisioningDevice.setIvUpdateFlag((byte) 0);
        provisioningDevice.setKeyRefreshFlag((byte) 0);
    }

    void startBinding(BindingParameters bindingParameters) {
        if (!validateActionMode(Mode.MODE_BIND)) {
            log("binding currently");
            return;
        }
        this.mDelayHandler.removeCallbacksAndMessages(null);
        BindingDevice bindingDevice = (BindingDevice) bindingParameters.get(Parameters.ACTION_BINDING_TARGET);
        if (!MeshUtils.validUnicastAddress(bindingDevice.getMeshAddress())) {
            log("start bind fail: node address invalid", 3);
            onBindingFail("node address invalid");
            return;
        }
        this.mActionParams = bindingParameters;
        this.actionMode = Mode.MODE_BIND;
        this.reconnectTarget = null;
        resetAction();
        int meshAddress = bindingDevice.getMeshAddress();
        BindingBearer bearer = bindingDevice.getBearer();
        if (useProxySelection()) {
            if (this.isLogin && this.mGattConnection.isProxyNodeConnected() && (bearer != BindingBearer.GattOnly || this.directDeviceAddress == meshAddress)) {
                onProxyLoginSuccess();
                return;
            } else {
                beginProxySearch();
                return;
            }
        }
        if (this.mGattConnection.isProxyNodeConnected() && (this.directDeviceAddress == meshAddress || bearer == BindingBearer.Any || bearer == BindingBearer.Flex)) {
            onConnectSuccess();
            return;
        }
        this.bindingStartTick = System.currentTimeMillis();
        if (this.mGattConnection.disconnect()) {
            this.isDisconnectWaiting = true;
        } else {
            startScan();
        }
    }

    void startRemoteProvision(RemoteProvisioningDevice remoteProvisioningDevice) {
        if (!validateActionMode(Mode.REMOTE_PROVISION)) {
            log("remote provisioning currently");
            return;
        }
        this.mDelayHandler.removeCallbacksAndMessages(null);
        if (!this.mGattConnection.isProxyNodeConnected()) {
            onRemoteProvisioningComplete(RemoteProvisioningEvent.EVENT_TYPE_REMOTE_PROVISIONING_FAIL, remoteProvisioningDevice, "proxy node not connected");
            return;
        }
        this.actionMode = Mode.REMOTE_PROVISION;
        rebuildProvisioningDevice(remoteProvisioningDevice);
        this.mRemoteProvisioningController.begin(this.mProvisioningController, remoteProvisioningDevice);
    }

    void startFastProvision(FastProvisioningParameters fastProvisioningParameters) {
        if (!validateActionMode(Mode.FAST_PROVISION)) {
            log("fast provisioning currently");
            return;
        }
        this.actionMode = Mode.FAST_PROVISION;
        this.mDelayHandler.removeCallbacksAndMessages(null);
        this.mActionParams = fastProvisioningParameters;
        this.mFastProvisioningController.init((FastProvisioningConfiguration) fastProvisioningParameters.get(Parameters.ACTION_FAST_PROVISION_CONFIG), this.meshConfiguration);
        if (this.mGattConnection.isProxyNodeConnected()) {
            onConnectSuccess();
        } else {
            onEventPrepared(new FastProvisioningEvent(this, FastProvisioningEvent.EVENT_TYPE_FAST_PROVISIONING_CONNECTING));
            startScan();
        }
    }

    void autoConnect(AutoConnectParameters autoConnectParameters) {
        if (!validateActionMode(Mode.AUTO_CONNECT)) {
            log("auto connect currently");
            return;
        }
        this.mDelayHandler.removeCallbacksAndMessages(null);
        this.mActionParams = autoConnectParameters;
        log("auto connect");
        this.actionMode = Mode.AUTO_CONNECT;
        if (validateAutoConnectTargets()) {
            if (useProxySelection()) {
                if (this.isLogin && this.mGattConnection.isProxyNodeConnected()) {
                    onProxyLoginSuccess();
                    return;
                } else {
                    beginProxySearch();
                    return;
                }
            }
            if (this.mGattConnection.isProxyNodeConnected()) {
                if (this.isLogin) {
                    onAutoConnectSuccess();
                    return;
                } else {
                    proxyFilterInit();
                    return;
                }
            }
            if (this.mGattConnection.disconnect()) {
                this.isDisconnectWaiting = true;
            } else {
                startScan();
            }
        }
    }

    void startGattOta(GattOtaParameters gattOtaParameters) {
        if (!validateActionMode(Mode.GATT_OTA)) {
            log("ota running currently");
            return;
        }
        this.mDelayHandler.removeCallbacksAndMessages(null);
        this.mActionParams = gattOtaParameters;
        this.actionMode = Mode.GATT_OTA;
        this.isProxyReconnect = false;
        this.lastNodeSetTimestamp = 0L;
        this.reconnectTarget = null;
        resetAction();
        if (validateGattConnection((ConnectionFilter) gattOtaParameters.get(Parameters.ACTION_CONNECTION_FILTER))) {
            onConnectSuccess();
        } else {
            startSafetyScan();
        }
    }

    void startGattConnection(GattConnectionParameters gattConnectionParameters) {
        if (!validateActionMode(Mode.GATT_CONNECTION)) {
            log("gatt connection running currently");
        }
        this.mDelayHandler.removeCallbacksAndMessages(null);
        this.mActionParams = gattConnectionParameters;
        this.actionMode = Mode.GATT_CONNECTION;
        this.isProxyReconnect = false;
        this.lastNodeSetTimestamp = 0L;
        this.reconnectTarget = null;
        resetAction();
        if (validateGattConnection((ConnectionFilter) gattConnectionParameters.get(Parameters.ACTION_CONNECTION_FILTER))) {
            onConnectSuccess();
        } else {
            startSafetyScan();
        }
    }

    private boolean validateGattConnection(ConnectionFilter connectionFilter) {
        if (!this.mGattConnection.isProxyNodeConnected()) {
            return false;
        }
        if (connectionFilter.type == 2) {
            String str = (String) connectionFilter.target;
            String deviceName = this.mGattConnection.getDeviceName();
            return (TextUtils.isEmpty(deviceName) || TextUtils.isEmpty(str) || !deviceName.equals(str)) ? false : true;
        }
        if (connectionFilter.type != 1) {
            return connectionFilter.type == 0;
        }
        String str2 = (String) connectionFilter.target;
        String macAddress = this.mGattConnection.getMacAddress();
        return (TextUtils.isEmpty(macAddress) || TextUtils.isEmpty(str2) || !macAddress.equalsIgnoreCase(str2)) ? false : true;
    }

    boolean sendGattRequest(GattRequest gattRequest) {
        return this.mGattConnection.sendRequest(gattRequest);
    }

    int getMtu() {
        return this.mGattConnection.getMtu();
    }

    void startMeshOTA(MeshOtaParameters meshOtaParameters) {
        if (!validateActionMode(Mode.MESH_OTA)) {
            log("mesh updating running currently");
            return;
        }
        this.mDelayHandler.removeCallbacksAndMessages(null);
        this.mActionParams = meshOtaParameters;
        this.actionMode = Mode.MESH_OTA;
        this.isProxyReconnect = false;
        this.lastNodeSetTimestamp = 0L;
        resetAction();
        if (this.mGattConnection.isProxyNodeConnected()) {
            onConnectSuccess();
        } else {
            startSafetyScan();
        }
    }

    void stopMeshOta() {
        if (this.actionMode != Mode.MESH_OTA) {
            log("mesh updating stop: not running...");
            return;
        }
        log("stop mesh ota");
        this.mNetworkingController.clear();
        this.fuController.stop();
    }

    private void startSafetyScan() {
        if (this.mGattConnection.disconnect()) {
            this.isDisconnectWaiting = true;
        } else {
            startScan();
        }
    }

    private boolean validateActionMode(Mode mode) {
        if (this.actionMode == mode) {
            MeshLogger.w("mode not changed : " + this.actionMode);
            return false;
        }
        cancelProxySearch();
        if (this.actionMode == Mode.REMOTE_PROVISION) {
            this.mRemoteProvisioningController.clear();
        } else if (this.actionMode == Mode.PROVISION) {
            this.mProvisioningController.clear();
        } else if (this.actionMode == Mode.MODE_BIND) {
            this.mBindingController.clear();
        } else if (this.actionMode == Mode.MESH_OTA) {
            this.fuController.clear();
        } else if (this.actionMode == Mode.FAST_PROVISION) {
            this.mFastProvisioningController.clear();
            this.isLogin = false;
            setupMeshNetwork(this.meshConfiguration);
        }
        this.actionMode = mode;
        return true;
    }

    private void startGattOta() {
        byte[] bArr = (byte[]) this.mActionParams.get(Parameters.ACTION_OTA_FIRMWARE);
        if (bArr == null) {
            onOtaComplete(false, "firmware not found");
        } else {
            onActionStart();
            this.mGattOtaController.begin(bArr);
        }
    }

    private boolean validateAutoConnectTargets() {
        if (this.meshConfiguration.deviceKeyMap.size() != 0) {
            return true;
        }
        idle(false);
        onMeshEvent(MeshEvent.EVENT_TYPE_MESH_EMPTY, "mesh empty");
        return false;
    }

    public void onGattConnectionComplete(boolean z, String str) {
        resetAction();
        idle(false);
        onEventPrepared(new GattConnectionEvent(this, z ? GattConnectionEvent.EVENT_TYPE_CONNECT_SUCCESS : GattConnectionEvent.EVENT_TYPE_CONNECT_FAIL, str));
    }

    private void onBluetoothEvent(int i, String str) {
        BluetoothEvent bluetoothEvent = new BluetoothEvent(this, BluetoothEvent.EVENT_TYPE_BLUETOOTH_STATE_CHANGE);
        bluetoothEvent.setState(i);
        bluetoothEvent.setDesc(str);
        onEventPrepared(bluetoothEvent);
    }

    private void onMeshEvent(String str, String str2) {
        onEventPrepared(new MeshEvent(this, str, str2));
    }

    private void onReliableMessageProcessEvent(String str, boolean z, int i, int i2, int i3, int i4, Integer[] numArr, String str2) {
        ReliableMessageProcessEvent reliableMessageProcessEvent = new ReliableMessageProcessEvent(this, str, z, i, i3, i4, str2);
        reliableMessageProcessEvent.setDest(i2);
        reliableMessageProcessEvent.setRspArr(numArr);
        onEventPrepared(reliableMessageProcessEvent);
    }

    private void onEventPrepared(Event event) {
        EventCallback eventCallback = this.eventCallback;
        if (eventCallback != null) {
            eventCallback.onEventPrepared(event);
        }
    }

    private void onActionStart() {
        this.isActionStarted = true;
    }

    private void resetAction() {
        this.isActionStarted = false;
        this.connectRetry = 0;
    }

    private void onAutoConnectSuccess() {
        this.mGattConnection.enableOnlineStatus();
        onAutoConnectEvent(AutoConnectEvent.EVENT_TYPE_AUTO_CONNECT_LOGIN);
    }

    private void onAutoConnectEvent(String str) {
        onEventPrepared(new AutoConnectEvent(this, str, this.directDeviceAddress));
    }

    public boolean getOnlineStatus() {
        return this.isLogin && this.mGattConnection.getOnlineStatus();
    }

    public void resetExtendBearerMode(ExtendBearerMode extendBearerMode) {
        NetworkingController networkingController = this.mNetworkingController;
        if (networkingController != null) {
            networkingController.setExtendBearerMode(extendBearerMode);
        }
    }

    public boolean sendMeshMessage(MeshMessage meshMessage) {
        if (!this.isLogin) {
            log("not login when sending message");
            return false;
        }
        log("send mesh message: " + meshMessage.getClass().getSimpleName() + String.format(" opcode: 0x%04X -- dst: 0x%04X", Integer.valueOf(meshMessage.getOpcode()), Integer.valueOf(meshMessage.getDestinationAddress())) + " isReliable: " + meshMessage.isReliable() + " retryCnt: " + meshMessage.getRetryCnt() + " rspMax: " + meshMessage.getResponseMax());
        if (meshMessage.useMultiMessageBroker()) {
            return this.mMulticastMessageBroker.sendMessage(meshMessage);
        }
        boolean zSendMeshMessage = this.mNetworkingController.sendMeshMessage(meshMessage);
        if (meshMessage.isReliable()) {
            if (zSendMeshMessage) {
                onReliableMessageProcessEvent(ReliableMessageProcessEvent.EVENT_TYPE_MSG_PROCESSING, false, meshMessage.getOpcode(), meshMessage.getDestinationAddress(), meshMessage.getResponseMax(), 0, null, "mesh message processing");
            } else {
                onReliableMessageProcessEvent(ReliableMessageProcessEvent.EVENT_TYPE_MSG_PROCESS_ERROR, false, meshMessage.getOpcode(), meshMessage.getDestinationAddress(), meshMessage.getResponseMax(), 0, null, "mesh message send fail");
            }
        }
        return zSendMeshMessage;
    }

    private void proxyFilterInit() {
        log("filter init start");
        this.mNetworkingController.proxyFilterInit();
    }

    private void onOnlineStatusNotify(byte[] bArr) {
        onEventPrepared(new OnlineStatusEvent(this, bArr));
    }

    private void onGattNotification(byte[] bArr) throws IllegalStateException, NoSuchAlgorithmException, SignatureException, InvalidKeyException, CertificateException, NoSuchProviderException, InvalidAlgorithmParameterException {
        ProvisioningController provisioningController;
        if (bArr.length > 1) {
            byte b = (byte) (bArr[0] & 63);
            int length = bArr.length - 1;
            byte[] bArr2 = new byte[length];
            System.arraycopy(bArr, 1, bArr2, 0, length);
            if (b == 0) {
                NetworkingController networkingController = this.mNetworkingController;
                if (networkingController != null) {
                    networkingController.parseNetworkPdu(bArr2);
                    return;
                }
                return;
            }
            if (b == 1) {
                NetworkingController networkingController2 = this.mNetworkingController;
                if (networkingController2 != null) {
                    byte b2 = bArr2[0];
                    if (b2 == 1) {
                        networkingController2.parseSecureBeacon(bArr2, this.networkBeaconKey);
                        return;
                    } else {
                        if (b2 == 2) {
                            networkingController2.parsePrivateBeacon(bArr2, this.privateBeaconKey);
                            return;
                        }
                        return;
                    }
                }
                return;
            }
            if (b == 2) {
                NetworkingController networkingController3 = this.mNetworkingController;
                if (networkingController3 != null) {
                    networkingController3.parseProxyConfigurationPdu(bArr2);
                    return;
                }
                return;
            }
            if (b == 3 && (provisioningController = this.mProvisioningController) != null && this.isActionStarted) {
                provisioningController.pushNotification(bArr2);
            }
        }
    }

    private void onUnexpectedNotify(UUID uuid, UUID uuid2, byte[] bArr) {
        onEventPrepared(new GattNotificationEvent(this, GattNotificationEvent.EVENT_TYPE_UNEXPECTED_NOTIFY, uuid, uuid2, bArr));
    }

    private void beginProvision() {
        ProvisioningDevice provisioningDevice = (ProvisioningDevice) this.mActionParams.get(Parameters.ACTION_PROVISIONING_TARGET);
        onProvisionBegin(provisioningDevice, "provision begin");
        this.mProvisioningController.begin(provisioningDevice);
    }

    private void onConnectSuccess() {
        if (this.actionMode == Mode.PROVISION) {
            onActionStart();
            beginProvision();
        } else {
            if (this.actionMode == Mode.FAST_PROVISION) {
                onProxyLoginSuccess();
                return;
            }
            boolean bool = this.mActionParams.getBool(Parameters.COMMON_PROXY_FILTER_INIT_NEEDED, false);
            if ((!this.isLogin && bool) || this.directDeviceAddress == 0) {
                proxyFilterInit();
            } else {
                onProxyLoginSuccess();
            }
        }
    }

    private void setNodeIdentity(int i) {
        log(String.format("set node identity on %04X", Integer.valueOf(i)));
        this.isProxyReconnect = false;
        NodeIdentitySetMessage nodeIdentitySetMessage = new NodeIdentitySetMessage(i);
        nodeIdentitySetMessage.setNetKeyIndex(this.meshConfiguration.netKeyIndex);
        nodeIdentitySetMessage.setIdentity(NodeIdentity.RUNNING.code);
        sendMeshMessage(nodeIdentitySetMessage);
    }

    private void onProxyLoginSuccess() {
        if (useProxySelection()) {
            String macAddress = this.mGattConnection.getMacAddress();
            if (macAddress != null) {
                this.lastProxySuccess = new ProxySuccess(macAddress, SystemClock.elapsedRealtime());
            }
            cancelProxySearch();
        }
        this.isLogin = true;
        switch (AnonymousClass9.$SwitchMap$com$telink$ble$mesh$foundation$MeshController$Mode[this.actionMode.ordinal()]) {
            case 1:
                onAutoConnectSuccess();
                break;
            case 2:
                final Parameters parameters = this.mActionParams;
                this.mDelayHandler.postDelayed(new Runnable() { // from class: com.telink.ble.mesh.foundation.MeshController.2
                    @Override // java.lang.Runnable
                    public void run() {
                        if (MeshController.access$100(MeshController.this) == Mode.MODE_BIND && MeshController.access$200(MeshController.this) == parameters) {
                            MeshController.access$300(MeshController.this);
                            BindingDevice bindingDevice = (BindingDevice) MeshController.access$200(MeshController.this).get(Parameters.ACTION_BINDING_TARGET);
                            int netKeyIndex = bindingDevice.getNetKeyIndex();
                            if (netKeyIndex == -1) {
                                netKeyIndex = MeshController.access$400(MeshController.this).netKeyIndex;
                            }
                            MeshController.access$500(MeshController.this).begin(netKeyIndex, MeshController.access$400(MeshController.this).appKeyMap.get(bindingDevice.getAppKeyIndex()), bindingDevice);
                        }
                    }
                }, 500L);
                break;
            case 3:
                int connectionTarget = getConnectionTarget();
                if (connectionTarget != -1) {
                    setNodeIdentity(connectionTarget);
                    break;
                } else {
                    startGattOta();
                    break;
                }
            case 4:
                int connectionTarget2 = getConnectionTarget();
                if (connectionTarget2 != -1) {
                    setNodeIdentity(connectionTarget2);
                    break;
                } else {
                    onGattConnectionComplete(true, "connect success");
                    break;
                }
            case 5:
                int meshOTATarget = getMeshOTATarget();
                if (meshOTATarget != -1) {
                    setNodeIdentity(meshOTATarget);
                    break;
                } else {
                    onActionStart();
                    FirmwareUpdateConfiguration firmwareUpdateConfiguration = (FirmwareUpdateConfiguration) this.mActionParams.get(Parameters.ACTION_MESH_OTA_CONFIG);
                    rebuildFirmwareUpdatingDevices(firmwareUpdateConfiguration);
                    this.fuController.begin(firmwareUpdateConfiguration, this.directDeviceAddress);
                    break;
                }
            case 6:
                onActionStart();
                this.mFastProvisioningController.begin();
                break;
        }
    }

    private int getConnectionTarget() {
        int iIntValue;
        ConnectionFilter connectionFilter = (ConnectionFilter) this.mActionParams.get(Parameters.ACTION_CONNECTION_FILTER);
        if (connectionFilter.type == 0 && this.directDeviceAddress != (iIntValue = ((Integer) connectionFilter.target).intValue())) {
            return iIntValue;
        }
        return -1;
    }

    private int getMeshOTATarget() {
        FirmwareUpdateConfiguration firmwareUpdateConfiguration = (FirmwareUpdateConfiguration) this.mActionParams.get(Parameters.ACTION_MESH_OTA_CONFIG);
        int proxyAddress = firmwareUpdateConfiguration.getProxyAddress();
        if (firmwareUpdateConfiguration.getDistributorType() != DistributorType.PHONE) {
            return -1;
        }
        log("reconnect proxy device when mesh ota - " + proxyAddress);
        if (this.directDeviceAddress != proxyAddress) {
            return proxyAddress;
        }
        return -1;
    }

    private void rebuildFirmwareUpdatingDevices(FirmwareUpdateConfiguration firmwareUpdateConfiguration) {
        List<MeshUpdatingDevice> updatingDevices = firmwareUpdateConfiguration.getUpdatingDevices();
        Iterator<MeshUpdatingDevice> it = updatingDevices.iterator();
        MeshUpdatingDevice meshUpdatingDevice = null;
        while (it.hasNext()) {
            MeshUpdatingDevice next = it.next();
            if (next.meshAddress == this.directDeviceAddress) {
                it.remove();
                meshUpdatingDevice = next;
            }
        }
        if (meshUpdatingDevice != null) {
            updatingDevices.add(meshUpdatingDevice);
        }
        firmwareUpdateConfiguration.setExtendBearerMode(this.mNetworkingController.getExtendBearerMode());
    }

    private boolean useProxySelection() {
        return this.preferReachableProxies && (this.actionMode == Mode.MODE_BIND || this.actionMode == Mode.AUTO_CONNECT);
    }

    private void cancelProxySearch() {
        this.proxySearch = null;
        Handler handler = this.proxyHandler;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
    }

    private void beginProxySearch() {
        cancelProxySearch();
        final ProxySearch proxySearch = new ProxySearch(null);
        this.proxySearch = proxySearch;
        this.proxyHandler.post(new Runnable() { // from class: com.telink.ble.mesh.foundation.MeshController$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m108x994833e(proxySearch);
            }
        });
    }

    /* renamed from: lambda$beginProxySearch$1$com-telink-ble-mesh-foundation-MeshController, reason: not valid java name */
    /* synthetic */ void m108x994833e(final ProxySearch proxySearch) {
        if (proxySearch == this.proxySearch && useProxySelection()) {
            this.isLogin = false;
            this.directDeviceAddress = 0;
            this.proxyHandler.postDelayed(new Runnable() { // from class: com.telink.ble.mesh.foundation.MeshController$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() throws NoSuchMethodException, SecurityException {
                    this.f$0.m107x941a5cfd(proxySearch);
                }
            }, PROXY_SEARCH_TIMEOUT_MS);
            if (this.mGattConnection.disconnect()) {
                return;
            }
            startScan();
        }
    }

    /* renamed from: lambda$beginProxySearch$0$com-telink-ble-mesh-foundation-MeshController, reason: not valid java name */
    /* synthetic */ void m107x941a5cfd(ProxySearch proxySearch) throws NoSuchMethodException, SecurityException {
        finishProxySearchFailure(proxySearch, "proxy candidates exhausted");
    }

    private void offerProxyCandidate(final ProxySearch proxySearch, final BluetoothDevice bluetoothDevice, final int i, byte[] bArr, byte[] bArr2) {
        if (bArr2 == null || bArr2.length < 9) {
            return;
        }
        int iProxyNodeAddress = proxyNodeAddress(bArr2);
        BindingDevice bindingDevice = this.actionMode == Mode.MODE_BIND ? (BindingDevice) this.mActionParams.get(Parameters.ACTION_BINDING_TARGET) : null;
        final boolean z = bindingDevice != null && iProxyNodeAddress == bindingDevice.getMeshAddress();
        if (bindingDevice == null || bindingDevice.getBearer() != BindingBearer.GattOnly || z) {
            if (iProxyNodeAddress != 0 || validateNetworkId(bArr)) {
                final String address = bluetoothDevice.getAddress();
                this.proxyHandler.post(new Runnable() { // from class: com.telink.ble.mesh.foundation.MeshController$$ExternalSyntheticLambda7
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m111x702f070a(proxySearch, address, bluetoothDevice, i, z);
                    }
                });
            }
        }
    }

    /* renamed from: lambda$offerProxyCandidate$3$com-telink-ble-mesh-foundation-MeshController, reason: not valid java name */
    /* synthetic */ void m111x702f070a(final ProxySearch proxySearch, String str, BluetoothDevice bluetoothDevice, int i, boolean z) {
        if (proxySearch == this.proxySearch && proxySearch.connectingMac == null && !proxySearch.tried.contains(str)) {
            ProxyCandidate proxyCandidate = proxySearch.candidates.get(str);
            if (proxyCandidate != null || proxySearch.candidates.size() < 24) {
                LinkedHashMap<String, ProxyCandidate> linkedHashMap = proxySearch.candidates;
                if (proxyCandidate != null) {
                    i = Math.max(i, proxyCandidate.rssi);
                }
                linkedHashMap.put(str, new ProxyCandidate(bluetoothDevice, i, z || (proxyCandidate != null && proxyCandidate.target)));
                if ((this.actionMode == Mode.AUTO_CONNECT && str.equals(recentProxyMac()) && connectBestProxy(proxySearch)) || proxySearch.selectionQueued) {
                    return;
                }
                proxySearch.selectionQueued = true;
                this.proxyHandler.postDelayed(new Runnable() { // from class: com.telink.ble.mesh.foundation.MeshController$$ExternalSyntheticLambda6
                    @Override // java.lang.Runnable
                    public final void run() throws NoSuchMethodException, SecurityException {
                        this.f$0.m110xfab4e0c9(proxySearch);
                    }
                }, PROXY_SELECTION_WINDOW_MS);
            }
        }
    }

    /* renamed from: lambda$offerProxyCandidate$2$com-telink-ble-mesh-foundation-MeshController, reason: not valid java name */
    /* synthetic */ void m110xfab4e0c9(ProxySearch proxySearch) throws NoSuchMethodException, SecurityException {
        proxySearch.selectionQueued = false;
        connectBestProxy(proxySearch);
    }

    private boolean connectBestProxy(final ProxySearch proxySearch) throws NoSuchMethodException, SecurityException {
        if (proxySearch != this.proxySearch || proxySearch.connectingMac != null || proxySearch.tried.size() >= 3 || proxySearch.candidates.isEmpty()) {
            return false;
        }
        String strRecentProxyMac = recentProxyMac();
        ProxyCandidate proxyCandidate = null;
        if (strRecentProxyMac == null || !proxySearch.candidates.containsKey(strRecentProxyMac)) {
            strRecentProxyMac = null;
        }
        if (strRecentProxyMac == null) {
            for (Map.Entry<String, ProxyCandidate> entry : proxySearch.candidates.entrySet()) {
                ProxyCandidate value = entry.getValue();
                if (proxyCandidate == null || ((value.target && !proxyCandidate.target) || (value.target == proxyCandidate.target && value.rssi > proxyCandidate.rssi))) {
                    strRecentProxyMac = entry.getKey();
                    proxyCandidate = value;
                }
            }
        }
        ProxyCandidate proxyCandidateRemove = proxySearch.candidates.remove(strRecentProxyMac);
        proxySearch.connectingMac = strRecentProxyMac;
        proxySearch.tried.add(strRecentProxyMac);
        proxySearch.disconnecting = false;
        this.directDeviceAddress = 0;
        Runnable runnable = new Runnable() { // from class: com.telink.ble.mesh.foundation.MeshController$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() throws NoSuchMethodException, SecurityException {
                this.f$0.m109x68b857d4(proxySearch);
            }
        };
        proxySearch.attemptTimeout = runnable;
        this.proxyHandler.postDelayed(runnable, PROXY_ATTEMPT_TIMEOUT_MS);
        try {
            connect(proxyCandidateRemove.device);
            return true;
        } catch (RuntimeException unused) {
            proxyCandidateFailed(proxySearch);
            return true;
        }
    }

    /* renamed from: lambda$connectBestProxy$4$com-telink-ble-mesh-foundation-MeshController, reason: not valid java name */
    /* synthetic */ void m109x68b857d4(ProxySearch proxySearch) throws NoSuchMethodException, SecurityException {
        proxyCandidateFailed(proxySearch);
    }

    private String recentProxyMac() {
        ProxySuccess proxySuccess = this.lastProxySuccess;
        if (proxySuccess == null || SystemClock.elapsedRealtime() - proxySuccess.time > PROXY_LAST_SUCCESS_WINDOW_MS) {
            return null;
        }
        return proxySuccess.mac;
    }

    private void proxyCandidateFailed(ProxySearch proxySearch) throws NoSuchMethodException, SecurityException {
        if (proxySearch != this.proxySearch || proxySearch.connectingMac == null || proxySearch.disconnecting) {
            return;
        }
        proxySearch.disconnecting = true;
        this.proxyHandler.removeCallbacks(proxySearch.attemptTimeout);
        this.mNetworkingController.clear();
        if (this.mGattConnection.disconnect()) {
            return;
        }
        proxyCandidateDisconnected(proxySearch);
    }

    private void proxyCandidateDisconnected(ProxySearch proxySearch) throws NoSuchMethodException, SecurityException {
        if (proxySearch != this.proxySearch) {
            return;
        }
        if (proxySearch.attemptTimeout != null) {
            this.proxyHandler.removeCallbacks(proxySearch.attemptTimeout);
            proxySearch.attemptTimeout = null;
        }
        proxySearch.connectingMac = null;
        proxySearch.disconnecting = false;
        if (proxySearch.tried.size() >= 3) {
            finishProxySearchFailure(proxySearch, "proxy candidates exhausted");
        } else {
            if (connectBestProxy(proxySearch)) {
                return;
            }
            startScan();
        }
    }

    private void finishProxySearchFailure(ProxySearch proxySearch, String str) throws NoSuchMethodException, SecurityException {
        if (proxySearch == this.proxySearch && useProxySelection()) {
            boolean z = this.actionMode == Mode.MODE_BIND;
            cancelProxySearch();
            if (z) {
                onBindingFail(str);
                this.mGattConnection.disconnect();
            } else {
                idle(true);
                onAutoConnectEvent(AutoConnectEvent.EVENT_TYPE_AUTO_CONNECT_FAIL);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    static final class ProxySearch {
        Runnable attemptTimeout;
        final LinkedHashMap<String, ProxyCandidate> candidates;
        String connectingMac;
        boolean disconnecting;
        boolean selectionQueued;
        final Set<String> tried;

        private ProxySearch() {
            this.candidates = new LinkedHashMap<>();
            this.tried = new LinkedHashSet();
        }

        /* synthetic */ ProxySearch(AnonymousClass1 anonymousClass1) {
            this();
        }
    }

    private static final class ProxyCandidate {
        final BluetoothDevice device;
        final int rssi;
        final boolean target;

        ProxyCandidate(BluetoothDevice bluetoothDevice, int i, boolean z) {
            this.device = bluetoothDevice;
            this.rssi = i;
            this.target = z;
        }
    }

    private static final class ProxySuccess {
        final String mac;
        final long time;

        ProxySuccess(String str, long j) {
            this.mac = str;
            this.time = j;
        }
    }

    private void onConnectionInterrupt() {
        int i = AnonymousClass9.$SwitchMap$com$telink$ble$mesh$foundation$MeshController$Mode[this.actionMode.ordinal()];
        if (i == 2) {
            onBindingFail("connection interrupt");
            return;
        }
        if (i == 3) {
            onOtaComplete(false, "connection interrupt");
            return;
        }
        if (i == 5) {
            if (this.fuController.isDistributingByDevice()) {
                startScan();
                return;
            } else {
                dispatchFUState(false, "connection interrupt");
                return;
            }
        }
        if (i == 6) {
            onFastProvisioningComplete(false, "connection interrupt");
        } else {
            if (i != 7) {
                return;
            }
            onProvisionFailed(this.mProvisioningController.getProvisioningDevice(), "connection interrupt");
        }
    }

    private void onConnectionFail() {
        switch (this.actionMode) {
            case MODE_BIND:
                onBindingFail("connect fail");
                break;
            case GATT_OTA:
                onOtaComplete(false, "connect fail");
                break;
            case GATT_CONNECTION:
                onGattConnectionComplete(false, "connect fail");
                break;
            case MESH_OTA:
                dispatchFUState(false, "connect fail");
                break;
            case FAST_PROVISION:
                onFastProvisioningComplete(false, "connect fail");
                break;
            case PROVISION:
                onProvisionFailed((ProvisioningDevice) this.mActionParams.get(Parameters.ACTION_PROVISIONING_TARGET), "connect fail");
                break;
        }
    }

    private void onGattDisconnected() {
        this.mDelayHandler.removeCallbacksAndMessages(null);
        onMeshEvent(MeshEvent.EVENT_TYPE_DISCONNECTED, "disconnected when: " + this.actionMode);
        this.mNetworkingController.clear();
        this.mNetworkingController.resetDirectAddress();
        if (this.isDisconnectWaiting) {
            this.isDisconnectWaiting = false;
            this.connectRetry = -1;
        }
        this.isLogin = false;
        this.directDeviceAddress = 0;
        if (this.actionMode != Mode.IDLE) {
            if (this.actionMode == Mode.MESH_OTA && this.fuController.needAutoConnect()) {
                this.fuController.hold();
            }
            this.mDelayHandler.postDelayed(this.DISCONNECTION_TASK, 500L);
        }
    }

    private void onOtaComplete(boolean z, String str) {
        if (z) {
            if (!this.mGattConnection.isConnected()) {
                onOtaSuccess();
                return;
            }
            log("ota complete -> waiting for gatt disconnect cb");
            this.isGattOtaDisconnectWaiting = true;
            this.mDelayHandler.removeCallbacks(this.GATT_OTA_SUCCESS_TASK);
            this.mDelayHandler.postDelayed(this.GATT_OTA_SUCCESS_TASK, 5000L);
            return;
        }
        resetAction();
        idle(false);
        onOtaEvent(GattOtaEvent.EVENT_TYPE_OTA_FAIL, 0, str);
    }

    private void onOtaSuccess() {
        this.mDelayHandler.removeCallbacks(this.GATT_OTA_SUCCESS_TASK);
        this.isGattOtaDisconnectWaiting = false;
        resetAction();
        idle(false);
        onOtaEvent(GattOtaEvent.EVENT_TYPE_OTA_SUCCESS, 0, "OTA Success");
    }

    private void onOtaProgress(int i) {
        onOtaEvent(GattOtaEvent.EVENT_TYPE_OTA_PROGRESS, i, "ota progress update");
    }

    private void onOtaEvent(String str, int i, String str2) {
        onEventPrepared(new GattOtaEvent(this, str, i, str2));
    }

    /* renamed from: com.telink.ble.mesh.foundation.MeshController$5, reason: invalid class name */
    class AnonymousClass5 implements GattConnection.ConnectionCallback {
        @Override // com.telink.ble.mesh.core.ble.GattConnection.ConnectionCallback
        public void onConnected() {
        }

        AnonymousClass5() {
        }

        @Override // com.telink.ble.mesh.core.ble.GattConnection.ConnectionCallback
        public void onDisconnected() {
            MeshController.access$2500(MeshController.this);
        }

        @Override // com.telink.ble.mesh.core.ble.GattConnection.ConnectionCallback
        public void onServicesDiscovered(List<BluetoothGattService> list) {
            MeshController.access$2600(MeshController.this).removeCallbacksAndMessages(null);
            final ProxySearch proxySearchAccess$800 = MeshController.access$800(MeshController.this);
            MeshController.access$2600(MeshController.this).postDelayed(new Runnable() { // from class: com.telink.ble.mesh.foundation.MeshController.5.1
                @Override // java.lang.Runnable
                public void run() throws NoSuchMethodException, SecurityException {
                    ProxySearch proxySearch = proxySearchAccess$800;
                    if (proxySearch == null || (proxySearch == MeshController.access$800(MeshController.this) && proxySearchAccess$800.connectingMac != null)) {
                        if (proxySearchAccess$800 != null && !MeshController.access$900(MeshController.this).isProxyNodeConnected()) {
                            MeshController.access$2700(MeshController.this, proxySearchAccess$800);
                            return;
                        }
                        if (MeshController.access$100(MeshController.this) == Mode.PROVISION) {
                            MeshController.access$900(MeshController.this).provisionInit();
                        } else {
                            MeshController.access$900(MeshController.this).proxyInit();
                            MeshController.access$3000(MeshController.this).checkSequenceNumber(MeshController.access$2800(MeshController.this), MeshController.access$2900(MeshController.this));
                        }
                        MeshController.access$2600(MeshController.this).postDelayed(new Runnable() { // from class: com.telink.ble.mesh.foundation.MeshController.5.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                if (proxySearchAccess$800 == null || (proxySearchAccess$800 == MeshController.access$800(MeshController.this) && proxySearchAccess$800.connectingMac != null)) {
                                    MeshController.access$3100(MeshController.this);
                                }
                            }
                        }, 200L);
                    }
                }
            }, 500L);
        }

        @Override // com.telink.ble.mesh.core.ble.GattConnection.ConnectionCallback
        public void onNotify(UUID uuid, UUID uuid2, byte[] bArr) throws IllegalStateException, NoSuchAlgorithmException, SignatureException, InvalidKeyException, CertificateException, NoSuchProviderException, InvalidAlgorithmParameterException {
            if (uuid2.equals(UUIDInfo.CHARACTERISTIC_ONLINE_STATUS)) {
                byte[] bArrDecryptOnlineStatus = Encipher.decryptOnlineStatus(bArr, MeshController.access$2900(MeshController.this));
                if (bArrDecryptOnlineStatus != null) {
                    MeshController.access$2300(MeshController.this, "online status decrypted data: " + Arrays.bytesToHexString(bArrDecryptOnlineStatus, ":"));
                    MeshController.access$3200(MeshController.this, bArrDecryptOnlineStatus);
                    return;
                }
                MeshController.access$2300(MeshController.this, "online status decrypt err");
                return;
            }
            if (uuid2.equals(UUIDInfo.CHARACTERISTIC_PROXY_OUT) || uuid2.equals(UUIDInfo.CHARACTERISTIC_PB_OUT)) {
                MeshController.access$3300(MeshController.this, bArr);
            } else {
                MeshController.access$3400(MeshController.this, uuid, uuid2, bArr);
            }
        }
    }

    private void onDeviceFound(AdvertisingDevice advertisingDevice) {
        log("on device found: " + advertisingDevice.device.getAddress());
        if (this.advDevices.add(advertisingDevice)) {
            onEventPrepared(new ScanEvent(this, ScanEvent.EVENT_TYPE_DEVICE_FOUND, advertisingDevice));
        } else {
            log("Device already exist");
        }
    }

    private void onScanFail() {
        final ProxySearch proxySearch = this.proxySearch;
        if (proxySearch != null && useProxySelection()) {
            this.proxyHandler.post(new Runnable() { // from class: com.telink.ble.mesh.foundation.MeshController$$ExternalSyntheticLambda4
                @Override // java.lang.Runnable
                public final void run() throws NoSuchMethodException, SecurityException {
                    this.f$0.m113x3fc4e0ef(proxySearch);
                }
            });
        } else if (this.actionMode == Mode.MODE_BIND && ((BindingDevice) this.mActionParams.get(Parameters.ACTION_BINDING_TARGET)).requiresConfirmedBinding()) {
            onBindingFail("proxy scan failed");
        } else {
            onEventPrepared(new ScanEvent(this, ScanEvent.EVENT_TYPE_SCAN_FAIL, null));
        }
    }

    /* renamed from: lambda$onScanFail$5$com-telink-ble-mesh-foundation-MeshController, reason: not valid java name */
    /* synthetic */ void m113x3fc4e0ef(ProxySearch proxySearch) throws NoSuchMethodException, SecurityException {
        if (proxySearch == this.proxySearch && proxySearch.connectingMac == null) {
            finishProxySearchFailure(proxySearch, "proxy scan failed");
        }
    }

    private void onScanTimeout(boolean z) throws NoSuchMethodException, SecurityException {
        ProxySearch proxySearch = this.proxySearch;
        String str = "device not found when scanning";
        if (proxySearch != null && useProxySelection()) {
            this.isScanning = false;
            if (proxySearch.connectingMac != null || connectBestProxy(proxySearch)) {
                return;
            }
            if (!proxySearch.tried.isEmpty()) {
                str = "proxy candidates exhausted";
            }
            finishProxySearchFailure(proxySearch, str);
            return;
        }
        log("scanning timeout: " + this.actionMode);
        switch (AnonymousClass9.$SwitchMap$com$telink$ble$mesh$foundation$MeshController$Mode[this.actionMode.ordinal()]) {
            case 1:
            case 5:
                this.mDelayHandler.postDelayed(this.restartScanTask, 3000L);
                break;
            case 2:
                onBindingFail("device not found when scanning");
                break;
            case 3:
                onOtaComplete(false, "ota fail: scan timeout");
                break;
            case 4:
                onGattConnectionComplete(false, "connection fail: scan timeout");
                break;
            case 6:
                onFastProvisioningComplete(false, "no unprovisioned device found");
                break;
            case 8:
                onScanTimeoutEvent();
                break;
        }
        if (z || ContextUtil.isLocationEnable(this.mContext)) {
            return;
        }
        onLocationDisableWarning();
    }

    private void onScanTimeoutEvent() {
        idle(false);
        onEventPrepared(new ScanEvent(this, ScanEvent.EVENT_TYPE_SCAN_TIMEOUT, null));
    }

    private void onLocationDisableWarning() {
        onEventPrepared(new ScanEvent(this, ScanEvent.EVENT_TYPE_SCAN_LOCATION_WARNING, null));
    }

    private boolean validateProxyAdv(byte[] bArr) {
        byte[] serviceData;
        MeshScanRecord fromBytes = MeshScanRecord.parseFromBytes(bArr);
        if (fromBytes != null && (serviceData = fromBytes.getServiceData(ParcelUuid.fromString(UUIDInfo.SERVICE_PROXY.toString()))) != null && serviceData.length >= 9) {
            byte b = serviceData[0];
            if (b == 0 || b == 2) {
                return validateNetworkId(bArr);
            }
            if (b == 1 || b == 3) {
                boolean zValidateNodeIdentity = validateNodeIdentity(serviceData);
                log("check node identity pass? " + zValidateNodeIdentity);
                return zValidateNodeIdentity;
            }
        }
        return false;
    }

    private boolean validateNetworkId(byte[] bArr) {
        byte[] serviceData;
        MeshScanRecord fromBytes = MeshScanRecord.parseFromBytes(bArr);
        if (fromBytes != null && (serviceData = fromBytes.getServiceData(ParcelUuid.fromString(UUIDInfo.SERVICE_PROXY.toString()))) != null && serviceData.length >= 9) {
            byte b = serviceData[0];
            if (b == 0) {
                byte[] bArr2 = new byte[8];
                System.arraycopy(serviceData, 1, bArr2, 0, 8);
                boolean zEquals = Arrays.equals(this.networkId, bArr2);
                log("check network id pass (normal) ? " + zEquals);
                return zEquals;
            }
            if (b == 2 && serviceData.length >= 17) {
                byte[] bArr3 = new byte[8];
                System.arraycopy(serviceData, 1, bArr3, 0, 8);
                byte[] bArr4 = new byte[8];
                System.arraycopy(serviceData, 9, bArr4, 0, 8);
                byte[] bArrAes = Encipher.aes(ByteBuffer.allocate(16).put(this.networkId).put(bArr4).array(), this.networkIdentityKey);
                if (bArrAes == null || bArrAes.length < 16) {
                    return false;
                }
                byte[] bArr5 = new byte[8];
                System.arraycopy(bArrAes, 8, bArr5, 0, 8);
                boolean zEquals2 = Arrays.equals(bArr3, bArr5);
                log("check network id pass (private) ? " + zEquals2);
                return zEquals2;
            }
            log("check network id error: not broadcasting network id type");
        }
        return false;
    }

    private boolean validateNodeIdentity(byte[] bArr) {
        int iProxyNodeAddress = proxyNodeAddress(bArr);
        if (iProxyNodeAddress == 0) {
            return false;
        }
        this.directDeviceAddress = iProxyNodeAddress;
        log("reset direct device address");
        return true;
    }

    private int proxyNodeAddress(byte[] bArr) {
        if (this.networkIdentityKey != null && bArr != null && bArr.length >= 17) {
            SparseArray<byte[]> sparseArray = this.meshConfiguration.deviceKeyMap;
            for (int i = 0; i < sparseArray.size(); i++) {
                int iKeyAt = sparseArray.keyAt(i);
                if (validateTargetNodeIdentity(bArr, iKeyAt)) {
                    return iKeyAt;
                }
            }
        }
        return 0;
    }

    private boolean validateTargetNodeIdentity(byte[] bArr, int i) {
        byte b;
        byte[] bArrGeneratePrivateNodeIdentityHash;
        boolean zEquals = false;
        if (this.networkIdentityKey != null && bArr != null && bArr.length >= 17 && ((b = bArr[0]) == 1 || b == 3)) {
            byte[] bArr2 = new byte[8];
            System.arraycopy(bArr, 1, bArr2, 0, 8);
            byte[] bArr3 = new byte[8];
            System.arraycopy(bArr, 9, bArr3, 0, 8);
            if (b == 1) {
                log("get node identity hash");
                bArrGeneratePrivateNodeIdentityHash = Encipher.generateNodeIdentityHash(this.networkIdentityKey, bArr3, i);
            } else {
                log("get private node identity hash");
                bArrGeneratePrivateNodeIdentityHash = Encipher.generatePrivateNodeIdentityHash(this.networkIdentityKey, bArr3, i);
            }
            zEquals = Arrays.equals(bArr2, bArrGeneratePrivateNodeIdentityHash);
        }
        log("check target node identity pass? " + zEquals);
        return zEquals;
    }

    private void onScanFilter(BluetoothDevice bluetoothDevice, int i, byte[] bArr) {
        boolean zValidateProxyAdv;
        boolean zEqualsIgnoreCase;
        synchronized (this.SCAN_LOCK) {
            if (this.isScanning) {
                MeshScanRecord fromBytes = MeshScanRecord.parseFromBytes(bArr);
                if (useProxySelection()) {
                    ProxySearch proxySearch = this.proxySearch;
                    if (proxySearch != null && fromBytes != null) {
                        offerProxyCandidate(proxySearch, bluetoothDevice, i, bArr, fromBytes.getProxyServiceData());
                    }
                    return;
                }
                if (this.actionMode == Mode.AUTO_CONNECT) {
                    zValidateProxyAdv = validateProxyAdv(bArr);
                } else {
                    boolean z = true;
                    if (this.actionMode == Mode.GATT_OTA || this.actionMode == Mode.GATT_CONNECTION) {
                        ConnectionFilter connectionFilter = (ConnectionFilter) this.mActionParams.get(Parameters.ACTION_CONNECTION_FILTER);
                        if (connectionFilter == null) {
                            return;
                        }
                        int i2 = connectionFilter.type;
                        if (i2 == 0) {
                            int iIntValue = ((Integer) connectionFilter.target).intValue();
                            if (connectionFilter.advFilter == MeshAdvFilter.NODE_ID_ONLY) {
                                zValidateProxyAdv = validateTargetNodeIdentity(fromBytes.getProxyServiceData(), iIntValue);
                            } else if (connectionFilter.advFilter == MeshAdvFilter.NETWORK_ID_ONLY) {
                                zValidateProxyAdv = validateNetworkId(bArr);
                            } else {
                                long jCurrentTimeMillis = System.currentTimeMillis() - this.lastNodeSetTimestamp;
                                if (this.isProxyReconnect && jCurrentTimeMillis < TARGET_PROXY_CONNECT_TIMEOUT) {
                                    zValidateProxyAdv = validateTargetNodeIdentity(fromBytes.getProxyServiceData(), iIntValue);
                                } else {
                                    zValidateProxyAdv = validateProxyAdv(bArr);
                                }
                                if (zValidateProxyAdv && this.directDeviceAddress == iIntValue) {
                                    this.reconnectTarget = bluetoothDevice;
                                }
                            }
                        } else if (i2 == 1) {
                            String str = (String) connectionFilter.target;
                            zEqualsIgnoreCase = str.equalsIgnoreCase(bluetoothDevice.getAddress());
                            if (zEqualsIgnoreCase) {
                                this.reconnectTarget = bluetoothDevice;
                                MeshLogger.d("connect by mac address: " + str);
                            }
                            zValidateProxyAdv = zEqualsIgnoreCase;
                        } else if (i2 != 2) {
                            zValidateProxyAdv = false;
                        } else {
                            String str2 = (String) connectionFilter.target;
                            if (TextUtils.isEmpty(bluetoothDevice.getName()) || TextUtils.isEmpty(str2) || !bluetoothDevice.getName().equals(str2)) {
                                z = false;
                            }
                            if (z) {
                                this.reconnectTarget = bluetoothDevice;
                                MeshLogger.d("connect by name: " + str2);
                            }
                            zValidateProxyAdv = z;
                        }
                    } else if (this.actionMode == Mode.MODE_BIND) {
                        BindingDevice bindingDevice = (BindingDevice) this.mActionParams.get(Parameters.ACTION_BINDING_TARGET);
                        if (bindingDevice.getBearer() == BindingBearer.GattOnly) {
                            boolean zValidateTargetNodeIdentity = validateTargetNodeIdentity(fromBytes.getProxyServiceData(), bindingDevice.getMeshAddress());
                            log("bind check node identity pass? " + zValidateTargetNodeIdentity);
                            zEqualsIgnoreCase = zValidateTargetNodeIdentity;
                        } else if (bindingDevice.getBearer() != BindingBearer.Flex || System.currentTimeMillis() - this.bindingStartTick > BINDING_NODE_IDENTITY_SCAN_PERIOD) {
                            zEqualsIgnoreCase = validateProxyAdv(bArr);
                        } else {
                            zEqualsIgnoreCase = validateTargetNodeIdentity(fromBytes.getProxyServiceData(), bindingDevice.getMeshAddress());
                        }
                        if (zEqualsIgnoreCase && this.directDeviceAddress == bindingDevice.getMeshAddress()) {
                            this.reconnectTarget = bluetoothDevice;
                        }
                        zValidateProxyAdv = zEqualsIgnoreCase;
                    } else if (this.actionMode == Mode.FAST_PROVISION) {
                        zValidateProxyAdv = z;
                    } else {
                        if (this.actionMode == Mode.SCAN) {
                            if (this.mActionParams.getBool(Parameters.SCAN_SINGLE_MODE, false)) {
                                stopScan();
                            }
                            onDeviceFound(new AdvertisingDevice(bluetoothDevice, i, bArr));
                        } else if (this.actionMode == Mode.MESH_OTA) {
                            FirmwareUpdateConfiguration firmwareUpdateConfiguration = (FirmwareUpdateConfiguration) this.mActionParams.get(Parameters.ACTION_MESH_OTA_CONFIG);
                            int proxyAddress = firmwareUpdateConfiguration.getProxyAddress();
                            if (firmwareUpdateConfiguration.getDistributorType() == DistributorType.PHONE && this.fuController.isDistributingByPhone()) {
                                log("reconnect proxy device when mesh ota - " + proxyAddress);
                                long jCurrentTimeMillis2 = System.currentTimeMillis() - this.lastNodeSetTimestamp;
                                if (this.isProxyReconnect && jCurrentTimeMillis2 < TARGET_PROXY_CONNECT_TIMEOUT) {
                                    zValidateProxyAdv = validateTargetNodeIdentity(fromBytes.getProxyServiceData(), proxyAddress);
                                } else {
                                    zValidateProxyAdv = validateProxyAdv(bArr);
                                }
                            } else {
                                zValidateProxyAdv = validateProxyAdv(bArr);
                            }
                        }
                        zValidateProxyAdv = false;
                    }
                }
                if (zValidateProxyAdv) {
                    this.isScanning = false;
                    connect(bluetoothDevice);
                }
            }
        }
    }

    private void postProvisioningEvent(String str, ProvisioningDevice provisioningDevice, String str2) {
        onEventPrepared(new ProvisioningEvent(this, str, provisioningDevice, str2));
    }

    private void onGetRevisionStart(ProvisioningDevice provisioningDevice, String str) {
        postProvisioningEvent(ProvisioningEvent.EVENT_TYPE_PROVISION_GET_REVISION, provisioningDevice, str);
    }

    private void onProvisionBegin(ProvisioningDevice provisioningDevice, String str) {
        postProvisioningEvent(ProvisioningEvent.EVENT_TYPE_PROVISION_BEGIN, provisioningDevice, str);
    }

    private void onProvisionFailed(ProvisioningDevice provisioningDevice, String str) {
        log("provisioning failed: " + str + " -- " + provisioningDevice.getUnicastAddress());
        onProvisionComplete(false);
        postProvisioningEvent(ProvisioningEvent.EVENT_TYPE_PROVISION_FAIL, provisioningDevice, str);
    }

    private void onProvisionSuccess(ProvisioningDevice provisioningDevice, String str) {
        onProvisionComplete(true);
        this.directDeviceAddress = provisioningDevice.getUnicastAddress();
        postProvisioningEvent(ProvisioningEvent.EVENT_TYPE_PROVISION_SUCCESS, provisioningDevice, str);
    }

    private void onProvisionCapabilityReceived(ProvisioningDevice provisioningDevice, String str) {
        postProvisioningEvent(ProvisioningEvent.EVENT_TYPE_CAPABILITY_RECEIVED, provisioningDevice, str);
    }

    private void onProvisionComplete(boolean z) {
        this.isActionStarted = false;
        idle(!z);
    }

    @Override // com.telink.ble.mesh.core.provisioning.ProvisioningBridge
    public void onProvisionStateChanged(int i, String str) {
        if (i == 4098) {
            log("on device capability received");
            onProvisionCapabilityReceived(this.mProvisioningController.getProvisioningDevice(), "device capability received");
            return;
        }
        if (i == 4107) {
            ProvisioningDevice provisioningDevice = this.mProvisioningController.getProvisioningDevice();
            updateDeviceKeyMap(provisioningDevice.getUnicastAddress(), provisioningDevice.getDeviceKey());
            onProvisionSuccess(provisioningDevice, str);
            log("provision success");
            return;
        }
        if (i != 4108) {
            return;
        }
        log("provision failed, " + str);
        onProvisionFailed(this.mProvisioningController.getProvisioningDevice(), str);
    }

    @Override // com.telink.ble.mesh.core.provisioning.ProvisioningBridge
    public void onCommandPrepared(byte b, byte[] bArr) {
        GattConnection gattConnection = this.mGattConnection;
        if (gattConnection != null) {
            gattConnection.sendMeshData(b, bArr);
        }
    }

    @Override // com.telink.ble.mesh.core.networking.NetworkingBridge
    public void onNetworkInfoUpdate(int i, int i2) {
        this.meshConfiguration.sequenceNumber = i;
        if (this.actionMode != Mode.FAST_PROVISION) {
            this.meshConfiguration.ivIndex = i2;
        }
        handleNetworkInfoUpdate(i, this.meshConfiguration.ivIndex);
    }

    public void handleNetworkInfoUpdate(int i, int i2) {
        log(String.format("handleNetworkInfoUpdate : sequenceNumber -- %06X | ivIndex -- %08X", Integer.valueOf(i), Integer.valueOf(i2)));
        onEventPrepared(new NetworkInfoUpdateEvent(this, NetworkInfoUpdateEvent.EVENT_TYPE_NETWORKD_INFO_UPDATE, i, i2));
    }

    @Override // com.telink.ble.mesh.core.networking.NetworkingBridge
    public void onMeshMessageReceived(int i, int i2, int i3, byte[] bArr) throws IllegalStateException, NoSuchAlgorithmException, SignatureException, InvalidKeyException, CertificateException, NoSuchProviderException, InvalidAlgorithmParameterException {
        log(String.format("mesh model message received: src -- 0x%04X | dst -- 0x%04X | opcode -- 0x%04X | params -- ", Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3)) + Arrays.bytesToHexString(bArr, "") + " | action mode -- " + this.actionMode);
        onMeshMessageNotification(new NotificationMessage(i, i2, i3, bArr));
    }

    @Override // com.telink.ble.mesh.core.networking.NetworkingBridge
    public void onProxyInitComplete(final boolean z, final int i) throws NoSuchMethodException, SecurityException {
        log("filter init complete, success? " + z);
        if (useProxySelection()) {
            final ProxySearch proxySearch = this.proxySearch;
            if (proxySearch != null) {
                this.proxyHandler.post(new Runnable() { // from class: com.telink.ble.mesh.foundation.MeshController$$ExternalSyntheticLambda2
                    @Override // java.lang.Runnable
                    public final void run() throws NoSuchMethodException, SecurityException {
                        this.f$0.m112x67313374(proxySearch, z, i);
                    }
                });
                return;
            }
            return;
        }
        if (z) {
            this.directDeviceAddress = i;
            onProxyLoginSuccess();
        } else {
            log("proxy init fail!", 3);
            this.mGattConnection.disconnect();
        }
    }

    /* renamed from: lambda$onProxyInitComplete$6$com-telink-ble-mesh-foundation-MeshController, reason: not valid java name */
    /* synthetic */ void m112x67313374(ProxySearch proxySearch, boolean z, int i) throws NoSuchMethodException, SecurityException {
        if (proxySearch != this.proxySearch || proxySearch.connectingMac == null || proxySearch.disconnecting) {
            return;
        }
        if (z && this.mGattConnection.isProxyNodeConnected()) {
            this.directDeviceAddress = i;
            onProxyLoginSuccess();
        } else {
            proxyCandidateFailed(proxySearch);
        }
    }

    @Override // com.telink.ble.mesh.core.networking.NetworkingBridge
    public void onReliableMessageComplete(boolean z, int i, int i2, int i3, int i4, Integer[] numArr) {
        if (this.actionMode == Mode.MODE_BIND) {
            this.mBindingController.onBindingCommandComplete(z, i, i3, i4);
        } else if (this.actionMode == Mode.MESH_OTA) {
            this.fuController.onUpdatingCommandComplete(z, i, i3, i4);
        } else if (this.actionMode == Mode.REMOTE_PROVISION) {
            this.mRemoteProvisioningController.onRemoteProvisioningCommandComplete(z, i, i3, i4);
        } else if (this.actionMode == Mode.FAST_PROVISION) {
            this.mFastProvisioningController.onFastProvisioningCommandComplete(z, i, i3, i4);
        }
        if (this.mMulticastMessageBroker.isBrokerBusy()) {
            this.mMulticastMessageBroker.onMessageComplete(z, i, numArr);
        }
        if (!z) {
            onInnerMessageFailed(i);
        }
        onReliableMessageProcessEvent(ReliableMessageProcessEvent.EVENT_TYPE_MSG_PROCESS_COMPLETE, z, i, i2, i3, i4, numArr, "mesh message send complete");
    }

    @Override // com.telink.ble.mesh.core.networking.NetworkingBridge
    public void onSegmentMessageComplete(boolean z) {
        if (this.actionMode == Mode.MESH_OTA) {
            this.fuController.onSegmentComplete(z);
        }
    }

    public void onInnerMessageFailed(int i) {
        if (i == Opcode.NODE_ID_SET.value) {
            if (this.actionMode == Mode.GATT_OTA) {
                onOtaComplete(false, "node identity set failed");
            } else if (this.actionMode == Mode.GATT_CONNECTION) {
                onGattConnectionComplete(false, "node identity set failed");
            }
        }
    }

    private void onInnerMessageHandle(NotificationMessage notificationMessage) {
        int src = notificationMessage.getSrc();
        int opcode = notificationMessage.getOpcode();
        if (opcode == Opcode.NODE_RESET_STATUS.value) {
            this.meshConfiguration.deviceKeyMap.delete(src);
            if (this.actionMode == Mode.AUTO_CONNECT) {
                validateAutoConnectTargets();
                return;
            }
            return;
        }
        if (opcode == Opcode.NODE_ID_STATUS.value) {
            NodeIdentityStatusMessage nodeIdentityStatusMessage = (NodeIdentityStatusMessage) notificationMessage.getStatusMessage();
            if (this.actionMode == Mode.GATT_OTA || this.actionMode == Mode.GATT_CONNECTION) {
                ConnectionFilter connectionFilter = (ConnectionFilter) this.mActionParams.get(Parameters.ACTION_CONNECTION_FILTER);
                if (connectionFilter.type == 0) {
                    onNodeIdentityStatusMessageReceived(src, nodeIdentityStatusMessage, ((Integer) connectionFilter.target).intValue());
                    return;
                }
                return;
            }
            if (this.actionMode == Mode.MESH_OTA) {
                FirmwareUpdateConfiguration firmwareUpdateConfiguration = (FirmwareUpdateConfiguration) this.mActionParams.get(Parameters.ACTION_MESH_OTA_CONFIG);
                int proxyAddress = firmwareUpdateConfiguration.getProxyAddress();
                if (firmwareUpdateConfiguration.getDistributorType() == DistributorType.PHONE) {
                    onNodeIdentityStatusMessageReceived(src, nodeIdentityStatusMessage, proxyAddress);
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0041  */
    /* JADX WARN: Removed duplicated region for block: B:13:0x004d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void onNodeIdentityStatusMessageReceived(int r3, com.telink.ble.mesh.core.message.config.NodeIdentityStatusMessage r4, int r5) {
        /*
            r2 = this;
            if (r3 != r5) goto L6a
            int r3 = r4.getStatus()
            com.telink.ble.mesh.core.message.config.ConfigStatus r5 = com.telink.ble.mesh.core.message.config.ConfigStatus.SUCCESS
            int r5 = r5.code
            r0 = 1
            r1 = 0
            if (r3 != r5) goto L30
            int r3 = r4.getIdentity()
            com.telink.ble.mesh.core.message.config.NodeIdentity r4 = com.telink.ble.mesh.core.message.config.NodeIdentity.RUNNING
            byte r4 = r4.code
            if (r3 != r4) goto L21
            java.lang.String r3 = "reconnect target device"
            r2.log(r3)
            java.lang.String r3 = ""
            r4 = r0
            goto L3f
        L21:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r5 = "node identity check error: "
            r4.<init>(r5)
            r4.append(r3)
            java.lang.String r3 = r4.toString()
            goto L3e
        L30:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r5 = "node identity status error: "
            r4.<init>(r5)
            r4.append(r3)
            java.lang.String r3 = r4.toString()
        L3e:
            r4 = r1
        L3f:
            if (r4 == 0) goto L4d
            r2.isProxyReconnect = r0
            long r3 = java.lang.System.currentTimeMillis()
            r2.lastNodeSetTimestamp = r3
            r2.startSafetyScan()
            goto L6a
        L4d:
            com.telink.ble.mesh.foundation.MeshController$Mode r4 = r2.actionMode
            com.telink.ble.mesh.foundation.MeshController$Mode r5 = com.telink.ble.mesh.foundation.MeshController.Mode.GATT_OTA
            if (r4 != r5) goto L57
            r2.onOtaComplete(r1, r3)
            goto L6a
        L57:
            com.telink.ble.mesh.foundation.MeshController$Mode r4 = r2.actionMode
            com.telink.ble.mesh.foundation.MeshController$Mode r5 = com.telink.ble.mesh.foundation.MeshController.Mode.GATT_CONNECTION
            if (r4 != r5) goto L61
            r2.onGattConnectionComplete(r1, r3)
            goto L6a
        L61:
            com.telink.ble.mesh.foundation.MeshController$Mode r4 = r2.actionMode
            com.telink.ble.mesh.foundation.MeshController$Mode r5 = com.telink.ble.mesh.foundation.MeshController.Mode.MESH_OTA
            if (r4 != r5) goto L6a
            r2.dispatchFUState(r1, r3)
        L6a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.telink.ble.mesh.foundation.MeshController.onNodeIdentityStatusMessageReceived(int, com.telink.ble.mesh.core.message.config.NodeIdentityStatusMessage, int):void");
    }

    private void onMeshMessageNotification(NotificationMessage notificationMessage) throws IllegalStateException, NoSuchAlgorithmException, SignatureException, InvalidKeyException, CertificateException, NoSuchProviderException, InvalidAlgorithmParameterException {
        String name;
        onInnerMessageHandle(notificationMessage);
        if (this.actionMode == Mode.MODE_BIND) {
            this.mBindingController.onMessageNotification(notificationMessage);
        } else if (this.actionMode == Mode.MESH_OTA) {
            this.fuController.onMessageNotification(notificationMessage);
        } else if (this.actionMode == Mode.REMOTE_PROVISION) {
            this.mRemoteProvisioningController.onMessageNotification(notificationMessage);
        } else if (this.actionMode == Mode.FAST_PROVISION) {
            this.mFastProvisioningController.onMessageNotification(notificationMessage);
        }
        this.mMulticastMessageBroker.onMessageNotification(notificationMessage);
        StatusMessage statusMessage = notificationMessage.getStatusMessage();
        if (statusMessage == null) {
            name = StatusNotificationEvent.EVENT_TYPE_NOTIFICATION_MESSAGE_UNKNOWN;
        } else {
            name = statusMessage.getClass().getName();
        }
        log("mesh message notification: " + name);
        onEventPrepared(new StatusNotificationEvent(this, name, notificationMessage));
    }

    @Override // com.telink.ble.mesh.core.access.AccessBridge
    public boolean onAccessMessagePrepared(MeshMessage meshMessage, int i) throws IllegalStateException, NoSuchAlgorithmException, SignatureException, InvalidKeyException, CertificateException, NoSuchProviderException, InvalidAlgorithmParameterException {
        if (meshMessage.getDestinationAddress() == 0) {
            if (!meshMessage.isReliable()) {
                return true;
            }
            onMeshMessageNotification(MessageResponder.responseMessage(meshMessage));
            return true;
        }
        return sendMeshMessage(meshMessage);
    }

    private void onBindingSuccess(String str) {
        onBindingComplete();
        onEventPrepared(new BindingEvent(this, BindingEvent.EVENT_TYPE_BIND_SUCCESS, this.mBindingController.getBindingDevice(), str));
    }

    private void onBindingFail(String str) {
        onBindingComplete();
        onEventPrepared(new BindingEvent(this, BindingEvent.EVENT_TYPE_BIND_FAIL, (BindingDevice) this.mActionParams.get(Parameters.ACTION_BINDING_TARGET), str));
    }

    private void onBindingComplete() {
        this.mNetworkingController.clear();
        this.isActionStarted = false;
        idle(false);
    }

    private void dispatchFUState(boolean z, String str) {
        if (!z) {
            this.fuController.dispatchError(str);
        }
        this.isActionStarted = false;
        idle(false);
    }

    private void onRemoteProvisioningComplete(String str, RemoteProvisioningDevice remoteProvisioningDevice, String str2) {
        idle(false);
        RemoteProvisioningEvent remoteProvisioningEvent = new RemoteProvisioningEvent(this, str);
        remoteProvisioningEvent.setRemoteProvisioningDevice(remoteProvisioningDevice);
        remoteProvisioningEvent.setDesc(str2);
        onEventPrepared(remoteProvisioningEvent);
    }

    private void onRemoteCapabilityReceived(RemoteProvisioningDevice remoteProvisioningDevice, String str) {
        RemoteProvisioningEvent remoteProvisioningEvent = new RemoteProvisioningEvent(this, RemoteProvisioningEvent.EVENT_TYPE_REMOTE_CAPABILITY_RECEIVED);
        remoteProvisioningEvent.setRemoteProvisioningDevice(remoteProvisioningDevice);
        remoteProvisioningEvent.setDesc(str);
        onEventPrepared(remoteProvisioningEvent);
    }

    private void updateDeviceKeyMap(int i, byte[] bArr) {
        this.mNetworkingController.addDeviceKey(i, bArr);
        this.meshConfiguration.deviceKeyMap.put(i, bArr);
    }

    @Override // com.telink.ble.mesh.core.access.AccessBridge
    public void onAccessStateChanged(int i, String str, int i2, Object obj) {
        log("access state changed: " + i + " -- " + str);
        if (this.actionMode == Mode.MODE_BIND && i2 == 1) {
            if (i == 0) {
                onBindingFail(str);
                return;
            } else {
                if (i == 1) {
                    onBindingSuccess(str);
                    return;
                }
                return;
            }
        }
        if (this.actionMode == Mode.MESH_OTA && i2 == 2) {
            if (i == FUState.UPDATE_COMPLETE.value || i == FUState.UPDATE_FAIL.value) {
                this.isActionStarted = false;
                idle(false);
                return;
            }
            return;
        }
        if (this.actionMode != Mode.REMOTE_PROVISION || i2 != 3) {
            if (this.actionMode == Mode.FAST_PROVISION && i2 == 4) {
                onFastPvStateChanged(i, str, obj);
                return;
            } else {
                if (i2 == 5) {
                    onMulticastMsgBrokerStateChanged(i, str, obj);
                    return;
                }
                return;
            }
        }
        if (i == 5) {
            onRemoteProvisioningComplete(RemoteProvisioningEvent.EVENT_TYPE_REMOTE_PROVISIONING_FAIL, (RemoteProvisioningDevice) obj, "remote provisioning fail");
            return;
        }
        if (i == 4) {
            RemoteProvisioningDevice remoteProvisioningDevice = (RemoteProvisioningDevice) obj;
            updateDeviceKeyMap(remoteProvisioningDevice.getUnicastAddress(), remoteProvisioningDevice.getDeviceKey());
            onRemoteProvisioningComplete(RemoteProvisioningEvent.EVENT_TYPE_REMOTE_PROVISIONING_SUCCESS, remoteProvisioningDevice, "remote provisioning success");
        } else if (i == 3) {
            onRemoteCapabilityReceived((RemoteProvisioningDevice) obj, "remote provisioning success");
        }
    }

    private void onFastPvStateChanged(int i, String str, Object obj) {
        if (i == 22) {
            FastProvisioningEvent fastProvisioningEvent = new FastProvisioningEvent(this, FastProvisioningEvent.EVENT_TYPE_FAST_PROVISIONING_SET_ADDRESS_SUCCESS);
            fastProvisioningEvent.setFastProvisioningDevice((FastProvisioningDevice) obj);
            onEventPrepared(fastProvisioningEvent);
            return;
        }
        if (i == 24 || i == 25) {
            onFastProvisioningComplete(i == 25, str);
            return;
        }
        if (i == 32) {
            FastProvisioningEvent fastProvisioningEvent2 = new FastProvisioningEvent(this, FastProvisioningEvent.EVENT_TYPE_FAST_PROVISIONING_SET_ADDRESS_FAIL);
            fastProvisioningEvent2.setFastProvisioningDevice((FastProvisioningDevice) obj);
            onEventPrepared(fastProvisioningEvent2);
            return;
        }
        if (i != 33) {
            switch (i) {
                case 17:
                    switchNetworking(false);
                    onEventPrepared(new FastProvisioningEvent(this, FastProvisioningEvent.EVENT_TYPE_FAST_PROVISIONING_RESET_NWK));
                    break;
                case 18:
                    onEventPrepared(new FastProvisioningEvent(this, FastProvisioningEvent.EVENT_TYPE_FAST_PROVISIONING_GET_ADDRESS));
                    break;
                case 19:
                    FastProvisioningDevice fastProvisioningDevice = (FastProvisioningDevice) obj;
                    updateDeviceKeyMap(fastProvisioningDevice.getNewAddress(), fastProvisioningDevice.getDeviceKey());
                    FastProvisioningEvent fastProvisioningEvent3 = new FastProvisioningEvent(this, FastProvisioningEvent.EVENT_TYPE_FAST_PROVISIONING_SET_ADDRESS);
                    fastProvisioningEvent3.setFastProvisioningDevice(fastProvisioningDevice);
                    onEventPrepared(fastProvisioningEvent3);
                    break;
                case 20:
                    onEventPrepared(new FastProvisioningEvent(this, FastProvisioningEvent.EVENT_TYPE_FAST_PROVISIONING_SET_DATA));
                    break;
            }
            return;
        }
        FastProvisioningEvent fastProvisioningEvent4 = new FastProvisioningEvent(this, FastProvisioningEvent.EVENT_TYPE_FAST_PROVISIONING_GET_ADDRESS_RSP);
        fastProvisioningEvent4.setFastProvisioningDevice((FastProvisioningDevice) obj);
        onEventPrepared(fastProvisioningEvent4);
    }

    private void onFastProvisioningComplete(boolean z, String str) {
        String str2;
        switchNetworking(true);
        this.isLogin = false;
        idle(false);
        resetAction();
        if (z) {
            str2 = FastProvisioningEvent.EVENT_TYPE_FAST_PROVISIONING_SUCCESS;
        } else {
            str2 = FastProvisioningEvent.EVENT_TYPE_FAST_PROVISIONING_FAIL;
        }
        FastProvisioningEvent fastProvisioningEvent = new FastProvisioningEvent(this, str2);
        fastProvisioningEvent.setDesc(str);
        onEventPrepared(fastProvisioningEvent);
    }

    public void switchNetworking(boolean z) {
        log("switch networking: " + z);
        if (z) {
            log("setup config back: " + this.meshConfiguration.ivIndex);
            this.mNetworkingController.setup(this.meshConfiguration);
            return;
        }
        FastProvisioningConfiguration configuration = this.mFastProvisioningController.getConfiguration();
        MeshConfiguration meshConfiguration = new MeshConfiguration();
        meshConfiguration.sequenceNumber = this.meshConfiguration.sequenceNumber;
        meshConfiguration.ivIndex = configuration.getIvIndex();
        meshConfiguration.deviceKeyMap = new SparseArray<>();
        meshConfiguration.netKeyIndex = configuration.getDefaultNetworkKeyIndex();
        meshConfiguration.networkKey = configuration.getDefaultNetworkKey();
        meshConfiguration.appKeyMap = new SparseArray<>();
        meshConfiguration.appKeyMap.put(configuration.getDefaultAppKeyIndex(), configuration.getDefaultAppKey());
        meshConfiguration.localAddress = this.meshConfiguration.localAddress;
        log("setup config fast: " + meshConfiguration.ivIndex);
        this.mNetworkingController.setup(meshConfiguration);
    }

    private void onMulticastMsgBrokerStateChanged(int i, String str, Object obj) {
        if (i != 3 && i == 4) {
            MulticastMessageBroker.Result result = (MulticastMessageBroker.Result) obj;
            if (this.actionMode == Mode.MESH_OTA) {
                this.fuController.onMulticastMessageComplete(result.opcode, result.remainingNodes);
            }
        }
    }

    public void setEventCallback(EventCallback eventCallback) {
        this.eventCallback = eventCallback;
    }

    private void log(String str) {
        log(str, 1);
    }

    private void log(String str, int i) {
        MeshLogger.log(str, LOG_TAG, i);
    }
}
