package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class DefaultTTLSetMessage extends ConfigMessage {
    public byte newTTL;

    public DefaultTTLSetMessage(int i) {
        super(i);
    }

    public static DefaultTTLSetMessage getSimple(int i, byte b) {
        DefaultTTLSetMessage defaultTTLSetMessage = new DefaultTTLSetMessage(i);
        defaultTTLSetMessage.newTTL = b;
        return defaultTTLSetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.CFG_DEFAULT_TTL_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_DEFAULT_TTL_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return new byte[]{this.newTTL};
    }
}
