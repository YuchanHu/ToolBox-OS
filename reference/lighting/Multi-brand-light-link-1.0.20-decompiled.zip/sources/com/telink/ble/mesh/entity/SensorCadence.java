package com.telink.ble.mesh.entity;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.DeviceProperty;
import com.telink.ble.mesh.core.MeshUtils;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public final class SensorCadence implements Serializable, Parcelable {
    public static final Parcelable.Creator<SensorCadence> CREATOR = new Parcelable.Creator<SensorCadence>() { // from class: com.telink.ble.mesh.entity.SensorCadence.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SensorCadence createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SensorCadence[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SensorCadence createFromParcel(Parcel parcel) {
            return new SensorCadence(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SensorCadence[] newArray(int i) {
            return new SensorCadence[i];
        }
    };
    public byte[] fastCadenceHigh;
    public byte[] fastCadenceLow;
    public byte fastCadencePeriodDivisor;
    public int propertyID;
    public byte statusMinInterval;
    public byte[] statusTriggerDeltaDown;
    public byte[] statusTriggerDeltaUp;
    public int statusTriggerType;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    protected SensorCadence(Parcel parcel) {
        this.propertyID = parcel.readInt();
        this.fastCadencePeriodDivisor = parcel.readByte();
        this.statusTriggerType = parcel.readInt();
        this.statusTriggerDeltaDown = parcel.createByteArray();
        this.statusTriggerDeltaUp = parcel.createByteArray();
        this.statusMinInterval = parcel.readByte();
        this.fastCadenceLow = parcel.createByteArray();
        this.fastCadenceHigh = parcel.createByteArray();
    }

    public static SensorCadence fromBytes(byte[] bArr) {
        int i;
        int i2;
        SensorCadence sensorCadence = new SensorCadence();
        int iBytes2Integer = MeshUtils.bytes2Integer(bArr, 0, 2, ByteOrder.LITTLE_ENDIAN);
        sensorCadence.propertyID = iBytes2Integer;
        byte b = bArr[2];
        sensorCadence.fastCadencePeriodDivisor = (byte) (b & 127);
        int i3 = 1;
        int i4 = (b >> 7) & 1;
        sensorCadence.statusTriggerType = i4;
        if (i4 == 0) {
            if (iBytes2Integer == DeviceProperty.PRESENT_AMBIENT_LIGHT_LEVEL.id) {
                i2 = DeviceProperty.PRESENT_AMBIENT_LIGHT_LEVEL.len;
            } else {
                if (sensorCadence.propertyID == DeviceProperty.MOTION_SENSED.id) {
                    i2 = DeviceProperty.MOTION_SENSED.len;
                }
                i = i3;
            }
            i3 = i2;
            i = i3;
        } else {
            i = 2;
        }
        byte[] bArr2 = new byte[i3];
        sensorCadence.statusTriggerDeltaDown = bArr2;
        System.arraycopy(bArr, 2, bArr2, 0, i3);
        int i5 = 2 + i3;
        byte[] bArr3 = new byte[i3];
        sensorCadence.statusTriggerDeltaUp = bArr3;
        System.arraycopy(bArr, i5, bArr3, 0, i3);
        int i6 = i5 + i3;
        int i7 = i6 + 1;
        sensorCadence.statusMinInterval = bArr[i6];
        byte[] bArr4 = new byte[i];
        sensorCadence.fastCadenceLow = bArr4;
        System.arraycopy(bArr, i7, bArr4, 0, i);
        byte[] bArr5 = new byte[i];
        sensorCadence.fastCadenceHigh = bArr5;
        System.arraycopy(bArr, i7 + i3, bArr5, 0, i);
        return sensorCadence;
    }

    public SensorCadence() {
    }

    public byte[] toBytes() {
        return ByteBuffer.allocate(this.statusTriggerDeltaDown.length + 3 + this.statusTriggerDeltaUp.length + 1 + this.fastCadenceLow.length + this.fastCadenceHigh.length).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.propertyID).put((byte) (this.fastCadencePeriodDivisor | (this.statusTriggerType << 7))).put(this.statusTriggerDeltaDown).put(this.statusTriggerDeltaUp).put(this.statusMinInterval).put(this.fastCadenceLow).put(this.fastCadenceHigh).array();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.propertyID);
        parcel.writeByte(this.fastCadencePeriodDivisor);
        parcel.writeInt(this.statusTriggerType);
        parcel.writeByteArray(this.statusTriggerDeltaDown);
        parcel.writeByteArray(this.statusTriggerDeltaUp);
        parcel.writeByte(this.statusMinInterval);
        parcel.writeByteArray(this.fastCadenceLow);
        parcel.writeByteArray(this.fastCadenceHigh);
    }
}
