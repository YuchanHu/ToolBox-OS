package com.telink.ble.mesh.core.message.lighting;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class CtlTemperatureStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<CtlTemperatureStatusMessage> CREATOR = new Parcelable.Creator<CtlTemperatureStatusMessage>() { // from class: com.telink.ble.mesh.core.message.lighting.CtlTemperatureStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ CtlTemperatureStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ CtlTemperatureStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public CtlTemperatureStatusMessage createFromParcel(Parcel parcel) {
            return new CtlTemperatureStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public CtlTemperatureStatusMessage[] newArray(int i) {
            return new CtlTemperatureStatusMessage[i];
        }
    };
    private static final int DATA_LEN_COMPLETE = 9;
    private boolean isComplete;
    private int presentDeltaUV;
    private int presentTemperature;
    private byte remainingTime;
    private int targetDeltaUV;
    private int targetTemperature;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public CtlTemperatureStatusMessage() {
        this.isComplete = false;
    }

    protected CtlTemperatureStatusMessage(Parcel parcel) {
        this.isComplete = false;
        this.presentTemperature = parcel.readInt();
        this.presentDeltaUV = parcel.readInt();
        this.targetTemperature = parcel.readInt();
        this.targetDeltaUV = parcel.readInt();
        this.remainingTime = parcel.readByte();
        this.isComplete = parcel.readByte() != 0;
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.presentTemperature = MeshUtils.bytes2Integer(bArr, 0, 2, ByteOrder.LITTLE_ENDIAN);
        this.presentDeltaUV = MeshUtils.bytes2Integer(bArr, 2, 2, ByteOrder.LITTLE_ENDIAN);
        if (bArr.length >= 9) {
            this.isComplete = true;
            this.targetTemperature = MeshUtils.bytes2Integer(bArr, 4, 2, ByteOrder.LITTLE_ENDIAN);
            this.targetDeltaUV = MeshUtils.bytes2Integer(bArr, 6, 2, ByteOrder.LITTLE_ENDIAN);
            this.remainingTime = bArr[8];
        }
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.presentTemperature);
        parcel.writeInt(this.presentDeltaUV);
        parcel.writeInt(this.targetTemperature);
        parcel.writeInt(this.targetDeltaUV);
        parcel.writeByte(this.remainingTime);
        parcel.writeByte(this.isComplete ? (byte) 1 : (byte) 0);
    }

    public int getPresentTemperature() {
        return this.presentTemperature;
    }

    public int getPresentDeltaUV() {
        return this.presentDeltaUV;
    }

    public int getTargetTemperature() {
        return this.targetTemperature;
    }

    public int getTargetDeltaUV() {
        return this.targetDeltaUV;
    }

    public byte getRemainingTime() {
        return this.remainingTime;
    }

    public boolean isComplete() {
        return this.isComplete;
    }
}
