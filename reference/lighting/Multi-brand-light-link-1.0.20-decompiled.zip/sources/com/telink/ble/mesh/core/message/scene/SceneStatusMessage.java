package com.telink.ble.mesh.core.message.scene;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class SceneStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<SceneStatusMessage> CREATOR = new Parcelable.Creator<SceneStatusMessage>() { // from class: com.telink.ble.mesh.core.message.scene.SceneStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SceneStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SceneStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SceneStatusMessage createFromParcel(Parcel parcel) {
            return new SceneStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SceneStatusMessage[] newArray(int i) {
            return new SceneStatusMessage[i];
        }
    };
    private static final int DATA_LEN_COMPLETE = 6;
    private int currentScene;
    private boolean isComplete;
    private byte remainingTime;
    private byte statusCode;
    private int targetScene;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public SceneStatusMessage() {
        this.isComplete = false;
    }

    protected SceneStatusMessage(Parcel parcel) {
        this.isComplete = false;
        this.statusCode = parcel.readByte();
        this.currentScene = parcel.readInt();
        this.targetScene = parcel.readInt();
        this.remainingTime = parcel.readByte();
        this.isComplete = parcel.readByte() != 0;
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.statusCode = bArr[0];
        this.currentScene = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.LITTLE_ENDIAN);
        if (bArr.length >= 6) {
            this.isComplete = true;
            this.targetScene = MeshUtils.bytes2Integer(bArr, 3, 2, ByteOrder.LITTLE_ENDIAN);
            this.remainingTime = bArr[5];
        }
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.statusCode);
        parcel.writeInt(this.currentScene);
        parcel.writeInt(this.targetScene);
        parcel.writeByte(this.remainingTime);
        parcel.writeByte(this.isComplete ? (byte) 1 : (byte) 0);
    }

    public byte getStatusCode() {
        return this.statusCode;
    }

    public int getCurrentScene() {
        return this.currentScene;
    }

    public int getTargetScene() {
        return this.targetScene;
    }

    public byte getRemainingTime() {
        return this.remainingTime;
    }

    public boolean isComplete() {
        return this.isComplete;
    }
}
