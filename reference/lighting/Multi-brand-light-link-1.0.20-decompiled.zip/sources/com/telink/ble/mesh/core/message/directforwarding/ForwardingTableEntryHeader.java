package com.telink.ble.mesh.core.message.directforwarding;

/* loaded from: classes.dex */
public class ForwardingTableEntryHeader {
}
