package com.telink.ble.mesh.entity;

/* loaded from: classes.dex */
public enum MeshAdvFilter {
    ANY,
    NETWORK_ID_ONLY,
    NODE_ID_ONLY
}
