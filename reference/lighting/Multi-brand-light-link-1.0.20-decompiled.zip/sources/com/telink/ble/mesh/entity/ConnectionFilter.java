package com.telink.ble.mesh.entity;

/* loaded from: classes.dex */
public class ConnectionFilter {
    public static final int TYPE_DEVICE_NAME = 2;
    public static final int TYPE_MAC_ADDRESS = 1;
    public static final int TYPE_MESH_ADDRESS = 0;
    public MeshAdvFilter advFilter = MeshAdvFilter.ANY;
    public Object target;
    public int type;

    public ConnectionFilter(int i, Object obj) {
        this.type = i;
        this.target = obj;
    }
}
