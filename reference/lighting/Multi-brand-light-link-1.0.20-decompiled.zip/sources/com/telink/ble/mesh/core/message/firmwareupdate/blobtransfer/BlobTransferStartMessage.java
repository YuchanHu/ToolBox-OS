package com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class BlobTransferStartMessage extends UpdatingMessage {
    private long blobId;
    private int blobSize;
    private int blockSizeLog;
    private int clientMTUSize;
    private TransferMode transferMode;

    public BlobTransferStartMessage(int i, int i2) {
        super(i, i2);
        this.transferMode = TransferMode.PUSH;
    }

    public static BlobTransferStartMessage getSimple(int i, int i2, long j, int i3, byte b, int i4) {
        BlobTransferStartMessage blobTransferStartMessage = new BlobTransferStartMessage(i, i2);
        blobTransferStartMessage.setResponseMax(1);
        blobTransferStartMessage.blobId = j;
        blobTransferStartMessage.blobSize = i3;
        blobTransferStartMessage.blockSizeLog = b;
        blobTransferStartMessage.clientMTUSize = i4;
        return blobTransferStartMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.BLOB_TRANSFER_START.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.BLOB_TRANSFER_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN).put((byte) (this.transferMode.value << 6)).putLong(this.blobId).putInt(this.blobSize).put((byte) this.blockSizeLog).putShort((short) this.clientMTUSize).array();
    }

    public void setTransferMode(TransferMode transferMode) {
        this.transferMode = transferMode;
    }

    public void setBlobId(long j) {
        this.blobId = j;
    }

    public void setBlobSize(int i) {
        this.blobSize = i;
    }

    public void setBlockSizeLog(int i) {
        this.blockSizeLog = i;
    }

    public void setClientMTUSize(int i) {
        this.clientMTUSize = i;
    }
}
