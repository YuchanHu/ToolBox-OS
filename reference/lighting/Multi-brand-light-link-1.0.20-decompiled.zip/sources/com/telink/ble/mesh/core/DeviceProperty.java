package com.telink.ble.mesh.core;

import java.io.Serializable;

/* loaded from: classes.dex */
public enum DeviceProperty implements Serializable {
    LC_AMBIENT_LUX_LEVEL_ON(43, 3, "Ambient Lux Level On", "Illuminance", "This property represents the minimum ambient illuminance level as measured by a lux sensor that determines if a light or a group of lights transitions from the standby state to a run state. "),
    LC_AMBIENT_LUX_LEVEL_PROLONG(44, 3, "Ambient Lux Level Prolong", "Illuminance", "This property represents the ambient light level for a light or a group of lights in the prolong state."),
    LC_AMBIENT_LUX_LEVEL_STANDBY(45, 3, "Ambient Lux Level Standby", "Illuminance", "This property represents the ambient light level for a light or a group of lights to remain in a standby state."),
    LC_REGULATOR_ACCURACY(49, 1, "Regulator Accuracy", "Percentage 8", "This property represents the accuracy of a proportional-integral light regulator. "),
    LC_REGULATOR_KID(50, 1, "Regulator Kid", "Percentage 8", "This property represents the integral coefficient K_i in a decreasing output operation mode of a proportional-integral light controller."),
    LC_REGULATOR_KIU(51, 1, "Regulator Kiu", "Percentage 8", "This property represents the integral coefficient K_i in an increasing output operation mode of a proportional-integral light controller. "),
    LC_REGULATOR_KPD(52, 1, "Regulator Kpd", "Percentage 8", "This property represents the proportional coefficient K_p in a decreasing output operation mode of a proportional-integral light controller."),
    LC_REGULATOR_KPU(53, 1, "Regulator Kpu", "Percentage 8", "This property represents the proportional coefficient K_p in an increasing output operation mode of a proportional-integral light controller. "),
    LC_LIGHTNESS_ON(46, 2, "Lightness On", "Perceived Lightness", "This property represents the light lightness level of a light or a group of lights in a run state."),
    LIGHTNESS_PROLONG(47, 2, "Lightness Prolong", "Perceived Lightness", "This property represents the light lightness level of a light or a group of lights when in a prolong state."),
    LIGHTNESS_STANDBY(48, 2, "Lightness Standby", "Perceived Lightness", "This property represents the perceived light lightness level of a light or a group of lights when in a standby state."),
    TIME_FADE(54, 3, "Time Fade", "Time Millisecond 24", "This property represents the time a light takes to transition from a run state to a prolong state. The run state is the state when the light is running at normal light level, the prolong state is an intermediate state of a light between the run state and the standby state."),
    TIME_FADE_ON(55, 3, "Time Fade On", "Time Millisecond 24", "This property represents the time lights take to transition from a standby state to a run state."),
    TIME_FADE_STANDBY_AUTO(56, 3, "Time Fade Standby Auto", "Time Millisecond 24", "This property represents the time lights transition from a prolong state to a standby state when the transition is automatic (such as when triggered by an occupancy or light sensor)."),
    TIME_FADE_STANDBY_MANUAL(57, 3, "Time Fade Standby Manual", "Time Millisecond 24", "This property represents the time lights take to transition to a standby state when the transition is triggered by a manual operation (e.g., by a user operating a light switch)."),
    TIME_OCCUPANCY_DELAY(58, 3, "Time Occupancy Delay", "Time Millisecond 24", "This property represents the time delay between receiving a signal from an occupancy sensor and a light controller executing a state change as a result of the signal."),
    TIME_PROLONG(59, 3, "Time Prolong", "Time Millisecond 24", "This property represents the duration of the prolong state, which is the state of a device between its run state and its standby state."),
    TIME_RUN_ON(60, 3, "Time Run On", "Time Millisecond 24", "This property represents the duration of the run state after last occupancy was detected."),
    MOTION_SENSED(66, 1, "Motion Sensed", "Percentage 8", "This property represents the activity level, as, for example, detected by a motion sensor."),
    PRESENT_AMBIENT_LIGHT_LEVEL(78, 3, "Present Ambient", "Illuminance", "This property represents the light level as measured by a light sensor measuring illuminance (Lux)."),
    PRESENCE_DETECTED(77, 1, "Presence Detected", "Boolean", "This property represents whether or not an occupant is detected within range of the occupancy detector."),
    SENSOR_GAIN(116, 1, "Sensor Gain", "Coefficient", "This property represents the ratio of the value reported by the sensor to the raw value measured by the sensor."),
    MOTION_THRESHOLD(67, 1, "Motion Threshold", "Percentage 8", "This property represents the activity level, for example, as detected by a motion or an occupancy sensor, below which motion or occupancy is not reported."),
    PEOPLE_COUNT(76, 2, "People Count", "Count 16", "This property represents the number of people present in a space or in a building. "),
    TIME_SINCE_MOTION_SENSED(104, 3, "Time Since Motion Sensed", "Time Millisecond 24", "This property represents the time that has elapsed since the sensor last detected any activity. "),
    PRECISE_TOTAL_DEVICE_ENERGY_USE(114, 4, "Precise Total Device Energy Use", "Energy 32", "This property represents the total energy used by a device over its lifetime.");

    public final String characteristic;
    public final String def;
    public final int id;
    public final int len;
    public final String name;

    DeviceProperty(int i, int i2, String str, String str2, String str3) {
        this.id = i;
        this.len = i2;
        this.name = str;
        this.characteristic = str2;
        this.def = str3;
    }

    public static DeviceProperty[] getLcProperties() {
        return new DeviceProperty[]{LC_LIGHTNESS_ON, LIGHTNESS_PROLONG, LIGHTNESS_STANDBY, LC_AMBIENT_LUX_LEVEL_ON, LC_AMBIENT_LUX_LEVEL_PROLONG, LC_AMBIENT_LUX_LEVEL_STANDBY, TIME_FADE_ON, TIME_RUN_ON, TIME_FADE, TIME_PROLONG, TIME_FADE_STANDBY_AUTO, TIME_FADE_STANDBY_MANUAL, TIME_OCCUPANCY_DELAY, LC_REGULATOR_ACCURACY, LC_REGULATOR_KID, LC_REGULATOR_KIU, LC_REGULATOR_KPD, LC_REGULATOR_KPU};
    }

    public static DeviceProperty getById(int i) {
        for (DeviceProperty deviceProperty : values()) {
            if (deviceProperty.id == i) {
                return deviceProperty;
            }
        }
        return null;
    }
}
