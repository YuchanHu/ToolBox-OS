package com.telink.ble.mesh.core.message.scheduler;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.lighting.LightingMessage;

/* loaded from: classes.dex */
public class SchedulerGetMessage extends LightingMessage {
    public SchedulerGetMessage(int i, int i2) {
        super(i, i2);
    }

    public static SchedulerGetMessage getSimple(int i, int i2, int i3) {
        SchedulerGetMessage schedulerGetMessage = new SchedulerGetMessage(i, i2);
        schedulerGetMessage.setResponseMax(i3);
        return schedulerGetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.SCHD_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.SCHD_STATUS.value;
    }
}
