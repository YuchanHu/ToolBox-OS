package com.telink.ble.mesh.foundation.event;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.entity.MeshUpdatingDevice;
import com.telink.ble.mesh.foundation.Event;

/* loaded from: classes.dex */
public class FirmwareUpdatingEvent extends Event<String> {
    public static final Parcelable.Creator<FirmwareUpdatingEvent> CREATOR = new Parcelable.Creator<FirmwareUpdatingEvent>() { // from class: com.telink.ble.mesh.foundation.event.FirmwareUpdatingEvent.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FirmwareUpdatingEvent createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FirmwareUpdatingEvent[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FirmwareUpdatingEvent createFromParcel(Parcel parcel) {
            return new FirmwareUpdatingEvent(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FirmwareUpdatingEvent[] newArray(int i) {
            return new FirmwareUpdatingEvent[i];
        }
    };
    public static final String EVENT_TYPE_DEVICE_FAIL = "com.telink.sig.mesh.EVENT_TYPE_DEVICE_FAIL";
    public static final String EVENT_TYPE_DEVICE_SUCCESS = "com.telink.sig.mesh.EVENT_TYPE_DEVICE_SUCCESS";
    public static final String EVENT_TYPE_UPDATING_FAIL = "com.telink.sig.mesh.EVENT_TYPE_UPDATING_FAIL";
    public static final String EVENT_TYPE_UPDATING_PREPARED = "com.telink.sig.mesh.EVENT_TYPE_UPDATING_PREPARED";
    public static final String EVENT_TYPE_UPDATING_PROGRESS = "com.telink.sig.mesh.EVENT_TYPE_UPDATING_PROGRESS";
    public static final String EVENT_TYPE_UPDATING_STOPPED = "com.telink.sig.mesh.EVENT_TYPE_UPDATING_STOPPED";
    public static final String EVENT_TYPE_UPDATING_SUCCESS = "com.telink.sig.mesh.EVENT_TYPE_UPDATING_SUCCESS";
    private String desc;
    private int progress;
    private MeshUpdatingDevice updatingDevice;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public FirmwareUpdatingEvent(Object obj, String str) {
        super(obj, str);
    }

    protected FirmwareUpdatingEvent(Parcel parcel) {
        this.updatingDevice = (MeshUpdatingDevice) parcel.readParcelable(MeshUpdatingDevice.class.getClassLoader());
        this.progress = parcel.readInt();
        this.desc = parcel.readString();
    }

    public void setUpdatingDevice(MeshUpdatingDevice meshUpdatingDevice) {
        this.updatingDevice = meshUpdatingDevice;
    }

    public void setProgress(int i) {
        this.progress = i;
    }

    public void setDesc(String str) {
        this.desc = str;
    }

    public MeshUpdatingDevice getUpdatingDevice() {
        return this.updatingDevice;
    }

    public int getProgress() {
        return this.progress;
    }

    public String getDesc() {
        return this.desc;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.updatingDevice, i);
        parcel.writeInt(this.progress);
        parcel.writeString(this.desc);
    }
}
