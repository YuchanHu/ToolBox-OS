package com.telink.ble.mesh.core.access.fu;

import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.TransferMode;

/* loaded from: classes.dex */
interface BlobTransferCallback {
    boolean onMeshMessagePrepared(MeshMessage meshMessage);

    void onTransferComplete(boolean z, String str);

    void onTransferLog(String str, String str2, int i);

    void onTransferProgressUpdate(int i, BlobTransferType blobTransferType);

    void onTransferStart(TransferMode transferMode);

    void onTransferringDeviceFail(int i, String str);
}
