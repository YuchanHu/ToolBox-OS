package com.telink.ble.mesh.core.message.scheduler;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;

/* loaded from: classes.dex */
public class SchedulerActionSetMessage extends GenericMessage {
    private boolean ack;
    private byte[] schedulerParams;

    public static SchedulerActionSetMessage getSimple(int i, int i2, byte[] bArr, boolean z, int i3) {
        SchedulerActionSetMessage schedulerActionSetMessage = new SchedulerActionSetMessage(i, i2);
        schedulerActionSetMessage.schedulerParams = bArr;
        schedulerActionSetMessage.ack = z;
        schedulerActionSetMessage.setResponseMax(i3);
        return schedulerActionSetMessage;
    }

    public SchedulerActionSetMessage(int i, int i2) {
        super(i, i2);
        this.ack = false;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return this.ack ? Opcode.SCHD_ACTION_STATUS.value : super.getResponseOpcode();
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.SCHD_ACTION_SET : Opcode.SCHD_ACTION_SET_NOACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return this.schedulerParams;
    }

    public void setSchedulerParams(byte[] bArr) {
        this.schedulerParams = bArr;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }
}
