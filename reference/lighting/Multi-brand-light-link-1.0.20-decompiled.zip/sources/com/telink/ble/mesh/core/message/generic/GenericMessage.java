package com.telink.ble.mesh.core.message.generic;

import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.networking.AccessType;

/* loaded from: classes.dex */
public abstract class GenericMessage extends MeshMessage {
    public GenericMessage(int i, int i2) {
        this.destinationAddress = i;
        this.appKeyIndex = i2;
        this.accessType = AccessType.APPLICATION;
    }
}
