package com.telink.ble.mesh.foundation.parameter;

import com.telink.ble.mesh.core.ble.LeScanFilter;
import com.telink.ble.mesh.core.ble.UUIDInfo;
import java.util.UUID;

/* loaded from: classes.dex */
public class ScanParameters extends Parameters {
    private LeScanFilter filter = new LeScanFilter();

    public static ScanParameters getDefault(boolean z, boolean z2) {
        ScanParameters scanParameters = new ScanParameters();
        if (z) {
            scanParameters.filter.uuidInclude = new UUID[]{UUIDInfo.SERVICE_PROXY};
        } else {
            scanParameters.filter.uuidInclude = new UUID[]{UUIDInfo.SERVICE_PROVISION};
        }
        scanParameters.setScanFilter(scanParameters.filter);
        scanParameters.singleMode(z2);
        return scanParameters;
    }

    public void setIncludeMacs(String[] strArr) {
        LeScanFilter leScanFilter = this.filter;
        if (leScanFilter != null) {
            leScanFilter.macInclude = strArr;
        }
    }

    public void setExcludeMacs(String[] strArr) {
        LeScanFilter leScanFilter = this.filter;
        if (leScanFilter != null) {
            leScanFilter.macExclude = strArr;
        }
    }

    public void singleMode(boolean z) {
        set(Parameters.SCAN_SINGLE_MODE, Boolean.valueOf(z));
    }
}
