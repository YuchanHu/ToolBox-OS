package com.telink.ble.mesh.core.networking.beacon;

import com.telink.ble.mesh.core.Encipher;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.util.Arrays;
import com.telink.ble.mesh.util.MeshLogger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class MeshPrivateBeacon extends MeshBeaconPDU {
    private static final int LENGTH_PAYLOAD = 27;
    private static final int MASK_IV_UPDATE = 2;
    private static final int MASK_KEY_REFRESH = 1;
    private byte[] authenticationTag;
    private final byte beaconType = 2;
    private byte flags;
    private int ivIndex;
    private byte[] obfuscatedData;
    private byte[] random;

    public byte getBeaconType() {
        return (byte) 2;
    }

    public static MeshPrivateBeacon from(byte[] bArr, byte[] bArr2) {
        if (bArr.length != 27 || bArr[0] != 2) {
            return null;
        }
        MeshPrivateBeacon meshPrivateBeacon = new MeshPrivateBeacon();
        byte[] bArr3 = new byte[13];
        System.arraycopy(bArr, 1, bArr3, 0, 13);
        meshPrivateBeacon.random = bArr3;
        byte[] bArr4 = new byte[5];
        meshPrivateBeacon.obfuscatedData = bArr4;
        System.arraycopy(bArr, 14, bArr4, 0, 5);
        byte[] bArr5 = new byte[8];
        meshPrivateBeacon.authenticationTag = bArr5;
        System.arraycopy(bArr, 19, bArr5, 0, 8);
        byte[] bArrAes = Encipher.aes(ByteBuffer.allocate(16).order(ByteOrder.BIG_ENDIAN).put((byte) 1).put(bArr3).putShort((short) 1).array(), bArr2);
        byte[] bArr6 = new byte[5];
        for (int i = 0; i < 5; i++) {
            bArr6[i] = (byte) (bArrAes[i] ^ meshPrivateBeacon.obfuscatedData[i]);
        }
        meshPrivateBeacon.flags = bArr6[0];
        meshPrivateBeacon.ivIndex = MeshUtils.bytes2Integer(bArr6, 1, 4, ByteOrder.BIG_ENDIAN);
        if (Arrays.equals(meshPrivateBeacon.authenticationTag, calcAuthTag(bArr6, bArr3, bArr2))) {
            return meshPrivateBeacon;
        }
        MeshLogger.w("private beacon auth tag check err");
        return null;
    }

    public static MeshPrivateBeacon createIvUpdatingBeacon(int i, byte[] bArr, boolean z) {
        MeshPrivateBeacon meshPrivateBeacon = new MeshPrivateBeacon();
        byte b = (byte) (z ? 2 : 0);
        meshPrivateBeacon.flags = b;
        if (z) {
            i++;
        }
        meshPrivateBeacon.ivIndex = i;
        byte[] bArrArray = ByteBuffer.allocate(5).order(ByteOrder.BIG_ENDIAN).put(b).putInt(i).array();
        MeshLogger.d("beacon data: " + Arrays.bytesToHexString(bArrArray));
        byte[] bArrGenerateRandom = MeshUtils.generateRandom(13);
        byte[] bArrCalcAuthTag = calcAuthTag(bArrArray, bArrGenerateRandom, bArr);
        MeshLogger.d("authTag: " + Arrays.bytesToHexString(bArrCalcAuthTag));
        byte[] bArrAes = Encipher.aes(ByteBuffer.allocate(16).order(ByteOrder.BIG_ENDIAN).put((byte) 1).put(bArrGenerateRandom).putShort((short) 1).array(), bArr);
        byte[] bArr2 = new byte[5];
        for (int i2 = 0; i2 < 5; i2++) {
            bArr2[i2] = (byte) (bArrAes[i2] ^ bArrArray[i2]);
        }
        meshPrivateBeacon.random = bArrGenerateRandom;
        meshPrivateBeacon.obfuscatedData = bArr2;
        meshPrivateBeacon.authenticationTag = bArrCalcAuthTag;
        return meshPrivateBeacon;
    }

    private static byte[] calcAuthTag(byte[] bArr, byte[] bArr2, byte[] bArr3) {
        byte[] bArrArray = ByteBuffer.allocate(16).order(ByteOrder.BIG_ENDIAN).put((byte) 25).put(bArr2).putShort((short) 5).array();
        byte[] bArrArray2 = ByteBuffer.allocate(16).order(ByteOrder.BIG_ENDIAN).put((byte) 1).put(bArr2).putShort((short) 0).array();
        byte[] bArr4 = new byte[16];
        java.util.Arrays.fill(bArr4, (byte) 0);
        System.arraycopy(bArr, 0, bArr4, 0, bArr.length);
        byte[] bArrAes = Encipher.aes(bArrArray, bArr3);
        byte[] bArr5 = new byte[bArrAes.length];
        for (int i = 0; i < bArrAes.length; i++) {
            bArr5[i] = (byte) (bArrAes[i] ^ bArr4[i]);
        }
        byte[] bArrAes2 = Encipher.aes(bArr5, bArr3);
        byte[] bArrAes3 = Encipher.aes(bArrArray2, bArr3);
        byte[] bArr6 = new byte[bArrAes2.length];
        for (int i2 = 0; i2 < bArrAes2.length; i2++) {
            bArr6[i2] = (byte) (bArrAes2[i2] ^ bArrAes3[i2]);
        }
        byte[] bArr7 = new byte[8];
        System.arraycopy(bArr6, 0, bArr7, 0, 8);
        return bArr7;
    }

    @Override // com.telink.ble.mesh.core.provisioning.pdu.PDU
    public byte[] toBytes() {
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(27).order(ByteOrder.BIG_ENDIAN);
        byteBufferOrder.put((byte) 2).put(this.random).put(this.obfuscatedData).put(this.authenticationTag);
        return byteBufferOrder.array();
    }

    public byte getFlags() {
        return this.flags;
    }

    public int getIvIndex() {
        return this.ivIndex;
    }

    public byte[] getRandom() {
        return this.random;
    }

    public boolean isIvUpdating() {
        return (this.flags & 2) != 0;
    }

    public String toString() {
        return "MeshPrivateBeacon{beaconType=2, flags=" + ((int) this.flags) + ", ivIndex=" + this.ivIndex + '}';
    }
}
