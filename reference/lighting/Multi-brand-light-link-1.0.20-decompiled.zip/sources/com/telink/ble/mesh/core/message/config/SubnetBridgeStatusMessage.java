package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class SubnetBridgeStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<SubnetBridgeStatusMessage> CREATOR = new Parcelable.Creator<SubnetBridgeStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.SubnetBridgeStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SubnetBridgeStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SubnetBridgeStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SubnetBridgeStatusMessage createFromParcel(Parcel parcel) {
            return new SubnetBridgeStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SubnetBridgeStatusMessage[] newArray(int i) {
            return new SubnetBridgeStatusMessage[i];
        }
    };
    private byte subnetBridgeState;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public SubnetBridgeStatusMessage() {
    }

    protected SubnetBridgeStatusMessage(Parcel parcel) {
        this.subnetBridgeState = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.subnetBridgeState = bArr[0];
    }

    public byte getSubnetBridgeState() {
        return this.subnetBridgeState;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.subnetBridgeState);
    }
}
