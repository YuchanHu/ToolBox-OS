package com.telink.ble.mesh.core.provisioning.pdu;

import com.telink.ble.mesh.core.access.fu.FUDistributor;

/* loaded from: classes.dex */
public class ProvisioningCapabilityPDU implements ProvisioningStatePDU {
    private static final int ALG_BIT_MASK_CMAC = 1;
    private static final int ALG_BIT_MASK_HMAC = 2;
    private static final int LEN = 11;
    public short algorithms;
    public byte eleNum;
    public short inputOOBAction;
    public byte inputOOBSize;
    public short outputOOBAction;
    public byte outputOOBSize;
    public byte publicKeyType;
    public byte[] rawData;
    public byte staticOOBType;

    @Override // com.telink.ble.mesh.core.provisioning.pdu.ProvisioningStatePDU
    public byte getState() {
        return (byte) 1;
    }

    public static ProvisioningCapabilityPDU fromBytes(byte[] bArr) {
        if (bArr == null || bArr.length < 11) {
            return null;
        }
        ProvisioningCapabilityPDU provisioningCapabilityPDU = new ProvisioningCapabilityPDU();
        provisioningCapabilityPDU.rawData = bArr;
        provisioningCapabilityPDU.eleNum = bArr[0];
        provisioningCapabilityPDU.algorithms = (short) (((bArr[1] & FUDistributor.UPDATE_TTL) << 8) | (bArr[2] & FUDistributor.UPDATE_TTL));
        provisioningCapabilityPDU.publicKeyType = bArr[3];
        provisioningCapabilityPDU.staticOOBType = bArr[4];
        provisioningCapabilityPDU.outputOOBSize = bArr[5];
        provisioningCapabilityPDU.outputOOBAction = (short) (((bArr[6] & FUDistributor.UPDATE_TTL) << 8) | (bArr[7] & FUDistributor.UPDATE_TTL));
        provisioningCapabilityPDU.inputOOBSize = bArr[8];
        provisioningCapabilityPDU.inputOOBAction = (short) ((bArr[10] & FUDistributor.UPDATE_TTL) | ((bArr[9] & FUDistributor.UPDATE_TTL) << 8));
        return provisioningCapabilityPDU;
    }

    public String toString() {
        return "ProvisioningCapabilityPDU{eleNum=" + ((int) this.eleNum) + ", algorithms=" + ((int) this.algorithms) + ", publicKeyType=" + ((int) this.publicKeyType) + ", staticOOBType=" + ((int) this.staticOOBType) + ", outputOOBSize=" + ((int) this.outputOOBSize) + ", outputOOBAction=" + ((int) this.outputOOBAction) + ", inputOOBSize=" + ((int) this.inputOOBSize) + ", inputOOBAction=" + ((int) this.inputOOBAction) + '}';
    }

    @Override // com.telink.ble.mesh.core.provisioning.pdu.PDU
    public byte[] toBytes() {
        return this.rawData;
    }

    public boolean isStaticOOBSupported() {
        return this.staticOOBType != 0;
    }

    public boolean isHMacAlgorithmSupported() {
        return (this.algorithms & 2) != 0;
    }
}
