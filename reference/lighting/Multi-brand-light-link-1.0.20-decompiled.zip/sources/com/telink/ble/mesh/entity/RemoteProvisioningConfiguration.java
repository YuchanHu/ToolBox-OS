package com.telink.ble.mesh.entity;

/* loaded from: classes.dex */
public class RemoteProvisioningConfiguration {
    private static final int DEFAULT_SCAN_LIMIT = 2;
    private static final int DEFAULT_SCAN_TIMEOUT = 3;
    private boolean bindNeed = true;
    private boolean defaultBind = false;
    private int provisioningIndex;
    private int scanLimit;
    private int scanTimeout;

    public RemoteProvisioningConfiguration(int i) {
        this.provisioningIndex = i;
    }

    public boolean isBindNeed() {
        return this.bindNeed;
    }

    public void setBindNeed(boolean z) {
        this.bindNeed = z;
    }

    public boolean isDefaultBind() {
        return this.defaultBind;
    }

    public void setDefaultBind(boolean z) {
        this.defaultBind = z;
    }

    public int getScanLimit() {
        return this.scanLimit;
    }

    public void setScanLimit(int i) {
        this.scanLimit = i;
    }

    public int getScanTimeout() {
        return this.scanTimeout;
    }

    public void setScanTimeout(int i) {
        this.scanTimeout = i;
    }

    public int getProvisioningIndex() {
        return this.provisioningIndex;
    }

    public void setProvisioningIndex(int i) {
        this.provisioningIndex = i;
    }
}
