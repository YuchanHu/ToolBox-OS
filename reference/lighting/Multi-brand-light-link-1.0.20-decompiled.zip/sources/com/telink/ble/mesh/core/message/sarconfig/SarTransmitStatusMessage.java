package com.telink.ble.mesh.core.message.sarconfig;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class SarTransmitStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<SarTransmitStatusMessage> CREATOR = new Parcelable.Creator<SarTransmitStatusMessage>() { // from class: com.telink.ble.mesh.core.message.sarconfig.SarTransmitStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SarTransmitStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SarTransmitStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SarTransmitStatusMessage createFromParcel(Parcel parcel) {
            return new SarTransmitStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SarTransmitStatusMessage[] newArray(int i) {
            return new SarTransmitStatusMessage[i];
        }
    };
    public int multicastRetransCnt;
    public int multicastRetransInterval;
    public int rfu;
    public int segmentIntervalStep;
    public int unicastRetransCnt;
    public int unicastRetransIntervalIncrement;
    public int unicastRetransIntervalStep;
    public int unicastRetransWithoutProgCnt;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public SarTransmitStatusMessage() {
    }

    protected SarTransmitStatusMessage(Parcel parcel) {
        this.segmentIntervalStep = parcel.readInt();
        this.unicastRetransCnt = parcel.readInt();
        this.unicastRetransWithoutProgCnt = parcel.readInt();
        this.unicastRetransIntervalStep = parcel.readInt();
        this.unicastRetransIntervalIncrement = parcel.readInt();
        this.multicastRetransCnt = parcel.readInt();
        this.multicastRetransInterval = parcel.readInt();
        this.rfu = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        byte b = bArr[0];
        this.segmentIntervalStep = b & 15;
        this.unicastRetransCnt = (b & 240) >> 4;
        byte b2 = bArr[1];
        this.unicastRetransWithoutProgCnt = b2 & 15;
        this.unicastRetransIntervalStep = (b2 & 240) >> 4;
        this.unicastRetransIntervalIncrement = bArr[2] & 15;
        byte b3 = bArr[3];
        this.multicastRetransInterval = b3 & 15;
        this.multicastRetransCnt = (b3 & 240) >> 4;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.segmentIntervalStep);
        parcel.writeInt(this.unicastRetransCnt);
        parcel.writeInt(this.unicastRetransWithoutProgCnt);
        parcel.writeInt(this.unicastRetransIntervalStep);
        parcel.writeInt(this.unicastRetransIntervalIncrement);
        parcel.writeInt(this.multicastRetransCnt);
        parcel.writeInt(this.multicastRetransInterval);
        parcel.writeInt(this.rfu);
    }
}
