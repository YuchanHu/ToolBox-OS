package com.telink.ble.mesh.core.message.fastpv;

import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class MeshProvisionCompleteMessage extends GenericMessage {
    private int delay;

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return -1;
    }

    public MeshProvisionCompleteMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.VD_MESH_PROV_COMPLETE.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return MeshUtils.integer2Bytes(this.delay, 2, ByteOrder.LITTLE_ENDIAN);
    }

    public void setDelay(int i) {
        this.delay = i;
    }

    public static MeshProvisionCompleteMessage getSimple(int i, int i2, int i3) {
        MeshProvisionCompleteMessage meshProvisionCompleteMessage = new MeshProvisionCompleteMessage(i, i2);
        meshProvisionCompleteMessage.delay = i3;
        return meshProvisionCompleteMessage;
    }
}
