package com.telink.ble.mesh.core.proxy;

import com.telink.ble.mesh.core.MeshUtils;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ProxyFilterStatusMessage extends ProxyConfigurationMessage {
    private static final int DATA_LEN = 4;
    private byte filterType;
    private int listSize;

    @Override // com.telink.ble.mesh.core.proxy.ProxyConfigurationMessage
    public byte getOpcode() {
        return (byte) 3;
    }

    public static ProxyFilterStatusMessage fromBytes(byte[] bArr) {
        if (bArr.length != 4) {
            return null;
        }
        ProxyFilterStatusMessage proxyFilterStatusMessage = new ProxyFilterStatusMessage();
        if (bArr[0] != 3) {
            return null;
        }
        proxyFilterStatusMessage.filterType = bArr[1];
        proxyFilterStatusMessage.listSize = MeshUtils.bytes2Integer(bArr, 2, 2, ByteOrder.BIG_ENDIAN);
        return proxyFilterStatusMessage;
    }

    @Override // com.telink.ble.mesh.core.proxy.ProxyConfigurationMessage
    public byte[] toByteArray() {
        return ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).put(this.filterType).putShort((short) this.listSize).array();
    }

    public byte getFilterType() {
        return this.filterType;
    }

    public int getListSize() {
        return this.listSize;
    }
}
