package com.telink.ble.mesh.core.message.scheduler;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class SchedulerStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<SchedulerStatusMessage> CREATOR = new Parcelable.Creator<SchedulerStatusMessage>() { // from class: com.telink.ble.mesh.core.message.scheduler.SchedulerStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SchedulerStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SchedulerStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SchedulerStatusMessage createFromParcel(Parcel parcel) {
            return new SchedulerStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SchedulerStatusMessage[] newArray(int i) {
            return new SchedulerStatusMessage[i];
        }
    };
    private int schedules;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public SchedulerStatusMessage() {
    }

    protected SchedulerStatusMessage(Parcel parcel) {
        this.schedules = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.schedules = MeshUtils.bytes2Integer(bArr, ByteOrder.LITTLE_ENDIAN);
    }

    public int getSchedules() {
        return this.schedules;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeLong(this.schedules);
    }
}
