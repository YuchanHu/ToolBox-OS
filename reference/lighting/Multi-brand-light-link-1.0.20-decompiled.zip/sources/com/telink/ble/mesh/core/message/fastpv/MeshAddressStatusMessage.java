package com.telink.ble.mesh.core.message.fastpv;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;
import java.util.Arrays;

/* loaded from: classes.dex */
public class MeshAddressStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<MeshAddressStatusMessage> CREATOR = new Parcelable.Creator<MeshAddressStatusMessage>() { // from class: com.telink.ble.mesh.core.message.fastpv.MeshAddressStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ MeshAddressStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ MeshAddressStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public MeshAddressStatusMessage createFromParcel(Parcel parcel) {
            return new MeshAddressStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public MeshAddressStatusMessage[] newArray(int i) {
            return new MeshAddressStatusMessage[i];
        }
    };
    private byte[] mac;
    private int pid;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public MeshAddressStatusMessage() {
    }

    protected MeshAddressStatusMessage(Parcel parcel) {
        this.mac = parcel.createByteArray();
        this.pid = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        byte[] bArr2 = new byte[6];
        this.mac = bArr2;
        System.arraycopy(bArr, 0, bArr2, 0, 6);
        this.pid = MeshUtils.bytes2Integer(bArr, 6, 2, ByteOrder.LITTLE_ENDIAN);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByteArray(this.mac);
        parcel.writeInt(this.pid);
    }

    public byte[] getMac() {
        return this.mac;
    }

    public int getPid() {
        return this.pid;
    }

    public String toString() {
        return "MeshAddressStatusMessage{mac=" + Arrays.toString(this.mac) + ", pid=" + this.pid + '}';
    }
}
