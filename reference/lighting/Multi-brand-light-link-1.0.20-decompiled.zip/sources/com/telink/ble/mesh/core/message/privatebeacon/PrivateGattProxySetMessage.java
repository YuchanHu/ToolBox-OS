package com.telink.ble.mesh.core.message.privatebeacon;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.config.ConfigMessage;

/* loaded from: classes.dex */
public class PrivateGattProxySetMessage extends ConfigMessage {
    public byte privateGattProxy;

    public PrivateGattProxySetMessage(int i) {
        super(i);
    }

    public static PrivateGattProxySetMessage getSimple(int i, byte b) {
        PrivateGattProxySetMessage privateGattProxySetMessage = new PrivateGattProxySetMessage(i);
        privateGattProxySetMessage.privateGattProxy = b;
        return privateGattProxySetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.PRIVATE_GATT_PROXY_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.PRIVATE_GATT_PROXY_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return new byte[]{this.privateGattProxy};
    }
}
