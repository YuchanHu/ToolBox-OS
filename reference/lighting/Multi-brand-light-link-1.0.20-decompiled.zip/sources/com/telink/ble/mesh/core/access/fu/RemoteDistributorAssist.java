package com.telink.ble.mesh.core.access.fu;

import android.os.Handler;
import android.os.HandlerThread;
import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.NotificationMessage;
import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwaredistribution.DistributionPhase;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDApplyMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDGetMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.DistributionStatus;
import com.telink.ble.mesh.core.message.firmwareupdate.FirmwareUpdateInfoGetMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.FirmwareUpdateInfoStatusMessage;
import com.telink.ble.mesh.entity.FirmwareUpdateConfiguration;
import com.telink.ble.mesh.entity.MeshUpdatingDevice;
import com.telink.ble.mesh.util.Arrays;
import com.telink.ble.mesh.util.MeshLogger;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
public class RemoteDistributorAssist {
    private static final long APPLY_INTERVAL = 10000;
    private static final long CONFIRM_INTERVAL = 10000;
    private static final int STEP_DIST_APPLYING = 1;
    private static final int STEP_DIST_GET = 2;
    private static final int STEP_IDLE = 0;
    private static final int STEP_RECHECK = 3;
    private FUActionHandler actionHandler;
    private int appKeyIndex;
    private List<MeshUpdatingDevice> devices;
    private int distributorAddress;
    private Handler handler;
    private byte[] newFirmwareId;
    private int step = 0;
    private int deviceIndex = 0;
    private final Runnable APPLY_TASK = new Runnable() { // from class: com.telink.ble.mesh.core.access.fu.RemoteDistributorAssist.1
        @Override // java.lang.Runnable
        public void run() {
            RemoteDistributorAssist.this.applyDistribute();
        }
    };
    private final Runnable DIST_GET_TASK = new Runnable() { // from class: com.telink.ble.mesh.core.access.fu.RemoteDistributorAssist.2
        @Override // java.lang.Runnable
        public void run() {
            RemoteDistributorAssist.access$000(RemoteDistributorAssist.this, "confirm distribute");
            RemoteDistributorAssist.this.onMeshMessagePrepared(FDGetMessage.getSimple(RemoteDistributorAssist.access$100(RemoteDistributorAssist.this), RemoteDistributorAssist.access$200(RemoteDistributorAssist.this)));
        }
    };

    static /* synthetic */ void access$000(RemoteDistributorAssist remoteDistributorAssist, String str) {
        remoteDistributorAssist.log(str);
    }

    static /* synthetic */ int access$100(RemoteDistributorAssist remoteDistributorAssist) {
        return remoteDistributorAssist.distributorAddress;
    }

    static /* synthetic */ int access$200(RemoteDistributorAssist remoteDistributorAssist) {
        return remoteDistributorAssist.appKeyIndex;
    }

    static /* synthetic */ void access$300(RemoteDistributorAssist remoteDistributorAssist) {
        remoteDistributorAssist.executeAction();
    }

    RemoteDistributorAssist(HandlerThread handlerThread, FUActionHandler fUActionHandler) {
        this.handler = new Handler(handlerThread.getLooper());
        this.actionHandler = fUActionHandler;
    }

    void resetConfig(FirmwareUpdateConfiguration firmwareUpdateConfiguration) {
        this.distributorAddress = firmwareUpdateConfiguration.getDistributorAddress();
        this.devices = firmwareUpdateConfiguration.getUpdatingDevices();
        this.appKeyIndex = firmwareUpdateConfiguration.getAppKeyIndex();
        this.newFirmwareId = firmwareUpdateConfiguration.getFirmwareId();
        this.deviceIndex = 0;
    }

    void clear() {
        this.step = 0;
        this.handler.removeCallbacksAndMessages(null);
    }

    void applyDistribute() {
        log("apply distribution");
        this.step = 1;
        this.deviceIndex = 0;
        executeAction();
    }

    void confirmDistribute() {
        log("confirm distribute after(ms) : 10000");
        this.step = 2;
        this.handler.removeCallbacks(this.DIST_GET_TASK);
        this.handler.postDelayed(this.DIST_GET_TASK, 10000L);
    }

    void recheckFirmware(boolean z) {
        log("recheck firmware");
        this.step = 3;
        this.deviceIndex = 0;
        this.handler.postDelayed(new Runnable() { // from class: com.telink.ble.mesh.core.access.fu.RemoteDistributorAssist.3
            @Override // java.lang.Runnable
            public void run() {
                RemoteDistributorAssist.access$300(RemoteDistributorAssist.this);
            }
        }, z ? 0L : 10000L);
    }

    private void onRecheckComplete() {
        log("recheck firmware info complete");
        onAssistComplete(true, "recheck complete");
    }

    private void executeAction() {
        log("execute action : " + this.step);
        int i = this.step;
        if (i == 1) {
            onMeshMessagePrepared(FDApplyMessage.getSimple(this.distributorAddress, this.appKeyIndex));
        } else if (i == 3) {
            if (this.deviceIndex >= this.devices.size()) {
                onRecheckComplete();
            } else {
                onMeshMessagePrepared(FirmwareUpdateInfoGetMessage.getSimple(this.devices.get(this.deviceIndex).meshAddress, this.appKeyIndex));
            }
        }
    }

    private void onDistributeStatus(NotificationMessage notificationMessage) {
        int i = this.step;
        if (i == 1) {
            FDStatusMessage fDStatusMessage = (FDStatusMessage) notificationMessage.getStatusMessage();
            if (fDStatusMessage.status == DistributionStatus.WRONG_PHASE.code && fDStatusMessage.distPhase == DistributionPhase.TRANSFER_ACTIVE.value) {
                log("waiting for next apply action...");
                this.handler.removeCallbacks(this.APPLY_TASK);
                this.handler.postDelayed(this.APPLY_TASK, 10000L);
                return;
            }
            onAssistComplete(fDStatusMessage.status == DistributionStatus.SUCCESS.code, "distribute apply complete");
            return;
        }
        if (i == 2) {
            FDStatusMessage fDStatusMessage2 = (FDStatusMessage) notificationMessage.getStatusMessage();
            if (fDStatusMessage2.status == DistributionStatus.SUCCESS.code) {
                int i2 = fDStatusMessage2.distPhase;
                if (i2 == DistributionPhase.COMPLETED.value) {
                    onAssistComplete(true, "distribute confirm complete");
                    return;
                } else if (i2 == DistributionPhase.APPLYING_UPDATE.value) {
                    confirmDistribute();
                    return;
                } else {
                    onAssistComplete(false, "distribute phase error");
                    return;
                }
            }
            onAssistComplete(false, "distribute status error");
        }
    }

    private void onFirmwareInfoStatus(NotificationMessage notificationMessage) {
        FirmwareUpdateInfoStatusMessage.FirmwareInformationEntry firstEntry = ((FirmwareUpdateInfoStatusMessage) notificationMessage.getStatusMessage()).getFirstEntry();
        int src = notificationMessage.getSrc();
        List<MeshUpdatingDevice> list = this.devices;
        if (list == null) {
            return;
        }
        Iterator<MeshUpdatingDevice> it = list.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            MeshUpdatingDevice next = it.next();
            if (next.meshAddress == src) {
                if (Arrays.equals(this.newFirmwareId, firstEntry.currentFirmwareID)) {
                    next.firmwareId = firstEntry.currentFirmwareID;
                    onDeviceStateUpdate(next, 1, "device firmware id updated");
                } else {
                    onDeviceStateUpdate(next, 2, "device firmware id not updated");
                }
            }
        }
        this.deviceIndex++;
        executeAction();
    }

    private void onAssistComplete(boolean z, String str) {
        this.step = 0;
        this.handler.removeCallbacksAndMessages(null);
        FUActionHandler fUActionHandler = this.actionHandler;
        if (fUActionHandler != null) {
            fUActionHandler.onActionComplete(z, FUAction.DISTRIBUTE_ASSIST, str);
        }
    }

    private void onDeviceFail(MeshUpdatingDevice meshUpdatingDevice, String str) {
        onDeviceStateUpdate(meshUpdatingDevice, 2, str);
    }

    private void onDeviceStateUpdate(MeshUpdatingDevice meshUpdatingDevice, int i, String str) {
        log(String.format("node updating changed : %04X -- " + str, Integer.valueOf(meshUpdatingDevice.meshAddress)));
        meshUpdatingDevice.state = i;
        FUActionHandler fUActionHandler = this.actionHandler;
        if (fUActionHandler != null) {
            fUActionHandler.onDeviceUpdate(meshUpdatingDevice, String.format("node(%04X)  state update : -- %02X -- %s", Integer.valueOf(meshUpdatingDevice.meshAddress), Integer.valueOf(i), str));
        }
    }

    public void onMessageNotification(NotificationMessage notificationMessage) {
        if (this.step == 0) {
            log("notification when idle");
            return;
        }
        if (notificationMessage.getOpcode() == Opcode.FD_STATUS.value) {
            onDistributeStatus(notificationMessage);
        } else if (this.step == 3 && notificationMessage.getOpcode() == Opcode.FIRMWARE_UPDATE_INFORMATION_STATUS.value) {
            onFirmwareInfoStatus(notificationMessage);
        }
    }

    public void onAssistCommandFailed(int i) {
        if (this.step == 1 && i == Opcode.FIRMWARE_UPDATE_APPLY.value) {
            onDeviceFail(this.devices.get(this.deviceIndex), "apply command send fail");
            this.deviceIndex++;
            executeAction();
        } else if (this.step == 3 && i == Opcode.FIRMWARE_UPDATE_INFORMATION_GET.value) {
            onDeviceFail(this.devices.get(this.deviceIndex), "recheck command fail");
            this.deviceIndex++;
            executeAction();
        }
    }

    public boolean onMeshMessagePrepared(MeshMessage meshMessage) {
        MeshLogger.d("initiator send message to : " + meshMessage.getDestinationAddress());
        return this.actionHandler.onMessagePrepared(meshMessage);
    }

    boolean isRunning() {
        return this.step != 0;
    }

    private void log(String str) {
        this.actionHandler.onActionLog("Assist", str, 1);
    }
}
