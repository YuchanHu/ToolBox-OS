package com.telink.ble.mesh.core.message.directforwarding;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.config.ConfigMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class DirectedControlSetMessage extends ConfigMessage {
    public byte directedForwarding;
    public byte directedFriend;
    private byte directedProxy;
    private byte directedProxyUseDirectedDefault;
    public byte directedRelay;
    public int netKeyIndex;

    public static DirectedControlSetMessage getSimple(int i, int i2) {
        DirectedControlSetMessage directedControlSetMessage = new DirectedControlSetMessage(i);
        directedControlSetMessage.setResponseMax(1);
        directedControlSetMessage.netKeyIndex = i2;
        return directedControlSetMessage;
    }

    public static DirectedControlSetMessage getDFEnable(int i, int i2, boolean z) {
        DirectedControlSetMessage directedControlSetMessage = new DirectedControlSetMessage(i);
        directedControlSetMessage.setResponseMax(1);
        directedControlSetMessage.netKeyIndex = i2;
        directedControlSetMessage.directedForwarding = z ? (byte) 1 : (byte) 0;
        return directedControlSetMessage;
    }

    public DirectedControlSetMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.DIRECTED_CONTROL_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.DIRECTED_CONTROL_STATUS.value;
    }

    public void setDirectedProxy(byte b) {
        this.directedProxy = b;
        this.directedProxyUseDirectedDefault = b;
    }

    public void setDirectedProxyUseDirectedDefault(byte b) {
        this.directedProxyUseDirectedDefault = b;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(7).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.netKeyIndex).put(this.directedForwarding).put(this.directedRelay).put(this.directedProxy).put(this.directedProxyUseDirectedDefault).put(this.directedFriend).array();
    }
}
