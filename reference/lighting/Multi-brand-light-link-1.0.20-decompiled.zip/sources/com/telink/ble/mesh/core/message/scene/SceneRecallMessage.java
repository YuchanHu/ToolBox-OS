package com.telink.ble.mesh.core.message.scene;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class SceneRecallMessage extends GenericMessage {
    private boolean ack;
    private byte delay;
    private boolean isComplete;
    private int sceneNumber;
    private byte tid;
    private byte transitionTime;

    public static SceneRecallMessage getSimple(int i, int i2, int i3, boolean z, int i4) {
        SceneRecallMessage sceneRecallMessage = new SceneRecallMessage(i, i2);
        sceneRecallMessage.sceneNumber = i3;
        sceneRecallMessage.ack = z;
        sceneRecallMessage.setResponseMax(i4);
        return sceneRecallMessage;
    }

    public SceneRecallMessage(int i, int i2) {
        super(i, i2);
        this.tid = (byte) 0;
        this.transitionTime = (byte) 0;
        this.delay = (byte) 0;
        this.ack = false;
        this.isComplete = false;
        setTidPosition(2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return this.ack ? Opcode.SCENE_STATUS.value : super.getResponseOpcode();
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.SCENE_RECALL : Opcode.SCENE_RECALL_NOACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        if (this.isComplete) {
            return ByteBuffer.allocate(5).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.sceneNumber).put(this.tid).put(this.transitionTime).put(this.delay).array();
        }
        return ByteBuffer.allocate(3).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.sceneNumber).put(this.tid).array();
    }

    public void setSceneNumber(int i) {
        this.sceneNumber = i;
    }

    public void setTid(byte b) {
        this.tid = b;
    }

    public void setTransitionTime(byte b) {
        this.transitionTime = b;
    }

    public void setDelay(byte b) {
        this.delay = b;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }

    public void setComplete(boolean z) {
        this.isComplete = z;
    }
}
