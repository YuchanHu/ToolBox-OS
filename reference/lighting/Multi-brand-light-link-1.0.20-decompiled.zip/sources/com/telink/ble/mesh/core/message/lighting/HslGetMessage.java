package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class HslGetMessage extends LightingMessage {
    public static HslGetMessage getSimple(int i, int i2, int i3) {
        HslGetMessage hslGetMessage = new HslGetMessage(i, i2);
        hslGetMessage.setResponseMax(i3);
        return hslGetMessage;
    }

    public HslGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.LIGHT_HSL_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.LIGHT_HSL_STATUS.value;
    }
}
