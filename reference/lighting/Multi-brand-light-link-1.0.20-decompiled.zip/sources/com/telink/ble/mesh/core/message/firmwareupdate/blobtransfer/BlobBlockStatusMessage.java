package com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class BlobBlockStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<BlobBlockStatusMessage> CREATOR = new Parcelable.Creator<BlobBlockStatusMessage>() { // from class: com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobBlockStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BlobBlockStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BlobBlockStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BlobBlockStatusMessage createFromParcel(Parcel parcel) {
            return new BlobBlockStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BlobBlockStatusMessage[] newArray(int i) {
            return new BlobBlockStatusMessage[i];
        }
    };
    public static final int FORMAT_ALL_CHUNKS_MISSING = 0;
    public static final int FORMAT_ENCODED_MISSING_CHUNKS = 3;
    public static final int FORMAT_NO_CHUNKS_MISSING = 1;
    public static final int FORMAT_SOME_CHUNKS_MISSING = 2;
    private int blockNumber;
    private int chunkSize;
    private List<Integer> encodedMissingChunks;
    private int format;
    private List<Integer> missingChunks;
    private int status;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public BlobBlockStatusMessage() {
    }

    protected BlobBlockStatusMessage(Parcel parcel) {
        this.status = parcel.readInt();
        this.format = parcel.readInt();
        this.blockNumber = parcel.readInt();
        this.chunkSize = parcel.readInt();
        ArrayList arrayList = new ArrayList();
        this.missingChunks = arrayList;
        parcel.readList(arrayList, null);
        ArrayList arrayList2 = new ArrayList();
        this.encodedMissingChunks = arrayList2;
        parcel.readList(arrayList2, null);
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        byte b = bArr[0];
        this.status = b & 15;
        this.format = (b >> 6) & 3;
        this.blockNumber = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.LITTLE_ENDIAN);
        this.chunkSize = MeshUtils.bytes2Integer(bArr, 3, 2, ByteOrder.LITTLE_ENDIAN);
        int i = this.format;
        if (i == 2) {
            this.missingChunks = MeshUtils.parseMissingBitField(bArr, 5);
            return;
        }
        if (i == 3) {
            this.encodedMissingChunks = new ArrayList();
            int length = bArr.length - 5;
            byte[] bArr2 = new byte[length];
            System.arraycopy(bArr, 5, bArr2, 0, length);
            for (char c : new String(bArr2, Charset.forName("UTF-8")).toCharArray()) {
                this.encodedMissingChunks.add(Integer.valueOf(c & 65535));
            }
        }
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.status);
        parcel.writeInt(this.format);
        parcel.writeInt(this.blockNumber);
        parcel.writeInt(this.chunkSize);
        parcel.writeList(this.missingChunks);
        parcel.writeList(this.encodedMissingChunks);
    }

    public int getStatus() {
        return this.status;
    }

    public int getFormat() {
        return this.format;
    }

    public int getBlockNumber() {
        return this.blockNumber;
    }

    public long getChunkSize() {
        return this.chunkSize;
    }

    public List<Integer> getMissingChunks() {
        return this.missingChunks;
    }

    public List<Integer> getEncodedMissingChunks() {
        return this.encodedMissingChunks;
    }

    public void setStatus(int i) {
        this.status = i;
    }

    public void setFormat(int i) {
        this.format = i;
    }

    public void setBlockNumber(int i) {
        this.blockNumber = i;
    }

    public void setChunkSize(int i) {
        this.chunkSize = i;
    }

    public void setMissingChunks(List<Integer> list) {
        this.missingChunks = list;
    }

    public void setEncodedMissingChunks(List<Integer> list) {
        this.encodedMissingChunks = list;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("BlobBlockStatusMessage{status=");
        sb.append(this.status);
        sb.append(", format=");
        sb.append(this.format);
        sb.append(", blockNumber=");
        sb.append(this.blockNumber);
        sb.append(", chunkSize=");
        sb.append(this.chunkSize);
        sb.append(", missingChunks=");
        List<Integer> list = this.missingChunks;
        sb.append(list == null ? "null" : Integer.valueOf(list.size()));
        sb.append(", encodedMissingChunks=");
        List<Integer> list2 = this.encodedMissingChunks;
        sb.append(list2 != null ? Integer.valueOf(list2.size()) : "null");
        sb.append('}');
        return sb.toString();
    }
}
