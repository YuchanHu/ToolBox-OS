package com.telink.ble.mesh.core.message.generic;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class OnOffGetMessage extends GenericMessage {
    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return null;
    }

    public static OnOffGetMessage getSimple(int i, int i2, int i3) {
        OnOffGetMessage onOffGetMessage = new OnOffGetMessage(i, i2);
        onOffGetMessage.setResponseMax(i3);
        return onOffGetMessage;
    }

    public OnOffGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.G_ONOFF_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.G_ONOFF_STATUS.value;
    }
}
