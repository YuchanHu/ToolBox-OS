package com.telink.ble.mesh.core.message.privatebeacon;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.config.ConfigMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class PrivateBeaconSetMessage extends ConfigMessage {
    public boolean isComplete;
    public byte privateBeacon;
    public byte randomUpdateIntervalSteps;

    public PrivateBeaconSetMessage(int i) {
        super(i);
        this.isComplete = false;
    }

    public static PrivateBeaconSetMessage getSimple(int i, byte b) {
        PrivateBeaconSetMessage privateBeaconSetMessage = new PrivateBeaconSetMessage(i);
        privateBeaconSetMessage.privateBeacon = b;
        return privateBeaconSetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.PRIVATE_BEACON_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.PRIVATE_BEACON_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return !this.isComplete ? new byte[]{this.privateBeacon} : ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).put(this.privateBeacon).put(this.randomUpdateIntervalSteps).array();
    }
}
