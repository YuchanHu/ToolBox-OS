package com.telink.ble.mesh.core.message.lighting;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class LcOmStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<LcOmStatusMessage> CREATOR = new Parcelable.Creator<LcOmStatusMessage>() { // from class: com.telink.ble.mesh.core.message.lighting.LcOmStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ LcOmStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ LcOmStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LcOmStatusMessage createFromParcel(Parcel parcel) {
            return new LcOmStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LcOmStatusMessage[] newArray(int i) {
            return new LcOmStatusMessage[i];
        }
    };
    private byte mode;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public LcOmStatusMessage() {
    }

    protected LcOmStatusMessage(Parcel parcel) {
        this.mode = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.mode = bArr[0];
    }

    public byte getMode() {
        return this.mode;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.mode);
    }
}
