package com.telink.ble.mesh.core.access;

/* loaded from: classes.dex */
public enum BindingBearer {
    GattOnly,
    Any,
    Flex
}
