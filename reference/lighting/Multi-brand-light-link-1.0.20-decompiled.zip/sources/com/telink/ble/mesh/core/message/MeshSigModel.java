package com.telink.ble.mesh.core.message;

import com.telink.ble.mesh.core.provisioning.ProvisioningController;
import java.io.Serializable;

/* loaded from: classes.dex */
public enum MeshSigModel implements Serializable {
    SIG_MD_CFG_SERVER(0, "config server", "", true),
    SIG_MD_CFG_CLIENT(1, "config client", "", true),
    SIG_MD_HEALTH_SERVER(2, "health server", "health server", false),
    SIG_MD_HEALTH_CLIENT(3, "health client", "health client", false),
    SIG_MD_REMOTE_PROV_SERVER(4, "remote provision server", "", true),
    SIG_MD_REMOTE_PROV_CLIENT(5, "remote provision client", "", true),
    SIG_MD_DF_CFG_S(6, "Directed Forwarding Configuration server", "", true),
    SIG_MD_DF_CFG_C(7, "Directed Forwarding Configuration client", "", true),
    SIG_MD_BRIDGE_CFG_SERVER(8, "Bridge Configuration Server", "", true),
    SIG_MD_BRIDGE_CFG_CLIENT(9, "Bridge Configuration Client", "", true),
    SIG_MD_PRIVATE_BEACON_SERVER(10, "Mesh Private Beacon Server", "", true),
    SIG_MD_PRIVATE_BEACON_CLIENT(11, "Mesh Private Beacon Client", "", true),
    SIG_MD_ON_DEMAND_PROXY_S(12, "On-Demand Private Proxy Server", "", true),
    SIG_MD_ON_DEMAND_PROXY_C(13, "On-Demand Private Proxy Client", "", true),
    SIG_MD_SAR_CFG_S(14, "SAR Configuration Server", "", true),
    SIG_MD_SAR_CFG_C(15, "SAR Configuration Client", "", true),
    SIG_MD_CFG_OP_AGG_S(16, "Opcodes Aggregator Server", "aggregator", true),
    SIG_MD_CFG_OP_AGG_C(17, "Opcodes Aggregator Client", "aggregator", true),
    SIG_MD_LARGE_CPS_S(18, "Large Composition Data Server", "", true),
    SIG_MD_LARGE_CPS_C(19, "Large Composition Data Client", "", true),
    SIG_MD_SOL_PDU_RPL_CFG_S(20, "Solicitation PDU RPL Configuration Server", "", true),
    SIG_MD_SOL_PDU_RPL_CFG_C(21, "Solicitation PDU RPL Configuration Client", "", true),
    SIG_MD_G_ONOFF_S(4096, "Generic OnOff Server", "Generic"),
    SIG_MD_G_ONOFF_C(ProvisioningController.STATE_INVITE, "Generic OnOff Client", "Generic"),
    SIG_MD_G_LEVEL_S(ProvisioningController.STATE_CAPABILITY, "Generic Level Server", "Generic"),
    SIG_MD_G_LEVEL_C(ProvisioningController.STATE_START, "Generic Level Client", "Generic"),
    SIG_MD_G_DEF_TRANSIT_TIME_S(ProvisioningController.STATE_PUB_KEY_SENT, "Generic Default Transition Time Server ", "Generic"),
    SIG_MD_G_DEF_TRANSIT_TIME_C(ProvisioningController.STATE_PUB_KEY_RECEIVED, "Generic Default Transition Time Client ", "Generic"),
    SIG_MD_G_POWER_ONOFF_S(ProvisioningController.STATE_CONFIRM_SENT, "Generic Power OnOff Server", "Generic"),
    SIG_MD_G_POWER_ONOFF_SETUP_S(ProvisioningController.STATE_CONFIRM_RECEIVED, "Generic Power OnOff Setup Server", "Generic"),
    SIG_MD_G_POWER_ONOFF_C(ProvisioningController.STATE_RANDOM_SENT, "Generic Power OnOff Client", "Generic"),
    SIG_MD_G_POWER_LEVEL_S(ProvisioningController.STATE_RANDOM_RECEIVED, "Generic Power Level Server", "Generic"),
    SIG_MD_G_POWER_LEVEL_SETUP_S(ProvisioningController.STATE_DATA, "Generic Power Level Setup Server", "Generic"),
    SIG_MD_G_POWER_LEVEL_C(ProvisioningController.STATE_COMPLETE, "Generic Power Level Client", "Generic"),
    SIG_MD_G_BAT_S(ProvisioningController.STATE_FAILED, "Generic Battery Server", "Generic"),
    SIG_MD_G_BAT_C(4109, "Generic Battery Client", "Generic"),
    SIG_MD_G_LOCATION_S(4110, "Generic Location Server", "Generic"),
    SIG_MD_G_LOCATION_SETUP_S(4111, "Generic Location Setup Server", "Generic"),
    SIG_MD_G_LOCATION_C(4112, "Generic Location Client", "Generic"),
    SIG_MD_G_ADMIN_PROP_S(4113, "Generic Admin Property Server", "Generic"),
    SIG_MD_G_MFR_PROP_S(4114, "Generic Manufacturer Property Server", "Generic"),
    SIG_MD_G_USER_PROP_S(4115, "Generic User Property Server", "Generic"),
    SIG_MD_G_CLIENT_PROP_S(4116, "Generic Client Property Server", "Generic"),
    SIG_MD_G_PROP_C(4117, "Generic Property Client", "Generic"),
    SIG_MD_SENSOR_S(4352, "Sensor Server", "Sensors"),
    SIG_MD_SENSOR_SETUP_S(4353, "Sensor Setup Server", "Sensors"),
    SIG_MD_SENSOR_C(4354, "Sensor Client", "Sensors"),
    SIG_MD_TIME_S(4608, "Time Server", "Time and Scenes"),
    SIG_MD_TIME_SETUP_S(4609, "Time Setup Server", "Time and Scenes"),
    SIG_MD_TIME_C(4610, "Time Client", "Time and Scenes"),
    SIG_MD_SCENE_S(4611, "Scene Server", "Time and Scenes"),
    SIG_MD_SCENE_SETUP_S(4612, "Scene Setup Server", "Time and Scenes"),
    SIG_MD_SCENE_C(4613, "Scene Client", "Time and Scenes"),
    SIG_MD_SCHED_S(4614, "MeshScheduler Server", "Time and Scenes"),
    SIG_MD_SCHED_SETUP_S(4615, "MeshScheduler Setup Server", "Time and Scenes"),
    SIG_MD_SCHED_C(4616, "MeshScheduler Client", "Time and Scenes"),
    SIG_MD_LIGHTNESS_S(4864, "Light Lightness Server", "Lighting"),
    SIG_MD_LIGHTNESS_SETUP_S(4865, "Light Lightness Setup Server", "Lighting"),
    SIG_MD_LIGHTNESS_C(4866, "Light Lightness Client", "Lighting"),
    SIG_MD_LIGHT_CTL_S(4867, "Light CTL Server", "Lighting"),
    SIG_MD_LIGHT_CTL_SETUP_S(4868, "Light CTL Setup Server", "Lighting"),
    SIG_MD_LIGHT_CTL_C(4869, "Light CTL Client", "Lighting"),
    SIG_MD_LIGHT_CTL_TEMP_S(4870, "Light CTL Temperature Server", "Lighting"),
    SIG_MD_LIGHT_HSL_S(4871, "Light HSL Server", "Lighting"),
    SIG_MD_LIGHT_HSL_SETUP_S(4872, "Light HSL Setup Server", "Lighting"),
    SIG_MD_LIGHT_HSL_C(4873, "Light HSL Client", "Lighting"),
    SIG_MD_LIGHT_HSL_HUE_S(4874, "Light HSL Hue Server", "Lighting"),
    SIG_MD_LIGHT_HSL_SAT_S(4875, "Light HSL Saturation Server", "Lighting"),
    SIG_MD_LIGHT_XYL_S(4876, "Light xyL Server", "Lighting"),
    SIG_MD_LIGHT_XYL_SETUP_S(4877, "Light xyL Setup Server", "Lighting"),
    SIG_MD_LIGHT_XYL_C(4878, "Light xyL Client", "Lighting"),
    SIG_MD_LIGHT_LC_S(4879, "Light LC Server", "Lighting"),
    SIG_MD_LIGHT_LC_SETUP_S(4880, "Light LC Setup Server", "Lighting"),
    SIG_MD_LIGHT_LC_C(4881, "Light LC Client", "Lighting"),
    SIG_MD_OBJ_TRANSFER_S(5120, "BLOB Transfer Server", "OTA"),
    SIG_MD_OBJ_TRANSFER_C(5121, "BLOB Transfer Client", "OTA"),
    SIG_MD_FW_UPDATE_S(5122, "Firmware Update Server", "OTA"),
    SIG_MD_FW_UPDATE_C(5123, "Firmware Update Client", "OTA"),
    SIG_MD_FW_DISTRIBUT_S(5124, "Firmware Distribute Server", "OTA"),
    SIG_MD_FW_DISTRIBUT_C(5125, "Firmware Distribute Client", "OTA");

    public boolean deviceKeyEnc;
    public String group;
    public int modelId;
    public String modelName;
    public boolean selected;

    MeshSigModel(int i, String str, String str2) {
        this(i, str, str2, false);
    }

    MeshSigModel(int i, String str, String str2, boolean z) {
        this.modelId = i;
        this.modelName = str;
        this.group = str2;
        this.deviceKeyEnc = z;
    }

    public static boolean useDeviceKeyForEnc(int i) {
        MeshSigModel byId = getById(i);
        return byId != null && byId.deviceKeyEnc;
    }

    public static boolean useDeviceKeyForEnc(String str) {
        MeshSigModel byId = getById(Integer.valueOf(str, 16).intValue());
        return byId != null && byId.deviceKeyEnc;
    }

    public static MeshSigModel[] getDefaultSubList() {
        return new MeshSigModel[]{SIG_MD_G_ONOFF_S, SIG_MD_LIGHTNESS_S, SIG_MD_LIGHT_CTL_S, SIG_MD_LIGHT_CTL_TEMP_S, SIG_MD_LIGHT_HSL_S, SIG_MD_LIGHT_LC_S, SIG_MD_G_LEVEL_S};
    }

    public static MeshSigModel[] getLevelAssociatedList() {
        return new MeshSigModel[]{SIG_MD_LIGHTNESS_S, SIG_MD_LIGHT_CTL_TEMP_S, SIG_MD_LIGHT_HSL_HUE_S, SIG_MD_LIGHT_HSL_SAT_S};
    }

    public static MeshSigModel getById(int i) {
        for (MeshSigModel meshSigModel : values()) {
            if (meshSigModel.modelId == i) {
                return meshSigModel;
            }
        }
        return null;
    }
}
