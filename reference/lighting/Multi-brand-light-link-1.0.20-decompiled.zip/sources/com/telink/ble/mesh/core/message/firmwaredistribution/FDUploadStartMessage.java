package com.telink.ble.mesh.core.message.firmwaredistribution;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class FDUploadStartMessage extends UpdatingMessage {
    public long uploadBLOBID;
    public byte[] uploadFirmwareID;
    public byte[] uploadFirmwareMetadata;
    public int uploadFirmwareMetadataLength;
    public int uploadFirmwareSize;
    public int uploadTTL;
    public int uploadTimeoutBase;

    public FDUploadStartMessage(int i, int i2) {
        super(i, i2);
    }

    public static FDUploadStartMessage getSimple(int i, int i2) {
        FDUploadStartMessage fDUploadStartMessage = new FDUploadStartMessage(i, i2);
        fDUploadStartMessage.setResponseMax(1);
        return fDUploadStartMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FD_UPLOAD_START.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FD_UPLOAD_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(this.uploadFirmwareMetadata.length + 16 + this.uploadFirmwareID.length).order(ByteOrder.LITTLE_ENDIAN);
        byteBufferOrder.put((byte) this.uploadTTL).putShort((short) this.uploadTimeoutBase).putLong(this.uploadBLOBID).putInt(this.uploadFirmwareSize).put((byte) this.uploadFirmwareMetadataLength).put(this.uploadFirmwareMetadata).put(this.uploadFirmwareID);
        return byteBufferOrder.array();
    }
}
