package com.telink.ble.mesh.core.message.firmwareupdate;

/* loaded from: classes.dex */
public enum AdditionalInformation {
    No_changes(0, "No changes to node composition data"),
    CPS_CHANGED_1(1, "Node composition data changed. The node does not support remote provisioning."),
    CPS_CHANGED_2(2, "Node composition data changed, and remote provisioning is supported. The node supports remote provisioning and composition data page 0x80. Page 0x80 contains different composition data than page 0x0."),
    NODE_UNPROVISIONED(3, "Node unprovisioned. The node is unprovisioned after successful application of a verified firmware image."),
    UNKNOWN_ERROR(255, "unknown error");

    public final int code;
    public final String desc;

    AdditionalInformation(int i, String str) {
        this.code = i;
        this.desc = str;
    }

    public static AdditionalInformation valueOf(int i) {
        for (AdditionalInformation additionalInformation : values()) {
            if (additionalInformation.code == i) {
                return additionalInformation;
            }
        }
        return UNKNOWN_ERROR;
    }
}
