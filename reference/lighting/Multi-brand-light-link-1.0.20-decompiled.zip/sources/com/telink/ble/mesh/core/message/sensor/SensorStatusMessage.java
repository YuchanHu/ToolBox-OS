package com.telink.ble.mesh.core.message.sensor;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.SparseArray;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import com.telink.ble.mesh.util.Arrays;
import com.telink.ble.mesh.util.MeshLogger;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class SensorStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<SensorStatusMessage> CREATOR = new Parcelable.Creator<SensorStatusMessage>() { // from class: com.telink.ble.mesh.core.message.sensor.SensorStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SensorStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SensorStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SensorStatusMessage createFromParcel(Parcel parcel) {
            return new SensorStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SensorStatusMessage[] newArray(int i) {
            return new SensorStatusMessage[i];
        }
    };
    public SparseArray<byte[]> sensorData;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
    }

    public SensorStatusMessage() {
    }

    protected SensorStatusMessage(Parcel parcel) {
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        int i;
        int iBytes2Integer;
        int i2;
        this.sensorData = new SparseArray<>();
        int i3 = 0;
        while (i3 < bArr.length) {
            int i4 = i3 + 1;
            int i5 = bArr[i3];
            if ((i5 & 1) == 0) {
                i = (i5 & 31) >> 1;
                i2 = i3 + 2;
                iBytes2Integer = (bArr[i4] << 8) | ((i5 & 255) >> 5);
            } else {
                int i6 = (i5 & 255) >> 1;
                i = i6 == 127 ? 0 : i6 + 1;
                iBytes2Integer = MeshUtils.bytes2Integer(bArr, i4, 2, ByteOrder.LITTLE_ENDIAN);
                i2 = i3 + 3;
            }
            byte[] bArr2 = new byte[i];
            System.arraycopy(bArr, i2, bArr2, 0, i);
            i3 = i2 + i;
            MeshLogger.d(String.format("sensor status : %04X - ", Integer.valueOf(iBytes2Integer)) + Arrays.bytesToHexString(bArr2));
            this.sensorData.append(iBytes2Integer, bArr2);
        }
    }
}
