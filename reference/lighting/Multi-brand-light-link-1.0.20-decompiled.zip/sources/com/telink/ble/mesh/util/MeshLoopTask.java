package com.telink.ble.mesh.util;

import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.NotificationMessage;
import java.util.List;

/* loaded from: classes.dex */
public class MeshLoopTask {
    List<MeshMessage> meshMessages;
    long minSpaceForUnreliable = 250;
    long minWaitingForReliable = 50;
    private int msgIndex;
    List<NotificationMessage> notificationMessages;

    interface Callback {
        int onLoopComplete();
    }

    void onReliableStop() {
    }

    void onMeshNotification(NotificationMessage notificationMessage) {
        int i = this.msgIndex;
        if (this.meshMessages.size() <= i || this.meshMessages.get(i).getResponseOpcode() != notificationMessage.getOpcode()) {
            return;
        }
        this.notificationMessages.add(notificationMessage);
    }

    private MeshMessage getCurrentMessage() {
        int i = this.msgIndex;
        if (this.meshMessages.size() > i) {
            return this.meshMessages.get(i);
        }
        return null;
    }
}
