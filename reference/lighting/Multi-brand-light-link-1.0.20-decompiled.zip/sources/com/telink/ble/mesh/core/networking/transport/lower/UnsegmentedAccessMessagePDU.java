package com.telink.ble.mesh.core.networking.transport.lower;

import com.telink.ble.mesh.core.networking.NetworkLayerPDU;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class UnsegmentedAccessMessagePDU extends LowerTransportPDU {
    private byte aid;
    private byte akf;
    private final byte seg = 0;
    private byte[] upperTransportPDU;

    public byte getSeg() {
        return (byte) 0;
    }

    @Override // com.telink.ble.mesh.core.networking.transport.lower.LowerTransportPDU
    public boolean segmented() {
        return false;
    }

    public UnsegmentedAccessMessagePDU() {
    }

    public UnsegmentedAccessMessagePDU(byte b, byte b2, byte[] bArr) {
        this.akf = b;
        this.aid = b2;
        this.upperTransportPDU = bArr;
    }

    @Override // com.telink.ble.mesh.core.networking.transport.lower.LowerTransportPDU
    public int getType() {
        return TYPE_UNSEGMENTED_ACCESS_MESSAGE;
    }

    @Override // com.telink.ble.mesh.core.networking.NetworkingPDU
    public byte[] toByteArray() {
        byte b = (byte) ((this.akf << 6) | this.aid);
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(this.upperTransportPDU.length + 1).order(ByteOrder.BIG_ENDIAN);
        byteBufferOrder.put(b);
        byteBufferOrder.put(this.upperTransportPDU);
        return byteBufferOrder.array();
    }

    public boolean parse(NetworkLayerPDU networkLayerPDU) {
        byte[] transportPDU = networkLayerPDU.getTransportPDU();
        byte b = transportPDU[0];
        this.akf = (byte) ((b >> 6) & 1);
        this.aid = (byte) (b & 63);
        int length = transportPDU.length - 1;
        byte[] bArr = new byte[length];
        System.arraycopy(transportPDU, 1, bArr, 0, length);
        this.upperTransportPDU = bArr;
        return length != 0;
    }

    public byte getAkf() {
        return this.akf;
    }

    public void setAkf(byte b) {
        this.akf = b;
    }

    public byte getAid() {
        return this.aid;
    }

    public void setAid(byte b) {
        this.aid = b;
    }

    public byte[] getUpperTransportPDU() {
        return this.upperTransportPDU;
    }

    public void setUpperTransportPDU(byte[] bArr) {
        this.upperTransportPDU = bArr;
    }
}
