package com.telink.ble.mesh.foundation.parameter;

import com.telink.ble.mesh.core.ble.UUIDInfo;
import com.telink.ble.mesh.entity.ProvisioningDevice;

/* loaded from: classes.dex */
public class ProvisioningParameters extends Parameters {
    public ProvisioningParameters(ProvisioningDevice provisioningDevice) {
        setScanFilter(createScanFilter(UUIDInfo.SERVICE_PROVISION));
        set(Parameters.ACTION_PROVISIONING_TARGET, provisioningDevice);
    }
}
