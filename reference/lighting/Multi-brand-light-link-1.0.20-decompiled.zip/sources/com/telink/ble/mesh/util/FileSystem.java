package com.telink.ble.mesh.util;

import android.content.Context;
import android.os.Environment;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;

/* loaded from: classes.dex */
public abstract class FileSystem {
    public static boolean writeAsObject(Context context, String str, Object obj) throws Throwable {
        Throwable th;
        FileOutputStream fileOutputStream;
        ObjectOutputStream objectOutputStream;
        File file = new File(context.getFilesDir(), str);
        ObjectOutputStream objectOutputStream2 = null;
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
            fileOutputStream = new FileOutputStream(file);
            try {
                objectOutputStream = new ObjectOutputStream(fileOutputStream);
            } catch (IOException unused) {
            } catch (Throwable th2) {
                th = th2;
            }
        } catch (IOException unused2) {
            fileOutputStream = null;
        } catch (Throwable th3) {
            th = th3;
            fileOutputStream = null;
        }
        try {
            objectOutputStream.writeObject(obj);
            objectOutputStream.flush();
            try {
                objectOutputStream.close();
                fileOutputStream.close();
            } catch (Exception unused3) {
            }
            return true;
        } catch (IOException unused4) {
            objectOutputStream2 = objectOutputStream;
            if (objectOutputStream2 != null) {
                try {
                    objectOutputStream2.close();
                } catch (Exception unused5) {
                    return false;
                }
            }
            if (objectOutputStream2 != null) {
                fileOutputStream.close();
            }
            return false;
        } catch (Throwable th4) {
            th = th4;
            objectOutputStream2 = objectOutputStream;
            if (objectOutputStream2 != null) {
                try {
                    objectOutputStream2.close();
                } catch (Exception unused6) {
                    throw th;
                }
            }
            if (objectOutputStream2 != null) {
                fileOutputStream.close();
            }
            throw th;
        }
    }

    /* JADX WARN: Can't wrap try/catch for region: R(5:5|(4:33|6|36|7)|31|8|23) */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0036 A[EXC_TOP_SPLITTER, PHI: r1 r5
      0x0036: PHI (r1v4 ??) = (r1v6 ??), (r1v7 ??) binds: [B:21:0x0057, B:7:0x0032] A[DONT_GENERATE, DONT_INLINE]
      0x0036: PHI (r5v6 java.lang.Object) = (r5v11 java.lang.Object), (r5v9 java.lang.Object) binds: [B:21:0x0057, B:7:0x0032] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:34:0x005f A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r1v0, types: [java.io.File] */
    /* JADX WARN: Type inference failed for: r1v2 */
    /* JADX WARN: Type inference failed for: r1v4, types: [java.io.ObjectInputStream] */
    /* JADX WARN: Type inference failed for: r1v6 */
    /* JADX WARN: Type inference failed for: r1v7 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.Object readAsObject(android.content.Context r4, java.lang.String r5) throws java.lang.Throwable {
        /*
            java.lang.String r0 = "read object error : "
            java.io.File r4 = r4.getFilesDir()
            java.io.File r1 = new java.io.File
            r1.<init>(r4, r5)
            boolean r4 = r1.exists()
            r5 = 0
            if (r4 != 0) goto L13
            return r5
        L13:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r2 = "obj file size: "
            r4.<init>(r2)
            long r2 = r1.length()
            r4.append(r2)
            java.lang.String r4 = r4.toString()
            com.telink.ble.mesh.util.MeshLogger.d(r4)
            java.io.FileInputStream r4 = new java.io.FileInputStream     // Catch: java.lang.Throwable -> L3e java.lang.ClassNotFoundException -> L40 java.io.IOException -> L42
            r4.<init>(r1)     // Catch: java.lang.Throwable -> L3e java.lang.ClassNotFoundException -> L40 java.io.IOException -> L42
            java.io.ObjectInputStream r1 = new java.io.ObjectInputStream     // Catch: java.lang.Throwable -> L3e java.lang.ClassNotFoundException -> L40 java.io.IOException -> L42
            r1.<init>(r4)     // Catch: java.lang.Throwable -> L3e java.lang.ClassNotFoundException -> L40 java.io.IOException -> L42
            java.lang.Object r5 = r1.readObject()     // Catch: java.lang.ClassNotFoundException -> L3a java.io.IOException -> L3c java.lang.Throwable -> L5b
        L36:
            r1.close()     // Catch: java.lang.Exception -> L5a
            goto L5a
        L3a:
            r4 = move-exception
            goto L44
        L3c:
            r4 = move-exception
            goto L44
        L3e:
            r4 = move-exception
            goto L5d
        L40:
            r4 = move-exception
            goto L43
        L42:
            r4 = move-exception
        L43:
            r1 = r5
        L44:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L5b
            r2.<init>(r0)     // Catch: java.lang.Throwable -> L5b
            java.lang.String r4 = r4.toString()     // Catch: java.lang.Throwable -> L5b
            r2.append(r4)     // Catch: java.lang.Throwable -> L5b
            java.lang.String r4 = r2.toString()     // Catch: java.lang.Throwable -> L5b
            com.telink.ble.mesh.util.MeshLogger.w(r4)     // Catch: java.lang.Throwable -> L5b
            if (r1 == 0) goto L5a
            goto L36
        L5a:
            return r5
        L5b:
            r4 = move-exception
            r5 = r1
        L5d:
            if (r5 == 0) goto L62
            r5.close()     // Catch: java.lang.Exception -> L62
        L62:
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.telink.ble.mesh.util.FileSystem.readAsObject(android.content.Context, java.lang.String):java.lang.Object");
    }

    public static void deleteFile(Context context, String str) {
        if (new File(context.getFilesDir(), str).delete()) {
            MeshLogger.d("file delete success");
        } else {
            MeshLogger.d("file delete fail");
        }
    }

    public static File getSettingPath() {
        return new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "TelinkBleMesh");
    }

    /* JADX WARN: Removed duplicated region for block: B:45:0x0057 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.io.File writeString(java.io.File r2, java.lang.String r3, java.lang.String r4) throws java.lang.Throwable {
        /*
            boolean r0 = r2.exists()
            if (r0 != 0) goto L9
            r2.mkdirs()
        L9:
            java.io.File r0 = new java.io.File
            r0.<init>(r2, r3)
            r2 = 0
            boolean r3 = r0.exists()     // Catch: java.lang.Throwable -> L41 java.io.IOException -> L43
            if (r3 != 0) goto L18
            r0.createNewFile()     // Catch: java.lang.Throwable -> L41 java.io.IOException -> L43
        L18:
            java.io.FileOutputStream r3 = new java.io.FileOutputStream     // Catch: java.lang.Throwable -> L41 java.io.IOException -> L43
            r3.<init>(r0)     // Catch: java.lang.Throwable -> L41 java.io.IOException -> L43
            byte[] r4 = r4.getBytes()     // Catch: java.lang.Throwable -> L37 java.io.IOException -> L3c
            r3.write(r4)     // Catch: java.lang.Throwable -> L37 java.io.IOException -> L3c
            r3.flush()     // Catch: java.lang.Throwable -> L37 java.io.IOException -> L3c
            java.io.FileDescriptor r4 = r3.getFD()     // Catch: java.lang.Throwable -> L37 java.io.IOException -> L3c
            r4.sync()     // Catch: java.lang.Throwable -> L37 java.io.IOException -> L3c
            r3.close()     // Catch: java.io.IOException -> L32
            goto L36
        L32:
            r2 = move-exception
            r2.printStackTrace()
        L36:
            return r0
        L37:
            r2 = move-exception
            r1 = r3
            r3 = r2
            r2 = r1
            goto L55
        L3c:
            r4 = move-exception
            r1 = r4
            r4 = r3
            r3 = r1
            goto L45
        L41:
            r3 = move-exception
            goto L55
        L43:
            r3 = move-exception
            r4 = r2
        L45:
            r3.printStackTrace()     // Catch: java.lang.Throwable -> L53
            if (r4 == 0) goto L52
            r4.close()     // Catch: java.io.IOException -> L4e
            goto L52
        L4e:
            r3 = move-exception
            r3.printStackTrace()
        L52:
            return r2
        L53:
            r3 = move-exception
            r2 = r4
        L55:
            if (r2 == 0) goto L5f
            r2.close()     // Catch: java.io.IOException -> L5b
            goto L5f
        L5b:
            r2 = move-exception
            r2.printStackTrace()
        L5f:
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.telink.ble.mesh.util.FileSystem.writeString(java.io.File, java.lang.String, java.lang.String):java.io.File");
    }

    public static String readString(File file) throws IOException {
        if (!file.exists()) {
            return "";
        }
        try {
            FileReader fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            StringBuilder sb = new StringBuilder();
            while (true) {
                String line = bufferedReader.readLine();
                if (line != null) {
                    sb.append(line);
                } else {
                    bufferedReader.close();
                    fileReader.close();
                    return sb.toString();
                }
            }
        } catch (IOException unused) {
            return "";
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:41:0x0053 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.io.File writeByteArray(java.io.File r2, java.lang.String r3, byte[] r4) throws java.lang.Throwable {
        /*
            boolean r0 = r2.exists()
            if (r0 != 0) goto L9
            r2.mkdirs()
        L9:
            java.io.File r0 = new java.io.File
            r0.<init>(r2, r3)
            r2 = 0
            boolean r3 = r0.exists()     // Catch: java.lang.Throwable -> L3d java.io.IOException -> L3f
            if (r3 != 0) goto L18
            r0.createNewFile()     // Catch: java.lang.Throwable -> L3d java.io.IOException -> L3f
        L18:
            java.io.FileOutputStream r3 = new java.io.FileOutputStream     // Catch: java.lang.Throwable -> L3d java.io.IOException -> L3f
            r3.<init>(r0)     // Catch: java.lang.Throwable -> L3d java.io.IOException -> L3f
            r3.write(r4)     // Catch: java.lang.Throwable -> L33 java.io.IOException -> L38
            r3.flush()     // Catch: java.lang.Throwable -> L33 java.io.IOException -> L38
            java.io.FileDescriptor r4 = r3.getFD()     // Catch: java.lang.Throwable -> L33 java.io.IOException -> L38
            r4.sync()     // Catch: java.lang.Throwable -> L33 java.io.IOException -> L38
            r3.close()     // Catch: java.io.IOException -> L2e
            goto L32
        L2e:
            r2 = move-exception
            r2.printStackTrace()
        L32:
            return r0
        L33:
            r2 = move-exception
            r1 = r3
            r3 = r2
            r2 = r1
            goto L51
        L38:
            r4 = move-exception
            r1 = r4
            r4 = r3
            r3 = r1
            goto L41
        L3d:
            r3 = move-exception
            goto L51
        L3f:
            r3 = move-exception
            r4 = r2
        L41:
            r3.printStackTrace()     // Catch: java.lang.Throwable -> L4f
            if (r4 == 0) goto L4e
            r4.close()     // Catch: java.io.IOException -> L4a
            goto L4e
        L4a:
            r3 = move-exception
            r3.printStackTrace()
        L4e:
            return r2
        L4f:
            r3 = move-exception
            r2 = r4
        L51:
            if (r2 == 0) goto L5b
            r2.close()     // Catch: java.io.IOException -> L57
            goto L5b
        L57:
            r2 = move-exception
            r2.printStackTrace()
        L5b:
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.telink.ble.mesh.util.FileSystem.writeByteArray(java.io.File, java.lang.String, byte[]):java.io.File");
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [boolean] */
    public static byte[] readByteArray(File file) throws Throwable {
        FileInputStream fileInputStream;
        ?? Exists = file.exists();
        FileInputStream fileInputStream2 = null;
        try {
            if (Exists == 0) {
                return null;
            }
            try {
                fileInputStream = new FileInputStream(file);
                try {
                    byte[] bArr = new byte[fileInputStream.available()];
                    fileInputStream.read(bArr);
                    try {
                        fileInputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    return bArr;
                } catch (IOException e2) {
                    e = e2;
                    e.printStackTrace();
                    if (fileInputStream != null) {
                        try {
                            fileInputStream.close();
                        } catch (IOException e3) {
                            e3.printStackTrace();
                        }
                    }
                    return null;
                }
            } catch (IOException e4) {
                e = e4;
                fileInputStream = null;
            } catch (Throwable th) {
                th = th;
                if (fileInputStream2 != null) {
                    try {
                        fileInputStream2.close();
                    } catch (IOException e5) {
                        e5.printStackTrace();
                    }
                }
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
            fileInputStream2 = Exists;
        }
    }

    public static File getBinPath(int i, int i2) {
        return new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "TelinkBleMesh" + File.separator + "bin" + File.separator + i + File.separator + String.format("%04X", Integer.valueOf(i2)) + ".bin");
    }

    public static File getBinDownloadingPath(int i, int i2) {
        return new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "TelinkBleMesh" + File.separator + "bin" + File.separator + i + File.separator + String.format("%04X", Integer.valueOf(i2)) + ".bin_tmp");
    }
}
