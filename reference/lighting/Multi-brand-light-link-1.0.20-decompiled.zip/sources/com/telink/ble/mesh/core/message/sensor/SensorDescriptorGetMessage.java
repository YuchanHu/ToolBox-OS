package com.telink.ble.mesh.core.message.sensor;

import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class SensorDescriptorGetMessage extends GenericMessage {
    private Integer propertyID;

    public static SensorDescriptorGetMessage getSimple(int i, int i2, Integer num) {
        SensorDescriptorGetMessage sensorDescriptorGetMessage = new SensorDescriptorGetMessage(i, i2);
        sensorDescriptorGetMessage.propertyID = num;
        sensorDescriptorGetMessage.setResponseMax(1);
        return sensorDescriptorGetMessage;
    }

    public static SensorDescriptorGetMessage getAll(int i, int i2) {
        SensorDescriptorGetMessage sensorDescriptorGetMessage = new SensorDescriptorGetMessage(i, i2);
        sensorDescriptorGetMessage.propertyID = null;
        sensorDescriptorGetMessage.setResponseMax(1);
        return sensorDescriptorGetMessage;
    }

    public SensorDescriptorGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.SENSOR_DESCRIP_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.SENSOR_DESCRIP_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        Integer num = this.propertyID;
        if (num == null) {
            return null;
        }
        return MeshUtils.integer2Bytes(num.intValue(), 2, ByteOrder.LITTLE_ENDIAN);
    }

    public void setPropertyID(int i) {
        this.propertyID = Integer.valueOf(i);
    }
}
