package com.telink.ble.mesh.core.ble;

/* loaded from: classes.dex */
public class LeScanSetting {
    public long spacing;
    public long timeout;

    public static LeScanSetting getDefault() {
        LeScanSetting leScanSetting = new LeScanSetting();
        leScanSetting.spacing = 5000L;
        leScanSetting.timeout = 10000L;
        return leScanSetting;
    }

    public LeScanSetting() {
    }

    public LeScanSetting(long j, long j2) {
        this.spacing = j;
        this.timeout = j2;
    }
}
