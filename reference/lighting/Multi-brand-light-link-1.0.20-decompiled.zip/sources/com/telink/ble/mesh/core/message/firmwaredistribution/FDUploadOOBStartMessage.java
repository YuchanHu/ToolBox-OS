package com.telink.ble.mesh.core.message.firmwaredistribution;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;

/* loaded from: classes.dex */
public class FDUploadOOBStartMessage extends UpdatingMessage {
    public byte[] uploadFirmwareID;
    public int uploadURI;
    public int uploadURILength;

    public FDUploadOOBStartMessage(int i, int i2) {
        super(i, i2);
    }

    public static FDUploadOOBStartMessage getSimple(int i, int i2) {
        FDUploadOOBStartMessage fDUploadOOBStartMessage = new FDUploadOOBStartMessage(i, i2);
        fDUploadOOBStartMessage.setResponseMax(1);
        return fDUploadOOBStartMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FD_UPLOAD_START.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FD_UPLOAD_STATUS.value;
    }
}
