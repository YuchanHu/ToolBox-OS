package com.telink.ble.mesh.core.message.generic;

import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class DeltaSetMessage extends GenericMessage {
    private boolean ack;
    private byte delay;
    private int deltaLevel;
    private boolean isComplete;
    private byte tid;
    private byte transitionTime;

    public static DeltaSetMessage getSimple(int i, int i2, int i3, boolean z, int i4) {
        DeltaSetMessage deltaSetMessage = new DeltaSetMessage(i, i2);
        deltaSetMessage.deltaLevel = i3;
        deltaSetMessage.transitionTime = (byte) 0;
        deltaSetMessage.delay = (byte) 0;
        deltaSetMessage.ack = z;
        deltaSetMessage.responseMax = i4;
        return deltaSetMessage;
    }

    public DeltaSetMessage(int i, int i2) {
        super(i, i2);
        this.isComplete = false;
        setTidPosition(4);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        if (this.ack) {
            return Opcode.G_LEVEL_STATUS.value;
        }
        return -1;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.G_DELTA_SET : Opcode.G_DELTA_SET_NOACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        if (this.isComplete) {
            return ByteBuffer.allocate(7).order(ByteOrder.LITTLE_ENDIAN).putInt(this.deltaLevel).put(this.tid).put(this.transitionTime).put(this.delay).array();
        }
        return ByteBuffer.allocate(5).order(ByteOrder.LITTLE_ENDIAN).putInt(this.deltaLevel).put(this.tid).array();
    }

    public void setDeltaLevel(int i) {
        this.deltaLevel = i;
    }

    public void setTid(byte b) {
        this.tid = b;
    }

    public void setTransitionTime(byte b) {
        this.transitionTime = b;
    }

    public void setDelay(byte b) {
        this.delay = b;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }

    public void setComplete(boolean z) {
        this.isComplete = z;
    }
}
