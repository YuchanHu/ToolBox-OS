package com.telink.ble.mesh.core.provisioning.pdu;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ProvisioningRecordRequestPDU implements ProvisioningStatePDU {
    public int fragmentMaxSize;
    public int fragmentOffset;
    public int recordID;

    @Override // com.telink.ble.mesh.core.provisioning.pdu.ProvisioningStatePDU
    public byte getState() {
        return (byte) 10;
    }

    public ProvisioningRecordRequestPDU(int i, int i2, int i3) {
        this.recordID = i;
        this.fragmentOffset = i2;
        this.fragmentMaxSize = i3;
    }

    @Override // com.telink.ble.mesh.core.provisioning.pdu.PDU
    public byte[] toBytes() {
        return ByteBuffer.allocate(6).order(ByteOrder.BIG_ENDIAN).putShort((short) this.recordID).putShort((short) this.fragmentOffset).putShort((short) this.fragmentMaxSize).array();
    }
}
