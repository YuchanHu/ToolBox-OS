package com.telink.ble.mesh.core.message.firmwaredistribution;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;

/* loaded from: classes.dex */
public class FDUploadCancelMessage extends UpdatingMessage {
    public FDUploadCancelMessage(int i, int i2) {
        super(i, i2);
    }

    public static FDUploadCancelMessage getSimple(int i, int i2) {
        FDUploadCancelMessage fDUploadCancelMessage = new FDUploadCancelMessage(i, i2);
        fDUploadCancelMessage.setResponseMax(1);
        return fDUploadCancelMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FD_UPLOAD_CANCEL.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FD_UPLOAD_STATUS.value;
    }
}
