package com.telink.ble.mesh.entity;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public final class SensorDescriptor implements Serializable, Parcelable {
    public static final Parcelable.Creator<SensorDescriptor> CREATOR = new Parcelable.Creator<SensorDescriptor>() { // from class: com.telink.ble.mesh.entity.SensorDescriptor.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SensorDescriptor createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SensorDescriptor[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SensorDescriptor createFromParcel(Parcel parcel) {
            return new SensorDescriptor(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SensorDescriptor[] newArray(int i) {
            return new SensorDescriptor[i];
        }
    };
    public static final int DATA_LEN = 8;
    public byte measurementPeriod;
    public int negativeTolerance;
    public int positiveTolerance;
    public int propertyID;
    public byte samplingFunction;
    public byte updateInterval;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    protected SensorDescriptor(Parcel parcel) {
        this.propertyID = parcel.readInt();
        this.positiveTolerance = parcel.readInt();
        this.negativeTolerance = parcel.readInt();
        this.samplingFunction = parcel.readByte();
        this.measurementPeriod = parcel.readByte();
        this.updateInterval = parcel.readByte();
    }

    public static SensorDescriptor fromBytes(byte[] bArr) {
        if (bArr.length < 8) {
            return null;
        }
        SensorDescriptor sensorDescriptor = new SensorDescriptor();
        sensorDescriptor.propertyID = MeshUtils.bytes2Integer(bArr, 0, 2, ByteOrder.LITTLE_ENDIAN);
        int iBytes2Integer = MeshUtils.bytes2Integer(bArr, 2, 3, ByteOrder.LITTLE_ENDIAN);
        sensorDescriptor.positiveTolerance = iBytes2Integer & 4095;
        sensorDescriptor.negativeTolerance = (iBytes2Integer >> 12) & 4095;
        sensorDescriptor.samplingFunction = bArr[5];
        sensorDescriptor.measurementPeriod = bArr[6];
        sensorDescriptor.updateInterval = bArr[7];
        return sensorDescriptor;
    }

    public SensorDescriptor() {
    }

    public byte[] toBytes() {
        return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.propertyID).put(MeshUtils.integer2Bytes((this.positiveTolerance & 4095) | ((this.negativeTolerance & 4095) << 12), 3, ByteOrder.LITTLE_ENDIAN)).put(this.samplingFunction).put(this.measurementPeriod).put(this.updateInterval).array();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.propertyID);
        parcel.writeInt(this.positiveTolerance);
        parcel.writeInt(this.negativeTolerance);
        parcel.writeByte(this.samplingFunction);
        parcel.writeByte(this.measurementPeriod);
        parcel.writeByte(this.updateInterval);
    }
}
