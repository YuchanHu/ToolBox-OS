package com.telink.ble.mesh.core.access.fu;

/* loaded from: classes.dex */
public enum BlobTransferType {
    LOCAL_INIT,
    GATT_INIT,
    GATT_DIST,
    MESH_DIST
}
