package com.telink.ble.mesh.core.message.directforwarding;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.config.ConfigMessage;

/* loaded from: classes.dex */
public class DirectedControlGetMessage extends ConfigMessage {
    public int netKeyIndex;

    public static DirectedControlGetMessage getSimple(int i, int i2) {
        DirectedControlGetMessage directedControlGetMessage = new DirectedControlGetMessage(i);
        directedControlGetMessage.setResponseMax(1);
        directedControlGetMessage.netKeyIndex = i2;
        return directedControlGetMessage;
    }

    public DirectedControlGetMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.DIRECTED_CONTROL_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.DIRECTED_CONTROL_STATUS.value;
    }
}
