package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class BeaconStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<BeaconStatusMessage> CREATOR = new Parcelable.Creator<BeaconStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.BeaconStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BeaconStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BeaconStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BeaconStatusMessage createFromParcel(Parcel parcel) {
            return new BeaconStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BeaconStatusMessage[] newArray(int i) {
            return new BeaconStatusMessage[i];
        }
    };
    public byte beacon;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public BeaconStatusMessage() {
    }

    protected BeaconStatusMessage(Parcel parcel) {
        this.beacon = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.beacon = bArr[0];
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.beacon);
    }
}
