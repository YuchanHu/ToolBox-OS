package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class BridgingTableRemoveMessage extends ConfigMessage {
    public int address1;
    public int address2;
    public int netKeyIndex1;
    public int netKeyIndex2;

    public BridgingTableRemoveMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.BRIDGING_TABLE_REMOVE.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.BRIDGING_TABLE_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(7).order(ByteOrder.LITTLE_ENDIAN).put(MeshUtils.integer2Bytes((this.netKeyIndex1 & 4095) | ((this.netKeyIndex2 & 4095) << 12), 3, ByteOrder.LITTLE_ENDIAN)).putShort((short) this.address1).putShort((short) this.address2).array();
    }
}
