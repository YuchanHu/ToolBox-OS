package com.telink.ble.mesh.core.networking;

import com.telink.ble.mesh.core.Encipher;
import com.telink.ble.mesh.core.MeshUtils;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class SolicitationPDU {
    private int dst;
    protected SolicitationEncryptionSuite encryptionSuite;
    private byte nid;
    private int seq;
    private int src;
    private byte ivi = 0;
    private byte ctl = 1;
    private byte ttl = 0;

    public SolicitationPDU(SolicitationEncryptionSuite solicitationEncryptionSuite) {
        this.encryptionSuite = solicitationEncryptionSuite;
    }

    public byte[] generateEncryptedPayload() {
        byte b = (byte) ((this.ivi << 7) | this.nid);
        byte b2 = (byte) ((this.ctl << 7) | this.ttl);
        byte[] bArrEncryptPduPayload = encryptPduPayload();
        byte[] bArrCreateObfuscatedNetworkHeader = createObfuscatedNetworkHeader(b2, this.seq, this.src, createPECB(createPrivacyRandom(bArrEncryptPduPayload)));
        return ByteBuffer.allocate(bArrCreateObfuscatedNetworkHeader.length + 1 + bArrEncryptPduPayload.length).order(ByteOrder.BIG_ENDIAN).put(b).put(bArrCreateObfuscatedNetworkHeader).put(bArrEncryptPduPayload).array();
    }

    private byte[] createObfuscatedNetworkHeader(byte b, int i, int i2, byte[] bArr) {
        byte[] bArrInteger2Bytes = MeshUtils.integer2Bytes(i, 3, ByteOrder.BIG_ENDIAN);
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(bArrInteger2Bytes.length + 3).order(ByteOrder.BIG_ENDIAN);
        byteBufferOrder.put(b);
        byteBufferOrder.put(bArrInteger2Bytes);
        byteBufferOrder.putShort((short) i2);
        byte[] bArrArray = byteBufferOrder.array();
        ByteBuffer.allocate(6).put(bArr, 0, 6);
        byte[] bArr2 = new byte[6];
        for (int i3 = 0; i3 < 6; i3++) {
            bArr2[i3] = (byte) (bArrArray[i3] ^ bArr[i3]);
        }
        return bArr2;
    }

    private byte[] createPECB(byte[] bArr) {
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(bArr.length + 9);
        byteBufferAllocate.order(ByteOrder.BIG_ENDIAN);
        byteBufferAllocate.put(new byte[]{0, 0, 0, 0, 0});
        byteBufferAllocate.putInt(0);
        byteBufferAllocate.put(bArr);
        return Encipher.aes(byteBufferAllocate.array(), this.encryptionSuite.privacyKey);
    }

    private byte[] createPrivacyRandom(byte[] bArr) {
        byte[] bArr2 = new byte[7];
        System.arraycopy(bArr, 0, bArr2, 0, 7);
        return bArr2;
    }

    private byte[] encryptPduPayload() {
        return Encipher.ccm(ByteBuffer.allocate(2).order(ByteOrder.BIG_ENDIAN).putShort((short) this.dst).array(), this.encryptionSuite.encryptionKey, generateNonce(), getMicLen(), true);
    }

    protected byte[] generateNonce() {
        return NonceGenerator.generateSolicitationNonce(MeshUtils.integer2Bytes(this.seq, 3, ByteOrder.BIG_ENDIAN), this.src);
    }

    private int getMicLen() {
        return this.ctl == 0 ? 4 : 8;
    }

    public byte getIvi() {
        return this.ivi;
    }

    public void setIvi(byte b) {
        this.ivi = b;
    }

    public byte getNid() {
        return this.nid;
    }

    public void setNid(byte b) {
        this.nid = b;
    }

    public byte getCtl() {
        return this.ctl;
    }

    public void setCtl(byte b) {
        this.ctl = b;
    }

    public byte getTtl() {
        return this.ttl;
    }

    public void setTtl(byte b) {
        this.ttl = b;
    }

    public int getSeq() {
        return this.seq;
    }

    public void setSeq(int i) {
        this.seq = i;
    }

    public int getSrc() {
        return this.src;
    }

    public void setSrc(int i) {
        this.src = i;
    }

    public int getDst() {
        return this.dst;
    }

    public void setDst(int i) {
        this.dst = i;
    }

    public static class SolicitationEncryptionSuite {
        protected byte[] encryptionKey;
        protected int nid;
        protected byte[] privacyKey;

        public SolicitationEncryptionSuite(byte[] bArr, byte[] bArr2, int i) {
            this.encryptionKey = bArr;
            this.privacyKey = bArr2;
            this.nid = i;
        }
    }

    public String toString() {
        return "NetworkLayerPDU{ivi=" + ((int) this.ivi) + ", nid=" + ((int) this.nid) + ", ctl=" + ((int) this.ctl) + ", ttl=" + ((int) this.ttl) + ", seq=0x" + Integer.toHexString(this.seq) + ", src=" + this.src + ", dst=" + this.dst + '}';
    }
}
