package com.telink.ble.mesh.entity;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.MeshSigModel;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/* loaded from: classes.dex */
public class CompositionData implements Serializable, Parcelable {
    public static final Parcelable.Creator<CompositionData> CREATOR = new Parcelable.Creator<CompositionData>() { // from class: com.telink.ble.mesh.entity.CompositionData.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ CompositionData createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ CompositionData[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public CompositionData createFromParcel(Parcel parcel) {
            return new CompositionData(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public CompositionData[] newArray(int i) {
            return new CompositionData[i];
        }
    };
    private static final int FEATURE_FRIEND = 4;
    private static final int FEATURE_LOW_POWER = 8;
    private static final int FEATURE_PROXY = 2;
    private static final int FEATURE_RELAY = 1;
    public int cid;
    public int crpl;
    public List<Element> elements;
    public int features;
    public int pid;
    public byte[] raw;
    public int vid;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public CompositionData() {
    }

    protected CompositionData(Parcel parcel) {
        this.cid = parcel.readInt();
        this.pid = parcel.readInt();
        this.vid = parcel.readInt();
        this.crpl = parcel.readInt();
        this.features = parcel.readInt();
    }

    public static CompositionData from(byte[] bArr) {
        if (bArr != null) {
            int i = 10;
            if (bArr.length >= 10) {
                CompositionData compositionData = new CompositionData();
                compositionData.raw = bArr;
                compositionData.cid = (bArr[0] & FUDistributor.UPDATE_TTL) | ((bArr[1] & FUDistributor.UPDATE_TTL) << 8);
                compositionData.pid = (bArr[2] & FUDistributor.UPDATE_TTL) | ((bArr[3] & FUDistributor.UPDATE_TTL) << 8);
                compositionData.vid = MeshUtils.bytes2Integer(bArr, 4, 2, ByteOrder.BIG_ENDIAN);
                compositionData.crpl = (bArr[6] & FUDistributor.UPDATE_TTL) | ((bArr[7] & FUDistributor.UPDATE_TTL) << 8);
                compositionData.features = (bArr[8] & FUDistributor.UPDATE_TTL) | ((bArr[9] & FUDistributor.UPDATE_TTL) << 8);
                compositionData.elements = new ArrayList();
                while (i < bArr.length) {
                    if (bArr.length - i < 4) {
                        return null;
                    }
                    Element element = new Element();
                    element.location = ((bArr[i + 1] & FUDistributor.UPDATE_TTL) << 8) | (bArr[i] & FUDistributor.UPDATE_TTL);
                    int i2 = i + 3;
                    element.sigNum = bArr[i + 2] & FUDistributor.UPDATE_TTL;
                    i += 4;
                    element.vendorNum = bArr[i2] & FUDistributor.UPDATE_TTL;
                    if (bArr.length - i < (element.sigNum * 2) + (element.vendorNum * 4)) {
                        return null;
                    }
                    element.sigModels = new ArrayList(element.sigNum);
                    for (int i3 = 0; i3 < element.sigNum; i3++) {
                        List<Integer> list = element.sigModels;
                        int i4 = i + 1;
                        int i5 = bArr[i] & FUDistributor.UPDATE_TTL;
                        i += 2;
                        list.add(Integer.valueOf(((bArr[i4] & FUDistributor.UPDATE_TTL) << 8) | i5));
                    }
                    element.vendorModels = new ArrayList(element.vendorNum);
                    for (int i6 = 0; i6 < element.vendorNum; i6++) {
                        List<Integer> list2 = element.vendorModels;
                        int i7 = i + 3;
                        int i8 = ((bArr[i + 1] & FUDistributor.UPDATE_TTL) << 8) | (bArr[i] & FUDistributor.UPDATE_TTL) | ((bArr[i + 2] & FUDistributor.UPDATE_TTL) << 16);
                        i += 4;
                        list2.add(Integer.valueOf(i8 | ((bArr[i7] & FUDistributor.UPDATE_TTL) << 24)));
                    }
                    compositionData.elements.add(element);
                }
                return compositionData;
            }
        }
        return null;
    }

    public byte[] toBytes() {
        byte[] bArrArray = ByteBuffer.allocate(10).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.cid).putShort((short) this.pid).put(MeshUtils.integer2Bytes(this.vid, 2, ByteOrder.BIG_ENDIAN)).putShort((short) this.crpl).putShort((short) this.features).array();
        for (Element element : this.elements) {
            ByteBuffer byteBufferPut = ByteBuffer.allocate(bArrArray.length + (element.sigNum * 2) + 4 + (element.vendorNum * 4)).order(ByteOrder.LITTLE_ENDIAN).put(bArrArray).putShort((short) element.location).put((byte) element.sigNum).put((byte) element.vendorNum);
            Iterator<Integer> it = element.sigModels.iterator();
            while (it.hasNext()) {
                byteBufferPut.putShort((short) it.next().intValue());
            }
            Iterator<Integer> it2 = element.vendorModels.iterator();
            while (it2.hasNext()) {
                byteBufferPut.putInt(it2.next().intValue());
            }
            bArrArray = byteBufferPut.array();
        }
        return bArrArray;
    }

    public List<Integer> getAllModels(boolean z) {
        if (this.elements == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (Element element : this.elements) {
            if (element.sigModels != null) {
                if (!z) {
                    arrayList.addAll(element.sigModels);
                } else {
                    for (Integer num : element.sigModels) {
                        if (!MeshSigModel.useDeviceKeyForEnc(num.intValue())) {
                            arrayList.add(num);
                        }
                    }
                }
            }
            if (element.vendorModels != null) {
                arrayList.addAll(element.vendorModels);
            }
        }
        return arrayList;
    }

    public int getElementOffset(int i) {
        int i2 = 0;
        for (Element element : this.elements) {
            if (element.sigModels != null && element.sigModels.contains(Integer.valueOf(i))) {
                return i2;
            }
            if (element.vendorModels != null && element.vendorModels.contains(Integer.valueOf(i))) {
                return i2;
            }
            i2++;
        }
        return -1;
    }

    public boolean relaySupport() {
        return (this.features & 1) != 0;
    }

    public boolean proxySupport() {
        return (this.features & 2) != 0;
    }

    public boolean friendSupport() {
        return (this.features & 4) != 0;
    }

    public boolean lowPowerSupport() {
        return (this.features & 8) != 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.cid);
        parcel.writeInt(this.pid);
        parcel.writeInt(this.vid);
        parcel.writeInt(this.crpl);
        parcel.writeInt(this.features);
        parcel.writeTypedList(this.elements);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.elements.size(); i++) {
            Element element = this.elements.get(i);
            sb.append("element ");
            sb.append(i);
            sb.append(" : \nlocation: ");
            sb.append(element.location);
            sb.append("\nSIG models-");
            sb.append(element.sigModels.size());
            sb.append(":");
            for (int i2 = 0; i2 < element.sigModels.size(); i2++) {
                sb.append(String.format("%04X", element.sigModels.get(i2)));
                sb.append(" ");
            }
            sb.append("\nVendor models-");
            sb.append(element.vendorModels.size());
            sb.append(":");
            for (int i3 = 0; i3 < element.vendorModels.size(); i3++) {
                sb.append(String.format("%08X", element.vendorModels.get(i3)));
                sb.append("\t");
            }
            sb.append("\n");
        }
        return "CompositionData{cid=" + String.format("%04X", Integer.valueOf(this.cid)) + ", pid=" + String.format("%04X", Integer.valueOf(this.pid)) + ", vid=" + String.format("%04X", Integer.valueOf(this.vid)) + ", crpl=" + String.format("%04X", Integer.valueOf(this.crpl)) + ", features=" + String.format("%04X", Integer.valueOf(this.features)) + ", elements=\n" + ((Object) sb) + '}';
    }

    public String toFormatString() {
        StringBuilder sb = new StringBuilder("Composition-Data:\n");
        sb.append(String.format("cid: 0x%04X", Integer.valueOf(this.cid)));
        sb.append("\n");
        sb.append(String.format("pid: 0x%04X", Integer.valueOf(this.pid)));
        sb.append("\n");
        sb.append(String.format("vid: 0x%04X", Integer.valueOf(this.vid)));
        sb.append("\n");
        sb.append(String.format("crpl: 0x%04X", Integer.valueOf(this.crpl)));
        sb.append("\n\n");
        sb.append(String.format("features: 0x%04X", Integer.valueOf(this.features)));
        sb.append("\n\trelay support: ");
        sb.append(relaySupport());
        sb.append("\n\tproxy support: ");
        sb.append(proxySupport());
        sb.append("\n\tfriend support: ");
        sb.append(friendSupport());
        sb.append("\n\tlow power support: ");
        sb.append(lowPowerSupport());
        sb.append("\n\nelements: (");
        sb.append(this.elements.size());
        sb.append(")\n");
        List<Element> list = this.elements;
        for (int i = 0; i < list.size(); i++) {
            Element element = list.get(i);
            sb.append("\t");
            sb.append(String.format(Locale.getDefault(), "element %d: ", Integer.valueOf(i)));
            sb.append("\n");
            for (Integer num : element.sigModels) {
                sb.append("\t\t");
                sb.append(String.format("SIG model -- 0x%04X", num));
                MeshSigModel byId = MeshSigModel.getById(num.intValue());
                if (byId != null) {
                    sb.append(" -- ");
                    sb.append(byId.modelName);
                }
                sb.append("\n");
            }
            for (Integer num2 : element.vendorModels) {
                sb.append("\t\t");
                sb.append(String.format("vendor model -- 0x%06X", num2));
                sb.append("\n");
            }
        }
        return sb.toString();
    }
}
