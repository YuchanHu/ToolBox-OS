package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;

/* loaded from: classes.dex */
public class LcLightOnOffSetMessage extends GenericMessage {
    private boolean ack;
    private byte delay;
    private boolean isComplete;
    private byte lightOnOff;
    private byte tid;
    private byte transitionTime;

    public static LcLightOnOffSetMessage getSimple(int i, int i2, byte b, boolean z, int i3) {
        LcLightOnOffSetMessage lcLightOnOffSetMessage = new LcLightOnOffSetMessage(i, i2);
        lcLightOnOffSetMessage.lightOnOff = b;
        lcLightOnOffSetMessage.ack = z;
        lcLightOnOffSetMessage.setResponseMax(i3);
        return lcLightOnOffSetMessage;
    }

    public LcLightOnOffSetMessage(int i, int i2) {
        super(i, i2);
        this.tid = (byte) 0;
        this.transitionTime = (byte) 0;
        this.delay = (byte) 0;
        this.ack = false;
        this.isComplete = false;
        setTidPosition(2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return this.ack ? Opcode.LIGHT_LC_ONOFF_STATUS.value : super.getResponseOpcode();
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.LIGHT_LC_ONOFF_SET : Opcode.LIGHT_LC_ONOFF_SET_NOACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        if (this.isComplete) {
            return new byte[]{this.lightOnOff, this.tid, this.transitionTime, this.delay};
        }
        return new byte[]{this.lightOnOff, this.tid};
    }

    public void setLightOnOff(byte b) {
        this.lightOnOff = b;
    }

    public void setTid(byte b) {
        this.tid = b;
    }

    public void setTransitionTime(byte b) {
        this.transitionTime = b;
    }

    public void setDelay(byte b) {
        this.delay = b;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }

    public void setComplete(boolean z) {
        this.isComplete = z;
    }
}
