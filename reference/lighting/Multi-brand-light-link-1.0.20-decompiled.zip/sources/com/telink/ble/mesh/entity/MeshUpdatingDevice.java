package com.telink.ble.mesh.entity;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.firmwareupdate.AdditionalInformation;
import java.io.Serializable;

/* loaded from: classes.dex */
public class MeshUpdatingDevice implements Serializable, Parcelable, Cloneable {
    public static final Parcelable.Creator<MeshUpdatingDevice> CREATOR = new Parcelable.Creator<MeshUpdatingDevice>() { // from class: com.telink.ble.mesh.entity.MeshUpdatingDevice.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ MeshUpdatingDevice createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ MeshUpdatingDevice[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public MeshUpdatingDevice createFromParcel(Parcel parcel) {
            return new MeshUpdatingDevice(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public MeshUpdatingDevice[] newArray(int i) {
            return new MeshUpdatingDevice[i];
        }
    };
    public static final int STATE_FAIL = 2;
    public static final int STATE_INITIAL = 0;
    public static final int STATE_METADATA_RSP = 3;
    public static final int STATE_SUCCESS = 1;
    public AdditionalInformation additionalInformation;
    public byte[] firmwareId;
    public boolean isLpn;
    public boolean isOnline;
    public boolean isSensor;
    public boolean isSupported;
    public int meshAddress;
    public boolean needUpdate;
    public int pid;
    public String pidInfo;
    public boolean selected;
    public int state;
    public int updatingEleAddress;
    public int vid;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public MeshUpdatingDevice() {
        this.state = 0;
        this.additionalInformation = null;
        this.pid = 0;
        this.vid = 0;
        this.isSupported = false;
        this.isOnline = false;
        this.selected = false;
        this.isLpn = false;
        this.isSensor = false;
        this.needUpdate = false;
    }

    protected MeshUpdatingDevice(Parcel parcel) {
        this.state = 0;
        this.additionalInformation = null;
        this.pid = 0;
        this.vid = 0;
        this.isSupported = false;
        this.isOnline = false;
        this.selected = false;
        this.isLpn = false;
        this.isSensor = false;
        this.needUpdate = false;
        this.meshAddress = parcel.readInt();
        this.updatingEleAddress = parcel.readInt();
        this.state = parcel.readInt();
        this.pidInfo = parcel.readString();
        this.firmwareId = parcel.createByteArray();
        this.pid = parcel.readInt();
        this.isSupported = parcel.readByte() != 0;
        this.isOnline = parcel.readByte() != 0;
        this.selected = parcel.readByte() != 0;
        this.isLpn = parcel.readByte() != 0;
    }

    public String getStateDesc() {
        int i = this.state;
        if (i == 0) {
            return "INIT";
        }
        if (i == 1) {
            return "Update Success";
        }
        if (i == 2) {
            return "Update Fail";
        }
        if (i == 3) {
            return "Metadata RSP";
        }
        return "";
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.meshAddress);
        parcel.writeInt(this.updatingEleAddress);
        parcel.writeInt(this.state);
        parcel.writeString(this.pidInfo);
        parcel.writeByteArray(this.firmwareId);
        parcel.writeInt(this.pid);
        parcel.writeByte(this.isSupported ? (byte) 1 : (byte) 0);
        parcel.writeByte(this.isOnline ? (byte) 1 : (byte) 0);
        parcel.writeByte(this.selected ? (byte) 1 : (byte) 0);
        parcel.writeByte(this.isLpn ? (byte) 1 : (byte) 0);
    }

    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
