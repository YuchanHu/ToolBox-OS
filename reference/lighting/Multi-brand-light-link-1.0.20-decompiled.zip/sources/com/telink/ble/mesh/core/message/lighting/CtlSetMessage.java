package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class CtlSetMessage extends GenericMessage {
    private boolean ack;
    private byte delay;
    private int deltaUV;
    private boolean isComplete;
    private int lightness;
    private int temperature;
    private byte tid;
    private byte transitionTime;

    public CtlSetMessage(int i, int i2) {
        super(i, i2);
        this.tid = (byte) 0;
        this.transitionTime = (byte) 0;
        this.delay = (byte) 0;
        this.ack = false;
        this.isComplete = false;
        setTidPosition(6);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return this.ack ? Opcode.LIGHT_CTL_STATUS.value : super.getResponseOpcode();
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.LIGHT_CTL_SET : Opcode.LIGHT_CTL_SET_NOACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        if (this.isComplete) {
            return ByteBuffer.allocate(9).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.lightness).putShort((short) this.temperature).putShort((short) this.deltaUV).put(this.tid).put(this.transitionTime).put(this.delay).array();
        }
        return ByteBuffer.allocate(7).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.lightness).putShort((short) this.temperature).putShort((short) this.deltaUV).put(this.tid).array();
    }

    public void setLightness(int i) {
        this.lightness = i;
    }

    public void setTemperature(int i) {
        this.temperature = i;
    }

    public void setDeltaUV(int i) {
        this.deltaUV = i;
    }

    public void setTid(byte b) {
        this.tid = b;
    }

    public void setTransitionTime(byte b) {
        this.transitionTime = b;
    }

    public void setDelay(byte b) {
        this.delay = b;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }

    public void setComplete(boolean z) {
        this.isComplete = z;
    }

    public static CtlSetMessage getSimple(int i, int i2, int i3, int i4, int i5, boolean z, int i6) {
        CtlSetMessage ctlSetMessage = new CtlSetMessage(i, i2);
        ctlSetMessage.lightness = i3;
        ctlSetMessage.temperature = i4;
        ctlSetMessage.deltaUV = i5;
        ctlSetMessage.ack = z;
        ctlSetMessage.setResponseMax(i6);
        return ctlSetMessage;
    }
}
