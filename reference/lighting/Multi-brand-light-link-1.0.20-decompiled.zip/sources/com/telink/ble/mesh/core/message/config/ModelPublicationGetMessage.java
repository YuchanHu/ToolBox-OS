package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ModelPublicationGetMessage extends ConfigMessage {
    public int elementAddress;
    public int modelId;
    public boolean sig;

    public static ModelPublicationGetMessage getSimple(int i, int i2, int i3) {
        ModelPublicationGetMessage modelPublicationGetMessage = new ModelPublicationGetMessage(i);
        modelPublicationGetMessage.elementAddress = i2;
        modelPublicationGetMessage.modelId = i3;
        return modelPublicationGetMessage;
    }

    public ModelPublicationGetMessage(int i) {
        super(i);
        this.sig = true;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.CFG_MODEL_PUB_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_MODEL_PUB_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(this.sig ? 4 : 6).order(ByteOrder.LITTLE_ENDIAN);
        byteBufferOrder.putShort((short) this.elementAddress);
        if (this.sig) {
            byteBufferOrder.putShort((short) this.modelId);
        } else {
            byteBufferOrder.putInt(this.modelId);
        }
        return byteBufferOrder.array();
    }
}
