package com.telink.ble.mesh.core.message.time;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class TimeSetMessage extends GenericMessage {
    private boolean ack;
    private int delta;
    private byte subSecond;
    private long taiSeconds;
    private byte timeAuthority;
    private byte uncertainty;
    private int zoneOffset;

    public static TimeSetMessage getSimple(int i, int i2, long j, int i3, int i4) {
        TimeSetMessage timeSetMessage = new TimeSetMessage(i, i2);
        timeSetMessage.taiSeconds = j;
        timeSetMessage.zoneOffset = i3;
        timeSetMessage.setResponseMax(i4);
        return timeSetMessage;
    }

    public TimeSetMessage(int i, int i2) {
        super(i, i2);
        this.ack = false;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        if (this.ack) {
            return Opcode.TIME_STATUS.value;
        }
        return -1;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.TIME_SET : Opcode.TIME_STATUS).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(10).order(ByteOrder.LITTLE_ENDIAN);
        byteBufferOrder.put((byte) this.taiSeconds).put((byte) (this.taiSeconds >> 8)).put((byte) (this.taiSeconds >> 16)).put((byte) (this.taiSeconds >> 24)).put((byte) (this.taiSeconds >> 32)).put(this.subSecond).put(this.uncertainty).putShort((short) ((this.delta << 1) | this.timeAuthority)).put((byte) this.zoneOffset);
        return byteBufferOrder.array();
    }

    public void setTaiSeconds(long j) {
        this.taiSeconds = j;
    }

    public void setSubSecond(byte b) {
        this.subSecond = b;
    }

    public void setUncertainty(byte b) {
        this.uncertainty = b;
    }

    public void setTimeAuthority(byte b) {
        this.timeAuthority = b;
    }

    public void setDelta(int i) {
        this.delta = i;
    }

    public void setZoneOffset(int i) {
        this.zoneOffset = i;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }
}
