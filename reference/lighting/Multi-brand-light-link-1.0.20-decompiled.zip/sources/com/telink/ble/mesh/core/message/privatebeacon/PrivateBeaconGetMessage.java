package com.telink.ble.mesh.core.message.privatebeacon;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.config.ConfigMessage;

/* loaded from: classes.dex */
public class PrivateBeaconGetMessage extends ConfigMessage {
    public PrivateBeaconGetMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.PRIVATE_BEACON_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.PRIVATE_BEACON_STATUS.value;
    }
}
