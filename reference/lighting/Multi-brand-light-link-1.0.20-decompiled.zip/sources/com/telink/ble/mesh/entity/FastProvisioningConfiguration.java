package com.telink.ble.mesh.entity;

import android.util.SparseIntArray;
import com.telink.ble.mesh.util.MeshLogger;

/* loaded from: classes.dex */
public class FastProvisioningConfiguration {
    public static final int DEFAULT_APP_KEY_INDEX = 0;
    public static final int DEFAULT_IV_INDEX = 305419896;
    public static final int DEFAULT_NETWORK_KEY_INDEX = 0;
    public static final int DEFAULT_RESET_DELAY = 2000;
    public static final int PID_ALL = 65535;
    private byte[] defaultAppKey;
    private byte[] defaultNetworkKey;
    private SparseIntArray elementPidMap;
    private int ivIndex;
    private int provisioningIndex;
    private int resetDelay;
    private int scanningPid;
    public static final byte[] DEFAULT_NETWORK_KEY = {125, -41, 54, 76, -40, 66, -83, 24, -63, 124, 116, 101, 108, 105, 110, 107};
    public static final byte[] DEFAULT_APP_KEY = {99, -106, 71, 113, 115, 79, -67, 118, -29, -76, 116, 101, 108, 105, 110, 107};
    private int defaultNetworkKeyIndex = 0;
    private int defaultAppKeyIndex = 0;

    public static FastProvisioningConfiguration getDefault(int i, SparseIntArray sparseIntArray) {
        FastProvisioningConfiguration fastProvisioningConfiguration = new FastProvisioningConfiguration();
        fastProvisioningConfiguration.resetDelay = DEFAULT_RESET_DELAY;
        fastProvisioningConfiguration.provisioningIndex = i;
        fastProvisioningConfiguration.elementPidMap = sparseIntArray;
        fastProvisioningConfiguration.scanningPid = 65535;
        fastProvisioningConfiguration.ivIndex = DEFAULT_IV_INDEX;
        fastProvisioningConfiguration.defaultNetworkKey = DEFAULT_NETWORK_KEY;
        fastProvisioningConfiguration.defaultNetworkKeyIndex = 0;
        fastProvisioningConfiguration.defaultAppKey = DEFAULT_APP_KEY;
        fastProvisioningConfiguration.defaultAppKeyIndex = 0;
        return fastProvisioningConfiguration;
    }

    public boolean pidExist(int i) {
        SparseIntArray sparseIntArray = this.elementPidMap;
        return (sparseIntArray == null || sparseIntArray.get(i) == 0) ? false : true;
    }

    public int getElementCount(int i) {
        MeshLogger.d(String.format("getElementCount : %04X", Integer.valueOf(i)));
        SparseIntArray sparseIntArray = this.elementPidMap;
        if (sparseIntArray != null) {
            return sparseIntArray.get(i);
        }
        return 0;
    }

    public int getProvisioningIndex() {
        return this.provisioningIndex;
    }

    public void setProvisioningIndex(int i) {
        this.provisioningIndex = i;
    }

    public void increaseProvisioningIndex(int i) {
        this.provisioningIndex += i;
    }

    public SparseIntArray getElementPidMap() {
        return this.elementPidMap;
    }

    public void setElementPidMap(SparseIntArray sparseIntArray) {
        this.elementPidMap = sparseIntArray;
    }

    public int getScanningPid() {
        return this.scanningPid;
    }

    public void setScanningPid(int i) {
        this.scanningPid = i;
    }

    public int getIvIndex() {
        return this.ivIndex;
    }

    public void setIvIndex(int i) {
        this.ivIndex = i;
    }

    public byte[] getDefaultNetworkKey() {
        return this.defaultNetworkKey;
    }

    public void setDefaultNetworkKey(byte[] bArr) {
        this.defaultNetworkKey = bArr;
    }

    public int getDefaultNetworkKeyIndex() {
        return this.defaultNetworkKeyIndex;
    }

    public void setDefaultNetworkKeyIndex(int i) {
        this.defaultNetworkKeyIndex = i;
    }

    public byte[] getDefaultAppKey() {
        return this.defaultAppKey;
    }

    public void setDefaultAppKey(byte[] bArr) {
        this.defaultAppKey = bArr;
    }

    public int getDefaultAppKeyIndex() {
        return this.defaultAppKeyIndex;
    }

    public void setDefaultAppKeyIndex(int i) {
        this.defaultAppKeyIndex = i;
    }

    public int getResetDelay() {
        return this.resetDelay;
    }

    public void setResetDelay(int i) {
        this.resetDelay = i;
    }
}
