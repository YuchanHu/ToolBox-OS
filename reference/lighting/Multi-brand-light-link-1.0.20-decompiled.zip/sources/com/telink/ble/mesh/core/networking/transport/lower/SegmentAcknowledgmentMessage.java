package com.telink.ble.mesh.core.networking.transport.lower;

import com.telink.ble.mesh.core.MeshUtils;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import org.spongycastle.asn1.eac.CertificateBody;

/* loaded from: classes.dex */
public class SegmentAcknowledgmentMessage extends UnsegmentedControlMessagePDU {
    public static final int DATA_LEN = 7;
    private int blockAck;
    private final int obo;
    private final int opcode;
    private final int rfu;
    private final int seg;
    private int seqZero;

    public boolean parse(byte[] bArr) {
        if (bArr.length != 7) {
            return false;
        }
        this.seqZero = (MeshUtils.bytes2Integer(new byte[]{bArr[1], bArr[2]}, ByteOrder.BIG_ENDIAN) & MeshUtils.UNICAST_ADDRESS_MAX) >> 2;
        this.blockAck = MeshUtils.bytes2Integer(new byte[]{bArr[3], bArr[4], bArr[5], bArr[6]}, ByteOrder.BIG_ENDIAN);
        return true;
    }

    public SegmentAcknowledgmentMessage() {
        this.seg = 0;
        this.opcode = 0;
        this.obo = 0;
        this.rfu = 0;
        this.blockAck = 0;
    }

    public SegmentAcknowledgmentMessage(int i, int i2) {
        this.seg = 0;
        this.opcode = 0;
        this.obo = 0;
        this.rfu = 0;
        this.seqZero = i;
        this.blockAck = i2;
    }

    @Override // com.telink.ble.mesh.core.networking.transport.lower.UnsegmentedControlMessagePDU, com.telink.ble.mesh.core.networking.NetworkingPDU
    public byte[] toByteArray() {
        return ByteBuffer.allocate(7).order(ByteOrder.BIG_ENDIAN).put((byte) 0).put((byte) ((this.seqZero >> 6) & CertificateBody.profileType)).put((byte) ((this.seqZero << 2) & 252)).putInt(this.blockAck).array();
    }

    public String toString() {
        return "SegmentAcknowledgmentMessage{seg=0, opcode=0, obo=0, seqZero=" + this.seqZero + ", rfu=0, blockAck=" + this.blockAck + '}';
    }

    public int getSeqZero() {
        return this.seqZero;
    }

    public int getBlockAck() {
        return this.blockAck;
    }
}
