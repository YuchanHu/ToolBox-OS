package com.telink.ble.mesh.core.message.scene;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.lighting.LightingMessage;

/* loaded from: classes.dex */
public class SceneGetMessage extends LightingMessage {
    public SceneGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.SCENE_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.SCENE_STATUS.value;
    }

    public static SceneGetMessage getSimple(int i, int i2, int i3) {
        SceneGetMessage sceneGetMessage = new SceneGetMessage(i, i2);
        sceneGetMessage.setResponseMax(i3);
        return sceneGetMessage;
    }
}
