package com.telink.ble.mesh.core.message;

import java.util.List;

/* loaded from: classes.dex */
public interface MeshMessageCallback {
    void onMessageComplete(MeshMessage meshMessage, boolean z, int i);

    void onMessageResponse(MeshMessage meshMessage, List<NotificationMessage> list);
}
