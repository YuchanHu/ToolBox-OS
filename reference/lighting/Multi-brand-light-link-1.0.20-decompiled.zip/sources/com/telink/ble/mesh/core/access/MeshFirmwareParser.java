package com.telink.ble.mesh.core.access;

import com.telink.ble.mesh.util.MeshLogger;
import java.util.zip.CRC32;

/* loaded from: classes.dex */
public class MeshFirmwareParser {
    private static final int DEFAULT_BLOCK_SIZE = 4096;
    private static final int DEFAULT_CHUNK_SIZE = 256;
    private int curBlockIndex;
    private int curChunkIndex;
    private byte[] firmwareData;
    private int objectSize;
    private int totalBlockNumber;
    private int totalChunkNumber;
    private int mBlockSize = 4096;
    private int mChunkSize = 256;
    private int progress = -1;

    public void reset(byte[] bArr) {
        this.firmwareData = bArr;
        int length = bArr.length;
        this.objectSize = length;
        this.curBlockIndex = -1;
        this.curChunkIndex = -1;
        this.progress = -1;
        this.totalBlockNumber = (int) Math.ceil(length / this.mBlockSize);
        this.totalChunkNumber = (int) Math.ceil(this.objectSize / this.mChunkSize);
    }

    public void reset(byte[] bArr, int i, int i2) {
        this.mBlockSize = i;
        this.mChunkSize = i2;
        reset(bArr);
    }

    public int nextBlock() {
        this.curChunkIndex = -1;
        int i = this.curBlockIndex + 1;
        this.curBlockIndex = i;
        return i;
    }

    public void resetBlock() {
        this.curChunkIndex = -1;
        MeshLogger.d("reset block : " + this.curBlockIndex + " -- " + this.curChunkIndex);
    }

    public boolean hasNextBlock() {
        return this.curBlockIndex + 1 < this.totalBlockNumber;
    }

    public int getCurBlockSize() {
        if (!hasNextBlock()) {
            int i = this.objectSize;
            int i2 = this.mBlockSize;
            if (i % i2 != 0) {
                return i % i2;
            }
        }
        return this.mBlockSize;
    }

    public boolean validateProgress() {
        int i = (int) ((((this.curBlockIndex * (this.mBlockSize / this.mChunkSize)) + (this.curChunkIndex + 1)) * 99.0f) / this.totalChunkNumber);
        if (i <= this.progress) {
            return false;
        }
        this.progress = i;
        return true;
    }

    public int getProgressAt(int i, int i2) {
        return (int) ((((i * (this.mBlockSize / this.mChunkSize)) + (i2 + 1)) * 99.0f) / this.totalChunkNumber);
    }

    public int getProgress() {
        return this.progress;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x002d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public byte[] nextChunk() {
        /*
            r9 = this;
            int r0 = r9.getCurBlockSize()
            double r0 = (double) r0
            int r2 = r9.mChunkSize
            double r2 = (double) r2
            double r2 = r0 / r2
            double r2 = java.lang.Math.ceil(r2)
            int r2 = (int) r2
            int r3 = r9.curChunkIndex
            int r4 = r3 + 1
            if (r4 >= r2) goto L41
            int r4 = r3 + 1
            r9.curChunkIndex = r4
            int r3 = r3 + 2
            if (r3 < r2) goto L2d
            int r2 = r9.mChunkSize
            double r5 = (double) r2
            double r5 = r0 % r5
            r7 = 0
            int r3 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r3 != 0) goto L29
            goto L2d
        L29:
            double r2 = (double) r2
            double r0 = r0 % r2
            int r0 = (int) r0
            goto L2f
        L2d:
            int r0 = r9.mChunkSize
        L2f:
            byte[] r1 = new byte[r0]
            int r2 = r9.curBlockIndex
            int r3 = r9.mBlockSize
            int r2 = r2 * r3
            int r3 = r9.mChunkSize
            int r4 = r4 * r3
            int r2 = r2 + r4
            byte[] r3 = r9.firmwareData
            r4 = 0
            java.lang.System.arraycopy(r3, r2, r1, r4, r0)
            return r1
        L41:
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.telink.ble.mesh.core.access.MeshFirmwareParser.nextChunk():byte[]");
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0027  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public byte[] chunkAt(int r8) {
        /*
            r7 = this;
            int r0 = r7.getCurBlockSize()
            double r0 = (double) r0
            int r2 = r7.mChunkSize
            double r2 = (double) r2
            double r2 = r0 / r2
            double r2 = java.lang.Math.ceil(r2)
            int r2 = (int) r2
            if (r8 < r2) goto L13
            r8 = 0
            return r8
        L13:
            int r3 = r8 + 1
            if (r3 < r2) goto L27
            int r2 = r7.mChunkSize
            double r3 = (double) r2
            double r3 = r0 % r3
            r5 = 0
            int r3 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r3 != 0) goto L23
            goto L27
        L23:
            double r2 = (double) r2
            double r0 = r0 % r2
            int r0 = (int) r0
            goto L29
        L27:
            int r0 = r7.mChunkSize
        L29:
            byte[] r1 = new byte[r0]
            int r2 = r7.curBlockIndex
            int r3 = r7.mBlockSize
            int r2 = r2 * r3
            int r3 = r7.mChunkSize
            int r8 = r8 * r3
            int r2 = r2 + r8
            byte[] r8 = r7.firmwareData
            r3 = 0
            java.lang.System.arraycopy(r8, r2, r1, r3, r0)
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.telink.ble.mesh.core.access.MeshFirmwareParser.chunkAt(int):byte[]");
    }

    public int currentBlockIndex() {
        return this.curBlockIndex;
    }

    public int currentChunkIndex() {
        return this.curChunkIndex;
    }

    public int getObjectSize() {
        return this.objectSize;
    }

    public int getBlockSize() {
        return this.mBlockSize;
    }

    public int getChunkSize() {
        return this.mChunkSize;
    }

    public int getBlockChecksum() {
        int curBlockSize = getCurBlockSize();
        byte[] bArr = new byte[curBlockSize];
        System.arraycopy(this.firmwareData, this.curBlockIndex * this.mBlockSize, bArr, 0, curBlockSize);
        CRC32 crc32 = new CRC32();
        crc32.update(bArr);
        return (int) crc32.getValue();
    }
}
