package com.telink.ble.mesh.core.message.fastpv;

import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class MeshGetAddressMessage extends GenericMessage {
    private int address;
    private int pid;

    public MeshGetAddressMessage(int i, int i2) {
        super(i, i2);
        this.address = 0;
    }

    public static MeshGetAddressMessage getSimple(int i, int i2, int i3, int i4) {
        MeshGetAddressMessage meshGetAddressMessage = new MeshGetAddressMessage(i, i2);
        meshGetAddressMessage.setRetryCnt(0);
        meshGetAddressMessage.setResponseMax(i3);
        meshGetAddressMessage.pid = i4;
        return meshGetAddressMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.VD_MESH_ADDR_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.VD_MESH_ADDR_GET_STS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        if (this.address == 0) {
            return MeshUtils.integer2Bytes(this.pid, 2, ByteOrder.LITTLE_ENDIAN);
        }
        return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.pid).putShort((short) this.address).array();
    }

    public void setPid(int i) {
        this.pid = i;
    }

    public void setAddress(int i) {
        this.address = i;
    }
}
