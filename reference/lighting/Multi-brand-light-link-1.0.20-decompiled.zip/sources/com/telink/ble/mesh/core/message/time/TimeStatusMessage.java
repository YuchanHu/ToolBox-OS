package com.telink.ble.mesh.core.message.time;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class TimeStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<TimeStatusMessage> CREATOR = new Parcelable.Creator<TimeStatusMessage>() { // from class: com.telink.ble.mesh.core.message.time.TimeStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ TimeStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ TimeStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public TimeStatusMessage createFromParcel(Parcel parcel) {
            return new TimeStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public TimeStatusMessage[] newArray(int i) {
            return new TimeStatusMessage[i];
        }
    };
    private static final int DATA_LEN_COMPLETE = 10;
    private int delta;
    private boolean isComplete;
    private byte subSecond;
    private long taiSeconds;
    private byte timeAuthority;
    private byte uncertainty;
    private int zoneOffset;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public TimeStatusMessage() {
        this.isComplete = false;
    }

    protected TimeStatusMessage(Parcel parcel) {
        this.isComplete = false;
        this.taiSeconds = parcel.readLong();
        this.subSecond = parcel.readByte();
        this.uncertainty = parcel.readByte();
        this.timeAuthority = parcel.readByte();
        this.delta = parcel.readInt();
        this.zoneOffset = parcel.readInt();
        this.isComplete = parcel.readByte() != 0;
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.taiSeconds = MeshUtils.bytes2Long(bArr, 0, 5, ByteOrder.LITTLE_ENDIAN);
        if (bArr.length >= 10) {
            this.isComplete = true;
            this.subSecond = bArr[5];
            this.uncertainty = bArr[6];
            byte b = bArr[7];
            this.timeAuthority = (byte) (b & 1);
            this.delta = (b & 239) | ((bArr[8] & FUDistributor.UPDATE_TTL) << 8);
            this.zoneOffset = bArr[9] & FUDistributor.UPDATE_TTL;
        }
    }

    public long getTaiSeconds() {
        return this.taiSeconds;
    }

    public byte getSubSecond() {
        return this.subSecond;
    }

    public byte getUncertainty() {
        return this.uncertainty;
    }

    public byte getTimeAuthority() {
        return this.timeAuthority;
    }

    public int getDelta() {
        return this.delta;
    }

    public int getZoneOffset() {
        return this.zoneOffset;
    }

    public boolean isComplete() {
        return this.isComplete;
    }

    public void setTaiSeconds(long j) {
        this.taiSeconds = j;
    }

    public void setSubSecond(byte b) {
        this.subSecond = b;
    }

    public void setUncertainty(byte b) {
        this.uncertainty = b;
    }

    public void setTimeAuthority(byte b) {
        this.timeAuthority = b;
    }

    public void setDelta(int i) {
        this.delta = i;
    }

    public void setZoneOffset(int i) {
        this.zoneOffset = i;
    }

    public void setComplete(boolean z) {
        this.isComplete = z;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeLong(this.taiSeconds);
        parcel.writeByte(this.subSecond);
        parcel.writeByte(this.uncertainty);
        parcel.writeByte(this.timeAuthority);
        parcel.writeInt(this.delta);
        parcel.writeInt(this.zoneOffset);
        parcel.writeByte(this.isComplete ? (byte) 1 : (byte) 0);
    }
}
