package com.telink.ble.mesh.core.message.firmwaredistribution;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class FDStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<FDStatusMessage> CREATOR = new Parcelable.Creator<FDStatusMessage>() { // from class: com.telink.ble.mesh.core.message.firmwaredistribution.FDStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FDStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FDStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FDStatusMessage createFromParcel(Parcel parcel) {
            return new FDStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FDStatusMessage[] newArray(int i) {
            return new FDStatusMessage[i];
        }
    };
    public int RFU;
    public int distAppKeyIndex;
    public int distImageIndex;
    public int distMulticastAddress;
    public int distPhase;
    public int distTTL;
    public int distTimeoutBase;
    public int distTransferMode;
    public int status;
    public int updatePolicy;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public FDStatusMessage() {
    }

    protected FDStatusMessage(Parcel parcel) {
        this.status = parcel.readInt();
        this.distPhase = parcel.readInt();
        this.distMulticastAddress = parcel.readInt();
        this.distAppKeyIndex = parcel.readInt();
        this.distTTL = parcel.readInt();
        this.distTimeoutBase = parcel.readInt();
        this.distTransferMode = parcel.readInt();
        this.updatePolicy = parcel.readInt();
        this.RFU = parcel.readInt();
        this.distImageIndex = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.status = bArr[0] & FUDistributor.UPDATE_TTL;
        this.distPhase = bArr[1] & FUDistributor.UPDATE_TTL;
        if (bArr.length == 2) {
            return;
        }
        this.distMulticastAddress = MeshUtils.bytes2Integer(bArr, 2, 2, ByteOrder.LITTLE_ENDIAN);
        this.distAppKeyIndex = MeshUtils.bytes2Integer(bArr, 4, 2, ByteOrder.LITTLE_ENDIAN);
        this.distTTL = bArr[6] & FUDistributor.UPDATE_TTL;
        this.distTimeoutBase = MeshUtils.bytes2Integer(bArr, 7, 2, ByteOrder.LITTLE_ENDIAN);
        byte b = bArr[9];
        this.distTransferMode = b & 3;
        this.updatePolicy = 1 & (b >> 2);
        this.RFU = (b >> 3) & 31;
        this.distImageIndex = MeshUtils.bytes2Integer(bArr, 9, 2, ByteOrder.LITTLE_ENDIAN);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.status);
        parcel.writeInt(this.distPhase);
        parcel.writeInt(this.distMulticastAddress);
        parcel.writeInt(this.distAppKeyIndex);
        parcel.writeInt(this.distTTL);
        parcel.writeInt(this.distTimeoutBase);
        parcel.writeInt(this.distTransferMode);
        parcel.writeInt(this.updatePolicy);
        parcel.writeInt(this.RFU);
        parcel.writeInt(this.distImageIndex);
    }

    public String toString() {
        return "FDStatusMessage{status=" + this.status + ", distPhase=" + this.distPhase + ", distMulticastAddress=" + this.distMulticastAddress + ", distAppKeyIndex=" + this.distAppKeyIndex + ", distTTL=" + this.distTTL + ", distTimeoutBase=" + this.distTimeoutBase + ", distTransferMode=" + this.distTransferMode + ", updatePolicy=" + this.updatePolicy + ", RFU=" + this.RFU + ", distImageIndex=" + this.distImageIndex + '}';
    }
}
