package com.telink.ble.mesh.core.networking;

/* loaded from: classes.dex */
public enum ExtendBearerMode {
    NONE,
    GATT,
    GATT_ADV
}
