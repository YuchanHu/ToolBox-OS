package com.telink.ble.mesh.core.message.privatebeacon;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class PrivateGattProxyStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<PrivateGattProxyStatusMessage> CREATOR = new Parcelable.Creator<PrivateGattProxyStatusMessage>() { // from class: com.telink.ble.mesh.core.message.privatebeacon.PrivateGattProxyStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ PrivateGattProxyStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ PrivateGattProxyStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public PrivateGattProxyStatusMessage createFromParcel(Parcel parcel) {
            return new PrivateGattProxyStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public PrivateGattProxyStatusMessage[] newArray(int i) {
            return new PrivateGattProxyStatusMessage[i];
        }
    };
    public byte privateGattProxy;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public PrivateGattProxyStatusMessage() {
    }

    protected PrivateGattProxyStatusMessage(Parcel parcel) {
        this.privateGattProxy = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.privateGattProxy = bArr[0];
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.privateGattProxy);
    }
}
