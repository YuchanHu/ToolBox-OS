package com.telink.ble.mesh.core.message.generic;

import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class MoveSetMessage extends GenericMessage {
    private boolean ack;
    private byte delay;
    private int deltaLevel;
    private boolean isComplete;
    private byte tid;
    private byte transitionTime;

    public MoveSetMessage(int i, int i2) {
        super(i, i2);
        this.isComplete = false;
        setTidPosition(2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.G_MOVE_SET : Opcode.G_MOVE_SET_NOACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        if (this.isComplete) {
            return ByteBuffer.allocate(5).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.deltaLevel).put(this.tid).put(this.transitionTime).put(this.delay).array();
        }
        return ByteBuffer.allocate(3).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.deltaLevel).put(this.tid).array();
    }

    public void setDeltaLevel(int i) {
        this.deltaLevel = i;
    }

    public void setTid(byte b) {
        this.tid = b;
    }

    public void setTransitionTime(byte b) {
        this.transitionTime = b;
    }

    public void setDelay(byte b) {
        this.delay = b;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }

    public void setComplete(boolean z) {
        this.isComplete = z;
    }
}
