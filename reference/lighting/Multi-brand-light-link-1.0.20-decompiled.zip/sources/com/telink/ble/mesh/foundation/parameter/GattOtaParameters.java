package com.telink.ble.mesh.foundation.parameter;

import com.telink.ble.mesh.entity.ConnectionFilter;

/* loaded from: classes.dex */
public class GattOtaParameters extends Parameters {
    public GattOtaParameters(ConnectionFilter connectionFilter, byte[] bArr) {
        set(Parameters.COMMON_PROXY_FILTER_INIT_NEEDED, true);
        set(Parameters.ACTION_CONNECTION_FILTER, connectionFilter);
        setFirmware(bArr);
    }

    public void setFirmware(byte[] bArr) {
        set(Parameters.ACTION_OTA_FIRMWARE, bArr);
    }
}
