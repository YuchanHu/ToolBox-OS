package com.telink.ble.mesh.core.message.firmwaredistribution;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class FDFirmwareStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<FDFirmwareStatusMessage> CREATOR = new Parcelable.Creator<FDFirmwareStatusMessage>() { // from class: com.telink.ble.mesh.core.message.firmwaredistribution.FDFirmwareStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FDFirmwareStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FDFirmwareStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FDFirmwareStatusMessage createFromParcel(Parcel parcel) {
            return new FDFirmwareStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FDFirmwareStatusMessage[] newArray(int i) {
            return new FDFirmwareStatusMessage[i];
        }
    };
    public int distImageIndex;
    public int entryCount;
    public byte[] firmwareID;
    public int status;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public FDFirmwareStatusMessage() {
    }

    protected FDFirmwareStatusMessage(Parcel parcel) {
        this.status = parcel.readInt();
        this.entryCount = parcel.readInt();
        this.distImageIndex = parcel.readInt();
        this.firmwareID = parcel.createByteArray();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.status = bArr[0] & FUDistributor.UPDATE_TTL;
        this.entryCount = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.LITTLE_ENDIAN);
        this.distImageIndex = MeshUtils.bytes2Integer(bArr, 3, 2, ByteOrder.LITTLE_ENDIAN);
        if (bArr.length == 5) {
            return;
        }
        byte[] bArr2 = new byte[bArr.length - 5];
        this.firmwareID = bArr2;
        System.arraycopy(bArr, 5, bArr2, 0, bArr2.length);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.status);
        parcel.writeInt(this.entryCount);
        parcel.writeInt(this.distImageIndex);
        parcel.writeByteArray(this.firmwareID);
    }
}
