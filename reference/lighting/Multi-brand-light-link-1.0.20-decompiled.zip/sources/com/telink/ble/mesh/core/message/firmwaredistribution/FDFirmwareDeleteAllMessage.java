package com.telink.ble.mesh.core.message.firmwaredistribution;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;

/* loaded from: classes.dex */
public class FDFirmwareDeleteAllMessage extends UpdatingMessage {
    public FDFirmwareDeleteAllMessage(int i, int i2) {
        super(i, i2);
    }

    public static FDFirmwareDeleteAllMessage getSimple(int i, int i2) {
        FDFirmwareDeleteAllMessage fDFirmwareDeleteAllMessage = new FDFirmwareDeleteAllMessage(i, i2);
        fDFirmwareDeleteAllMessage.setResponseMax(1);
        return fDFirmwareDeleteAllMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FD_FIRMWARE_DELETE_ALL.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FD_UPLOAD_STATUS.value;
    }
}
