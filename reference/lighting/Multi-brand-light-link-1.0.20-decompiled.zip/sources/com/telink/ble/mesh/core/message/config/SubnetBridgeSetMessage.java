package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class SubnetBridgeSetMessage extends ConfigMessage {
    public byte subnetBridgeState;

    public SubnetBridgeSetMessage(int i) {
        super(i);
    }

    public SubnetBridgeSetMessage(int i, byte b) {
        super(i);
        this.subnetBridgeState = b;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.SUBNET_BRIDGE_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.SUBNET_BRIDGE_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return new byte[]{this.subnetBridgeState};
    }
}
