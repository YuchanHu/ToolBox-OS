package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class LightnessDefaultGetMessage extends LightingMessage {
    public static LightnessDefaultGetMessage getSimple(int i, int i2, int i3) {
        LightnessDefaultGetMessage lightnessDefaultGetMessage = new LightnessDefaultGetMessage(i, i2);
        lightnessDefaultGetMessage.setResponseMax(i3);
        return lightnessDefaultGetMessage;
    }

    public LightnessDefaultGetMessage(int i, int i2) {
        super(i, i2);
    }

    public LightnessDefaultGetMessage() {
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.LIGHTNESS_DEFAULT_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.LIGHTNESS_DEFAULT_STATUS.value;
    }
}
