package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class CtlTemperatureSetMessage extends GenericMessage {
    private boolean ack;
    private byte delay;
    private int deltaUV;
    private boolean isComplete;
    private int temperature;
    private byte tid;
    private byte transitionTime;

    public CtlTemperatureSetMessage(int i, int i2) {
        super(i, i2);
        this.tid = (byte) 0;
        this.transitionTime = (byte) 0;
        this.delay = (byte) 0;
        this.ack = false;
        this.isComplete = false;
        setTidPosition(4);
    }

    public static CtlTemperatureSetMessage getSimple(int i, int i2, int i3, int i4, boolean z, int i5) {
        CtlTemperatureSetMessage ctlTemperatureSetMessage = new CtlTemperatureSetMessage(i, i2);
        ctlTemperatureSetMessage.temperature = i3;
        ctlTemperatureSetMessage.deltaUV = i4;
        ctlTemperatureSetMessage.ack = z;
        ctlTemperatureSetMessage.setResponseMax(i5);
        return ctlTemperatureSetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return this.ack ? Opcode.LIGHT_CTL_TEMP_STATUS.value : super.getResponseOpcode();
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.LIGHT_CTL_TEMP_SET : Opcode.LIGHT_CTL_TEMP_SET_NOACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        if (this.isComplete) {
            return ByteBuffer.allocate(7).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.temperature).putShort((short) this.deltaUV).put(this.tid).put(this.transitionTime).put(this.delay).array();
        }
        return ByteBuffer.allocate(5).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.temperature).putShort((short) this.deltaUV).put(this.tid).array();
    }

    public void setTemperature(int i) {
        this.temperature = i;
    }

    public void setDeltaUV(int i) {
        this.deltaUV = i;
    }

    public void setTid(byte b) {
        this.tid = b;
    }

    public void setTransitionTime(byte b) {
        this.transitionTime = b;
    }

    public void setDelay(byte b) {
        this.delay = b;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }

    public void setComplete(boolean z) {
        this.isComplete = z;
    }
}
