package com.telink.ble.mesh.core.networking.transport.upper;

import android.util.SparseArray;
import com.telink.ble.mesh.core.Encipher;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.networking.AccessType;
import com.telink.ble.mesh.core.networking.NonceGenerator;
import com.telink.ble.mesh.core.networking.transport.lower.SegmentedAccessMessagePDU;
import com.telink.ble.mesh.core.networking.transport.lower.UnsegmentedAccessMessagePDU;
import com.telink.ble.mesh.util.MeshLogger;
import java.nio.ByteOrder;
import java.util.List;
import org.spongycastle.crypto.DataLengthException;

/* loaded from: classes.dex */
public class UpperTransportAccessPDU {
    private byte[] decryptedPayload;
    private byte[] encryptedPayload;
    private UpperTransportEncryptionSuite mEncryptionSuite;

    public UpperTransportAccessPDU(UpperTransportEncryptionSuite upperTransportEncryptionSuite) {
        this.mEncryptionSuite = upperTransportEncryptionSuite;
    }

    public byte[] getEncryptedPayload() {
        return this.encryptedPayload;
    }

    public byte[] getDecryptedPayload() {
        return this.decryptedPayload;
    }

    public boolean parseAndDecryptSegmentedMessage(SparseArray<SegmentedAccessMessagePDU> sparseArray, int i, int i2, int i3) {
        int length = 0;
        for (int i4 = 0; i4 < sparseArray.size(); i4++) {
            length += sparseArray.get(i4).getSegmentM().length;
        }
        byte[] bArr = new byte[length];
        int i5 = 0;
        for (int i6 = 0; i6 < sparseArray.size(); i6++) {
            int length2 = sparseArray.get(i6).getSegmentM().length;
            System.arraycopy(sparseArray.get(i6).getSegmentM(), 0, bArr, i5, length2);
            i5 += length2;
        }
        this.encryptedPayload = bArr;
        SegmentedAccessMessagePDU segmentedAccessMessagePDU = sparseArray.get(0);
        byte[] bArrDecrypt = decrypt(segmentedAccessMessagePDU.getAkf(), segmentedAccessMessagePDU.getAid(), segmentedAccessMessagePDU.getSzmic(), i, i2, i3);
        this.decryptedPayload = bArrDecrypt;
        return bArrDecrypt != null;
    }

    public boolean parseAndDecryptUnsegmentedMessage(UnsegmentedAccessMessagePDU unsegmentedAccessMessagePDU, int i, int i2, int i3) {
        this.encryptedPayload = unsegmentedAccessMessagePDU.getUpperTransportPDU();
        byte[] bArrDecrypt = decrypt(unsegmentedAccessMessagePDU.getAkf(), unsegmentedAccessMessagePDU.getAid(), 0, i, i2, i3);
        this.decryptedPayload = bArrDecrypt;
        return bArrDecrypt != null;
    }

    public boolean encrypt(byte[] bArr, byte b, AccessType accessType, int i, int i2, int i3) throws IllegalStateException, DataLengthException, IllegalArgumentException {
        byte[] bArrAccess$200;
        this.decryptedPayload = bArr;
        byte[] bArrGenerateAccessNonce = NonceGenerator.generateAccessNonce(b, MeshUtils.integer2Bytes(i, 3, ByteOrder.BIG_ENDIAN), i2, i3, UpperTransportEncryptionSuite.access$000(this.mEncryptionSuite), accessType);
        int micSize = MeshUtils.getMicSize(b);
        if (accessType == AccessType.APPLICATION) {
            bArrAccess$200 = (byte[]) UpperTransportEncryptionSuite.access$100(this.mEncryptionSuite).get(0);
        } else {
            bArrAccess$200 = UpperTransportEncryptionSuite.access$200(this.mEncryptionSuite);
        }
        if (bArrAccess$200 == null) {
            MeshLogger.e("upper transport encryption err: key null");
            return false;
        }
        byte[] bArrCcm = Encipher.ccm(this.decryptedPayload, bArrAccess$200, bArrGenerateAccessNonce, micSize, true);
        this.encryptedPayload = bArrCcm;
        return bArrCcm != null;
    }

    private byte[] decrypt(int i, byte b, int i2, int i3, int i4, int i5) {
        byte[] bArrSequenceNumber2Buffer = MeshUtils.sequenceNumber2Buffer(i3);
        if (AccessType.DEVICE.akf == i) {
            byte[] bArrGenerateAccessNonce = NonceGenerator.generateAccessNonce((byte) i2, bArrSequenceNumber2Buffer, i4, i5, UpperTransportEncryptionSuite.access$000(this.mEncryptionSuite), AccessType.DEVICE);
            byte[] bArrAccess$200 = UpperTransportEncryptionSuite.access$200(this.mEncryptionSuite);
            if (bArrAccess$200 == null) {
                MeshLogger.e("decrypt err: device key null");
                return null;
            }
            return decryptPayload(this.encryptedPayload, bArrAccess$200, bArrGenerateAccessNonce, i2);
        }
        if (UpperTransportEncryptionSuite.access$100(this.mEncryptionSuite) != null) {
            byte[] bArrGenerateAccessNonce2 = null;
            for (byte[] bArr : UpperTransportEncryptionSuite.access$100(this.mEncryptionSuite)) {
                if (MeshUtils.generateAid(bArr) == b) {
                    if (bArrGenerateAccessNonce2 == null) {
                        bArrGenerateAccessNonce2 = NonceGenerator.generateAccessNonce((byte) i2, bArrSequenceNumber2Buffer, i4, i5, UpperTransportEncryptionSuite.access$000(this.mEncryptionSuite), AccessType.APPLICATION);
                    }
                    byte[] bArrDecryptPayload = decryptPayload(this.encryptedPayload, bArr, bArrGenerateAccessNonce2, i2);
                    if (bArrDecryptPayload != null) {
                        return bArrDecryptPayload;
                    }
                }
            }
        }
        return null;
    }

    private byte[] decryptPayload(byte[] bArr, byte[] bArr2, byte[] bArr3, int i) {
        if (i == 1) {
            return Encipher.ccm(bArr, bArr2, bArr3, 8, false);
        }
        return Encipher.ccm(bArr, bArr2, bArr3, 4, false);
    }

    public static class UpperTransportEncryptionSuite {
        private List<byte[]> appKeyList;
        private byte[] deviceKey;
        private int ivIndex;

        static /* synthetic */ int access$000(UpperTransportEncryptionSuite upperTransportEncryptionSuite) {
            return upperTransportEncryptionSuite.ivIndex;
        }

        static /* synthetic */ List access$100(UpperTransportEncryptionSuite upperTransportEncryptionSuite) {
            return upperTransportEncryptionSuite.appKeyList;
        }

        static /* synthetic */ byte[] access$200(UpperTransportEncryptionSuite upperTransportEncryptionSuite) {
            return upperTransportEncryptionSuite.deviceKey;
        }

        public UpperTransportEncryptionSuite(byte[] bArr, int i) {
            this.deviceKey = bArr;
            this.ivIndex = i;
        }

        public UpperTransportEncryptionSuite(List<byte[]> list, int i) {
            this.appKeyList = list;
            this.ivIndex = i;
        }
    }
}
