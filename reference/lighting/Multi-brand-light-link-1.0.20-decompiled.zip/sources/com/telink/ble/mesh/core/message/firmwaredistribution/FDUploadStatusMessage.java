package com.telink.ble.mesh.core.message.firmwaredistribution;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;
import com.telink.ble.mesh.util.Arrays;

/* loaded from: classes.dex */
public class FDUploadStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<FDUploadStatusMessage> CREATOR = new Parcelable.Creator<FDUploadStatusMessage>() { // from class: com.telink.ble.mesh.core.message.firmwaredistribution.FDUploadStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FDUploadStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FDUploadStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FDUploadStatusMessage createFromParcel(Parcel parcel) {
            return new FDUploadStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FDUploadStatusMessage[] newArray(int i) {
            return new FDUploadStatusMessage[i];
        }
    };
    private int status;
    public byte[] uploadFirmwareID;
    public int uploadPhase;
    public int uploadProgress;
    public int uploadType;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public FDUploadStatusMessage() {
    }

    protected FDUploadStatusMessage(Parcel parcel) {
        this.status = parcel.readInt();
        this.uploadPhase = parcel.readInt();
        this.uploadProgress = parcel.readInt();
        this.uploadFirmwareID = parcel.createByteArray();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.status = bArr[0] & FUDistributor.UPDATE_TTL;
        this.uploadPhase = bArr[1] & FUDistributor.UPDATE_TTL;
        if (bArr.length == 2) {
            return;
        }
        byte b = bArr[2];
        this.uploadProgress = (b & 127) >> 1;
        this.uploadType = 1 & b;
        byte[] bArr2 = new byte[bArr.length - 3];
        this.uploadFirmwareID = bArr2;
        System.arraycopy(bArr, 3, bArr2, 0, bArr2.length);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.status);
        parcel.writeInt(this.uploadPhase);
        parcel.writeInt(this.uploadProgress);
        parcel.writeByteArray(this.uploadFirmwareID);
    }

    public String toString() {
        return "FDUploadStatusMessage{status=" + this.status + ", uploadPhase=" + this.uploadPhase + ", uploadProgress=" + this.uploadProgress + ", uploadType=" + this.uploadType + ", uploadFirmwareID=" + Arrays.bytesToHexString(this.uploadFirmwareID) + '}';
    }
}
