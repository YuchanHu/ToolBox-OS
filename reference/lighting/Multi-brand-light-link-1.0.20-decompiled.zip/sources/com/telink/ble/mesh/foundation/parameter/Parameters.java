package com.telink.ble.mesh.foundation.parameter;

import com.telink.ble.mesh.core.ble.LeScanFilter;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/* loaded from: classes.dex */
public class Parameters {
    public static final String ACTION_AUTO_CONNECT_NETWORK_KEY = "com.telink.ble.mesh.light.ACTION_AUTO_CONNECT_NETWORK_KEY";
    public static final String ACTION_AUTO_CONNECT_NODE_ADDRESS_LIST = "com.telink.ble.mesh.light.ACTION_AUTO_CONNECT_NODE_ADDRESS_LIST";
    public static final String ACTION_AUTO_CONNECT_SCAN_MIN_PERIOD = "com.telink.ble.mesh.light.ACTION_AUTO_CONNECT_SCAN_MIN_PERIOD";
    public static final String ACTION_AUTO_CONNECT_SCAN_REST = "com.telink.ble.mesh.light.ACTION_AUTO_CONNECT_SCAN_REST";
    public static final String ACTION_AUTO_CONNECT_TARGET_LIST = "com.telink.ble.mesh.light.ACTION_AUTO_CONNECT_TARGET_LIST";
    public static final String ACTION_BINDING_TARGET = "com.telink.ble.mesh.light.ACTION_BINDING_TARGET";
    public static final String ACTION_CONNECTION_DEVICE_NAME = "com.telink.ble.mesh.light.ACTION_CONNECTION_DEVICE_NAME";
    public static final String ACTION_CONNECTION_FILTER = "com.telink.ble.mesh.light.ACTION_CONNECTION_FILTER";
    public static final String ACTION_CONNECTION_MAC_ADDRESS = "com.telink.ble.mesh.light.ACTION_CONNECTION_MAC_ADDRESS";
    public static final String ACTION_FAST_PROVISION_CONFIG = "com.telink.ble.mesh.light.ACTION_FAST_PROVISION_CONFIG";
    public static final String ACTION_MESH_OTA_CONFIG = "com.telink.ble.mesh.light.ACTION_MESH_OTA_CONFIG";
    public static final String ACTION_MESH_OTA_FIRMWARE = "com.telink.ble.mesh.light.ACTION_MESH_OTA_FIRMWARE";
    public static final String ACTION_OTA_FIRMWARE = "com.telink.ble.mesh.light.ACTION_OTA_FIRMWARE";
    public static final String ACTION_PROVISIONING_TARGET = "com.telink.ble.mesh.light.ACTION_PROVISIONING_TARGET";
    public static final String COMMON_CONNECT_RETRY = "com.telink.ble.mesh.light.COMMON_CONNECT_RETRY";
    public static final String COMMON_CONNECT_TIMEOUT = "com.telink.ble.mesh.light.COMMON_CONNECT_TIMEOUT";
    public static final String COMMON_PROXY_FILTER_INIT_NEEDED = "com.telink.ble.mesh.light.COMMON_PROXY_FILTER_INIT_NEEDED";
    public static final String COMMON_SCAN_MIN_SPACING = "com.telink.ble.mesh.light.COMMON_SCAN_MIN_SPACING";
    public static final String COMMON_SCAN_TIMEOUT = "com.telink.ble.mesh.light.COMMON_SCAN_TIMEOUT";
    private static final int DEFAULT_CONNECT_RETRY = 2;
    private static final long DEFAULT_CONNECT_TIMEOUT = 10000;
    private static final long DEFAULT_SCAN_SPACING_ABOVE_N = 6000;
    private static final long DEFAULT_SCAN_TIMEOUT = 10000;
    public static final String SCAN_FILTERS = "com.telink.ble.mesh.light.SCAN_FILTERS";
    public static final String SCAN_SINGLE_MODE = "com.telink.ble.mesh.light.SCAN_SINGLE_MODE";
    protected Map<String, Object> mParams = new LinkedHashMap();

    protected Parameters() {
        setScanMinSpacing(0L);
        setScanTimeout(10000L);
        setConnectTimeout(10000L);
        setConnectRetry(2);
        set(COMMON_PROXY_FILTER_INIT_NEEDED, true);
    }

    protected void set(String str, Object obj) {
        Map<String, Object> map = this.mParams;
        if (map != null) {
            map.put(str, obj);
        }
    }

    public Object get(String str) {
        Map<String, Object> map = this.mParams;
        if (map != null) {
            return map.get(str);
        }
        return null;
    }

    public boolean getBool(String str, boolean z) {
        Map<String, Object> map = this.mParams;
        return (map == null || !map.containsKey(str)) ? z : ((Boolean) this.mParams.get(str)).booleanValue();
    }

    public int getInt(String str, int i) {
        Map<String, Object> map = this.mParams;
        return map != null ? ((Integer) map.get(str)).intValue() : i;
    }

    public long getLong(String str, long j) {
        Map<String, Object> map = this.mParams;
        return map != null ? ((Long) map.get(str)).longValue() : j;
    }

    public String getString(String str) {
        Map<String, Object> map = this.mParams;
        if (map != null) {
            return (String) map.get(str);
        }
        return null;
    }

    public String[] getStringArray(String str) {
        Map<String, Object> map = this.mParams;
        if (map != null) {
            return (String[]) map.get(str);
        }
        return null;
    }

    public byte[] getByteArray(String str) {
        Map<String, Object> map = this.mParams;
        if (map != null) {
            return (byte[]) map.get(str);
        }
        return null;
    }

    public void setScanMinSpacing(long j) {
        set(COMMON_SCAN_MIN_SPACING, Long.valueOf(j));
    }

    public void setScanTimeout(long j) {
        set(COMMON_SCAN_TIMEOUT, Long.valueOf(j));
    }

    public void setConnectTimeout(long j) {
        set(COMMON_CONNECT_TIMEOUT, Long.valueOf(j));
    }

    public void setConnectRetry(int i) {
        set(COMMON_CONNECT_RETRY, Integer.valueOf(i));
    }

    public void setScanFilter(LeScanFilter leScanFilter) {
        set(SCAN_FILTERS, leScanFilter);
    }

    public LeScanFilter createScanFilter(UUID[] uuidArr) {
        LeScanFilter leScanFilter = new LeScanFilter();
        leScanFilter.uuidInclude = uuidArr;
        return leScanFilter;
    }

    public LeScanFilter createScanFilter(UUID uuid) {
        LeScanFilter leScanFilter = new LeScanFilter();
        leScanFilter.uuidInclude = new UUID[]{uuid};
        return leScanFilter;
    }
}
