package com.telink.ble.mesh.foundation.parameter;

import com.telink.ble.mesh.core.ble.UUIDInfo;

/* loaded from: classes.dex */
public class AutoConnectParameters extends Parameters {
    public AutoConnectParameters() {
        setScanFilter(createScanFilter(UUIDInfo.SERVICE_PROXY));
    }
}
