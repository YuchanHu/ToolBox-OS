package com.telink.ble.mesh.core.networking;

import android.os.Handler;
import android.os.HandlerThread;
import android.util.SparseArray;
import android.util.SparseLongArray;
import com.telink.ble.mesh.core.Encipher;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.networking.NetworkLayerPDU;
import com.telink.ble.mesh.core.networking.beacon.MeshBeaconPDU;
import com.telink.ble.mesh.core.networking.beacon.MeshPrivateBeacon;
import com.telink.ble.mesh.core.networking.beacon.SecureNetworkBeacon;
import com.telink.ble.mesh.core.networking.transport.lower.LowerTransportPDU;
import com.telink.ble.mesh.core.networking.transport.lower.SegmentAcknowledgmentMessage;
import com.telink.ble.mesh.core.networking.transport.lower.SegmentedAccessMessagePDU;
import com.telink.ble.mesh.core.networking.transport.lower.UnsegmentedAccessMessagePDU;
import com.telink.ble.mesh.core.networking.transport.lower.UnsegmentedControlMessagePDU;
import com.telink.ble.mesh.core.networking.transport.upper.UpperTransportAccessPDU;
import com.telink.ble.mesh.core.proxy.ProxyAddAddressMessage;
import com.telink.ble.mesh.core.proxy.ProxyConfigurationMessage;
import com.telink.ble.mesh.core.proxy.ProxyConfigurationPDU;
import com.telink.ble.mesh.core.proxy.ProxyFilterStatusMessage;
import com.telink.ble.mesh.core.proxy.ProxyFilterType;
import com.telink.ble.mesh.core.proxy.ProxySetFilterTypeMessage;
import com.telink.ble.mesh.foundation.MeshConfiguration;
import com.telink.ble.mesh.util.Arrays;
import com.telink.ble.mesh.util.MeshLogger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.IntSupplier;

/* loaded from: classes.dex */
public class NetworkingController {
    private static final int BLOCK_ACK_WAITING_TIMEOUT = 15000;
    private static final int DEFAULT_SEQUENCE_NUMBER_UPDATE_STEP = 256;
    private static final String LOG_TAG = "Networking";
    public static final long NETWORK_INTERVAL_DEFAULT = 240;
    private static final int PROXY_FILTER_INIT_STEP_SET_TYPE = 1;
    private static final int PROXY_FILTER_INIT_TIMEOUT = 5000;
    private static final int PROXY_FILTER_SET_STEP_ADD_ADR = 2;
    private static final long SEG_TIMEOUT = 10000;
    private static final int SEQ_AUTH_BUF_CAPACITY = 10;
    private static final int SEQ_ZERO_LIMIT = 8191;
    private static final int THRESHOLD_SEQUENCE_NUMBER = 12582912;
    private static final int TRANSPORT_IN = 0;
    private static final int TRANSPORT_OUT = 1;
    public static final int UNSEGMENTED_ACCESS_PAYLOAD_MAX_LENGTH_DEFAULT = 11;
    public static final int UNSEGMENTED_ACCESS_PAYLOAD_MAX_LENGTH_LONG = 225;
    public static final int UNSEGMENTED_TRANSPORT_PAYLOAD_MAX_LENGTH = 15;
    public static long netPktSendInterval = 240;
    private byte[] encryptionKey;
    private final IntSupplier gattMtu;
    private Handler mDelayHandler;
    private NetworkingBridge mNetworkingBridge;
    private MeshMessage mSendingReliableMessage;
    private int netKeyIndex;
    private byte nid;
    private byte[] privacyKey;
    private int[] whiteList;
    private ExtendBearerMode extendBearerMode = ExtendBearerMode.NONE;
    private AtomicInteger mSequenceNumber = new AtomicInteger(1);
    private boolean privateBeaconReceived = false;
    private boolean isIvUpdating = false;
    private SparseLongArray deviceSequenceNumberMap = new SparseLongArray();
    private long initIvIndex = 0;
    private long ivIndex = 0;
    private int localAddress = MeshUtils.UNICAST_ADDRESS_MAX;
    private int directAddress = 0;
    private AtomicInteger tid = new AtomicInteger(0);
    private SparseArray<SegmentedAccessMessagePDU> receivedSegmentedMessageBuffer = new SparseArray<>();
    private SparseLongArray completedSeqAuthBuffer = new SparseLongArray();
    private SparseLongArray busySeqAuthBuffer = new SparseLongArray();
    private SparseArray<SegmentedAccessMessagePDU> sentSegmentedMessageBuffer = new SparseArray<>();
    private long lastSeqAuth = 0;
    private int lastSegSrc = 0;
    private boolean lastSegComplete = true;
    private int mSnoUpdateStep = 256;
    private SegmentAckMessageSentTask mAccessSegCheckTask = new SegmentAckMessageSentTask(this, null);
    private SegmentBlockWaitingTask mSegmentBlockWaitingTask = new SegmentBlockWaitingTask(this, null);
    private boolean segmentedBusy = false;
    private Runnable segmentedMessageTimeoutTask = new SegmentedMessageTimeoutTask(this, null);
    private boolean reliableBusy = false;
    private final Object RELIABLE_SEGMENTED_LOCK = new Object();
    private Set<Integer> mResponseMessageBuffer = new LinkedHashSet();
    private int proxyFilterInitStep = 0;
    private final Queue<byte[]> mNetworkingQueue = new ConcurrentLinkedQueue();
    private final Object mNetworkBusyLock = new Object();
    private boolean networkingBusy = false;
    private byte[] privateBeaconKey = null;
    private Runnable networkingSendingTask = new Runnable() { // from class: com.telink.ble.mesh.core.networking.NetworkingController.1
        @Override // java.lang.Runnable
        public void run() {
            NetworkingController.access$300(NetworkingController.this);
        }
    };
    private Runnable proxyFilterInitTimeoutTask = new Runnable() { // from class: com.telink.ble.mesh.core.networking.NetworkingController.2
        @Override // java.lang.Runnable
        public void run() {
            NetworkingController.access$400(NetworkingController.this, "filter init timeout");
            NetworkingController.access$500(NetworkingController.this, false);
        }
    };
    private Runnable reliableMessageTimeoutTask = new Runnable() { // from class: com.telink.ble.mesh.core.networking.NetworkingController.3
        @Override // java.lang.Runnable
        public void run() {
            MeshMessage meshMessageAccess$1000 = NetworkingController.access$1000(NetworkingController.this);
            if (meshMessageAccess$1000 != null) {
                NetworkingController.access$400(NetworkingController.this, String.format(Locale.getDefault(), "reliable message retry segmentRxComplete? %B retryCnt: %d %s opcode: %06X", Boolean.valueOf(NetworkingController.access$1100(NetworkingController.this)), Integer.valueOf(meshMessageAccess$1000.getRetryCnt()), meshMessageAccess$1000.getClass().getSimpleName(), Integer.valueOf(meshMessageAccess$1000.getOpcode())));
                if (NetworkingController.access$1100(NetworkingController.this)) {
                    if (meshMessageAccess$1000.getRetryCnt() <= 0) {
                        NetworkingController.access$1200(NetworkingController.this, false);
                        return;
                    }
                    meshMessageAccess$1000.setRetryCnt(meshMessageAccess$1000.getRetryCnt() - 1);
                    synchronized (NetworkingController.access$1300(NetworkingController.this)) {
                        NetworkingController.access$1402(NetworkingController.this, false);
                        if (NetworkingController.access$1500(NetworkingController.this) && meshMessageAccess$1000.isSegmented()) {
                            NetworkingController.access$1600(NetworkingController.this, true, false);
                        }
                    }
                    NetworkingController.access$1700(NetworkingController.this, meshMessageAccess$1000, true);
                    return;
                }
                NetworkingController.access$1800(NetworkingController.this);
            }
        }
    };
    private Runnable segmentTimeoutTask = new Runnable() { // from class: com.telink.ble.mesh.core.networking.NetworkingController.4
        @Override // java.lang.Runnable
        public void run() {
            NetworkingController.access$2100(NetworkingController.this);
            NetworkingController.access$400(NetworkingController.this, String.format(Locale.getDefault(), "segment timeout : lastSeqAuth: 0x%014X -- src: %02d", Long.valueOf(NetworkingController.access$2200(NetworkingController.this)), Integer.valueOf(NetworkingController.access$2300(NetworkingController.this))));
            NetworkingController.access$1102(NetworkingController.this, true);
            NetworkingController.access$2302(NetworkingController.this, 0);
            NetworkingController.access$2202(NetworkingController.this, 0L);
        }
    };
    private SparseArray<byte[]> appKeyMap = new SparseArray<>();
    private SparseArray<byte[]> deviceKeyMap = new SparseArray<>();

    private int getIvIndexInCache(long j) {
        return (int) ((j >> 32) & 4294967295L);
    }

    private long getSequenceNumberInCache(long j) {
        return j & 16777215;
    }

    private boolean validateDestinationAddress(int i) {
        return i != 0;
    }

    static /* synthetic */ MeshMessage access$1000(NetworkingController networkingController) {
        return networkingController.mSendingReliableMessage;
    }

    static /* synthetic */ boolean access$1100(NetworkingController networkingController) {
        return networkingController.lastSegComplete;
    }

    static /* synthetic */ boolean access$1102(NetworkingController networkingController, boolean z) {
        networkingController.lastSegComplete = z;
        return z;
    }

    static /* synthetic */ void access$1200(NetworkingController networkingController, boolean z) {
        networkingController.onReliableMessageComplete(z);
    }

    static /* synthetic */ Object access$1300(NetworkingController networkingController) {
        return networkingController.RELIABLE_SEGMENTED_LOCK;
    }

    static /* synthetic */ boolean access$1402(NetworkingController networkingController, boolean z) {
        networkingController.reliableBusy = z;
        return z;
    }

    static /* synthetic */ boolean access$1500(NetworkingController networkingController) {
        return networkingController.segmentedBusy;
    }

    static /* synthetic */ void access$1600(NetworkingController networkingController, boolean z, boolean z2) {
        networkingController.stopSegmentedBlockAckWaiting(z, z2);
    }

    static /* synthetic */ boolean access$1700(NetworkingController networkingController, MeshMessage meshMessage, boolean z) {
        return networkingController.postMeshMessage(meshMessage, z);
    }

    static /* synthetic */ void access$1800(NetworkingController networkingController) {
        networkingController.restartReliableMessageTimeoutTask();
    }

    static /* synthetic */ void access$2100(NetworkingController networkingController) {
        networkingController.stopSegmentBlockAckTask();
    }

    static /* synthetic */ long access$2200(NetworkingController networkingController) {
        return networkingController.lastSeqAuth;
    }

    static /* synthetic */ long access$2202(NetworkingController networkingController, long j) {
        networkingController.lastSeqAuth = j;
        return j;
    }

    static /* synthetic */ int access$2300(NetworkingController networkingController) {
        return networkingController.lastSegSrc;
    }

    static /* synthetic */ int access$2302(NetworkingController networkingController, int i) {
        networkingController.lastSegSrc = i;
        return i;
    }

    static /* synthetic */ void access$2400(NetworkingController networkingController, int i, int i2) {
        networkingController.sendSegmentBlockAck(i, i2);
    }

    static /* synthetic */ void access$2500(NetworkingController networkingController, int i, int i2) {
        networkingController.resendSegmentedMessages(i, i2);
    }

    static /* synthetic */ void access$300(NetworkingController networkingController) {
        networkingController.pollNetworkingQueue();
    }

    static /* synthetic */ void access$400(NetworkingController networkingController, String str) {
        networkingController.log(str);
    }

    static /* synthetic */ void access$500(NetworkingController networkingController, boolean z) {
        networkingController.onProxyInitComplete(z);
    }

    public NetworkingController(HandlerThread handlerThread, IntSupplier intSupplier) {
        this.gattMtu = intSupplier;
        this.mDelayHandler = new Handler(handlerThread.getLooper());
    }

    public void setNetworkingBridge(NetworkingBridge networkingBridge) {
        this.mNetworkingBridge = networkingBridge;
    }

    public void setup(MeshConfiguration meshConfiguration) {
        clear();
        resetDirectAddress();
        long j = meshConfiguration.ivIndex & 4294967295L;
        this.initIvIndex = j;
        this.ivIndex = j;
        this.mSequenceNumber.set(initSequenceNumber(meshConfiguration.sequenceNumber));
        this.netKeyIndex = meshConfiguration.netKeyIndex;
        byte[][] bArrCalculateNetKeyK2 = Encipher.calculateNetKeyK2(meshConfiguration.networkKey);
        this.nid = (byte) (bArrCalculateNetKeyK2[0][15] & 127);
        this.encryptionKey = bArrCalculateNetKeyK2[1];
        this.privacyKey = bArrCalculateNetKeyK2[2];
        this.privateBeaconKey = Encipher.generatePrivateBeaconKey(meshConfiguration.networkKey);
        this.appKeyMap = meshConfiguration.appKeyMap;
        this.deviceKeyMap = meshConfiguration.deviceKeyMap;
        this.localAddress = meshConfiguration.localAddress;
        this.whiteList = meshConfiguration.proxyFilterWhiteList;
    }

    public void clear() {
        Handler handler = this.mDelayHandler;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
        this.networkingBusy = false;
        this.segmentedBusy = false;
        this.reliableBusy = false;
        this.mNetworkingQueue.clear();
        this.lastSegComplete = true;
        this.deviceSequenceNumberMap.clear();
        this.receivedSegmentedMessageBuffer.clear();
        this.sentSegmentedMessageBuffer.clear();
        this.mResponseMessageBuffer.clear();
        this.isIvUpdating = false;
        this.lastSegComplete = true;
        this.privateBeaconReceived = false;
    }

    public void resetDirectAddress() {
        this.directAddress = 0;
    }

    public void addDeviceKey(int i, byte[] bArr) {
        this.deviceKeyMap.put(i, bArr);
    }

    public void removeDeviceKey(int i) {
        this.deviceKeyMap.remove(i);
    }

    public void setExtendBearerMode(ExtendBearerMode extendBearerMode) {
        log("setExtendBearerMode: " + extendBearerMode);
        this.extendBearerMode = extendBearerMode;
    }

    public ExtendBearerMode getExtendBearerMode() {
        return this.extendBearerMode;
    }

    private int getSegmentAccessLength(int i, int i2) {
        if (this.gattMtu.getAsInt() < 225) {
            return 11;
        }
        if (i == this.directAddress && i2 == Opcode.BLOB_CHUNK_TRANSFER.value) {
            return UNSEGMENTED_ACCESS_PAYLOAD_MAX_LENGTH_LONG;
        }
        int i3 = AnonymousClass5.$SwitchMap$com$telink$ble$mesh$core$networking$ExtendBearerMode[this.extendBearerMode.ordinal()];
        if (i3 != 2) {
            if (i3 != 3) {
                return 11;
            }
            return UNSEGMENTED_ACCESS_PAYLOAD_MAX_LENGTH_LONG;
        }
        if (i == this.directAddress) {
            return UNSEGMENTED_ACCESS_PAYLOAD_MAX_LENGTH_LONG;
        }
        return 11;
    }

    /* renamed from: com.telink.ble.mesh.core.networking.NetworkingController$5, reason: invalid class name */
    static /* synthetic */ class AnonymousClass5 {
        static final /* synthetic */ int[] $SwitchMap$com$telink$ble$mesh$core$networking$ExtendBearerMode;

        static {
            int[] iArr = new int[ExtendBearerMode.values().length];
            $SwitchMap$com$telink$ble$mesh$core$networking$ExtendBearerMode = iArr;
            try {
                iArr[ExtendBearerMode.NONE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$networking$ExtendBearerMode[ExtendBearerMode.GATT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$networking$ExtendBearerMode[ExtendBearerMode.GATT_ADV.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    private synchronized void saveCompletedSeqAuth(int i, long j) {
        log(String.format(Locale.getDefault(), "save complete seqAuth src: 0x%04X -- seqAuth: 0x%014X", Integer.valueOf(i), Long.valueOf(j)));
        this.completedSeqAuthBuffer.put(i, j);
    }

    private boolean isCompleteAuthExists(int i, long j) {
        return this.completedSeqAuthBuffer.get(i, 0L) == j;
    }

    private synchronized void saveBusySeqAuth(int i, long j) {
        log(String.format(Locale.getDefault(), "save busy seqAuth src: 0x%04X -- seqAuth: 0x%014X", Integer.valueOf(i), Long.valueOf(j)));
        this.busySeqAuthBuffer.put(i, j);
    }

    private boolean isBusyAuthExists(int i, long j) {
        return this.busySeqAuthBuffer.get(i, 0L) == j;
    }

    public void checkSequenceNumber(byte[] bArr, byte[] bArr2) {
        boolean z = this.mSequenceNumber.get() >= THRESHOLD_SEQUENCE_NUMBER;
        log("checkSequenceNumber => " + z + " -- " + this.isIvUpdating + " -> " + this.mSequenceNumber.get());
        if (this.isIvUpdating) {
            log("beacon updating status changed by remote device ");
        } else {
            this.isIvUpdating = z;
            if (z) {
                this.ivIndex = this.initIvIndex + 1;
            }
        }
        if (this.privateBeaconReceived) {
            sendMeshBeaconPdu(MeshPrivateBeacon.createIvUpdatingBeacon((int) this.initIvIndex, this.privateBeaconKey, this.isIvUpdating));
            return;
        }
        SecureNetworkBeacon secureNetworkBeaconCreateIvUpdatingBeacon = SecureNetworkBeacon.createIvUpdatingBeacon((int) this.initIvIndex, bArr, bArr2, this.isIvUpdating);
        log("send beacon: " + secureNetworkBeaconCreateIvUpdatingBeacon.toString());
        sendMeshBeaconPdu(secureNetworkBeaconCreateIvUpdatingBeacon);
    }

    private void onIvUpdated(long j) {
        long j2 = this.initIvIndex;
        if (j > j2 || j2 == 4294967295L) {
            log(String.format(" iv updated to %08X", Long.valueOf(j)));
            int i = (int) j;
            this.initIvIndex = i;
            this.deviceSequenceNumberMap.clear();
            this.mSequenceNumber.set(0);
            NetworkingBridge networkingBridge = this.mNetworkingBridge;
            if (networkingBridge != null) {
                networkingBridge.onNetworkInfoUpdate(this.mSequenceNumber.get(), i);
                return;
            }
            return;
        }
        log(" iv not updated");
    }

    private void onIvIndexReceived(long j, boolean z) {
        log(String.format("iv index received iv: %08X -- updating: %b -- localIv: %08X -- updating: %b ", Long.valueOf(j), Boolean.valueOf(z), Long.valueOf(this.ivIndex), Boolean.valueOf(this.isIvUpdating)));
        long j2 = this.ivIndex;
        if (j2 == 4294967295L) {
            this.isIvUpdating = z;
            this.ivIndex = j;
            onIvUpdated(j);
            return;
        }
        long j3 = j - j2;
        if (j3 == 0) {
            if (z || !this.isIvUpdating) {
                return;
            }
            this.isIvUpdating = false;
            onIvUpdated(j);
            return;
        }
        if (j3 > 0) {
            log("larger iv index received");
            if (j3 <= 42) {
                this.isIvUpdating = z;
                this.ivIndex = j;
                if (z) {
                    j--;
                }
                onIvUpdated(j);
                return;
            }
            log("iv index dVal greater than 42");
            return;
        }
        log(" smaller iv index received", 3);
    }

    private int initSequenceNumber(int i) {
        int i2 = this.mSnoUpdateStep;
        if (i2 == 0 || i2 == 1) {
            return i;
        }
        int i3 = ((i / i2) + 1) * i2;
        onSequenceNumberUpdate(i3);
        log("init sno: " + i3);
        return i3;
    }

    private void sendProxyConfigurationMessage(ProxyConfigurationMessage proxyConfigurationMessage) {
        sendProxyNetworkPdu(createProxyConfigurationPdu(proxyConfigurationMessage.toByteArray(), this.localAddress, getTransmitIvIndex(), this.mSequenceNumber.get()));
    }

    public boolean sendMeshMessage(MeshMessage meshMessage) {
        byte[] deviceKey;
        int destinationAddress = meshMessage.getDestinationAddress();
        if (!validateDestinationAddress(destinationAddress)) {
            log("invalid dst address: " + String.format("%04X", Integer.valueOf(destinationAddress)), 3);
            return false;
        }
        AccessType accessType = meshMessage.getAccessType();
        if (accessType == AccessType.APPLICATION) {
            deviceKey = getAppKey(meshMessage.getAppKeyIndex());
        } else {
            deviceKey = getDeviceKey(meshMessage.getDestinationAddress());
        }
        if (deviceKey == null) {
            log("access key not found : " + accessType, 3);
            return false;
        }
        meshMessage.setAccessKey(deviceKey);
        return postMeshMessage(meshMessage, false);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r13v1 */
    /* JADX WARN: Type inference failed for: r13v2 */
    /* JADX WARN: Type inference failed for: r13v3 */
    private boolean postMeshMessage(MeshMessage meshMessage, boolean z) throws Throwable {
        ?? r13;
        boolean z2;
        int destinationAddress = meshMessage.getDestinationAddress();
        int i = this.localAddress;
        int szmic = meshMessage.getSzmic();
        int opcode = meshMessage.getOpcode();
        byte b = meshMessage.getAccessType().akf;
        int i2 = 0;
        byte bK4 = meshMessage.getAccessType() == AccessType.APPLICATION ? Encipher.k4(meshMessage.getAccessKey()) : (byte) 0;
        int i3 = this.mSequenceNumber.get();
        byte[] params = meshMessage.getParams();
        int tidPosition = meshMessage.getTidPosition();
        if (params != null && tidPosition >= 0 && params.length > tidPosition) {
            AtomicInteger atomicInteger = this.tid;
            params[tidPosition] = (byte) (z ? atomicInteger.get() : atomicInteger.incrementAndGet());
        }
        AccessLayerPDU accessLayerPDU = new AccessLayerPDU(meshMessage.getOpcode(), params);
        byte[] byteArray = accessLayerPDU.toByteArray();
        int segmentAccessLength = getSegmentAccessLength(destinationAddress, opcode);
        boolean z3 = byteArray.length > segmentAccessLength;
        meshMessage.setSegmented(z3);
        if (z3) {
            synchronized (this.RELIABLE_SEGMENTED_LOCK) {
                if (this.segmentedBusy) {
                    log("segment message send err: segmented busy");
                    return false;
                }
            }
        }
        log("post access pdu: " + Arrays.bytesToHexString(accessLayerPDU.toByteArray(), ""));
        int transmitIvIndex = getTransmitIvIndex();
        boolean z4 = z3;
        byte b2 = bK4;
        UpperTransportAccessPDU upperTransportAccessPDUCreateUpperTransportAccessPDU = createUpperTransportAccessPDU(byteArray, meshMessage.getAccessKey(), (byte) meshMessage.getSzmic(), meshMessage.getAccessType(), transmitIvIndex, i3, i, destinationAddress);
        if (upperTransportAccessPDUCreateUpperTransportAccessPDU == null) {
            log("create upper transport pdu err: encrypt err", 3);
            return false;
        }
        log("upper transport pdu: " + Arrays.bytesToHexString(upperTransportAccessPDUCreateUpperTransportAccessPDU.getEncryptedPayload(), ""));
        boolean zIsReliable = meshMessage.isReliable();
        if (!z4) {
            log("send unsegmented access message");
            if (!zIsReliable) {
                z2 = true;
            } else {
                if (this.reliableBusy) {
                    log("unsegmented reliable message send err: busy", 3);
                    return false;
                }
                z2 = true;
                this.reliableBusy = true;
                this.mSendingReliableMessage = meshMessage;
                restartReliableMessageTimeoutTask();
            }
            sendNetworkPdu(createNetworkPDU(createUnsegmentedAccessMessage(upperTransportAccessPDUCreateUpperTransportAccessPDU.getEncryptedPayload(), b, b2).toByteArray(), meshMessage.getCtl(), meshMessage.getTtl(), i, destinationAddress, transmitIvIndex, i3));
            return z2;
        }
        boolean z5 = true;
        Object obj = this.RELIABLE_SEGMENTED_LOCK;
        synchronized (obj) {
            try {
                if (zIsReliable) {
                    try {
                        if (this.reliableBusy) {
                            log("segmented reliable message send err: busy", 3);
                            return false;
                        }
                        this.reliableBusy = true;
                        this.mSendingReliableMessage = meshMessage;
                    } catch (Throwable th) {
                        th = th;
                        r13 = obj;
                        throw th;
                    }
                }
                SparseArray<SegmentedAccessMessagePDU> sparseArrayCreateSegmentedAccessMessage = createSegmentedAccessMessage(upperTransportAccessPDUCreateUpperTransportAccessPDU.getEncryptedPayload(), b, b2, szmic, i3, segmentAccessLength);
                if (sparseArrayCreateSegmentedAccessMessage.size() == 0) {
                    return false;
                }
                log("send segmented access message");
                ArrayList arrayList = new ArrayList();
                while (i2 < sparseArrayCreateSegmentedAccessMessage.size()) {
                    ArrayList arrayList2 = arrayList;
                    arrayList2.add(createNetworkPDU(sparseArrayCreateSegmentedAccessMessage.get(i2).toByteArray(), meshMessage.getCtl(), meshMessage.getTtl(), i, destinationAddress, transmitIvIndex, i3 + i2));
                    i2++;
                    arrayList = arrayList2;
                    z5 = z5;
                }
                ArrayList arrayList3 = arrayList;
                boolean z6 = z5;
                if (MeshUtils.validUnicastAddress(destinationAddress)) {
                    this.sentSegmentedMessageBuffer = sparseArrayCreateSegmentedAccessMessage.clone();
                    startSegmentedMessageTimeoutCheck();
                    startSegmentedBlockAckWaiting(meshMessage.getCtl(), meshMessage.getTtl(), i, destinationAddress);
                } else if (zIsReliable) {
                    restartReliableMessageTimeoutTask();
                }
                sendNetworkPduList(arrayList3);
                return z6;
            } catch (Throwable th2) {
                th = th2;
                r13 = szmic;
            }
        }
    }

    public void proxyFilterInit() {
        this.proxyFilterInitStep = 0;
        this.mDelayHandler.removeCallbacks(this.proxyFilterInitTimeoutTask);
        this.mDelayHandler.postDelayed(this.proxyFilterInitTimeoutTask, 5000L);
        setFilterType(ProxyFilterType.WhiteList);
    }

    private void setFilterType(ProxyFilterType proxyFilterType) {
        sendProxyConfigurationMessage(new ProxySetFilterTypeMessage(proxyFilterType.value));
    }

    private void addFilterAddress(int[] iArr) {
        sendProxyConfigurationMessage(new ProxyAddAddressMessage(iArr));
    }

    private byte[] getAppKey(int i) {
        SparseArray<byte[]> sparseArray = this.appKeyMap;
        if (sparseArray == null) {
            return null;
        }
        return sparseArray.get(i);
    }

    private byte[] getDeviceKey(int i) {
        SparseArray<byte[]> sparseArray = this.deviceKeyMap;
        if (sparseArray == null) {
            return null;
        }
        return sparseArray.get(i);
    }

    private void startSegmentedMessageTimeoutCheck() {
        this.segmentedBusy = true;
        this.mDelayHandler.removeCallbacks(this.segmentedMessageTimeoutTask);
        this.mDelayHandler.postDelayed(this.segmentedMessageTimeoutTask, 15000L);
    }

    private void startSegmentedBlockAckWaiting(int i, int i2, int i3, int i4) {
        this.mDelayHandler.removeCallbacks(this.mSegmentBlockWaitingTask);
        this.mSegmentBlockWaitingTask.resetParams(i, i2, i3, i4);
        this.mDelayHandler.postDelayed(this.mSegmentBlockWaitingTask, getSegmentedTimeout(i2, true));
    }

    private void stopSegmentedBlockAckWaiting(boolean z, boolean z2) {
        log(String.format("stop segmented block waiting, complete - %B success - %B", Boolean.valueOf(z), Boolean.valueOf(z2)));
        this.mDelayHandler.removeCallbacks(this.mSegmentBlockWaitingTask);
        if (z) {
            onSegmentedMessageComplete(z2);
        }
    }

    private void onSegmentedMessageComplete(boolean z) {
        log("segmented message complete, success? : " + z);
        clearSegmentSendingState(z);
        if (this.reliableBusy) {
            if (z) {
                restartReliableMessageTimeoutTask();
            } else {
                onReliableMessageComplete(false);
            }
        }
    }

    private void clearSegmentSendingState(boolean z) {
        this.segmentedBusy = false;
        this.mDelayHandler.removeCallbacks(this.segmentedMessageTimeoutTask);
        this.sentSegmentedMessageBuffer.clear();
        NetworkingBridge networkingBridge = this.mNetworkingBridge;
        if (networkingBridge != null) {
            networkingBridge.onSegmentMessageComplete(z);
        }
    }

    private long getSegmentedTimeout(int i, boolean z) {
        long j;
        int size;
        int i2 = i * 50;
        if (z) {
            synchronized (this.mNetworkingQueue) {
                size = this.mNetworkingQueue.size();
            }
            j = i2 + 500 + (size * netPktSendInterval);
        } else {
            j = i2 + 500;
        }
        log("get segment ack timeout: " + j);
        return j;
    }

    private long getReliableMessageTimeout() {
        int size;
        synchronized (this.mNetworkingQueue) {
            size = this.mNetworkingQueue.size();
        }
        long j = size * netPktSendInterval;
        MeshMessage meshMessage = this.mSendingReliableMessage;
        long retryInterval = j + (meshMessage != null ? meshMessage.getRetryInterval() : 1280L);
        log("reliable message timeout:" + retryInterval);
        return retryInterval;
    }

    private void increaseSequenceNumber() {
        onSequenceNumberUpdate(this.mSequenceNumber.incrementAndGet());
    }

    private void sendNetworkPduList(List<NetworkLayerPDU> list) {
        if (this.mNetworkingBridge != null) {
            for (NetworkLayerPDU networkLayerPDU : list) {
                byte[] bArrGenerateEncryptedPayload = networkLayerPDU.generateEncryptedPayload();
                log("multi network pdu: " + Arrays.bytesToHexString(bArrGenerateEncryptedPayload, ":"));
                onNetworkingPduPrepared(bArrGenerateEncryptedPayload, networkLayerPDU.getDst());
            }
        }
    }

    private void sendNetworkPdu(NetworkLayerPDU networkLayerPDU) {
        if (this.mNetworkingBridge != null) {
            byte[] bArrGenerateEncryptedPayload = networkLayerPDU.generateEncryptedPayload();
            log("single network pdu: " + Arrays.bytesToHexString(bArrGenerateEncryptedPayload, ":"));
            onNetworkingPduPrepared(bArrGenerateEncryptedPayload, networkLayerPDU.getDst());
        }
    }

    private void sendProxyNetworkPdu(ProxyConfigurationPDU proxyConfigurationPDU) {
        if (this.mNetworkingBridge != null) {
            byte[] bArrGenerateEncryptedPayload = proxyConfigurationPDU.generateEncryptedPayload();
            log("proxy network pdu: " + Arrays.bytesToHexString(bArrGenerateEncryptedPayload, ":"));
            this.mNetworkingBridge.onCommandPrepared((byte) 2, bArrGenerateEncryptedPayload);
        }
    }

    private void onNetworkingPduPrepared(byte[] bArr, int i) {
        log("networking pdu prepared: " + Arrays.bytesToHexString(bArr, ":") + " busy?-" + this.networkingBusy);
        synchronized (this.mNetworkBusyLock) {
            if (!this.networkingBusy && i == this.directAddress) {
                log("networking pdu sending direct ");
                NetworkingBridge networkingBridge = this.mNetworkingBridge;
                if (networkingBridge != null) {
                    networkingBridge.onCommandPrepared((byte) 0, bArr);
                }
                return;
            }
            synchronized (this.mNetworkingQueue) {
                this.mNetworkingQueue.add(bArr);
            }
            synchronized (this.mNetworkBusyLock) {
                if (!this.networkingBusy) {
                    this.networkingBusy = true;
                    pollNetworkingQueue();
                }
            }
        }
    }

    private void pollNetworkingQueue() {
        byte[] bArrPoll;
        synchronized (this.mNetworkingQueue) {
            bArrPoll = this.mNetworkingQueue.poll();
        }
        if (bArrPoll == null) {
            log("networking pdu poll: null");
            synchronized (this.mNetworkBusyLock) {
                this.networkingBusy = false;
            }
            return;
        }
        log("networking pdu poll: " + Arrays.bytesToHexString(bArrPoll, ":"));
        NetworkingBridge networkingBridge = this.mNetworkingBridge;
        if (networkingBridge != null) {
            networkingBridge.onCommandPrepared((byte) 0, bArrPoll);
        }
        this.mDelayHandler.removeCallbacks(this.networkingSendingTask);
        this.mDelayHandler.postDelayed(this.networkingSendingTask, netPktSendInterval);
    }

    private void onSequenceNumberUpdate(int i) {
        NetworkingBridge networkingBridge = this.mNetworkingBridge;
        if (networkingBridge != null) {
            int i2 = this.mSnoUpdateStep;
            if (i2 == 0 || i % i2 == 0) {
                networkingBridge.onNetworkInfoUpdate(i, (int) this.initIvIndex);
            }
        }
    }

    public void parseSecureBeacon(byte[] bArr, byte[] bArr2) {
        SecureNetworkBeacon secureNetworkBeaconFrom = SecureNetworkBeacon.from(bArr, bArr2);
        if (secureNetworkBeaconFrom != null) {
            log("SecureNetworkBeacon received: " + secureNetworkBeaconFrom.toString());
            onIvIndexReceived(((long) secureNetworkBeaconFrom.getIvIndex()) & 4294967295L, secureNetworkBeaconFrom.isIvUpdating());
            return;
        }
        log("network beacon parse err");
    }

    public void parsePrivateBeacon(byte[] bArr, byte[] bArr2) {
        MeshPrivateBeacon meshPrivateBeaconFrom = MeshPrivateBeacon.from(bArr, bArr2);
        if (meshPrivateBeaconFrom != null) {
            this.privateBeaconReceived = true;
            log("MeshPrivateBeacon received: " + meshPrivateBeaconFrom.toString());
            onIvIndexReceived(((long) meshPrivateBeaconFrom.getIvIndex()) & 4294967295L, meshPrivateBeaconFrom.isIvUpdating());
            return;
        }
        log("private beacon parse error");
    }

    private int getAcceptedIvIndex(int i) {
        log(String.format("getAcceptedIvIndex : %08X", Long.valueOf(this.ivIndex)) + " ivi: " + i);
        long j = this.ivIndex;
        if ((j & 1) != i) {
            j--;
        }
        return (int) j;
    }

    private int getTransmitIvIndex() {
        int i = (int) (!this.isIvUpdating ? this.ivIndex : this.ivIndex - 1);
        log(String.format("getTransmitIvIndex : %08X", Integer.valueOf(i)));
        return i;
    }

    private void sendMeshBeaconPdu(MeshBeaconPDU meshBeaconPDU) {
        NetworkingBridge networkingBridge = this.mNetworkingBridge;
        if (networkingBridge != null) {
            networkingBridge.onCommandPrepared((byte) 1, meshBeaconPDU.toBytes());
        }
    }

    public void parseNetworkPdu(byte[] bArr) {
        int acceptedIvIndex = getAcceptedIvIndex((bArr[0] & FUDistributor.UPDATE_TTL) >> 7);
        NetworkLayerPDU networkLayerPDU = new NetworkLayerPDU(new NetworkLayerPDU.NetworkEncryptionSuite(acceptedIvIndex, this.encryptionKey, this.privacyKey, this.nid));
        if (networkLayerPDU.parse(bArr)) {
            log("network pdu: " + networkLayerPDU.toString());
            if (!validateSequenceNumber(networkLayerPDU, acceptedIvIndex)) {
                log("network pdu sequence number check err", 3);
                return;
            } else if (networkLayerPDU.getCtl() == 0) {
                parseAccessMessage(networkLayerPDU);
                return;
            } else {
                parseControlMessage(networkLayerPDU);
                return;
            }
        }
        log("network layer parse err", 3);
    }

    public void parseProxyConfigurationPdu(byte[] bArr) {
        int acceptedIvIndex = getAcceptedIvIndex((bArr[0] & FUDistributor.UPDATE_TTL) >> 7);
        ProxyConfigurationPDU proxyConfigurationPDU = new ProxyConfigurationPDU(new NetworkLayerPDU.NetworkEncryptionSuite(acceptedIvIndex, this.encryptionKey, this.privacyKey, this.nid));
        if (proxyConfigurationPDU.parse(bArr)) {
            log("proxy pdu: " + proxyConfigurationPDU.toString());
            if (!validateSequenceNumber(proxyConfigurationPDU, acceptedIvIndex)) {
                log("proxy config pdu sequence number check err", 3);
            } else {
                log(String.format("proxy network pdu src: %04X dst: %04X", Integer.valueOf(proxyConfigurationPDU.getSrc()), Integer.valueOf(proxyConfigurationPDU.getDst())));
                onProxyConfigurationNotify(proxyConfigurationPDU.getTransportPDU(), proxyConfigurationPDU.getSrc());
            }
        }
    }

    private void onProxyConfigurationNotify(byte[] bArr, int i) {
        log("onProxyConfigurationNotify: " + Arrays.bytesToHexString(bArr, ":"));
        ProxyFilterStatusMessage proxyFilterStatusMessageFromBytes = ProxyFilterStatusMessage.fromBytes(bArr);
        if (proxyFilterStatusMessageFromBytes == null || proxyFilterStatusMessageFromBytes.getFilterType() != ProxyFilterType.WhiteList.value) {
            return;
        }
        if (this.proxyFilterInitStep < 0) {
            log("filter init action not started!", 3);
            return;
        }
        log(String.format("reset direct address: %04X", Integer.valueOf(i)));
        this.directAddress = i;
        int i2 = this.proxyFilterInitStep + 1;
        this.proxyFilterInitStep = i2;
        if (i2 != 1) {
            if (i2 == 2) {
                onProxyInitComplete(true);
            }
        } else {
            int[] iArr = this.whiteList;
            if (iArr == null || iArr.length == 0) {
                addFilterAddress(new int[]{this.localAddress, 65535});
            } else {
                addFilterAddress(iArr);
            }
        }
    }

    private void onProxyInitComplete(boolean z) {
        this.proxyFilterInitStep = -1;
        if (z) {
            this.mDelayHandler.removeCallbacks(this.proxyFilterInitTimeoutTask);
        }
        NetworkingBridge networkingBridge = this.mNetworkingBridge;
        if (networkingBridge != null) {
            networkingBridge.onProxyInitComplete(z, this.directAddress);
        }
    }

    private boolean validateSequenceNumber(NetworkLayerPDU networkLayerPDU, int i) {
        int src = networkLayerPDU.getSrc();
        int seq = networkLayerPDU.getSeq();
        long j = this.deviceSequenceNumberMap.get(src, -1L);
        long sequenceNumberInCache = getSequenceNumberInCache(j);
        if (j == -1) {
            log("put init sequence number");
            saveSequenceCache(src, seq, i);
        } else {
            int ivIndexInCache = getIvIndexInCache(j);
            if (i > ivIndexInCache) {
                log("network pdu - larger ivIndex received, save the new ivIndex");
                saveSequenceCache(src, seq, i);
            } else {
                if (i != ivIndexInCache) {
                    log("network pdu error: less ivIndex pdu received");
                    return false;
                }
                if (seq > sequenceNumberInCache) {
                    saveSequenceCache(src, seq, i);
                } else {
                    log(String.format("validate sequence number error  src: %04X -- pdu-sno: %06X -- dev-sno: %06X", Integer.valueOf(src), Integer.valueOf(seq), Long.valueOf(sequenceNumberInCache)));
                    return false;
                }
            }
        }
        return true;
    }

    private void saveSequenceCache(int i, int i2, int i3) {
        this.deviceSequenceNumberMap.put(i, (i2 & 16777215) | ((i3 & 4294967295L) << 32));
    }

    private void parseControlMessage(NetworkLayerPDU networkLayerPDU) {
        byte[] transportPDU = networkLayerPDU.getTransportPDU();
        byte b = transportPDU[0];
        int i = (b & FUDistributor.UPDATE_TTL) >> 7;
        int i2 = b & 127;
        log("parse control message  seg:" + i + " -- opcode:" + i2);
        if (i == LowerTransportPDU.SEG_TYPE_UNSEGMENTED) {
            if (i2 != 0) {
                if (i2 == 10) {
                    onHeartbeatNotify(networkLayerPDU.getSrc(), networkLayerPDU.getDst(), transportPDU);
                }
            } else {
                SegmentAcknowledgmentMessage segmentAcknowledgmentMessage = new SegmentAcknowledgmentMessage();
                if (segmentAcknowledgmentMessage.parse(transportPDU)) {
                    onSegmentAckMessageReceived(segmentAcknowledgmentMessage);
                }
            }
        }
    }

    private void onHeartbeatNotify(int i, int i2, byte[] bArr) {
        log("on heart beat notify: " + Arrays.bytesToHexString(bArr, ":"));
        NetworkingBridge networkingBridge = this.mNetworkingBridge;
        if (networkingBridge != null) {
            networkingBridge.onHeartbeatMessageReceived(i, i2, bArr);
        }
    }

    private void onSegmentAckMessageReceived(SegmentAcknowledgmentMessage segmentAcknowledgmentMessage) {
        log("onSegmentAckMessageReceived: " + segmentAcknowledgmentMessage.toString());
        if (this.segmentedBusy) {
            resendSegmentedMessages(segmentAcknowledgmentMessage.getSeqZero(), segmentAcknowledgmentMessage.getBlockAck());
        } else {
            log("Segment Acknowledgment Message err: segmented messages not sending", 3);
        }
    }

    private void resendSegmentedMessages(int i, int i2) {
        int i3;
        ArrayList arrayList;
        int i4 = i2;
        SparseArray<SegmentedAccessMessagePDU> sparseArrayClone = this.sentSegmentedMessageBuffer.clone();
        log("resendSegmentedMessages: seqZero: " + i + " block ack: " + i4 + " buffer size: " + sparseArrayClone.size());
        if (sparseArrayClone.size() != 0) {
            SegmentedAccessMessagePDU segmentedAccessMessagePDU = sparseArrayClone.get(sparseArrayClone.keyAt(0));
            int seqZero = segmentedAccessMessagePDU.getSeqZero();
            if (i != -1) {
                if (i != seqZero) {
                    return;
                } else {
                    stopSegmentedBlockAckWaiting(false, false);
                }
            }
            int iAccess$600 = SegmentBlockWaitingTask.access$600(this.mSegmentBlockWaitingTask);
            int iAccess$700 = SegmentBlockWaitingTask.access$700(this.mSegmentBlockWaitingTask);
            int iAccess$800 = SegmentBlockWaitingTask.access$800(this.mSegmentBlockWaitingTask);
            int iAccess$900 = SegmentBlockWaitingTask.access$900(this.mSegmentBlockWaitingTask);
            int segN = segmentedAccessMessagePDU.getSegN();
            int transmitIvIndex = getTransmitIvIndex();
            int i5 = this.mSequenceNumber.get();
            ArrayList arrayList2 = new ArrayList();
            int i6 = 0;
            int i7 = 0;
            while (i6 <= segN) {
                if ((MeshUtils.bit(i6) & i4) != 0) {
                    i3 = i6;
                    arrayList = arrayList2;
                } else {
                    SegmentedAccessMessagePDU segmentedAccessMessagePDU2 = sparseArrayClone.get(i6);
                    byte[] byteArray = segmentedAccessMessagePDU2.toByteArray();
                    log("resend segmented message: seqZero:" + segmentedAccessMessagePDU2.getSeqZero() + " -- segO:" + segmentedAccessMessagePDU2.getSegO());
                    i3 = i6;
                    arrayList = arrayList2;
                    NetworkLayerPDU networkLayerPDUCreateNetworkPDU = createNetworkPDU(byteArray, iAccess$600, iAccess$700, iAccess$800, iAccess$900, transmitIvIndex, i5 + i7);
                    i7++;
                    arrayList.add(networkLayerPDUCreateNetworkPDU);
                }
                i6 = i3 + 1;
                arrayList2 = arrayList;
                i4 = i2;
            }
            ArrayList arrayList3 = arrayList2;
            if (arrayList3.size() == 0) {
                stopSegmentedBlockAckWaiting(true, true);
            } else {
                startSegmentedBlockAckWaiting(iAccess$600, iAccess$700, iAccess$800, iAccess$900);
                sendNetworkPduList(arrayList3);
            }
        }
    }

    private void parseAccessMessage(NetworkLayerPDU networkLayerPDU) {
        AccessLayerPDU unsegmentedAccessMessage;
        log("parse access message");
        int src = networkLayerPDU.getSrc();
        int dst = networkLayerPDU.getDst();
        if (!MeshUtils.validUnicastAddress(dst) || dst == this.localAddress) {
            if (((networkLayerPDU.getTransportPDU()[0] >> 7) & 1) == 1) {
                log("parse segmented access message");
                unsegmentedAccessMessage = parseSegmentedAccessMessage(networkLayerPDU);
            } else {
                log("parse unsegmented access message");
                unsegmentedAccessMessage = parseUnsegmentedAccessMessage(networkLayerPDU);
            }
            if (unsegmentedAccessMessage != null) {
                onAccessPduReceived(src, dst, unsegmentedAccessMessage);
            }
        }
    }

    private void onAccessPduReceived(int i, int i2, AccessLayerPDU accessLayerPDU) {
        log(String.format("access pdu received at 0x%04X: opcode -- 0x%04X", Integer.valueOf(i), Integer.valueOf(accessLayerPDU.opcode)) + " params -- " + Arrays.bytesToHexString(accessLayerPDU.params, ""));
        updateReliableMessage(i, accessLayerPDU);
        NetworkingBridge networkingBridge = this.mNetworkingBridge;
        if (networkingBridge != null) {
            networkingBridge.onMeshMessageReceived(i, i2, accessLayerPDU.opcode, accessLayerPDU.params);
        }
    }

    private void updateReliableMessage(int i, AccessLayerPDU accessLayerPDU) {
        MeshMessage meshMessage;
        if (this.reliableBusy && (meshMessage = this.mSendingReliableMessage) != null && meshMessage.getResponseOpcode() == accessLayerPDU.opcode) {
            int destinationAddress = meshMessage.getDestinationAddress();
            if (MeshUtils.validUnicastAddress(destinationAddress) && destinationAddress != i) {
                log(String.format("not expected response : %04X - %04X", Integer.valueOf(destinationAddress), Integer.valueOf(i)));
                return;
            }
            this.mResponseMessageBuffer.add(Integer.valueOf(i));
            if (this.mResponseMessageBuffer.size() >= meshMessage.getResponseMax()) {
                onReliableMessageComplete(true);
            }
        }
    }

    private void onReliableMessageComplete(boolean z) {
        log("clear network buffer");
        synchronized (this.mNetworkingQueue) {
            this.mDelayHandler.removeCallbacks(this.networkingSendingTask);
            this.networkingBusy = false;
            this.mNetworkingQueue.clear();
        }
        MeshMessage meshMessage = this.mSendingReliableMessage;
        if (meshMessage == null) {
            return;
        }
        this.mDelayHandler.removeCallbacks(this.reliableMessageTimeoutTask);
        int opcode = meshMessage.getOpcode();
        int destinationAddress = meshMessage.getDestinationAddress();
        int responseMax = meshMessage.getResponseMax();
        int size = this.mResponseMessageBuffer.size();
        log(String.format("Reliable Message Complete: %06X success?: %b", Integer.valueOf(opcode), Boolean.valueOf(z)));
        Integer[] numArr = (Integer[]) this.mResponseMessageBuffer.toArray(new Integer[0]);
        this.mResponseMessageBuffer.clear();
        synchronized (this.RELIABLE_SEGMENTED_LOCK) {
            this.reliableBusy = false;
            if (z && this.segmentedBusy && meshMessage.isSegmented()) {
                this.segmentedBusy = false;
                stopSegmentedBlockAckWaiting(true, true);
            }
        }
        NetworkingBridge networkingBridge = this.mNetworkingBridge;
        if (networkingBridge != null) {
            networkingBridge.onReliableMessageComplete(z, opcode, destinationAddress, responseMax, size, numArr);
        }
    }

    private void restartReliableMessageTimeoutTask() {
        log("restart reliable message timeout task, immediate");
        this.mDelayHandler.removeCallbacks(this.reliableMessageTimeoutTask);
        this.mDelayHandler.postDelayed(this.reliableMessageTimeoutTask, getReliableMessageTimeout());
    }

    private AccessLayerPDU parseUnsegmentedAccessMessage(NetworkLayerPDU networkLayerPDU) {
        UpperTransportAccessPDU.UpperTransportEncryptionSuite upperTransportEncryptionSuite;
        int i = (networkLayerPDU.getTransportPDU()[0] >> 6) & 1;
        int i2 = networkLayerPDU.encryptionSuite.ivIndex;
        UnsegmentedAccessMessagePDU unsegmentedAccessMessagePDU = new UnsegmentedAccessMessagePDU();
        if (!unsegmentedAccessMessagePDU.parse(networkLayerPDU)) {
            return null;
        }
        if (AccessType.DEVICE.akf == i) {
            upperTransportEncryptionSuite = new UpperTransportAccessPDU.UpperTransportEncryptionSuite(getDeviceKey(networkLayerPDU.getSrc()), i2);
        } else {
            upperTransportEncryptionSuite = new UpperTransportAccessPDU.UpperTransportEncryptionSuite(getAppKeyList(), i2);
        }
        UpperTransportAccessPDU upperTransportAccessPDU = new UpperTransportAccessPDU(upperTransportEncryptionSuite);
        if (upperTransportAccessPDU.parseAndDecryptUnsegmentedMessage(unsegmentedAccessMessagePDU, networkLayerPDU.getSeq(), networkLayerPDU.getSrc(), networkLayerPDU.getDst())) {
            return AccessLayerPDU.parse(upperTransportAccessPDU.getDecryptedPayload());
        }
        log("unsegmented access message parse err", 3);
        return null;
    }

    private List<byte[]> getAppKeyList() {
        SparseArray<byte[]> sparseArray = this.appKeyMap;
        if (sparseArray == null || sparseArray.size() == 0) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < this.appKeyMap.size(); i++) {
            SparseArray<byte[]> sparseArray2 = this.appKeyMap;
            arrayList.add(sparseArray2.get(sparseArray2.keyAt(i)));
        }
        return arrayList;
    }

    private void checkSegmentBlock(boolean z, int i, int i2) {
        if (z) {
            stopSegmentTimeoutTask();
        } else {
            restartSegmentTimeoutTask();
        }
        this.mDelayHandler.removeCallbacks(this.mAccessSegCheckTask);
        long segmentedTimeout = z ? 0L : getSegmentedTimeout(i, false);
        SegmentAckMessageSentTask.access$1902(this.mAccessSegCheckTask, i2);
        SegmentAckMessageSentTask.access$2002(this.mAccessSegCheckTask, i);
        log("check segment block: immediate-" + z + " ttl-" + i + " src-" + i2 + " timeout-" + segmentedTimeout);
        this.mDelayHandler.postDelayed(this.mAccessSegCheckTask, segmentedTimeout);
    }

    private void stopSegmentBlockAckTask() {
        this.mDelayHandler.removeCallbacks(this.mAccessSegCheckTask);
    }

    private void sendSegmentBlockAck(int i, int i2) {
        log("send segment block ack:" + i);
        SparseArray<SegmentedAccessMessagePDU> sparseArrayClone = this.receivedSegmentedMessageBuffer.clone();
        if (sparseArrayClone.size() > 0) {
            int i3 = 0;
            int seqZero = -1;
            int segN = -1;
            for (int i4 = 0; i4 < sparseArrayClone.size(); i4++) {
                int iKeyAt = sparseArrayClone.keyAt(i4);
                SegmentedAccessMessagePDU segmentedAccessMessagePDU = sparseArrayClone.get(iKeyAt);
                if (segN == -1) {
                    segN = segmentedAccessMessagePDU.getSegN();
                }
                if (seqZero == -1) {
                    seqZero = segmentedAccessMessagePDU.getSeqZero();
                }
                i3 |= 1 << iKeyAt;
            }
            sendSegmentAckMessage(new SegmentAcknowledgmentMessage(seqZero, i3), i);
            if (sparseArrayClone.size() == segN + 1) {
                return;
            }
            this.mDelayHandler.removeCallbacks(this.mAccessSegCheckTask);
            this.mDelayHandler.postDelayed(this.mAccessSegCheckTask, getSegmentedTimeout(i2, false));
        }
    }

    private void sendSegmentBlockBusyAck(int i, int i2, long j) {
        log("send segment block busy ack:" + i);
        saveBusySeqAuth(i, j);
        sendSegmentAckMessage(new SegmentAcknowledgmentMessage(i2, 0), i);
    }

    private void sendSegmentAckMessage(SegmentAcknowledgmentMessage segmentAcknowledgmentMessage, int i) {
        log("send segment ack: " + segmentAcknowledgmentMessage.toString());
        sendUnsegmentedControlMessage(segmentAcknowledgmentMessage, i);
    }

    private void sendUnsegmentedControlMessage(UnsegmentedControlMessagePDU unsegmentedControlMessagePDU, int i) {
        byte[] byteArray = unsegmentedControlMessagePDU.toByteArray();
        log("send control message: " + Arrays.bytesToHexString(byteArray, ""));
        sendNetworkPdu(createNetworkPDU(byteArray, 1, 5, this.localAddress, i, getTransmitIvIndex(), this.mSequenceNumber.get()));
    }

    private void restartSegmentTimeoutTask() {
        this.mDelayHandler.removeCallbacks(this.segmentTimeoutTask);
        this.mDelayHandler.postDelayed(this.segmentTimeoutTask, SEG_TIMEOUT);
    }

    private void stopSegmentTimeoutTask() {
        this.mDelayHandler.removeCallbacks(this.segmentTimeoutTask);
    }

    private void sendSegmentCompleteBlockAck(int i, int i2, int i3) {
        int i4 = 0;
        for (int i5 = 0; i5 < i2 + 1; i5++) {
            i4 |= 1 << i5;
        }
        sendSegmentAckMessage(new SegmentAcknowledgmentMessage(i3, i4), i);
    }

    private AccessLayerPDU parseSegmentedAccessMessage(NetworkLayerPDU networkLayerPDU) {
        UpperTransportAccessPDU.UpperTransportEncryptionSuite upperTransportEncryptionSuite;
        SegmentedAccessMessagePDU segmentedAccessMessagePDU = new SegmentedAccessMessagePDU();
        segmentedAccessMessagePDU.parse(networkLayerPDU);
        int src = networkLayerPDU.getSrc();
        int ttl = networkLayerPDU.getTtl() & FUDistributor.UPDATE_TTL;
        int seq = networkLayerPDU.getSeq();
        int i = seq & SEQ_ZERO_LIMIT;
        int seqZero = segmentedAccessMessagePDU.getSeqZero();
        if (i < seqZero) {
            seq -= 8192;
        }
        int i2 = (seq & 16769024) | seqZero;
        int i3 = networkLayerPDU.encryptionSuite.ivIndex;
        long j = (i2 & 16777215) | ((i3 & 2147483647L) << 24);
        int segO = segmentedAccessMessagePDU.getSegO();
        int segN = segmentedAccessMessagePDU.getSegN();
        log(String.format(Locale.getDefault(), "lastComplete? :%B -- seqAuth: 0x%014X -- lastSeqAuth: 0x%014X -- src: 0x%04X -- lastSrc: 0x%04X -- seg0: %02d -- segN: %02d", Boolean.valueOf(this.lastSegComplete), Long.valueOf(j), Long.valueOf(this.lastSeqAuth), Integer.valueOf(src), Integer.valueOf(this.lastSegSrc), Integer.valueOf(segO), Integer.valueOf(segN)));
        if (isBusyAuthExists(src, j)) {
            log("busy auth exists");
            sendSegmentBlockBusyAck(src, seqZero, j);
            return null;
        }
        if (isCompleteAuthExists(src, j)) {
            log("complete auth exists");
            sendSegmentCompleteBlockAck(src, segN, seqZero);
            return null;
        }
        if (j != this.lastSeqAuth || this.lastSegSrc != src) {
            if (this.lastSegComplete) {
                log("last segment complete");
                saveCompletedSeqAuth(this.lastSegSrc, this.lastSeqAuth);
                this.lastSegComplete = false;
                this.lastSeqAuth = j;
                this.lastSegSrc = src;
                this.receivedSegmentedMessageBuffer.clear();
            } else {
                sendSegmentBlockBusyAck(src, seqZero, j);
                return null;
            }
        }
        this.receivedSegmentedMessageBuffer.put(segO, segmentedAccessMessagePDU);
        int size = this.receivedSegmentedMessageBuffer.size();
        log("received segment message count: " + size);
        if (size != segN + 1) {
            this.lastSeqAuth = j;
            checkSegmentBlock(false, ttl, src);
            return null;
        }
        this.lastSegComplete = true;
        checkSegmentBlock(true, ttl, src);
        if (isCompleteAuthExists(src, j)) {
            log(" seqAuth already received: " + j);
            this.lastSeqAuth = 0L;
            return null;
        }
        if (segmentedAccessMessagePDU.getAkf() == AccessType.APPLICATION.akf) {
            upperTransportEncryptionSuite = new UpperTransportAccessPDU.UpperTransportEncryptionSuite(getAppKeyList(), i3);
        } else {
            byte[] deviceKey = getDeviceKey(src);
            if (deviceKey == null) {
                log("Device key not found when decrypt segmented access message", 3);
                return null;
            }
            upperTransportEncryptionSuite = new UpperTransportAccessPDU.UpperTransportEncryptionSuite(deviceKey, i3);
        }
        UpperTransportAccessPDU upperTransportAccessPDU = new UpperTransportAccessPDU(upperTransportEncryptionSuite);
        upperTransportAccessPDU.parseAndDecryptSegmentedMessage(this.receivedSegmentedMessageBuffer.clone(), i2, src, networkLayerPDU.getDst());
        byte[] decryptedPayload = upperTransportAccessPDU.getDecryptedPayload();
        log("decrypted upper: " + Arrays.bytesToHexString(decryptedPayload, ""));
        if (decryptedPayload != null) {
            return AccessLayerPDU.parse(decryptedPayload);
        }
        log("upper pdu decryption error: ", 3);
        return null;
    }

    private UpperTransportAccessPDU createUpperTransportAccessPDU(byte[] bArr, byte[] bArr2, byte b, AccessType accessType, int i, int i2, int i3, int i4) {
        UpperTransportAccessPDU.UpperTransportEncryptionSuite upperTransportEncryptionSuite;
        if (accessType == AccessType.APPLICATION) {
            ArrayList arrayList = new ArrayList();
            arrayList.add(bArr2);
            upperTransportEncryptionSuite = new UpperTransportAccessPDU.UpperTransportEncryptionSuite(arrayList, i);
        } else {
            upperTransportEncryptionSuite = new UpperTransportAccessPDU.UpperTransportEncryptionSuite(bArr2, i);
        }
        UpperTransportAccessPDU upperTransportAccessPDU = new UpperTransportAccessPDU(upperTransportEncryptionSuite);
        if (upperTransportAccessPDU.encrypt(bArr, b, accessType, i2, i3, i4)) {
            return upperTransportAccessPDU;
        }
        return null;
    }

    private SparseArray<SegmentedAccessMessagePDU> createSegmentedAccessMessage(byte[] bArr, byte b, byte b2, int i, int i2, int i3) {
        int i4 = i3 + 1;
        byte[] bArrInteger2Bytes = MeshUtils.integer2Bytes(i2, 3, ByteOrder.BIG_ENDIAN);
        int i5 = (bArrInteger2Bytes[2] & FUDistributor.UPDATE_TTL) | ((bArrInteger2Bytes[1] & 31) << 8);
        int iCeil = (int) Math.ceil(bArr.length / i4);
        int i6 = iCeil - 1;
        log("create segmented access message: seqZero - " + i5 + " segN - " + i6);
        SparseArray<SegmentedAccessMessagePDU> sparseArray = new SparseArray<>();
        int i7 = 0;
        for (int i8 = 0; i8 < iCeil; i8++) {
            int iMin = Math.min(bArr.length - i7, i4);
            SegmentedAccessMessagePDU segmentedAccessMessagePDU = new SegmentedAccessMessagePDU();
            segmentedAccessMessagePDU.setAkf(b);
            segmentedAccessMessagePDU.setAid(b2);
            segmentedAccessMessagePDU.setSzmic(i);
            segmentedAccessMessagePDU.setSeqZero(i5);
            segmentedAccessMessagePDU.setSegO(i8);
            segmentedAccessMessagePDU.setSegN(i6);
            segmentedAccessMessagePDU.setSegmentM(ByteBuffer.allocate(iMin).put(bArr, i7, iMin).array());
            i7 += iMin;
            sparseArray.put(i8, segmentedAccessMessagePDU);
        }
        return sparseArray;
    }

    private UnsegmentedAccessMessagePDU createUnsegmentedAccessMessage(byte[] bArr, byte b, byte b2) {
        return new UnsegmentedAccessMessagePDU(b, b2, bArr);
    }

    private NetworkLayerPDU createNetworkPDU(byte[] bArr, int i, int i2, int i3, int i4, int i5, int i6) {
        NetworkLayerPDU networkLayerPDU = new NetworkLayerPDU(new NetworkLayerPDU.NetworkEncryptionSuite(i5, this.encryptionKey, this.privacyKey, this.nid));
        networkLayerPDU.setIvi((byte) (i5 & 1));
        networkLayerPDU.setNid(this.nid);
        networkLayerPDU.setCtl((byte) i);
        networkLayerPDU.setTtl((byte) i2);
        networkLayerPDU.setSeq(i6);
        networkLayerPDU.setSrc(i3);
        networkLayerPDU.setDst(i4);
        networkLayerPDU.setTransportPDU(bArr);
        increaseSequenceNumber();
        return networkLayerPDU;
    }

    private ProxyConfigurationPDU createProxyConfigurationPdu(byte[] bArr, int i, int i2, int i3) {
        ProxyConfigurationPDU proxyConfigurationPDU = new ProxyConfigurationPDU(new NetworkLayerPDU.NetworkEncryptionSuite(i2, this.encryptionKey, this.privacyKey, this.nid));
        proxyConfigurationPDU.setIvi((byte) (i2 & 1));
        proxyConfigurationPDU.setNid(this.nid);
        proxyConfigurationPDU.setCtl((byte) 1);
        proxyConfigurationPDU.setTtl((byte) 0);
        proxyConfigurationPDU.setSeq(i3);
        proxyConfigurationPDU.setSrc(i);
        proxyConfigurationPDU.setDst(0);
        proxyConfigurationPDU.setTransportPDU(bArr);
        increaseSequenceNumber();
        return proxyConfigurationPDU;
    }

    private class SegmentAckMessageSentTask implements Runnable {
        private int src;
        private int ttl;

        private SegmentAckMessageSentTask() {
        }

        /* synthetic */ SegmentAckMessageSentTask(NetworkingController networkingController, AnonymousClass1 anonymousClass1) {
            this();
        }

        static /* synthetic */ int access$1902(SegmentAckMessageSentTask segmentAckMessageSentTask, int i) {
            segmentAckMessageSentTask.src = i;
            return i;
        }

        static /* synthetic */ int access$2002(SegmentAckMessageSentTask segmentAckMessageSentTask, int i) {
            segmentAckMessageSentTask.ttl = i;
            return i;
        }

        @Override // java.lang.Runnable
        public void run() {
            NetworkingController.access$2400(NetworkingController.this, this.src, this.ttl);
        }
    }

    private class SegmentedMessageTimeoutTask implements Runnable {
        private SegmentedMessageTimeoutTask() {
        }

        /* synthetic */ SegmentedMessageTimeoutTask(NetworkingController networkingController, AnonymousClass1 anonymousClass1) {
            this();
        }

        @Override // java.lang.Runnable
        public void run() {
            NetworkingController.access$400(NetworkingController.this, "segmented message timeout");
            NetworkingController.access$1600(NetworkingController.this, true, false);
        }
    }

    private class SegmentBlockWaitingTask implements Runnable {
        private int ctl;
        private int dst;
        private int src;
        private int ttl;

        private SegmentBlockWaitingTask() {
        }

        /* synthetic */ SegmentBlockWaitingTask(NetworkingController networkingController, AnonymousClass1 anonymousClass1) {
            this();
        }

        static /* synthetic */ int access$600(SegmentBlockWaitingTask segmentBlockWaitingTask) {
            return segmentBlockWaitingTask.ctl;
        }

        static /* synthetic */ int access$700(SegmentBlockWaitingTask segmentBlockWaitingTask) {
            return segmentBlockWaitingTask.ttl;
        }

        static /* synthetic */ int access$800(SegmentBlockWaitingTask segmentBlockWaitingTask) {
            return segmentBlockWaitingTask.src;
        }

        static /* synthetic */ int access$900(SegmentBlockWaitingTask segmentBlockWaitingTask) {
            return segmentBlockWaitingTask.dst;
        }

        public void resetParams(int i, int i2, int i3, int i4) {
            this.ctl = i;
            this.ttl = i2;
            this.src = i3;
            this.dst = i4;
        }

        @Override // java.lang.Runnable
        public void run() {
            NetworkingController.access$2500(NetworkingController.this, -1, 0);
        }
    }

    private void log(String str) {
        log(str, 1);
    }

    private void log(String str, int i) {
        MeshLogger.log(str, LOG_TAG, i);
    }
}
