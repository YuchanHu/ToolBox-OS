package com.telink.ble.mesh.core.message.lighting;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class LcPropertyStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<LcPropertyStatusMessage> CREATOR = new Parcelable.Creator<LcPropertyStatusMessage>() { // from class: com.telink.ble.mesh.core.message.lighting.LcPropertyStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ LcPropertyStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ LcPropertyStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LcPropertyStatusMessage createFromParcel(Parcel parcel) {
            return new LcPropertyStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LcPropertyStatusMessage[] newArray(int i) {
            return new LcPropertyStatusMessage[i];
        }
    };
    private int propertyID;
    private byte[] propertyValue;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public LcPropertyStatusMessage() {
    }

    protected LcPropertyStatusMessage(Parcel parcel) {
        this.propertyID = parcel.readInt();
        parcel.readByteArray(this.propertyValue);
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.propertyID = MeshUtils.bytes2Integer(bArr, 0, 2, ByteOrder.LITTLE_ENDIAN);
        byte[] bArr2 = new byte[bArr.length - 2];
        this.propertyValue = bArr2;
        System.arraycopy(bArr, 2, bArr2, 0, bArr.length - 2);
    }

    public int getPropertyID() {
        return this.propertyID;
    }

    public byte[] getPropertyValue() {
        return this.propertyValue;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.propertyID);
        parcel.writeByteArray(this.propertyValue);
    }
}
