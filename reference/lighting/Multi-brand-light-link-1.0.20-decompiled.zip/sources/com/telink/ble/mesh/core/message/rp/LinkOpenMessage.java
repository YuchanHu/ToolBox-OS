package com.telink.ble.mesh.core.message.rp;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class LinkOpenMessage extends RemoteProvisionMessage {
    private byte[] uuid;

    public LinkOpenMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.REMOTE_PROV_LINK_OPEN.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.REMOTE_PROV_LINK_STS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return this.uuid;
    }

    public void setUuid(byte[] bArr) {
        this.uuid = bArr;
    }

    public static LinkOpenMessage getSimple(int i, int i2, byte[] bArr) {
        LinkOpenMessage linkOpenMessage = new LinkOpenMessage(i);
        linkOpenMessage.setResponseMax(i2);
        linkOpenMessage.uuid = bArr;
        return linkOpenMessage;
    }
}
