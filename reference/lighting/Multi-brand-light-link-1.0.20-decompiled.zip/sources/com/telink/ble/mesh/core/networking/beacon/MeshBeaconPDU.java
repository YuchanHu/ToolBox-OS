package com.telink.ble.mesh.core.networking.beacon;

import com.telink.ble.mesh.core.provisioning.pdu.PDU;

/* loaded from: classes.dex */
public abstract class MeshBeaconPDU implements PDU {
    public static final byte BEACON_TYPE_MESH_PRIVATE = 2;
    public static final byte BEACON_TYPE_SECURE_NETWORK = 1;
    public static final byte BEACON_TYPE_UNPROVISIONED_DEVICE = 0;
    protected byte[] beaconData;
    protected byte beaconType;
}
