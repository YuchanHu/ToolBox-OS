package com.telink.ble.mesh.foundation.parameter;

import com.telink.ble.mesh.entity.FirmwareUpdateConfiguration;

/* loaded from: classes.dex */
public class MeshOtaParameters extends Parameters {
    public MeshOtaParameters(FirmwareUpdateConfiguration firmwareUpdateConfiguration) {
        set(Parameters.COMMON_PROXY_FILTER_INIT_NEEDED, true);
        set(Parameters.ACTION_MESH_OTA_CONFIG, firmwareUpdateConfiguration);
    }
}
