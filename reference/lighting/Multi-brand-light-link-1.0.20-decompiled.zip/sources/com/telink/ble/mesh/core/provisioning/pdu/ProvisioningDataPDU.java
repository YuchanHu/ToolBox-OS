package com.telink.ble.mesh.core.provisioning.pdu;

/* loaded from: classes.dex */
public class ProvisioningDataPDU implements ProvisioningStatePDU {
    public byte[] encryptedData;

    @Override // com.telink.ble.mesh.core.provisioning.pdu.ProvisioningStatePDU
    public byte getState() {
        return (byte) 7;
    }

    public ProvisioningDataPDU(byte[] bArr) {
        this.encryptedData = bArr;
    }

    @Override // com.telink.ble.mesh.core.provisioning.pdu.PDU
    public byte[] toBytes() {
        return this.encryptedData;
    }
}
