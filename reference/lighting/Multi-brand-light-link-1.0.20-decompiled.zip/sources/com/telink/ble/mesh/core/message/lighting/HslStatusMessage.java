package com.telink.ble.mesh.core.message.lighting;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class HslStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<HslStatusMessage> CREATOR = new Parcelable.Creator<HslStatusMessage>() { // from class: com.telink.ble.mesh.core.message.lighting.HslStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ HslStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ HslStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public HslStatusMessage createFromParcel(Parcel parcel) {
            return new HslStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public HslStatusMessage[] newArray(int i) {
            return new HslStatusMessage[i];
        }
    };
    private static final int DATA_LEN_COMPLETE = 7;
    private int hue;
    private boolean isComplete;
    private int lightness;
    private byte remainingTime;
    private int saturation;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public HslStatusMessage() {
        this.isComplete = false;
    }

    protected HslStatusMessage(Parcel parcel) {
        this.isComplete = false;
        this.lightness = parcel.readInt();
        this.hue = parcel.readInt();
        this.saturation = parcel.readInt();
        this.remainingTime = parcel.readByte();
        this.isComplete = parcel.readByte() != 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.lightness);
        parcel.writeInt(this.hue);
        parcel.writeInt(this.saturation);
        parcel.writeByte(this.remainingTime);
        parcel.writeByte(this.isComplete ? (byte) 1 : (byte) 0);
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.lightness = MeshUtils.bytes2Integer(bArr, 0, 2, ByteOrder.LITTLE_ENDIAN);
        this.hue = MeshUtils.bytes2Integer(bArr, 2, 2, ByteOrder.LITTLE_ENDIAN);
        this.saturation = MeshUtils.bytes2Integer(bArr, 4, 2, ByteOrder.LITTLE_ENDIAN);
        if (bArr.length >= 7) {
            this.isComplete = true;
            this.remainingTime = bArr[6];
        }
    }

    public int getLightness() {
        return this.lightness;
    }

    public int getHue() {
        return this.hue;
    }

    public int getSaturation() {
        return this.saturation;
    }

    public byte getRemainingTime() {
        return this.remainingTime;
    }

    public boolean isComplete() {
        return this.isComplete;
    }
}
