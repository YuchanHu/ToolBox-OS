package com.telink.ble.mesh.core.message.firmwareupdate;

/* loaded from: classes.dex */
public enum DistributionStatus {
    SUCCESS(0, "The message was processed successfully"),
    INSUFFICIENT_RESOURCES(1, "Insufficient resources on the node"),
    WRONG_PHASE(2, "The operation cannot be performed while the server is in the current phase"),
    INTERNAL_ERROR(3, "An internal error occurred on the node"),
    FIRMWARE_NOT_FOUND(4, "The requested firmware image is not stored on the Distributor"),
    INVALID_APPKEY_INDEX(5, "The AppKey identified by the AppKey Index is not known to the node"),
    RECEIVERS_LIST_EMPTY(6, "There are no Updating nodes in the Distribution Receivers List state"),
    BUSY_WITH_DISTRIBUTION(7, "Another firmware image distribution is in progress"),
    BUSY_WITH_UPLOAD(8, "Another upload is in progress"),
    URI_NOT_SUPPORTED(9, "The URI scheme name indicated by the Update URI is not supported"),
    URI_MALFORMED(10, "The format of the Update URI is invalid"),
    URI_UNREACHABLE(11, "The URI is unreachable."),
    NEW_FIRMWARE_NOT_AVAILABLE(12, "The Check Firmware OOB procedure did not find any new firmware."),
    SUSPEND_FAILED(13, "The suspension of the Distribute Firmware procedure failed."),
    UNKNOWN_ERROR(255, "unknown error");

    public final int code;
    public final String desc;

    DistributionStatus(int i, String str) {
        this.code = i;
        this.desc = str;
    }

    public static DistributionStatus valueOf(int i) {
        for (DistributionStatus distributionStatus : values()) {
            if (distributionStatus.code == i) {
                return distributionStatus;
            }
        }
        return UNKNOWN_ERROR;
    }
}
