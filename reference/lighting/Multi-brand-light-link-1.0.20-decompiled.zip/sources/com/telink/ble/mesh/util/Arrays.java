package com.telink.ble.mesh.util;

import com.telink.ble.mesh.core.access.fu.FUDistributor;
import java.io.UnsupportedEncodingException;
import java.security.SecureRandom;

/* loaded from: classes.dex */
public final class Arrays {
    public static final char[] HEX_BASIC = "0123456789ABCDEF".toCharArray();

    private Arrays() {
    }

    public static byte[] reverse(byte[] bArr) {
        if (bArr == null) {
            return null;
        }
        int length = bArr.length;
        byte[] bArr2 = new byte[length];
        int i = 0;
        while (true) {
            length--;
            if (length < 0) {
                return bArr2;
            }
            bArr2[length] = bArr[i];
            i++;
        }
    }

    public static byte[] reverse(byte[] bArr, int i, int i2) {
        while (i < i2) {
            byte b = bArr[i2];
            bArr[i2] = bArr[i];
            bArr[i] = b;
            i++;
            i2--;
        }
        return bArr;
    }

    public static boolean equals(byte[] bArr, byte[] bArr2) {
        if (bArr == bArr2) {
            return true;
        }
        if (bArr == null || bArr2 == null || bArr.length != bArr2.length) {
            return false;
        }
        for (int i = 0; i < bArr.length; i++) {
            if (bArr[i] != bArr2[i]) {
                return false;
            }
        }
        return true;
    }

    public static String bytesToString(byte[] bArr) {
        if (bArr == null) {
            return "null";
        }
        if (bArr.length == 0) {
            return "[]";
        }
        StringBuilder sb = new StringBuilder(bArr.length * 6);
        sb.append('[');
        sb.append((int) bArr[0]);
        for (int i = 1; i < bArr.length; i++) {
            sb.append(", ");
            sb.append((int) bArr[i]);
        }
        sb.append(']');
        return sb.toString();
    }

    public static String bytesToString(byte[] bArr, String str) throws UnsupportedEncodingException {
        return new String(bArr, str);
    }

    public static String bytesToHexString(byte[] bArr) {
        return bytesToHexString(bArr, "");
    }

    public static String bytesToHexString(byte[] bArr, String str) {
        if (bArr == null || bArr.length == 0) {
            return "";
        }
        boolean z = str == null || str.length() == 0;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < bArr.length; i++) {
            byte b = bArr[i];
            int i2 = b & FUDistributor.UPDATE_TTL;
            if (i != 0 && !z) {
                sb.append(str);
            }
            char[] cArr = HEX_BASIC;
            sb.append(cArr[i2 >>> 4]);
            sb.append(cArr[b & 15]);
        }
        return sb.toString();
    }

    public static byte[] hexToBytes(String str) {
        if (str == null) {
            return null;
        }
        if (str.length() == 1) {
            str = "0" + str;
        }
        int length = str.length() / 2;
        byte[] bArr = new byte[length];
        for (int i = 0; i < length; i++) {
            int i2 = i * 2;
            bArr[i] = (byte) Integer.parseInt(str.substring(i2, i2 + 2), 16);
        }
        return bArr;
    }

    public static byte[] generateRandom(int i) {
        byte[] bArr = new byte[i];
        new SecureRandom().nextBytes(bArr);
        return bArr;
    }
}
