package com.telink.ble.mesh.core.ble;

import android.os.ParcelUuid;
import android.util.SparseArray;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public class MeshScanRecord {
    private static final int DATA_TYPE_FLAGS = 1;
    private static final int DATA_TYPE_LOCAL_NAME_COMPLETE = 9;
    private static final int DATA_TYPE_LOCAL_NAME_SHORT = 8;
    private static final int DATA_TYPE_MANUFACTURER_SPECIFIC_DATA = 255;
    private static final int DATA_TYPE_SERVICE_DATA = 22;
    private static final int DATA_TYPE_SERVICE_UUIDS_128_BIT_COMPLETE = 7;
    private static final int DATA_TYPE_SERVICE_UUIDS_128_BIT_PARTIAL = 6;
    private static final int DATA_TYPE_SERVICE_UUIDS_16_BIT_COMPLETE = 3;
    private static final int DATA_TYPE_SERVICE_UUIDS_16_BIT_PARTIAL = 2;
    private static final int DATA_TYPE_SERVICE_UUIDS_32_BIT_COMPLETE = 5;
    private static final int DATA_TYPE_SERVICE_UUIDS_32_BIT_PARTIAL = 4;
    private static final int DATA_TYPE_TX_POWER_LEVEL = 10;
    private ParcelUuid PROV_SERVICE_UUID = ParcelUuid.fromString(UUIDInfo.SERVICE_PROXY.toString());
    private ParcelUuid PROXY_SERVICE_UUID = ParcelUuid.fromString(UUIDInfo.SERVICE_PROXY.toString());
    private final int mAdvertiseFlags;
    private final byte[] mBytes;
    private final String mDeviceName;
    private final SparseArray<byte[]> mManufacturerSpecificData;
    private final Map<ParcelUuid, byte[]> mServiceData;
    private final List<ParcelUuid> mServiceUuids;
    private final int mTxPowerLevel;

    public int getAdvertiseFlags() {
        return this.mAdvertiseFlags;
    }

    public List<ParcelUuid> getServiceUuids() {
        return this.mServiceUuids;
    }

    public SparseArray<byte[]> getManufacturerSpecificData() {
        return this.mManufacturerSpecificData;
    }

    public byte[] getManufacturerSpecificData(int i) {
        return this.mManufacturerSpecificData.get(i);
    }

    public Map<ParcelUuid, byte[]> getServiceData() {
        return this.mServiceData;
    }

    public byte[] getServiceData(ParcelUuid parcelUuid) {
        Map<ParcelUuid, byte[]> map;
        if (parcelUuid == null || (map = this.mServiceData) == null) {
            return null;
        }
        return map.get(parcelUuid);
    }

    public byte[] getProvServiceData() {
        return getServiceData(this.PROV_SERVICE_UUID);
    }

    public byte[] getProxyServiceData() {
        return getServiceData(this.PROXY_SERVICE_UUID);
    }

    public int getTxPowerLevel() {
        return this.mTxPowerLevel;
    }

    public String getDeviceName() {
        return this.mDeviceName;
    }

    public byte[] getBytes() {
        return this.mBytes;
    }

    private MeshScanRecord(List<ParcelUuid> list, SparseArray<byte[]> sparseArray, Map<ParcelUuid, byte[]> map, int i, int i2, String str, byte[] bArr) {
        this.mServiceUuids = list;
        this.mManufacturerSpecificData = sparseArray;
        this.mServiceData = map;
        this.mDeviceName = str;
        this.mAdvertiseFlags = i;
        this.mTxPowerLevel = i2;
        this.mBytes = bArr;
    }

    /* JADX WARN: Removed duplicated region for block: B:27:0x008d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static com.telink.ble.mesh.core.ble.MeshScanRecord parseFromBytes(byte[] r16) {
        /*
            r8 = r16
            r0 = 0
            if (r8 != 0) goto L6
            return r0
        L6:
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            android.util.SparseArray r2 = new android.util.SparseArray
            r2.<init>()
            java.util.HashMap r3 = new java.util.HashMap
            r3.<init>()
            r4 = 0
            r5 = -1
            r6 = -2147483648(0xffffffff80000000, float:-0.0)
            r7 = r0
        L1a:
            int r9 = r8.length     // Catch: java.lang.Exception -> L9a
            if (r4 >= r9) goto L87
            int r9 = r4 + 1
            r10 = r8[r4]     // Catch: java.lang.Exception -> L9a
            r11 = 255(0xff, float:3.57E-43)
            r10 = r10 & r11
            if (r10 != 0) goto L27
            goto L87
        L27:
            int r12 = r10 + (-1)
            int r13 = r4 + 2
            r9 = r8[r9]     // Catch: java.lang.Exception -> L9a
            r9 = r9 & r11
            r14 = 22
            r15 = 2
            if (r9 == r14) goto L71
            if (r9 == r11) goto L5a
            switch(r9) {
                case 1: goto L55;
                case 2: goto L51;
                case 3: goto L51;
                case 4: goto L4c;
                case 5: goto L4c;
                case 6: goto L46;
                case 7: goto L46;
                case 8: goto L3c;
                case 9: goto L3c;
                case 10: goto L39;
                default: goto L38;
            }     // Catch: java.lang.Exception -> L9a
        L38:
            goto L84
        L39:
            r6 = r8[r13]     // Catch: java.lang.Exception -> L9a
            goto L84
        L3c:
            java.lang.String r7 = new java.lang.String     // Catch: java.lang.Exception -> L9a
            byte[] r4 = extractBytes(r8, r13, r12)     // Catch: java.lang.Exception -> L9a
            r7.<init>(r4)     // Catch: java.lang.Exception -> L9a
            goto L84
        L46:
            r4 = 16
            parseServiceUuid(r8, r13, r12, r4, r1)     // Catch: java.lang.Exception -> L9a
            goto L84
        L4c:
            r4 = 4
            parseServiceUuid(r8, r13, r12, r4, r1)     // Catch: java.lang.Exception -> L9a
            goto L84
        L51:
            parseServiceUuid(r8, r13, r12, r15, r1)     // Catch: java.lang.Exception -> L9a
            goto L84
        L55:
            r4 = r8[r13]     // Catch: java.lang.Exception -> L9a
            r5 = r4 & 255(0xff, float:3.57E-43)
            goto L84
        L5a:
            int r9 = r4 + 3
            r9 = r8[r9]     // Catch: java.lang.Exception -> L9a
            r9 = r9 & r11
            int r9 = r9 << 8
            r14 = r8[r13]     // Catch: java.lang.Exception -> L9a
            r11 = r11 & r14
            int r9 = r9 + r11
            int r4 = r4 + 4
            int r10 = r10 + (-3)
            byte[] r4 = extractBytes(r8, r4, r10)     // Catch: java.lang.Exception -> L9a
            r2.put(r9, r4)     // Catch: java.lang.Exception -> L9a
            goto L84
        L71:
            byte[] r9 = extractBytes(r8, r13, r15)     // Catch: java.lang.Exception -> L9a
            android.os.ParcelUuid r9 = com.telink.ble.mesh.core.ble.MeshBluetoothUUID.parseUuidFrom(r9)     // Catch: java.lang.Exception -> L9a
            int r4 = r4 + 4
            int r10 = r10 + (-3)
            byte[] r4 = extractBytes(r8, r4, r10)     // Catch: java.lang.Exception -> L9a
            r3.put(r9, r4)     // Catch: java.lang.Exception -> L9a
        L84:
            int r4 = r13 + r12
            goto L1a
        L87:
            boolean r4 = r1.isEmpty()     // Catch: java.lang.Exception -> L9a
            if (r4 == 0) goto L8e
            r1 = r0
        L8e:
            com.telink.ble.mesh.core.ble.MeshScanRecord r9 = new com.telink.ble.mesh.core.ble.MeshScanRecord     // Catch: java.lang.Exception -> L9a
            r0 = r9
            r4 = r5
            r5 = r6
            r6 = r7
            r7 = r16
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)     // Catch: java.lang.Exception -> L9a
            return r9
        L9a:
            com.telink.ble.mesh.core.ble.MeshScanRecord r9 = new com.telink.ble.mesh.core.ble.MeshScanRecord
            r5 = -2147483648(0xffffffff80000000, float:-0.0)
            r6 = 0
            r1 = 0
            r2 = 0
            r3 = 0
            r4 = -1
            r0 = r9
            r7 = r16
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: com.telink.ble.mesh.core.ble.MeshScanRecord.parseFromBytes(byte[]):com.telink.ble.mesh.core.ble.MeshScanRecord");
    }

    private static int parseServiceUuid(byte[] bArr, int i, int i2, int i3, List<ParcelUuid> list) {
        while (i2 > 0) {
            list.add(MeshBluetoothUUID.parseUuidFrom(extractBytes(bArr, i, i3)));
            i2 -= i3;
            i += i3;
        }
        return i;
    }

    private static byte[] extractBytes(byte[] bArr, int i, int i2) {
        byte[] bArr2 = new byte[i2];
        System.arraycopy(bArr, i, bArr2, 0, i2);
        return bArr2;
    }
}
