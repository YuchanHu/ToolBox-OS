package com.telink.ble.mesh.core.networking;

/* loaded from: classes.dex */
public interface NetworkingPDU<T> {
    byte[] toByteArray();
}
