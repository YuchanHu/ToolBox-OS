package com.telink.ble.mesh.foundation;

/* loaded from: classes.dex */
public interface EventHandler {
    void onEventHandle(Event<String> event);
}
