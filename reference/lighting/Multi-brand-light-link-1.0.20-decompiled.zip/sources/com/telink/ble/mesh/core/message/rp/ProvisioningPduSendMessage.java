package com.telink.ble.mesh.core.message.rp;

import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;

/* loaded from: classes.dex */
public class ProvisioningPduSendMessage extends RemoteProvisionMessage {
    private byte outboundPDUNumber;
    private byte[] provisioningPDU;

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return -1;
    }

    public static ProvisioningPduSendMessage getSimple(int i, int i2, byte b, byte[] bArr) {
        ProvisioningPduSendMessage provisioningPduSendMessage = new ProvisioningPduSendMessage(i);
        provisioningPduSendMessage.setResponseMax(i2);
        provisioningPduSendMessage.outboundPDUNumber = b;
        provisioningPduSendMessage.provisioningPDU = bArr;
        return provisioningPduSendMessage;
    }

    public ProvisioningPduSendMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.REMOTE_PROV_PDU_SEND.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(this.provisioningPDU.length + 1).put(this.outboundPDUNumber).put(this.provisioningPDU).array();
    }

    public void setOutboundPDUNumber(byte b) {
        this.outboundPDUNumber = b;
    }

    public void setProvisioningPDU(byte[] bArr) {
        this.provisioningPDU = bArr;
    }
}
