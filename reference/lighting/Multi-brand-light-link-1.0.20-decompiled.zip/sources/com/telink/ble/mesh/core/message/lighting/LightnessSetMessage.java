package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;

/* loaded from: classes.dex */
public class LightnessSetMessage extends GenericMessage {
    private boolean ack;
    private byte delay;
    private boolean isComplete;
    private int lightness;
    private byte tid;
    private byte transitionTime;

    public static LightnessSetMessage getSimple(int i, int i2, int i3, boolean z, int i4) {
        LightnessSetMessage lightnessSetMessage = new LightnessSetMessage(i, i2);
        lightnessSetMessage.lightness = i3;
        lightnessSetMessage.ack = z;
        lightnessSetMessage.setResponseMax(i4);
        return lightnessSetMessage;
    }

    public LightnessSetMessage(int i, int i2) {
        super(i, i2);
        this.tid = (byte) 0;
        this.transitionTime = (byte) 0;
        this.delay = (byte) 0;
        this.ack = false;
        this.isComplete = false;
        setTidPosition(2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return this.ack ? Opcode.LIGHTNESS_STATUS.value : super.getResponseOpcode();
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.LIGHTNESS_SET : Opcode.LIGHTNESS_SET_NOACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        if (this.isComplete) {
            int i = this.lightness;
            return new byte[]{(byte) i, (byte) (i >> 8), this.tid, this.transitionTime, this.delay};
        }
        int i2 = this.lightness;
        return new byte[]{(byte) i2, (byte) (i2 >> 8), this.tid};
    }

    public void setLightness(int i) {
        this.lightness = i;
    }

    public void setTid(byte b) {
        this.tid = b;
    }

    public void setTransitionTime(byte b) {
        this.transitionTime = b;
    }

    public void setDelay(byte b) {
        this.delay = b;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }

    public void setComplete(boolean z) {
        this.isComplete = z;
    }
}
