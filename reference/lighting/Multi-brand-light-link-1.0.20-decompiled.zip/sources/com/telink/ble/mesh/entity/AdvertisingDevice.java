package com.telink.ble.mesh.entity;

import android.bluetooth.BluetoothDevice;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.Arrays;

/* loaded from: classes.dex */
public class AdvertisingDevice implements Parcelable {
    public static final Parcelable.Creator<AdvertisingDevice> CREATOR = new Parcelable.Creator<AdvertisingDevice>() { // from class: com.telink.ble.mesh.entity.AdvertisingDevice.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ AdvertisingDevice createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ AdvertisingDevice[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public AdvertisingDevice createFromParcel(Parcel parcel) {
            return new AdvertisingDevice(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public AdvertisingDevice[] newArray(int i) {
            return new AdvertisingDevice[i];
        }
    };
    public BluetoothDevice device;
    public int rssi;
    public byte[] scanRecord;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public AdvertisingDevice(BluetoothDevice bluetoothDevice, int i, byte[] bArr) {
        this.device = bluetoothDevice;
        this.rssi = i;
        this.scanRecord = bArr;
    }

    public AdvertisingDevice(Parcel parcel) {
        this.device = (BluetoothDevice) parcel.readParcelable(getClass().getClassLoader());
        this.rssi = parcel.readInt();
        byte[] bArr = new byte[parcel.readInt()];
        this.scanRecord = bArr;
        parcel.readByteArray(bArr);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.device, 0);
        parcel.writeInt(this.rssi);
        parcel.writeInt(this.scanRecord.length);
        parcel.writeByteArray(this.scanRecord);
    }

    public boolean equals(Object obj) {
        if (obj instanceof AdvertisingDevice) {
            AdvertisingDevice advertisingDevice = (AdvertisingDevice) obj;
            if (advertisingDevice.device.equals(this.device) && Arrays.equals(advertisingDevice.scanRecord, this.scanRecord)) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        return this.device.hashCode();
    }
}
