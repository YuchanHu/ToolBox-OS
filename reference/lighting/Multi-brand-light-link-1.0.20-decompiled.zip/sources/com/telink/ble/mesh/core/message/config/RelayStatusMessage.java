package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class RelayStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<RelayStatusMessage> CREATOR = new Parcelable.Creator<RelayStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.RelayStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ RelayStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ RelayStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public RelayStatusMessage createFromParcel(Parcel parcel) {
            return new RelayStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public RelayStatusMessage[] newArray(int i) {
            return new RelayStatusMessage[i];
        }
    };
    public byte relay;
    public byte retransmitCount;
    public byte retransmitIntervalSteps;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public RelayStatusMessage() {
    }

    protected RelayStatusMessage(Parcel parcel) {
        this.relay = parcel.readByte();
        this.retransmitCount = parcel.readByte();
        this.retransmitIntervalSteps = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.relay = bArr[0];
        byte b = bArr[1];
        this.retransmitCount = (byte) (b & 7);
        this.retransmitIntervalSteps = (byte) ((b & FUDistributor.UPDATE_TTL) >> 3);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.relay);
        parcel.writeByte(this.retransmitCount);
        parcel.writeByte(this.retransmitIntervalSteps);
    }
}
