package com.telink.ble.mesh.foundation.event;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.entity.AdvertisingDevice;
import com.telink.ble.mesh.foundation.Event;

/* loaded from: classes.dex */
public class ScanEvent extends Event<String> implements Parcelable {
    public static final Parcelable.Creator<ScanEvent> CREATOR = new Parcelable.Creator<ScanEvent>() { // from class: com.telink.ble.mesh.foundation.event.ScanEvent.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ScanEvent createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ScanEvent[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ScanEvent createFromParcel(Parcel parcel) {
            return new ScanEvent(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ScanEvent[] newArray(int i) {
            return new ScanEvent[i];
        }
    };
    public static final String EVENT_TYPE_DEVICE_FOUND = "com.telink.ble.mesh.EVENT_TYPE_DEVICE_FOUND";
    public static final String EVENT_TYPE_SCAN_FAIL = "com.telink.ble.mesh.EVENT_TYPE_SCAN_FAIL";
    public static final String EVENT_TYPE_SCAN_LOCATION_WARNING = "com.telink.ble.mesh.EVENT_TYPE_SCAN_LOCATION_WARNING";
    public static final String EVENT_TYPE_SCAN_TIMEOUT = "com.telink.ble.mesh.EVENT_TYPE_SCAN_TIMEOUT";
    private AdvertisingDevice advertisingDevice;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public ScanEvent(Object obj, String str, AdvertisingDevice advertisingDevice) {
        super(obj, str);
        this.advertisingDevice = advertisingDevice;
    }

    public ScanEvent(Object obj, String str) {
        super(obj, str);
    }

    protected ScanEvent(Parcel parcel) {
        this.advertisingDevice = (AdvertisingDevice) parcel.readParcelable(AdvertisingDevice.class.getClassLoader());
    }

    public AdvertisingDevice getAdvertisingDevice() {
        return this.advertisingDevice;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.advertisingDevice, i);
    }
}
