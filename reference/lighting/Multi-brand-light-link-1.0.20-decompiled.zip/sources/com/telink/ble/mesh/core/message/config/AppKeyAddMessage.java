package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class AppKeyAddMessage extends ConfigMessage {
    private byte[] appKey;
    private int appKeyIndex;
    private int netKeyIndex;

    public AppKeyAddMessage(int i) {
        super(i);
    }

    public void setNetKeyIndex(int i) {
        this.netKeyIndex = i;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public void setAppKeyIndex(int i) {
        this.appKeyIndex = i;
    }

    public void setAppKey(byte[] bArr) {
        this.appKey = bArr;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.APPKEY_ADD.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.APPKEY_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(19).order(ByteOrder.LITTLE_ENDIAN).put(MeshUtils.integer2Bytes((this.netKeyIndex & 4095) | ((this.appKeyIndex & 4095) << 12), 3, ByteOrder.LITTLE_ENDIAN)).put(this.appKey).array();
    }
}
