package com.telink.ble.mesh.core.message.firmwareupdate;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class FirmwareUpdateInfoStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<FirmwareUpdateInfoStatusMessage> CREATOR = new Parcelable.Creator<FirmwareUpdateInfoStatusMessage>() { // from class: com.telink.ble.mesh.core.message.firmwareupdate.FirmwareUpdateInfoStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FirmwareUpdateInfoStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FirmwareUpdateInfoStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FirmwareUpdateInfoStatusMessage createFromParcel(Parcel parcel) {
            return new FirmwareUpdateInfoStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FirmwareUpdateInfoStatusMessage[] newArray(int i) {
            return new FirmwareUpdateInfoStatusMessage[i];
        }
    };
    private List<FirmwareInformationEntry> firmwareInformationList;
    private int firstIndex;
    private int listCount;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public FirmwareUpdateInfoStatusMessage() {
    }

    protected FirmwareUpdateInfoStatusMessage(Parcel parcel) {
        this.listCount = parcel.readInt();
        this.firstIndex = parcel.readInt();
        this.firmwareInformationList = parcel.createTypedArrayList(FirmwareInformationEntry.CREATOR);
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        byte[] bArr2;
        this.listCount = bArr[0] & 255;
        this.firstIndex = bArr[1] & 255;
        this.firmwareInformationList = new ArrayList();
        int i = 2;
        int i2 = 0;
        while (i2 < this.listCount) {
            int i3 = i + 1;
            int i4 = bArr[i] & 255;
            byte[] bArr3 = null;
            if (i4 > 0) {
                bArr2 = new byte[i4];
                System.arraycopy(bArr, i3, bArr2, 0, i4);
                i3 += i4;
            } else {
                bArr2 = null;
            }
            int i5 = i3 + 1;
            int i6 = bArr[i3];
            if (i6 > 0) {
                bArr3 = new byte[i6];
                System.arraycopy(bArr, i5, bArr3, 0, i6);
                i5 += i6;
            }
            FirmwareInformationEntry firmwareInformationEntry = new FirmwareInformationEntry();
            firmwareInformationEntry.currentFirmwareIDLength = i4;
            firmwareInformationEntry.currentFirmwareID = bArr2;
            firmwareInformationEntry.updateURILength = i6;
            firmwareInformationEntry.updateURI = bArr3;
            this.firmwareInformationList.add(firmwareInformationEntry);
            i2++;
            i = i5;
        }
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.listCount);
        parcel.writeInt(this.firstIndex);
        parcel.writeTypedList(this.firmwareInformationList);
    }

    public int getListCount() {
        return this.listCount;
    }

    public int getFirstIndex() {
        return this.firstIndex;
    }

    public List<FirmwareInformationEntry> getFirmwareInformationList() {
        return this.firmwareInformationList;
    }

    public FirmwareInformationEntry getFirstEntry() {
        List<FirmwareInformationEntry> list = this.firmwareInformationList;
        if (list == null) {
            return null;
        }
        int size = list.size();
        int i = this.firstIndex;
        if (size < i + 1) {
            return null;
        }
        return this.firmwareInformationList.get(i);
    }

    public static class FirmwareInformationEntry implements Parcelable {
        public static final Parcelable.Creator<FirmwareInformationEntry> CREATOR = new Parcelable.Creator<FirmwareInformationEntry>() { // from class: com.telink.ble.mesh.core.message.firmwareupdate.FirmwareUpdateInfoStatusMessage.FirmwareInformationEntry.1
            @Override // android.os.Parcelable.Creator
            public /* bridge */ /* synthetic */ FirmwareInformationEntry createFromParcel(Parcel parcel) {
                return createFromParcel(parcel);
            }

            @Override // android.os.Parcelable.Creator
            public /* bridge */ /* synthetic */ FirmwareInformationEntry[] newArray(int i) {
                return newArray(i);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // android.os.Parcelable.Creator
            public FirmwareInformationEntry createFromParcel(Parcel parcel) {
                return new FirmwareInformationEntry(parcel);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // android.os.Parcelable.Creator
            public FirmwareInformationEntry[] newArray(int i) {
                return new FirmwareInformationEntry[i];
            }
        };
        public byte[] currentFirmwareID;
        public int currentFirmwareIDLength;
        public byte[] updateURI;
        public int updateURILength;

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public FirmwareInformationEntry() {
        }

        protected FirmwareInformationEntry(Parcel parcel) {
            this.currentFirmwareIDLength = parcel.readInt();
            this.currentFirmwareID = parcel.createByteArray();
            this.updateURILength = parcel.readInt();
            this.updateURI = parcel.createByteArray();
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.currentFirmwareIDLength);
            parcel.writeByteArray(this.currentFirmwareID);
            parcel.writeInt(this.updateURILength);
            parcel.writeByteArray(this.updateURI);
        }
    }

    public String toString() {
        return "FirmwareUpdateInfoStatusMessage{listCount=" + this.listCount + ", firstIndex=" + this.firstIndex + ", firmwareInformationList=" + this.firmwareInformationList.size() + '}';
    }
}
