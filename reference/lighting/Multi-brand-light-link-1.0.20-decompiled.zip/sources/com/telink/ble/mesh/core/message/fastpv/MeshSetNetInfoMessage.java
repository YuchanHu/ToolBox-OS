package com.telink.ble.mesh.core.message.fastpv;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;

/* loaded from: classes.dex */
public class MeshSetNetInfoMessage extends GenericMessage {
    private byte[] netInfoData;

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return -1;
    }

    public static MeshSetNetInfoMessage getSimple(int i, int i2, byte[] bArr) {
        MeshSetNetInfoMessage meshSetNetInfoMessage = new MeshSetNetInfoMessage(i, i2);
        meshSetNetInfoMessage.netInfoData = bArr;
        return meshSetNetInfoMessage;
    }

    public MeshSetNetInfoMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.VD_MESH_PROV_DATA_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return this.netInfoData;
    }

    public void setNetInfoData(byte[] bArr) {
        this.netInfoData = bArr;
    }
}
