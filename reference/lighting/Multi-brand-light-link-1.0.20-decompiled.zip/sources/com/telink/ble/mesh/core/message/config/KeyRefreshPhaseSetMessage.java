package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class KeyRefreshPhaseSetMessage extends ConfigMessage {
    public int netKeyIndex;
    public byte transition;

    public KeyRefreshPhaseSetMessage(int i) {
        super(i);
    }

    public static KeyRefreshPhaseSetMessage getSimple(int i, byte b) {
        KeyRefreshPhaseSetMessage keyRefreshPhaseSetMessage = new KeyRefreshPhaseSetMessage(i);
        keyRefreshPhaseSetMessage.transition = b;
        return keyRefreshPhaseSetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.CFG_KEY_REFRESH_PHASE_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_KEY_REFRESH_PHASE_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(3).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.netKeyIndex).put(this.transition).array();
    }
}
