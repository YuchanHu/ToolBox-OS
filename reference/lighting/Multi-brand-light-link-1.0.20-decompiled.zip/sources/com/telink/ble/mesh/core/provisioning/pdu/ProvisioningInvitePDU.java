package com.telink.ble.mesh.core.provisioning.pdu;

/* loaded from: classes.dex */
public class ProvisioningInvitePDU implements ProvisioningStatePDU {
    public byte attentionDuration;

    @Override // com.telink.ble.mesh.core.provisioning.pdu.ProvisioningStatePDU
    public byte getState() {
        return (byte) 0;
    }

    public ProvisioningInvitePDU(byte b) {
        this.attentionDuration = b;
    }

    @Override // com.telink.ble.mesh.core.provisioning.pdu.PDU
    public byte[] toBytes() {
        return new byte[]{this.attentionDuration};
    }
}
