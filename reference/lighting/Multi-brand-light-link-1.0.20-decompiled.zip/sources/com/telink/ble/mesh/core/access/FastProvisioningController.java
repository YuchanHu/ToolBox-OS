package com.telink.ble.mesh.core.access;

import android.os.Handler;
import android.os.HandlerThread;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.NotificationMessage;
import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.fastpv.MeshAddressStatusMessage;
import com.telink.ble.mesh.core.message.fastpv.MeshConfirmRequestMessage;
import com.telink.ble.mesh.core.message.fastpv.MeshGetAddressMessage;
import com.telink.ble.mesh.core.message.fastpv.MeshProvisionCompleteMessage;
import com.telink.ble.mesh.core.message.fastpv.MeshSetAddressMessage;
import com.telink.ble.mesh.core.message.fastpv.MeshSetNetInfoMessage;
import com.telink.ble.mesh.core.message.fastpv.ResetNetworkMessage;
import com.telink.ble.mesh.entity.FastProvisioningConfiguration;
import com.telink.ble.mesh.entity.FastProvisioningDevice;
import com.telink.ble.mesh.foundation.MeshConfiguration;
import com.telink.ble.mesh.util.Arrays;
import com.telink.ble.mesh.util.MeshLogger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;

/* loaded from: classes.dex */
public class FastProvisioningController {
    private static final int CONFIRM_CHECK_TIMEOUT = 3000;
    private static final int CONFIRM_RETRY_MAX = 5;
    private static final int FAST_SCANNING_TIMEOUT = 3500;
    private static final int FLOW_TIMEOUT = 300000;
    private static final int PROVISIONER_DELAY = 500;
    private static final int ROUND_MAX = 10;
    public static final int STATE_CONFIRM = 21;
    public static final int STATE_FAIL = 24;
    public static final int STATE_GET_ADDR = 18;
    public static final int STATE_GET_ADDR_RSP = 33;
    public static final int STATE_IDLE = 16;
    public static final int STATE_RESET_NETWORK = 17;
    public static final int STATE_SET_ADDR = 19;
    public static final int STATE_SET_ADDR_FAIL = 32;
    public static final int STATE_SET_ADDR_SUCCESS = 22;
    public static final int STATE_SET_NET_INFO = 20;
    public static final int STATE_SUCCESS = 25;
    private AccessBridge accessBridge;
    private FastProvisioningConfiguration configuration;
    private Handler delayHandler;
    private MeshConfiguration originMeshConfiguration;
    private int settingIndex;
    private int state;
    private final String LOG_TAG = "FastProv";
    private ArrayList<FastProvisioningDevice> provisioningDeviceList = new ArrayList<>();
    private boolean confirmRetryNeeded = false;
    private int confirmRetryCnt = 0;
    private Runnable flowTimeoutTask = new Runnable() { // from class: com.telink.ble.mesh.core.access.FastProvisioningController.1
        @Override // java.lang.Runnable
        public void run() {
            FastProvisioningController.access$000(FastProvisioningController.this, false, "fast provision timeout");
        }
    };
    private Runnable resetNetworkTask = new Runnable() { // from class: com.telink.ble.mesh.core.access.FastProvisioningController.2
        @Override // java.lang.Runnable
        public void run() {
            FastProvisioningController.access$100(FastProvisioningController.this);
            FastProvisioningController.access$200(FastProvisioningController.this, 0);
        }
    };
    private Runnable fastScanningTimeoutTask = new Runnable() { // from class: com.telink.ble.mesh.core.access.FastProvisioningController.3
        @Override // java.lang.Runnable
        public void run() {
            if (FastProvisioningController.access$300(FastProvisioningController.this).size() > 0) {
                if (FastProvisioningController.access$300(FastProvisioningController.this).size() > FastProvisioningController.access$400(FastProvisioningController.this)) {
                    FastProvisioningController.access$500(FastProvisioningController.this, "set next mesh address when scan timeout");
                    FastProvisioningController.access$600(FastProvisioningController.this);
                    return;
                } else {
                    FastProvisioningController.access$500(FastProvisioningController.this, "all device set address complete no other device found");
                    FastProvisioningController.access$702(FastProvisioningController.this, 0);
                    FastProvisioningController.access$800(FastProvisioningController.this, false);
                    return;
                }
            }
            FastProvisioningController.access$000(FastProvisioningController.this, false, "no device found");
        }
    };
    private Runnable SET_ADR_TIMEOUT_TASK = new Runnable() { // from class: com.telink.ble.mesh.core.access.FastProvisioningController.4
        @Override // java.lang.Runnable
        public void run() {
        }
    };
    private Runnable confirmCheckTimeoutTask = new Runnable() { // from class: com.telink.ble.mesh.core.access.FastProvisioningController.5
        @Override // java.lang.Runnable
        public void run() {
            if (FastProvisioningController.access$900(FastProvisioningController.this)) {
                FastProvisioningController.access$708(FastProvisioningController.this);
                if (FastProvisioningController.access$700(FastProvisioningController.this) > 5) {
                    FastProvisioningController.access$000(FastProvisioningController.this, false, "confirm check retry max");
                    return;
                } else {
                    FastProvisioningController.access$800(FastProvisioningController.this, true);
                    return;
                }
            }
            FastProvisioningController.access$000(FastProvisioningController.this, true, "confirm check success");
        }
    };

    static /* synthetic */ void access$000(FastProvisioningController fastProvisioningController, boolean z, String str) {
        fastProvisioningController.onFastProvisionComplete(z, str);
    }

    static /* synthetic */ void access$100(FastProvisioningController fastProvisioningController) {
        fastProvisioningController.restartScanningTimeoutTask();
    }

    static /* synthetic */ void access$1000(FastProvisioningController fastProvisioningController, int i, String str, Object obj, boolean z) {
        fastProvisioningController.onStateUpdate(i, str, obj, z);
    }

    static /* synthetic */ void access$200(FastProvisioningController fastProvisioningController, int i) {
        fastProvisioningController.startFastScanning(i);
    }

    static /* synthetic */ ArrayList access$300(FastProvisioningController fastProvisioningController) {
        return fastProvisioningController.provisioningDeviceList;
    }

    static /* synthetic */ int access$400(FastProvisioningController fastProvisioningController) {
        return fastProvisioningController.settingIndex;
    }

    static /* synthetic */ void access$500(FastProvisioningController fastProvisioningController, String str) {
        fastProvisioningController.log(str);
    }

    static /* synthetic */ void access$600(FastProvisioningController fastProvisioningController) {
        fastProvisioningController.setNextMeshAddress();
    }

    static /* synthetic */ int access$700(FastProvisioningController fastProvisioningController) {
        return fastProvisioningController.confirmRetryCnt;
    }

    static /* synthetic */ int access$702(FastProvisioningController fastProvisioningController, int i) {
        fastProvisioningController.confirmRetryCnt = i;
        return i;
    }

    static /* synthetic */ int access$708(FastProvisioningController fastProvisioningController) {
        int i = fastProvisioningController.confirmRetryCnt;
        fastProvisioningController.confirmRetryCnt = i + 1;
        return i;
    }

    static /* synthetic */ void access$800(FastProvisioningController fastProvisioningController, boolean z) {
        fastProvisioningController.setMeshNetInfo(z);
    }

    static /* synthetic */ boolean access$900(FastProvisioningController fastProvisioningController) {
        return fastProvisioningController.confirmRetryNeeded;
    }

    public FastProvisioningController(HandlerThread handlerThread) {
        this.delayHandler = new Handler(handlerThread.getLooper());
    }

    public void register(AccessBridge accessBridge) {
        this.accessBridge = accessBridge;
    }

    public FastProvisioningConfiguration getConfiguration() {
        return this.configuration;
    }

    public void init(FastProvisioningConfiguration fastProvisioningConfiguration, MeshConfiguration meshConfiguration) {
        this.configuration = fastProvisioningConfiguration;
        this.originMeshConfiguration = meshConfiguration;
    }

    public void begin() {
        log("begin");
        this.settingIndex = 0;
        this.provisioningDeviceList.clear();
        this.delayHandler.removeCallbacks(this.flowTimeoutTask);
        this.delayHandler.postDelayed(this.flowTimeoutTask, 300000L);
        resetNetwork();
    }

    public void clear() {
        this.state = 16;
        this.settingIndex = 0;
        Handler handler = this.delayHandler;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
        this.provisioningDeviceList.clear();
    }

    public void stop() {
        if (this.state != 16) {
            sendCompleteMessage();
        }
        clear();
    }

    private void resetNetwork() {
        if (onMeshMessagePrepared(ResetNetworkMessage.getSimple(65535, this.originMeshConfiguration.getDefaultAppKeyIndex(), this.configuration.getResetDelay()))) {
            onStateUpdate(17, "reset provisioner network", null, true);
            this.delayHandler.removeCallbacks(this.resetNetworkTask);
            this.delayHandler.postDelayed(this.resetNetworkTask, this.configuration.getResetDelay() + PROVISIONER_DELAY);
            return;
        }
        onFastProvisionComplete(false, "reset command send err");
    }

    private void startFastScanning(int i) {
        onStateUpdate(18, "mesh get address", null, true);
        MeshGetAddressMessage simple = MeshGetAddressMessage.getSimple(65535, this.configuration.getDefaultAppKeyIndex(), 10, this.configuration.getScanningPid());
        simple.setAddress(i);
        log("get address params : " + Arrays.bytesToHexString(simple.getParams()));
        onMeshMessagePrepared(simple);
    }

    private void restartScanningTimeoutTask() {
        this.delayHandler.removeCallbacks(this.fastScanningTimeoutTask);
        this.delayHandler.postDelayed(this.fastScanningTimeoutTask, 3500L);
    }

    private void pushNewDevice(FastProvisioningDevice fastProvisioningDevice) {
        if (!this.provisioningDeviceList.contains(fastProvisioningDevice)) {
            this.provisioningDeviceList.add(fastProvisioningDevice);
            restartScanningTimeoutTask();
            postStateCb(33, "get address response", fastProvisioningDevice);
        } else {
            log("provisioning device exists: " + Arrays.bytesToHexString(fastProvisioningDevice.getMac()));
        }
    }

    private void setNextMeshAddress() {
        log("set next -- " + this.provisioningDeviceList.size() + " -- " + this.settingIndex);
        int size = this.provisioningDeviceList.size();
        int i = this.settingIndex;
        if (size > i) {
            FastProvisioningDevice fastProvisioningDevice = this.provisioningDeviceList.get(i);
            this.settingIndex++;
            if (fastProvisioningDevice != null) {
                log(String.format(Locale.getDefault(), "mesh set next address: mac -- %s originAddress -- %04X newAddress -- %04X index -- %02d", Arrays.bytesToHexString(fastProvisioningDevice.getMac()), Integer.valueOf(fastProvisioningDevice.getOriginAddress()), Integer.valueOf(fastProvisioningDevice.getNewAddress()), Integer.valueOf(this.settingIndex)));
                onStateUpdate(19, "mesh set address", fastProvisioningDevice, true);
                MeshMessage simple = MeshSetAddressMessage.getSimple(65535, this.configuration.getDefaultAppKeyIndex(), Arrays.reverse(fastProvisioningDevice.getMac()), fastProvisioningDevice.getNewAddress());
                this.delayHandler.postDelayed(this.SET_ADR_TIMEOUT_TASK, 5000L);
                onMeshMessagePrepared(simple);
                return;
            }
            log("provisioning device not found");
            return;
        }
        log("round complete -> start next scanning action ");
        restartScanningTimeoutTask();
        startFastScanning(this.configuration.getProvisioningIndex());
    }

    private void setMeshNetInfo(boolean z) {
        onStateUpdate(20, "mesh set net info", null, !z);
        onMeshMessagePrepared(MeshSetNetInfoMessage.getSimple(65535, this.configuration.getDefaultAppKeyIndex(), getNetInfoData()));
        sendConfirmRequest();
    }

    private void sendConfirmRequest() {
        onStateUpdate(21, "fast provision confirming", null, true);
        this.confirmRetryNeeded = false;
        onMeshMessagePrepared(MeshConfirmRequestMessage.getSimple(65535, this.configuration.getDefaultAppKeyIndex()));
        this.delayHandler.postDelayed(this.confirmCheckTimeoutTask, 3000L);
    }

    private void onFastProvisionComplete(final boolean z, final String str) {
        log("complete: " + str + " success?" + z);
        sendCompleteMessage();
        this.delayHandler.postDelayed(new Runnable() { // from class: com.telink.ble.mesh.core.access.FastProvisioningController.6
            @Override // java.lang.Runnable
            public void run() {
                FastProvisioningController.this.clear();
                FastProvisioningController.access$1000(FastProvisioningController.this, z ? 25 : 24, str, null, true);
            }
        }, 500L);
    }

    private void sendCompleteMessage() {
        onMeshMessagePrepared(MeshProvisionCompleteMessage.getSimple(65535, this.configuration.getDefaultAppKeyIndex(), this.configuration.getResetDelay()));
    }

    private boolean onMeshMessagePrepared(MeshMessage meshMessage) {
        log("mesh message prepared: " + meshMessage.getClass().getSimpleName() + String.format(" opcode: 0x%04X -- dst: 0x%04X", Integer.valueOf(meshMessage.getOpcode()), Integer.valueOf(meshMessage.getDestinationAddress())));
        AccessBridge accessBridge = this.accessBridge;
        if (accessBridge == null) {
            return false;
        }
        boolean zOnAccessMessagePrepared = accessBridge.onAccessMessagePrepared(meshMessage, 2);
        if (!zOnAccessMessagePrepared) {
            log("message send error");
        }
        return zOnAccessMessagePrepared;
    }

    private int getProvisioningMeshAddress(int i) {
        int elementCount = this.configuration.getElementCount(i);
        if (elementCount != 0) {
            int provisioningIndex = this.configuration.getProvisioningIndex();
            if (MeshUtils.validUnicastAddress(provisioningIndex)) {
                this.configuration.increaseProvisioningIndex(elementCount);
                return provisioningIndex;
            }
            log("invalid address", 3);
            return 0;
        }
        log("pid not found", 3);
        return 0;
    }

    public void onFastProvisioningCommandComplete(boolean z, int i, int i2, int i3) {
        if (i == Opcode.VD_MESH_ADDR_SET.value && this.state == 19 && !z) {
            postStateCb(32, "device set address fail", this.provisioningDeviceList.get(this.settingIndex - 1));
            setNextMeshAddress();
        }
    }

    public void onMessageNotification(NotificationMessage notificationMessage) {
        Opcode opcodeValueOf = Opcode.valueOf(notificationMessage.getOpcode());
        log("message notification: " + opcodeValueOf);
        if (opcodeValueOf == null) {
            return;
        }
        int i = AnonymousClass7.$SwitchMap$com$telink$ble$mesh$core$message$Opcode[opcodeValueOf.ordinal()];
        if (i == 1) {
            if (this.state == 18) {
                MeshAddressStatusMessage meshAddressStatusMessage = (MeshAddressStatusMessage) notificationMessage.getStatusMessage();
                int src = notificationMessage.getSrc();
                int pid = meshAddressStatusMessage.getPid();
                log("device address notify: " + Arrays.bytesToHexString(meshAddressStatusMessage.getMac()));
                int i2 = pid & 4095;
                int provisioningMeshAddress = getProvisioningMeshAddress(i2);
                if (provisioningMeshAddress != 0) {
                    pushNewDevice(new FastProvisioningDevice(src, provisioningMeshAddress, pid, this.configuration.getElementCount(i2), meshAddressStatusMessage.getMac()));
                    return;
                }
                return;
            }
            return;
        }
        if (i == 2) {
            if (this.state == 19) {
                int src2 = notificationMessage.getSrc();
                FastProvisioningDevice provisioningDeviceByAddress = getProvisioningDeviceByAddress(src2);
                if (provisioningDeviceByAddress != null) {
                    if (!provisioningDeviceByAddress.isSetAdrComplete()) {
                        provisioningDeviceByAddress.setSetAdrComplete(true);
                        postStateCb(22, "device set address success", provisioningDeviceByAddress);
                        setNextMeshAddress();
                        return;
                    }
                    log(String.format("device already set address complete : %04X", Integer.valueOf(provisioningDeviceByAddress.getOriginAddress())));
                    return;
                }
                log(String.format("device info not found when receive set st : %04X", Integer.valueOf(src2)));
                return;
            }
            return;
        }
        if (i == 3 && this.state == 21) {
            this.confirmRetryNeeded = true;
        }
    }

    /* renamed from: com.telink.ble.mesh.core.access.FastProvisioningController$7, reason: invalid class name */
    static /* synthetic */ class AnonymousClass7 {
        static final /* synthetic */ int[] $SwitchMap$com$telink$ble$mesh$core$message$Opcode;

        static {
            int[] iArr = new int[Opcode.values().length];
            $SwitchMap$com$telink$ble$mesh$core$message$Opcode = iArr;
            try {
                iArr[Opcode.VD_MESH_ADDR_GET_STS.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$message$Opcode[Opcode.VD_MESH_ADDR_SET_STS.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$message$Opcode[Opcode.VD_MESH_PROV_CONFIRM_STS.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    private FastProvisioningDevice getProvisioningDeviceByAddress(int i) {
        Iterator<FastProvisioningDevice> it = this.provisioningDeviceList.iterator();
        while (it.hasNext()) {
            FastProvisioningDevice next = it.next();
            if (next.getOriginAddress() == i) {
                return next;
            }
        }
        return null;
    }

    private void onStateUpdate(int i, String str, Object obj, boolean z) {
        log("fast pv state update : " + i + " -- " + str);
        this.state = i;
        if (z) {
            postStateCb(i, str, obj);
        }
    }

    private void postStateCb(int i, String str, Object obj) {
        AccessBridge accessBridge = this.accessBridge;
        if (accessBridge != null) {
            accessBridge.onAccessStateChanged(i, str, 4, obj);
        }
    }

    private void log(String str) {
        log(str, 1);
    }

    private void log(String str, int i) {
        MeshLogger.log(str, "FastProv", i);
    }

    public byte[] getNetInfoData() {
        byte[] bArr = this.originMeshConfiguration.networkKey;
        int i = this.originMeshConfiguration.netKeyIndex;
        int defaultAppKeyIndex = this.originMeshConfiguration.getDefaultAppKeyIndex();
        byte[] defaultAppKey = this.originMeshConfiguration.getDefaultAppKey();
        if (defaultAppKey == null) {
            throw new RuntimeException("app key not found!");
        }
        int i2 = this.originMeshConfiguration.ivIndex;
        byte[] bArr2 = new byte[25];
        System.arraycopy(bArr, 0, bArr2, 0, 16);
        bArr2[16] = (byte) (i & 255);
        bArr2[17] = (byte) ((i >> 8) & 255);
        bArr2[18] = 0;
        bArr2[19] = (byte) ((i2 >> 24) & 255);
        bArr2[20] = (byte) ((i2 >> 16) & 255);
        bArr2[21] = (byte) ((i2 >> 8) & 255);
        bArr2[22] = (byte) (i2 & 255);
        return ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).put(bArr2).put(MeshUtils.integer2Bytes((i & 4095) | ((defaultAppKeyIndex & 4095) << 12), 3, ByteOrder.LITTLE_ENDIAN)).put(defaultAppKey).array();
    }
}
