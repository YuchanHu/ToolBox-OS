package com.telink.ble.mesh.core.message.firmwareupdate;

/* loaded from: classes.dex */
public enum UpdatePhase {
    IDLE(0, "No firmware transfer is in progress"),
    TRANSFER_ERROR(1, "Firmware transfer was not completed"),
    TRANSFER_ACTIVE(2, "Firmware transfer is in progress"),
    VERIFYING_UPDATE(3, "Verification of the firmware image is in progress"),
    VERIFICATION_SUCCEEDED(4, "Firmware image verification succeeded"),
    VERIFICATION_FAILED(5, "Firmware image verification failed"),
    APPLYING_UPDATE(6, "Firmware applying is in progress"),
    TRANSFER_CANCELED(7, "Firmware transfer has been canceled"),
    APPLY_SUCCESS(8, "Firmware applying succeeded"),
    APPLY_FAILED(9, "Firmware applying failed"),
    UNKNOWN_ERROR(255, "unknown error");

    public final int code;
    public final String desc;

    UpdatePhase(int i, String str) {
        this.code = i;
        this.desc = str;
    }

    public static UpdatePhase valueOf(int i) {
        for (UpdatePhase updatePhase : values()) {
            if (updatePhase.code == i) {
                return updatePhase;
            }
        }
        return UNKNOWN_ERROR;
    }
}
