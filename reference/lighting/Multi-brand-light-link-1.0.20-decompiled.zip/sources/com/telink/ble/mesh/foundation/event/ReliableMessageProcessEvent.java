package com.telink.ble.mesh.foundation.event;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.foundation.Event;

/* loaded from: classes.dex */
public class ReliableMessageProcessEvent extends Event<String> implements Parcelable {
    public static final Parcelable.Creator<ReliableMessageProcessEvent> CREATOR = new Parcelable.Creator<ReliableMessageProcessEvent>() { // from class: com.telink.ble.mesh.foundation.event.ReliableMessageProcessEvent.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ReliableMessageProcessEvent createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ReliableMessageProcessEvent[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ReliableMessageProcessEvent createFromParcel(Parcel parcel) {
            return new ReliableMessageProcessEvent(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ReliableMessageProcessEvent[] newArray(int i) {
            return new ReliableMessageProcessEvent[i];
        }
    };
    public static final String EVENT_TYPE_MSG_PROCESSING = "com.telink.sig.mesh.EVENT_TYPE_CMD_PROCESSING";
    public static final String EVENT_TYPE_MSG_PROCESS_COMPLETE = "com.telink.sig.mesh.EVENT_TYPE_CMD_COMPLETE";
    public static final String EVENT_TYPE_MSG_PROCESS_ERROR = "com.telink.sig.mesh.EVENT_TYPE_CMD_ERROR";
    private String desc;
    private int dest;
    private int opcode;
    private Integer[] rspArr;
    private int rspCount;
    private int rspMax;
    private boolean success;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public ReliableMessageProcessEvent(Object obj, String str) {
        super(obj, str);
    }

    public ReliableMessageProcessEvent(Object obj, String str, boolean z, int i, int i2, int i3, String str2) {
        super(obj, str);
        this.success = z;
        this.opcode = i;
        this.rspMax = i2;
        this.rspCount = i3;
        this.desc = str2;
    }

    protected ReliableMessageProcessEvent(Parcel parcel) {
        this.success = parcel.readByte() != 0;
        this.opcode = parcel.readInt();
        this.rspMax = parcel.readInt();
        this.rspCount = parcel.readInt();
        this.rspArr = (Integer[]) parcel.readArray(Integer.class.getClassLoader());
        this.desc = parcel.readString();
    }

    public boolean isSuccess() {
        return this.success;
    }

    public void setSuccess(boolean z) {
        this.success = z;
    }

    public int getOpcode() {
        return this.opcode;
    }

    public void setOpcode(int i) {
        this.opcode = i;
    }

    public int getRspMax() {
        return this.rspMax;
    }

    public void setRspMax(int i) {
        this.rspMax = i;
    }

    public int getRspCount() {
        return this.rspCount;
    }

    public void setRspCount(int i) {
        this.rspCount = i;
    }

    public String getDesc() {
        return this.desc;
    }

    public void setDesc(String str) {
        this.desc = str;
    }

    public Integer[] getRspArr() {
        return this.rspArr;
    }

    public void setRspArr(Integer[] numArr) {
        this.rspArr = numArr;
    }

    public int getDest() {
        return this.dest;
    }

    public void setDest(int i) {
        this.dest = i;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.success ? (byte) 1 : (byte) 0);
        parcel.writeInt(this.opcode);
        parcel.writeInt(this.rspMax);
        parcel.writeInt(this.rspCount);
        parcel.writeArray(this.rspArr);
        parcel.writeString(this.desc);
    }
}
