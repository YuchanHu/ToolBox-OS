package com.telink.ble.mesh.core.message;

import android.util.SparseArray;
import com.telink.ble.mesh.core.message.aggregator.OpcodeAggregatorStatusMessage;
import com.telink.ble.mesh.core.message.config.AppKeyStatusMessage;
import com.telink.ble.mesh.core.message.config.BeaconStatusMessage;
import com.telink.ble.mesh.core.message.config.BridgingTableStatusMessage;
import com.telink.ble.mesh.core.message.config.CompositionDataStatusMessage;
import com.telink.ble.mesh.core.message.config.DefaultTTLStatusMessage;
import com.telink.ble.mesh.core.message.config.FriendStatusMessage;
import com.telink.ble.mesh.core.message.config.GattProxyStatusMessage;
import com.telink.ble.mesh.core.message.config.KeyRefreshPhaseStatusMessage;
import com.telink.ble.mesh.core.message.config.ModelAppStatusMessage;
import com.telink.ble.mesh.core.message.config.ModelPublicationStatusMessage;
import com.telink.ble.mesh.core.message.config.ModelSubscriptionStatusMessage;
import com.telink.ble.mesh.core.message.config.NetKeyStatusMessage;
import com.telink.ble.mesh.core.message.config.NetworkTransmitStatusMessage;
import com.telink.ble.mesh.core.message.config.NodeIdentityStatusMessage;
import com.telink.ble.mesh.core.message.config.NodeResetStatusMessage;
import com.telink.ble.mesh.core.message.config.RelayStatusMessage;
import com.telink.ble.mesh.core.message.config.SubnetBridgeStatusMessage;
import com.telink.ble.mesh.core.message.directforwarding.DirectedControlStatusMessage;
import com.telink.ble.mesh.core.message.directforwarding.ForwardingTableStatusMessage;
import com.telink.ble.mesh.core.message.fastpv.MeshAddressStatusMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDCapabilitiesStatusMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDFirmwareStatusMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDReceiversListMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDReceiversStatusMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDStatusMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDUploadStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.FirmwareMetadataStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.FirmwareUpdateInfoStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.FirmwareUpdateStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobBlockStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobInfoStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobPartialBlockReportMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobTransferStatusMessage;
import com.telink.ble.mesh.core.message.generic.LevelStatusMessage;
import com.telink.ble.mesh.core.message.generic.OnOffStatusMessage;
import com.telink.ble.mesh.core.message.largecps.LargeCompositionDataStatusMessage;
import com.telink.ble.mesh.core.message.lighting.CtlStatusMessage;
import com.telink.ble.mesh.core.message.lighting.CtlTemperatureStatusMessage;
import com.telink.ble.mesh.core.message.lighting.HslStatusMessage;
import com.telink.ble.mesh.core.message.lighting.HslTargetStatusMessage;
import com.telink.ble.mesh.core.message.lighting.LcLightOnOffStatusMessage;
import com.telink.ble.mesh.core.message.lighting.LcModeStatusMessage;
import com.telink.ble.mesh.core.message.lighting.LcOmStatusMessage;
import com.telink.ble.mesh.core.message.lighting.LcPropertyStatusMessage;
import com.telink.ble.mesh.core.message.lighting.LightnessStatusMessage;
import com.telink.ble.mesh.core.message.ondmdpxy.OnDemandPrivateProxyStatusMessage;
import com.telink.ble.mesh.core.message.privatebeacon.PrivateBeaconStatusMessage;
import com.telink.ble.mesh.core.message.privatebeacon.PrivateGattProxyStatusMessage;
import com.telink.ble.mesh.core.message.privatebeacon.PrivateNodeIdentityStatusMessage;
import com.telink.ble.mesh.core.message.rp.LinkStatusMessage;
import com.telink.ble.mesh.core.message.rp.ProvisioningPDUOutboundReportMessage;
import com.telink.ble.mesh.core.message.rp.ProvisioningPDUReportMessage;
import com.telink.ble.mesh.core.message.rp.ScanReportStatusMessage;
import com.telink.ble.mesh.core.message.rp.ScanStatusMessage;
import com.telink.ble.mesh.core.message.sarconfig.SarReceiverStatusMessage;
import com.telink.ble.mesh.core.message.sarconfig.SarTransmitStatusMessage;
import com.telink.ble.mesh.core.message.scene.SceneRegisterStatusMessage;
import com.telink.ble.mesh.core.message.scene.SceneStatusMessage;
import com.telink.ble.mesh.core.message.scheduler.SchedulerActionStatusMessage;
import com.telink.ble.mesh.core.message.scheduler.SchedulerStatusMessage;
import com.telink.ble.mesh.core.message.sensor.SensorCadenceStatusMessage;
import com.telink.ble.mesh.core.message.sensor.SensorDescriptorStatusMessage;
import com.telink.ble.mesh.core.message.sensor.SensorStatusMessage;
import com.telink.ble.mesh.core.message.solicitation.SolicitationItemsStatusMessage;
import com.telink.ble.mesh.core.message.time.TimeStatusMessage;

/* loaded from: classes.dex */
public class MeshStatus {
    private int opcode;
    private Class statusMessageCls;

    static /* synthetic */ int access$000(MeshStatus meshStatus) {
        return meshStatus.opcode;
    }

    static /* synthetic */ Class access$100(MeshStatus meshStatus) {
        return meshStatus.statusMessageCls;
    }

    public MeshStatus(int i, Class cls) {
        this.opcode = i;
        this.statusMessageCls = cls;
    }

    public Class getStatusMessageCls() {
        return this.statusMessageCls;
    }

    public void setStatusMessageCls(Class cls) {
        this.statusMessageCls = cls;
    }

    public int getOpcode() {
        return this.opcode;
    }

    public void setOpcode(int i) {
        this.opcode = i;
    }

    public static class Container {
        private static SparseArray<Class> statusMap = new SparseArray<>();

        static {
            register(Opcode.COMPOSITION_DATA_STATUS.value, CompositionDataStatusMessage.class);
            register(Opcode.MODE_APP_STATUS.value, ModelAppStatusMessage.class);
            register(Opcode.APPKEY_STATUS.value, AppKeyStatusMessage.class);
            register(Opcode.NODE_RESET_STATUS.value, NodeResetStatusMessage.class);
            register(Opcode.CFG_MODEL_SUB_STATUS.value, ModelSubscriptionStatusMessage.class);
            register(Opcode.CFG_MODEL_PUB_STATUS.value, ModelPublicationStatusMessage.class);
            register(Opcode.NODE_ID_STATUS.value, NodeIdentityStatusMessage.class);
            register(Opcode.NETKEY_STATUS.value, NetKeyStatusMessage.class);
            register(Opcode.SUBNET_BRIDGE_STATUS.value, SubnetBridgeStatusMessage.class);
            register(Opcode.BRIDGING_TABLE_STATUS.value, BridgingTableStatusMessage.class);
            register(Opcode.CFG_NW_TRANSMIT_STATUS.value, NetworkTransmitStatusMessage.class);
            register(Opcode.CFG_BEACON_STATUS.value, BeaconStatusMessage.class);
            register(Opcode.CFG_DEFAULT_TTL_STATUS.value, DefaultTTLStatusMessage.class);
            register(Opcode.CFG_RELAY_STATUS.value, RelayStatusMessage.class);
            register(Opcode.CFG_FRIEND_STATUS.value, FriendStatusMessage.class);
            register(Opcode.CFG_GATT_PROXY_STATUS.value, GattProxyStatusMessage.class);
            register(Opcode.CFG_KEY_REFRESH_PHASE_STATUS.value, KeyRefreshPhaseStatusMessage.class);
            register(Opcode.PRIVATE_BEACON_STATUS.value, PrivateBeaconStatusMessage.class);
            register(Opcode.PRIVATE_NODE_IDENTITY_STATUS.value, PrivateNodeIdentityStatusMessage.class);
            register(Opcode.PRIVATE_GATT_PROXY_STATUS.value, PrivateGattProxyStatusMessage.class);
            register(Opcode.G_ONOFF_STATUS.value, OnOffStatusMessage.class);
            register(Opcode.G_LEVEL_STATUS.value, LevelStatusMessage.class);
            register(Opcode.LIGHTNESS_STATUS.value, LightnessStatusMessage.class);
            register(Opcode.LIGHT_CTL_TEMP_STATUS.value, CtlTemperatureStatusMessage.class);
            register(Opcode.LIGHT_CTL_STATUS.value, CtlStatusMessage.class);
            register(Opcode.LIGHT_HSL_STATUS.value, HslStatusMessage.class);
            register(Opcode.LIGHT_HSL_TARGET_STATUS.value, HslTargetStatusMessage.class);
            register(Opcode.LIGHT_LC_MODE_STATUS.value, LcModeStatusMessage.class);
            register(Opcode.LIGHT_LC_OM_STATUS.value, LcOmStatusMessage.class);
            register(Opcode.LIGHT_LC_ONOFF_STATUS.value, LcLightOnOffStatusMessage.class);
            register(Opcode.LIGHT_LC_PROPERTY_STATUS.value, LcPropertyStatusMessage.class);
            register(Opcode.SENSOR_CANDECE_STATUS.value, SensorCadenceStatusMessage.class);
            register(Opcode.SENSOR_STATUS.value, SensorStatusMessage.class);
            register(Opcode.SENSOR_DESCRIP_STATUS.value, SensorDescriptorStatusMessage.class);
            register(Opcode.TIME_STATUS.value, TimeStatusMessage.class);
            register(Opcode.SCENE_STATUS.value, SceneStatusMessage.class);
            register(Opcode.SCENE_REG_STATUS.value, SceneRegisterStatusMessage.class);
            register(Opcode.SCHD_STATUS.value, SchedulerStatusMessage.class);
            register(Opcode.SCHD_ACTION_STATUS.value, SchedulerActionStatusMessage.class);
            register(Opcode.FIRMWARE_UPDATE_INFORMATION_STATUS.value, FirmwareUpdateInfoStatusMessage.class);
            register(Opcode.FIRMWARE_UPDATE_FIRMWARE_METADATA_STATUS.value, FirmwareMetadataStatusMessage.class);
            register(Opcode.FIRMWARE_UPDATE_STATUS.value, FirmwareUpdateStatusMessage.class);
            register(Opcode.FD_STATUS.value, FDStatusMessage.class);
            register(Opcode.FD_CAPABILITIES_STATUS.value, FDCapabilitiesStatusMessage.class);
            register(Opcode.FD_RECEIVERS_STATUS.value, FDReceiversStatusMessage.class);
            register(Opcode.FD_RECEIVERS_LIST.value, FDReceiversListMessage.class);
            register(Opcode.FD_UPLOAD_STATUS.value, FDUploadStatusMessage.class);
            register(Opcode.FD_FIRMWARE_STATUS.value, FDFirmwareStatusMessage.class);
            register(Opcode.BLOB_BLOCK_STATUS.value, BlobBlockStatusMessage.class);
            register(Opcode.BLOB_INFORMATION_STATUS.value, BlobInfoStatusMessage.class);
            register(Opcode.BLOB_TRANSFER_STATUS.value, BlobTransferStatusMessage.class);
            register(Opcode.BLOB_PARTIAL_BLOCK_REPORT.value, BlobPartialBlockReportMessage.class);
            register(Opcode.REMOTE_PROV_SCAN_STS.value, ScanStatusMessage.class);
            register(Opcode.REMOTE_PROV_SCAN_REPORT.value, ScanReportStatusMessage.class);
            register(Opcode.REMOTE_PROV_LINK_STS.value, LinkStatusMessage.class);
            register(Opcode.REMOTE_PROV_PDU_REPORT.value, ProvisioningPDUReportMessage.class);
            register(Opcode.REMOTE_PROV_PDU_OUTBOUND_REPORT.value, ProvisioningPDUOutboundReportMessage.class);
            register(Opcode.VD_MESH_ADDR_GET_STS.value, MeshAddressStatusMessage.class);
            register(Opcode.CFG_OP_AGG_STATUS.value, OpcodeAggregatorStatusMessage.class);
            register(Opcode.FORWARDING_TABLE_STATUS.value, ForwardingTableStatusMessage.class);
            register(Opcode.DIRECTED_CONTROL_STATUS.value, DirectedControlStatusMessage.class);
            register(Opcode.CFG_SAR_TRANSMITTER_STATUS.value, SarTransmitStatusMessage.class);
            register(Opcode.CFG_SAR_RECEIVER_STATUS.value, SarReceiverStatusMessage.class);
            register(Opcode.CFG_ON_DEMAND_PROXY_STATUS.value, OnDemandPrivateProxyStatusMessage.class);
            register(Opcode.LARGE_CPS_STATUS.value, LargeCompositionDataStatusMessage.class);
            register(Opcode.SOLI_PDU_RPL_ITEM_STATUS.value, SolicitationItemsStatusMessage.class);
        }

        public static void register(MeshStatus meshStatus) {
            statusMap.put(MeshStatus.access$000(meshStatus), MeshStatus.access$100(meshStatus));
        }

        public static void register(int i, Class cls) {
            statusMap.put(i, cls);
        }

        public static Class getMessageClass(int i) {
            return statusMap.get(i);
        }
    }
}
