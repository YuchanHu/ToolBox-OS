package com.telink.ble.mesh.core.networking;

import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.OpcodeType;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class AccessLayerPDU implements NetworkingPDU {
    public int opcode;
    public byte[] params;

    private AccessLayerPDU() {
    }

    public AccessLayerPDU(int i, byte[] bArr) {
        this.opcode = i;
        this.params = bArr;
    }

    public static AccessLayerPDU parse(byte[] bArr) {
        AccessLayerPDU accessLayerPDU = new AccessLayerPDU();
        OpcodeType byFirstByte = OpcodeType.getByFirstByte(bArr[0]);
        accessLayerPDU.opcode = 0;
        int i = 0;
        int i2 = 0;
        while (i < byFirstByte.length) {
            accessLayerPDU.opcode = ((bArr[i2] & FUDistributor.UPDATE_TTL) << (i * 8)) | accessLayerPDU.opcode;
            i++;
            i2++;
        }
        int length = bArr.length - byFirstByte.length;
        byte[] bArr2 = new byte[length];
        accessLayerPDU.params = bArr2;
        System.arraycopy(bArr, i2, bArr2, 0, length);
        return accessLayerPDU;
    }

    @Override // com.telink.ble.mesh.core.networking.NetworkingPDU
    public byte[] toByteArray() {
        int i = OpcodeType.getByFirstByte((byte) this.opcode).length;
        byte[] bArr = this.params;
        if (bArr == null || bArr.length == 0) {
            return MeshUtils.integer2Bytes(this.opcode, i, ByteOrder.LITTLE_ENDIAN);
        }
        return ByteBuffer.allocate(bArr.length + i).order(ByteOrder.LITTLE_ENDIAN).put(MeshUtils.integer2Bytes(this.opcode, i, ByteOrder.LITTLE_ENDIAN)).put(this.params).array();
    }
}
