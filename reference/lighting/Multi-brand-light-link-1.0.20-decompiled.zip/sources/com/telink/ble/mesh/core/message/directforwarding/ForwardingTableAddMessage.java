package com.telink.ble.mesh.core.message.directforwarding;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.config.ConfigMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ForwardingTableAddMessage extends ConfigMessage {
    public int Prohibited;
    public int backwardPathValidatedFlag;
    public int bearerTowardPathOrigin;
    public int bearerTowardPathTarget;
    public int multicastDestination;
    public int netKeyIndex;
    public byte[] pathOriginUnicastAddrRange;
    public byte[] pathTargetUnicastAddrRange;
    public int unicastDestinationFlag;

    public static ForwardingTableAddMessage getSimple(int i, int i2) {
        ForwardingTableAddMessage forwardingTableAddMessage = new ForwardingTableAddMessage(i);
        forwardingTableAddMessage.setResponseMax(1);
        forwardingTableAddMessage.netKeyIndex = i2;
        return forwardingTableAddMessage;
    }

    public ForwardingTableAddMessage(int i) {
        super(i);
        this.multicastDestination = 0;
        this.bearerTowardPathOrigin = 0;
        this.bearerTowardPathTarget = 0;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FORWARDING_TABLE_ADD.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FORWARDING_TABLE_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        boolean z = this.unicastDestinationFlag == 1;
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(this.pathOriginUnicastAddrRange.length + 6 + (z ? this.pathTargetUnicastAddrRange.length : 2)).order(ByteOrder.LITTLE_ENDIAN);
        byteBufferOrder.putShort((short) ((this.backwardPathValidatedFlag << 15) | (this.unicastDestinationFlag << 14) | this.netKeyIndex)).put(this.pathOriginUnicastAddrRange);
        if (z) {
            byteBufferOrder.put(this.pathTargetUnicastAddrRange);
        } else {
            byteBufferOrder.putShort((short) this.multicastDestination);
        }
        byteBufferOrder.putShort((short) this.bearerTowardPathOrigin).putShort((short) this.bearerTowardPathTarget);
        return byteBufferOrder.array();
    }
}
