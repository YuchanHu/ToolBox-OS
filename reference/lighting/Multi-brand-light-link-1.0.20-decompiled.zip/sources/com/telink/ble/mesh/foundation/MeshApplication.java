package com.telink.ble.mesh.foundation;

import android.app.Application;
import com.telink.ble.mesh.foundation.event.MeshEvent;
import com.telink.ble.mesh.foundation.event.NetworkInfoUpdateEvent;
import com.telink.ble.mesh.foundation.event.OnlineStatusEvent;
import com.telink.ble.mesh.foundation.event.ReliableMessageProcessEvent;
import com.telink.ble.mesh.foundation.event.StatusNotificationEvent;
import com.telink.ble.mesh.util.MeshLogger;

/* loaded from: classes.dex */
public abstract class MeshApplication extends Application implements EventHandler {
    private EventBus<String> mEventBus;

    protected abstract void onMeshEvent(MeshEvent meshEvent);

    protected abstract void onNetworkInfoUpdate(NetworkInfoUpdateEvent networkInfoUpdateEvent);

    protected abstract void onOnlineStatusEvent(OnlineStatusEvent onlineStatusEvent);

    protected abstract void onReliableMessageProcessEvent(ReliableMessageProcessEvent reliableMessageProcessEvent);

    protected abstract void onStatusNotificationEvent(StatusNotificationEvent statusNotificationEvent);

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        this.mEventBus = new EventBus<>();
    }

    @Override // com.telink.ble.mesh.foundation.EventHandler
    public void onEventHandle(Event<String> event) {
        MeshLogger.d("event handle: " + event.getType());
        if (event instanceof NetworkInfoUpdateEvent) {
            onNetworkInfoUpdate((NetworkInfoUpdateEvent) event);
        } else if (event instanceof StatusNotificationEvent) {
            onStatusNotificationEvent((StatusNotificationEvent) event);
        } else if (event instanceof OnlineStatusEvent) {
            onOnlineStatusEvent((OnlineStatusEvent) event);
        } else if (event instanceof MeshEvent) {
            onMeshEvent((MeshEvent) event);
        } else if (event instanceof ReliableMessageProcessEvent) {
            onReliableMessageProcessEvent((ReliableMessageProcessEvent) event);
        }
        dispatchEvent(event);
    }

    public void addEventListener(String str, EventListener<String> eventListener) {
        this.mEventBus.addEventListener(str, eventListener);
    }

    public void removeEventListener(EventListener<String> eventListener) {
        this.mEventBus.removeEventListener(eventListener);
    }

    public void removeEventListener(String str, EventListener<String> eventListener) {
        this.mEventBus.removeEventListener(str, eventListener);
    }

    public void removeEventListeners() {
        this.mEventBus.removeEventListeners();
    }

    public void dispatchEvent(Event<String> event) {
        this.mEventBus.dispatchEvent(event);
    }
}
