package com.telink.ble.mesh.util;

import android.util.Log;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class MeshLogger {
    public static final int DEFAULT_LEVEL = 1;
    public static final String DEFAULT_TAG = "SIG-Mesh";
    public static final int LEVEL_DEBUG = 1;
    public static final int LEVEL_ERROR = 4;
    public static final int LEVEL_INFO = 2;
    public static final int LEVEL_VERBOSE = 0;
    public static final int LEVEL_WARN = 3;
    public static List<LogInfo> logInfoList = new ArrayList();
    private static boolean print = true;
    private static boolean record = true;

    public static void enableRecord(boolean z) {
        record = z;
    }

    public static void enablePrint(boolean z) {
        print = z;
    }

    public static void log(String str) {
        log(str, DEFAULT_TAG);
    }

    public static void log(String str, String str2) {
        log(str, str2, 1);
    }

    public static void log(String str, int i) {
        log(str, DEFAULT_TAG, i);
    }

    public static void v(String str) {
        log(str, 0);
    }

    public static void d(String str) {
        log(str, 1);
    }

    public static void i(String str) {
        log(str, 2);
    }

    public static void w(String str) {
        log(str, 3);
    }

    public static void e(String str) {
        log(str, 4);
    }

    public static void log(String str, String str2, int i) {
        if (print) {
            if (i == 0) {
                Log.v(str2, str);
            } else if (i == 2) {
                Log.i(str2, str);
            } else if (i == 3) {
                Log.w(str2, str);
            } else if (i == 4) {
                Log.e(str2, str);
            } else {
                Log.d(str2, str);
            }
        }
        if (record) {
            logInfoList.add(new LogInfo(str2, str, i));
        }
    }
}
