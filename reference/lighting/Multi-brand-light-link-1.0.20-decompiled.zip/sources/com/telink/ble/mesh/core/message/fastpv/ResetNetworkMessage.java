package com.telink.ble.mesh.core.message.fastpv;

import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ResetNetworkMessage extends GenericMessage {
    private int delay;

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return -1;
    }

    public ResetNetworkMessage(int i, int i2) {
        super(i, i2);
    }

    public static ResetNetworkMessage getSimple(int i, int i2, int i3) {
        ResetNetworkMessage resetNetworkMessage = new ResetNetworkMessage(i, i2);
        resetNetworkMessage.delay = i3;
        return resetNetworkMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.VD_MESH_RESET_NETWORK.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return MeshUtils.integer2Bytes(this.delay, 2, ByteOrder.LITTLE_ENDIAN);
    }

    public void setDelay(int i) {
        this.delay = i;
    }
}
