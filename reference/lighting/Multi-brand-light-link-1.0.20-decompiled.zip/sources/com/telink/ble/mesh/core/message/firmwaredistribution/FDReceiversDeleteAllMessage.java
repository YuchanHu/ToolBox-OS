package com.telink.ble.mesh.core.message.firmwaredistribution;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;

/* loaded from: classes.dex */
public class FDReceiversDeleteAllMessage extends UpdatingMessage {
    public FDReceiversDeleteAllMessage(int i, int i2) {
        super(i, i2);
    }

    public static FDReceiversDeleteAllMessage getSimple(int i, int i2) {
        FDReceiversDeleteAllMessage fDReceiversDeleteAllMessage = new FDReceiversDeleteAllMessage(i, i2);
        fDReceiversDeleteAllMessage.setResponseMax(1);
        return fDReceiversDeleteAllMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FD_RECEIVERS_DELETE_ALL.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FD_RECEIVERS_STATUS.value;
    }
}
