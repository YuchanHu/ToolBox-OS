package com.telink.ble.mesh.core.message.aggregator;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.OpcodeType;
import com.telink.ble.mesh.util.Arrays;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class AggregatorItem implements Parcelable {
    public static final Parcelable.Creator<AggregatorItem> CREATOR = new Parcelable.Creator<AggregatorItem>() { // from class: com.telink.ble.mesh.core.message.aggregator.AggregatorItem.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ AggregatorItem createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ AggregatorItem[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public AggregatorItem createFromParcel(Parcel parcel) {
            return new AggregatorItem(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public AggregatorItem[] newArray(int i) {
            return new AggregatorItem[i];
        }
    };
    public static final int LENGTH_LONG = 1;
    public static final int LENGTH_SHORT = 0;
    public int opcode;
    public byte[] parameters;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public AggregatorItem() {
    }

    public AggregatorItem(int i, byte[] bArr) {
        this.opcode = i;
        this.parameters = bArr;
    }

    protected AggregatorItem(Parcel parcel) {
        this.opcode = parcel.readInt();
        this.parameters = parcel.createByteArray();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.opcode);
        parcel.writeByteArray(this.parameters);
    }

    public byte[] toBytes() {
        int i = OpcodeType.getByFirstByte((byte) this.opcode).length;
        byte[] bArr = this.parameters;
        int length = bArr == null ? i : bArr.length + i;
        boolean z = length > 127;
        ByteBuffer byteBufferOrder = ByteBuffer.allocate((z ? 2 : 1) + length).order(ByteOrder.LITTLE_ENDIAN);
        int i2 = length << 1;
        if (z) {
            byteBufferOrder.putShort((short) i2);
        } else {
            byteBufferOrder.put((byte) i2);
        }
        byteBufferOrder.put(MeshUtils.integer2Bytes(this.opcode, i, ByteOrder.LITTLE_ENDIAN));
        byte[] bArr2 = this.parameters;
        if (bArr2 != null) {
            byteBufferOrder.put(bArr2);
        }
        return byteBufferOrder.array();
    }

    public static AggregatorItem fromBytes(byte[] bArr) {
        OpcodeType byFirstByte = OpcodeType.getByFirstByte(bArr[0]);
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        while (i < byFirstByte.length) {
            i3 |= (bArr[i2] & FUDistributor.UPDATE_TTL) << (i * 8);
            i++;
            i2++;
        }
        int length = bArr.length - byFirstByte.length;
        byte[] bArr2 = new byte[length];
        System.arraycopy(bArr, i2, bArr2, 0, length);
        AggregatorItem aggregatorItem = new AggregatorItem();
        aggregatorItem.opcode = i3;
        aggregatorItem.parameters = bArr2;
        return aggregatorItem;
    }

    public String toString() {
        return "AggregatorItem{" + String.format("opcode=%04X", Integer.valueOf(this.opcode)) + ", parameters=" + Arrays.bytesToHexString(this.parameters) + '}';
    }
}
