package com.telink.ble.mesh.core.message;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public class NotificationMessage implements Parcelable {
    public static final Parcelable.Creator<NotificationMessage> CREATOR = new Parcelable.Creator<NotificationMessage>() { // from class: com.telink.ble.mesh.core.message.NotificationMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ NotificationMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ NotificationMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public NotificationMessage createFromParcel(Parcel parcel) {
            return new NotificationMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public NotificationMessage[] newArray(int i) {
            return new NotificationMessage[i];
        }
    };
    private int dst;
    private int opcode;
    private byte[] params;
    private int src;
    private StatusMessage statusMessage;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public NotificationMessage(int i, int i2, int i3, byte[] bArr) {
        this.src = i;
        this.dst = i2;
        this.opcode = i3;
        this.params = bArr;
        parseStatusMessage();
    }

    private void parseStatusMessage() {
        this.statusMessage = StatusMessage.createByAccessMessage(this.opcode, this.params);
    }

    protected NotificationMessage(Parcel parcel) {
        this.src = parcel.readInt();
        this.dst = parcel.readInt();
        this.opcode = parcel.readInt();
        this.params = parcel.createByteArray();
        this.statusMessage = (StatusMessage) parcel.readParcelable(StatusMessage.class.getClassLoader());
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.src);
        parcel.writeInt(this.dst);
        parcel.writeInt(this.opcode);
        parcel.writeByteArray(this.params);
        parcel.writeParcelable(this.statusMessage, i);
    }

    public int getSrc() {
        return this.src;
    }

    public void setSrc(int i) {
        this.src = i;
    }

    public int getDst() {
        return this.dst;
    }

    public void setDst(int i) {
        this.dst = i;
    }

    public int getOpcode() {
        return this.opcode;
    }

    public void setOpcode(int i) {
        this.opcode = i;
    }

    public byte[] getParams() {
        return this.params;
    }

    public void setParams(byte[] bArr) {
        this.params = bArr;
    }

    public StatusMessage getStatusMessage() {
        return this.statusMessage;
    }

    public void setStatusMessage(StatusMessage statusMessage) {
        this.statusMessage = statusMessage;
    }
}
