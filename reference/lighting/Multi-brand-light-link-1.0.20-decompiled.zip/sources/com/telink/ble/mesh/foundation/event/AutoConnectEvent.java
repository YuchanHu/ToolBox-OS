package com.telink.ble.mesh.foundation.event;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.foundation.Event;

/* loaded from: classes.dex */
public class AutoConnectEvent extends Event<String> {
    public static final Parcelable.Creator<AutoConnectEvent> CREATOR = new Parcelable.Creator<AutoConnectEvent>() { // from class: com.telink.ble.mesh.foundation.event.AutoConnectEvent.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ AutoConnectEvent createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ AutoConnectEvent[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public AutoConnectEvent createFromParcel(Parcel parcel) {
            return new AutoConnectEvent(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public AutoConnectEvent[] newArray(int i) {
            return new AutoConnectEvent[i];
        }
    };
    public static final String EVENT_TYPE_AUTO_CONNECT_FAIL = "com.telink.ble.mesh.EVENT_TYPE_AUTO_CONNECT_FAIL";
    public static final String EVENT_TYPE_AUTO_CONNECT_LOGIN = "com.telink.ble.mesh.EVENT_TYPE_AUTO_CONNECT_LOGIN";
    private int connectedAddress;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public AutoConnectEvent(Object obj, String str, int i) {
        super(obj, str);
        this.connectedAddress = i;
    }

    protected AutoConnectEvent(Parcel parcel) {
        this.connectedAddress = parcel.readInt();
    }

    public int getConnectedAddress() {
        return this.connectedAddress;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.connectedAddress);
    }
}
