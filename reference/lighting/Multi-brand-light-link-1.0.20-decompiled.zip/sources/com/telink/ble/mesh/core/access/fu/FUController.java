package com.telink.ble.mesh.core.access.fu;

import android.os.Handler;
import android.os.HandlerThread;
import com.telink.ble.mesh.core.access.AccessBridge;
import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.NotificationMessage;
import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDCancelMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDReceiversGetMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDReceiversListMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatePhase;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.TransferMode;
import com.telink.ble.mesh.entity.FirmwareUpdateConfiguration;
import com.telink.ble.mesh.entity.MeshUpdatingDevice;
import com.telink.ble.mesh.util.MeshLogger;
import java.util.Iterator;
import java.util.List;
import java.util.function.IntSupplier;

/* loaded from: classes.dex */
public class FUController implements FUActionHandler {
    private AccessBridge accessBridge;
    private int connectedAddress;
    private List<MeshUpdatingDevice> deviceList;
    private FUDistributor distributor;
    private RemoteDistributorAssist distributorAssist;
    private Handler handler;
    private FUInitiator initiator;
    private UpdatePolicy updatePolicy;
    private final String LOG_TAG = "FU-Controller";
    private FUState currentState = FUState.IDLE;
    private FirmwareUpdateConfiguration configuration = null;
    private int distributorAddress = 0;
    private int appKeyIndex = 0;
    private int firstIndexInList = 0;
    private boolean isDirectUpdating = false;
    private final Runnable progressCheckTask = new Runnable() { // from class: com.telink.ble.mesh.core.access.fu.FUController.1
        @Override // java.lang.Runnable
        public void run() {
            FUController.access$000(FUController.this);
        }
    };

    static /* synthetic */ void access$000(FUController fUController) {
        fUController.fetchProgressState();
    }

    public FUController(HandlerThread handlerThread, IntSupplier intSupplier) {
        this.initiator = null;
        this.distributor = null;
        this.distributorAssist = null;
        this.handler = new Handler(handlerThread.getLooper());
        this.initiator = new FUInitiator(handlerThread, this, intSupplier);
        this.distributor = new FUDistributor(handlerThread, this, intSupplier);
        this.distributorAssist = new RemoteDistributorAssist(handlerThread, this);
    }

    public void register(AccessBridge accessBridge) {
        this.accessBridge = accessBridge;
    }

    public void begin(FirmwareUpdateConfiguration firmwareUpdateConfiguration, int i) {
        this.configuration = firmwareUpdateConfiguration;
        this.updatePolicy = firmwareUpdateConfiguration.getUpdatePolicy();
        this.deviceList = firmwareUpdateConfiguration.getUpdatingDevices();
        this.distributorAddress = firmwareUpdateConfiguration.getDistributorAddress();
        this.appKeyIndex = firmwareUpdateConfiguration.getAppKeyIndex();
        this.connectedAddress = i;
        this.isDirectUpdating = isConnectedNodeUpdating(i);
        this.distributorAssist.resetConfig(firmwareUpdateConfiguration);
        List<MeshUpdatingDevice> list = this.deviceList;
        if (list == null || list.size() == 0) {
            onComplete(false, "device list empty");
            return;
        }
        log("FU begin - " + this.updatePolicy + "  isContinue ? " + firmwareUpdateConfiguration.isContinue() + " -- " + this.currentState + " -- " + firmwareUpdateConfiguration.toString());
        if (this.currentState == FUState.IDLE && !firmwareUpdateConfiguration.isContinue()) {
            startInitiate();
            return;
        }
        if (this.currentState == FUState.DISTRIBUTING_BY_PHONE) {
            log("begin -> distributing by phone");
            onFUStateUpdate(FUState.DISTRIBUTING_BY_PHONE, null);
            this.distributor.begin(firmwareUpdateConfiguration, i, true);
        } else if (this.currentState == FUState.UPDATE_RECHECKING) {
            log("begin -> rechecking firmware");
            this.distributorAssist.recheckFirmware(true);
        } else {
            onFUStateUpdate(FUState.DISTRIBUTING_BY_DEVICE, null);
            fetchProgressState();
        }
    }

    public void stop() {
        if (isInitiating()) {
            onComplete(false, "initiate stopped");
            return;
        }
        if (isDistributingByPhone()) {
            this.distributor.stop();
        } else if (isDistributingByDevice()) {
            cancelDistribution();
            onComplete(false, "device distribute stopped");
        }
    }

    public boolean isInitiating() {
        return this.currentState == FUState.INITIATING;
    }

    public boolean isDistributingByPhone() {
        return this.currentState == FUState.DISTRIBUTING_BY_PHONE;
    }

    public void hold() {
        log("hold dist " + this.distributor.isRunning());
        if (this.distributor.isRunning()) {
            this.distributor.holdTransfer();
        }
    }

    private void fetchProgressState() {
        onMessagePrepared(FDReceiversGetMessage.getSimple(this.distributorAddress, this.appKeyIndex, this.firstIndexInList, 1));
    }

    private void startProgressCheckTask() {
        log("start progress check task");
        this.handler.removeCallbacks(this.progressCheckTask);
        this.handler.postDelayed(this.progressCheckTask, 10000L);
    }

    private void onProgressState(NotificationMessage notificationMessage) {
        List<FDReceiversListMessage.DistributionReceiver> receiversList = ((FDReceiversListMessage) notificationMessage.getStatusMessage()).getReceiversList();
        if (receiversList != null && receiversList.size() != 0) {
            FDReceiversListMessage.DistributionReceiver distributionReceiver = receiversList.get(0);
            MeshLogger.d("first receiver : " + distributionReceiver.toString());
            int i = distributionReceiver.transferProgress * 2;
            onTransferProgress(i, BlobTransferType.MESH_DIST);
            if (i >= 100) {
                byte b = distributionReceiver.retrievedUpdatePhase;
                if (b == UpdatePhase.IDLE.code) {
                    onFUStateUpdate(FUState.UPDATE_RECHECKING, "device may reboot complete");
                    this.distributorAssist.recheckFirmware(true);
                    return;
                }
                if (b == UpdatePhase.TRANSFER_ERROR.code || b == UpdatePhase.APPLY_FAILED.code || b == UpdatePhase.TRANSFER_CANCELED.code) {
                    onDeviceUpdate(this.deviceList.get(this.firstIndexInList), "device ReceiversList phase error : phase-" + ((int) b));
                    int i2 = this.firstIndexInList + 1;
                    this.firstIndexInList = i2;
                    if (i2 >= this.deviceList.size()) {
                        onComplete(false, "all devices phase error");
                        return;
                    } else {
                        startProgressCheckTask();
                        return;
                    }
                }
                MeshLogger.d("onProgressState : " + this.currentState);
                if (this.updatePolicy == UpdatePolicy.VerifyOnly) {
                    if (b == UpdatePhase.VERIFICATION_FAILED.code || b == UpdatePhase.VERIFICATION_SUCCEEDED.code) {
                        onFUStateUpdate(FUState.UPDATE_APPLYING, null);
                        this.distributorAssist.applyDistribute();
                        return;
                    } else {
                        startProgressCheckTask();
                        return;
                    }
                }
                if (this.isDirectUpdating) {
                    onFUStateUpdate(FUState.UPDATE_RECHECKING, null);
                    log("waiting for disconnect -- 1");
                    return;
                } else if (b == UpdatePhase.APPLY_SUCCESS.code || b == UpdatePhase.APPLYING_UPDATE.code) {
                    onFUStateUpdate(FUState.DISTRIBUTE_CONFIRMING, null);
                    this.distributorAssist.confirmDistribute();
                    return;
                } else {
                    startProgressCheckTask();
                    return;
                }
            }
            if (distributionReceiver.retrievedUpdatePhase == UpdatePhase.TRANSFER_ACTIVE.code) {
                startProgressCheckTask();
                return;
            } else {
                onComplete(false, "phase error - progress not 100 ");
                return;
            }
        }
        onFUStateUpdate(FUState.UPDATE_RECHECKING, "no receivers found");
        this.distributorAssist.recheckFirmware(true);
    }

    private boolean isConnectedNodeUpdating(int i) {
        FirmwareUpdateConfiguration firmwareUpdateConfiguration = this.configuration;
        if (firmwareUpdateConfiguration != null && firmwareUpdateConfiguration.getUpdatingDevices() != null) {
            Iterator<MeshUpdatingDevice> it = this.configuration.getUpdatingDevices().iterator();
            while (it.hasNext()) {
                if (it.next().meshAddress == i) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean needAutoConnect() {
        return this.currentState.value >= FUState.DISTRIBUTING_BY_PHONE.value;
    }

    public boolean isRunning() {
        return this.currentState != FUState.IDLE;
    }

    public void clear() {
        this.currentState = FUState.IDLE;
        this.firstIndexInList = 0;
        log("clear FU --------");
        if (this.initiator.isRunning()) {
            this.initiator.clear();
        }
        if (this.distributor.isRunning()) {
            this.distributor.clear();
        }
        FirmwareUpdateConfiguration firmwareUpdateConfiguration = this.configuration;
        if (firmwareUpdateConfiguration != null) {
            firmwareUpdateConfiguration.setCallback(null);
            this.configuration = null;
        }
    }

    public void dispatchError(String str) {
        onComplete(false, str);
    }

    public void onUpdatingCommandComplete(boolean z, int i, int i2, int i3) {
        log(String.format("updating command complete: opcode-%04X success?-%b", Integer.valueOf(i), Boolean.valueOf(z)));
        if (z) {
            return;
        }
        if (i == Opcode.FD_RECEIVERS_LIST.value) {
            onComplete(false, "receiver list command send fail");
            return;
        }
        if (this.initiator.isRunning()) {
            this.initiator.onInitiateCommandFailed(i);
        } else if (this.distributor.isRunning()) {
            this.distributor.onDistributeCommandFailed(i);
        } else if (this.distributorAssist.isRunning()) {
            this.distributorAssist.onAssistCommandFailed(i);
        }
    }

    public void onSegmentComplete(boolean z) {
        if (this.initiator.isRunning()) {
            this.initiator.getTransfer().onTransferSegmentComplete(z);
        } else if (this.distributor.isRunning()) {
            this.distributor.getTransfer().onTransferSegmentComplete(z);
        }
    }

    public void onMessageNotification(NotificationMessage notificationMessage) {
        log(String.format("rcv notification : %04X", Integer.valueOf(notificationMessage.getOpcode())));
        if (notificationMessage.getOpcode() == Opcode.FD_RECEIVERS_LIST.value) {
            onProgressState(notificationMessage);
            return;
        }
        if (this.initiator.isRunning()) {
            log("retransmit to initiator");
            this.initiator.onMessageNotification(notificationMessage);
        } else if (this.distributor.isRunning()) {
            log("retransmit to distributor");
            this.distributor.onMessageNotification(notificationMessage);
        } else if (this.distributorAssist.isRunning()) {
            log("retransmit to assist");
            this.distributorAssist.onMessageNotification(notificationMessage);
        }
    }

    public void onMulticastMessageComplete(int i, List<Integer> list) {
        if (this.initiator.isRunning()) {
            log("multicast msg complete -> initiator");
            this.initiator.onMulticastMessageComplete(i, list);
        } else if (this.distributor.isRunning()) {
            log("multicast msg complete -> distributor");
            this.distributor.onMulticastMessageComplete(i, list);
        }
    }

    public boolean isDistributingByDevice() {
        return this.currentState == FUState.DISTRIBUTING_BY_DEVICE;
    }

    private void startInitiate() {
        this.initiator.clear();
        this.distributor.clear();
        onFUStateUpdate(FUState.INITIATING, null);
        this.initiator.begin(this.configuration, this.distributorAddress);
    }

    private void onFUStateUpdate(FUState fUState, String str) {
        log("state update : " + fUState.desc);
        this.currentState = fUState;
        FirmwareUpdateConfiguration firmwareUpdateConfiguration = this.configuration;
        if (firmwareUpdateConfiguration != null) {
            firmwareUpdateConfiguration.dispatchFUState(fUState, str);
        }
        AccessBridge accessBridge = this.accessBridge;
        if (accessBridge != null) {
            accessBridge.onAccessStateChanged(fUState.value, fUState.desc, 2, null);
        }
    }

    private void onComplete(boolean z, String str) {
        log("firmware update complete - " + str + " -- " + z);
        cancelDistribution();
        this.handler.removeCallbacksAndMessages(null);
        onFUStateUpdate(z ? FUState.UPDATE_COMPLETE : FUState.UPDATE_FAIL, str);
        clear();
    }

    @Override // com.telink.ble.mesh.core.access.fu.FUActionHandler
    public void onDeviceUpdate(MeshUpdatingDevice meshUpdatingDevice, String str) {
        log("device state update : " + str);
        FirmwareUpdateConfiguration firmwareUpdateConfiguration = this.configuration;
        if (firmwareUpdateConfiguration != null) {
            firmwareUpdateConfiguration.dispatchDeviceState(meshUpdatingDevice, str);
        }
    }

    /* renamed from: com.telink.ble.mesh.core.access.fu.FUController$2, reason: invalid class name */
    static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] $SwitchMap$com$telink$ble$mesh$core$access$fu$FUAction;

        static {
            int[] iArr = new int[FUAction.values().length];
            $SwitchMap$com$telink$ble$mesh$core$access$fu$FUAction = iArr;
            try {
                iArr[FUAction.INITIATE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$access$fu$FUAction[FUAction.DISTRIBUTE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$access$fu$FUAction[FUAction.DISTRIBUTE_ASSIST.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    @Override // com.telink.ble.mesh.core.access.fu.FUActionHandler
    public void onActionComplete(boolean z, FUAction fUAction, String str) {
        log("action complete - " + str + " success ? " + z + " -- " + fUAction);
        int i = AnonymousClass2.$SwitchMap$com$telink$ble$mesh$core$access$fu$FUAction[fUAction.ordinal()];
        if (i == 1) {
            if (!z) {
                onFUStateUpdate(FUState.INITIATE_FAIL, null);
                onComplete(false, str);
                return;
            }
            onFUStateUpdate(FUState.INITIATE_SUCCESS, null);
            if (this.distributorAddress == 0) {
                log("start distribution by phone");
                onFUStateUpdate(FUState.DISTRIBUTING_BY_PHONE, null);
                this.distributor.begin(this.configuration, this.connectedAddress, false);
                return;
            } else {
                log("start distribution by remote device -- > end");
                onFUStateUpdate(FUState.DISTRIBUTING_BY_DEVICE, null);
                startProgressCheckTask();
                return;
            }
        }
        if (i == 2) {
            if (z) {
                onFUStateUpdate(FUState.UPDATE_RECHECKING, null);
                if (!this.isDirectUpdating) {
                    this.distributorAssist.recheckFirmware(false);
                    return;
                } else {
                    log("direct device will lose disconnection - 0");
                    return;
                }
            }
            onComplete(false, str);
            return;
        }
        if (i != 3) {
            return;
        }
        if (!z) {
            onComplete(false, str);
            return;
        }
        if (this.currentState == FUState.UPDATE_APPLYING) {
            if (!this.isDirectUpdating) {
                onFUStateUpdate(FUState.DISTRIBUTE_CONFIRMING, null);
                this.distributorAssist.confirmDistribute();
                return;
            } else {
                log("direct device will lose disconnection - 1");
                onFUStateUpdate(FUState.UPDATE_RECHECKING, null);
                return;
            }
        }
        if (this.currentState == FUState.DISTRIBUTE_CONFIRMING) {
            onFUStateUpdate(FUState.UPDATE_RECHECKING, null);
            this.distributorAssist.recheckFirmware(false);
        } else if (this.currentState == FUState.UPDATE_RECHECKING) {
            onComplete(true, str);
        }
    }

    private void cancelDistribution() {
        FDCancelMessage simple = FDCancelMessage.getSimple(this.distributorAddress, this.appKeyIndex);
        simple.setAck(false);
        onMessagePrepared(simple);
    }

    @Override // com.telink.ble.mesh.core.access.fu.FUActionHandler
    public boolean onMessagePrepared(MeshMessage meshMessage) {
        meshMessage.setRetryInterval(5000L);
        return this.accessBridge.onAccessMessagePrepared(meshMessage, 2);
    }

    @Override // com.telink.ble.mesh.core.access.fu.FUActionHandler
    public void onTransferStart(TransferMode transferMode) {
        FirmwareUpdateConfiguration firmwareUpdateConfiguration = this.configuration;
        if (firmwareUpdateConfiguration != null) {
            firmwareUpdateConfiguration.dispatchFUState(FUState.TRANSFER_START, transferMode.desc);
        }
    }

    @Override // com.telink.ble.mesh.core.access.fu.FUActionHandler
    public void onTransferProgress(int i, BlobTransferType blobTransferType) {
        FirmwareUpdateConfiguration firmwareUpdateConfiguration = this.configuration;
        if (firmwareUpdateConfiguration != null) {
            firmwareUpdateConfiguration.dispatchTransferProgress(i, blobTransferType);
        }
    }

    @Override // com.telink.ble.mesh.core.access.fu.FUActionHandler
    public void onActionLog(String str, String str2, int i) {
        MeshLogger.log(str2, "FU-Controller", i);
        FirmwareUpdateConfiguration firmwareUpdateConfiguration = this.configuration;
        if (firmwareUpdateConfiguration != null) {
            firmwareUpdateConfiguration.dispatchLogInfo(str, str2, i);
        }
    }

    private void log(String str) {
        onActionLog("FU-Controller", str, 1);
    }
}
