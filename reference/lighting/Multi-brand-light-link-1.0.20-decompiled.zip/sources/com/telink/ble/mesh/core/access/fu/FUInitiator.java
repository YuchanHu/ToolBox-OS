package com.telink.ble.mesh.core.access.fu;

import android.os.HandlerThread;
import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.MeshSigModel;
import com.telink.ble.mesh.core.message.NotificationMessage;
import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.config.ConfigStatus;
import com.telink.ble.mesh.core.message.config.ModelSubscriptionSetMessage;
import com.telink.ble.mesh.core.message.config.ModelSubscriptionStatusMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDCapabilitiesGetMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDCapabilitiesStatusMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDReceiversAddMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDReceiversStatusMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDStartMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDStatusMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDUploadStartMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.FDUploadStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.AdditionalInformation;
import com.telink.ble.mesh.core.message.firmwareupdate.DistributionStatus;
import com.telink.ble.mesh.core.message.firmwareupdate.FirmwareMetadataCheckMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.FirmwareMetadataStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.FirmwareUpdateInfoGetMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.FirmwareUpdateInfoStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdateStatus;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.TransferMode;
import com.telink.ble.mesh.entity.FirmwareUpdateConfiguration;
import com.telink.ble.mesh.entity.MeshUpdatingDevice;
import com.telink.ble.mesh.foundation.MulticastMessageBroker;
import com.telink.ble.mesh.util.MeshLogger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.IntSupplier;

/* loaded from: classes.dex */
class FUInitiator implements BlobTransferCallback {
    private static final int STEP_BLOB_TRANSFER = 7;
    private static final int STEP_DST_CAP_GET = 1;
    private static final int STEP_DST_RECEIVERS_ADD = 5;
    public static final int STEP_DST_START = 8;
    private static final int STEP_DST_UPLOAD_START = 6;
    private static final int STEP_IDLE = 0;
    private static final int STEP_SUB_SET = 3;
    private static final int STEP_UPDATE_INFO_GET = 4;
    private static final int STEP_UPDATE_METADATA_CHECK = 2;
    private FUActionHandler actionHandler;
    private long blobId;
    private int deviceIndex;
    private int distributorAddress;
    private byte[] firmwareId;
    private int firmwareSize;
    private int groupAddress;
    private BlobTransfer transfer;
    private BlobTransferType type;
    private List<MeshUpdatingDevice> updatingDevices;
    private final String LOG_TAG = "FU-Initiator";
    private int step = 0;
    private int appKeyIndex = 0;
    private int metadataIndex = 0;
    private byte[] metadata = new byte[8];
    private UpdatePolicy updatePolicy = UpdatePolicy.VerifyOnly;
    private boolean isUpdatingLpn = false;

    FUInitiator(HandlerThread handlerThread, FUActionHandler fUActionHandler, IntSupplier intSupplier) {
        this.transfer = new BlobTransfer(handlerThread, this, intSupplier);
        this.actionHandler = fUActionHandler;
    }

    void begin(FirmwareUpdateConfiguration firmwareUpdateConfiguration, int i) {
        this.updatingDevices = firmwareUpdateConfiguration.getUpdatingDevices();
        this.metadata = firmwareUpdateConfiguration.getMetadata();
        this.groupAddress = firmwareUpdateConfiguration.getGroupAddress();
        this.appKeyIndex = firmwareUpdateConfiguration.getAppKeyIndex();
        if (this.updatingDevices.size() != 0) {
            this.isUpdatingLpn = this.updatingDevices.get(0).isLpn;
        }
        this.blobId = firmwareUpdateConfiguration.getBlobId();
        if (!firmwareUpdateConfiguration.isContinue()) {
            this.firmwareSize = firmwareUpdateConfiguration.getFirmwareData().length;
        }
        this.firmwareId = firmwareUpdateConfiguration.getFirmwareId();
        this.updatePolicy = firmwareUpdateConfiguration.getUpdatePolicy();
        this.distributorAddress = i;
        BlobTransferType blobTransferType = i == 0 ? BlobTransferType.LOCAL_INIT : BlobTransferType.GATT_INIT;
        this.type = blobTransferType;
        this.transfer.resetParams(firmwareUpdateConfiguration, blobTransferType, i);
        log("initiator begin : node size - " + this.updatingDevices.size() + " -- distAdr - " + i);
        this.step = 1;
        nextAction();
    }

    void clear() {
        this.transfer.clear();
        this.step = 0;
    }

    boolean isRunning() {
        return this.step != 0;
    }

    private void onInitComplete(boolean z, String str) {
        if (z) {
            onTransferProgressUpdate(100, this.type);
        }
        this.step = 0;
        this.actionHandler.onActionComplete(z, FUAction.INITIATE, str);
    }

    public BlobTransfer getTransfer() {
        return this.transfer;
    }

    private void nextAction() {
        int i = this.step;
        if (i == 2 || i == 3 || (i == 4 && this.isUpdatingLpn)) {
            if (this.deviceIndex >= this.updatingDevices.size()) {
                log("current step complete: " + this.step);
                removeFailedDevices();
                if (this.updatingDevices.size() != 0) {
                    this.deviceIndex = 0;
                    log("next step: " + (this.step + 1));
                    this.step = this.step + 1;
                    nextAction();
                    return;
                }
                onInitComplete(false, "all device failed when initiate");
                return;
            }
            int i2 = this.updatingDevices.get(this.deviceIndex).meshAddress;
            log(String.format("action executing: " + this.step + " -- %04X", Integer.valueOf(i2)));
            int i3 = this.step;
            if (i3 == 2) {
                log(String.format("node -> metadata check %04X", Integer.valueOf(i2)), 3);
                onMeshMessagePrepared(FirmwareMetadataCheckMessage.getSimple(i2, this.appKeyIndex, this.metadataIndex, this.metadata));
                return;
            }
            if (i3 == 3) {
                log(String.format("node -> sub set %04X", Integer.valueOf(i2)), 3);
                onMeshMessagePrepared(ModelSubscriptionSetMessage.getSimple(i2, 0, this.updatingDevices.get(this.deviceIndex).updatingEleAddress, this.groupAddress, MeshSigModel.SIG_MD_OBJ_TRANSFER_S.modelId, true));
                return;
            }
            if (i3 == 4) {
                log(String.format("node -> update info get %04X", Integer.valueOf(i2)), 3);
                MeshMessage simple = FirmwareUpdateInfoGetMessage.getSimple(i2, this.appKeyIndex);
                ArrayList arrayList = new ArrayList();
                Iterator<MeshUpdatingDevice> it = this.updatingDevices.iterator();
                while (it.hasNext()) {
                    arrayList.add(Integer.valueOf(it.next().meshAddress));
                }
                simple.setResponseMax(arrayList.size());
                simple.setBrokerConfig(new MulticastMessageBroker.Config(arrayList));
                onMeshMessagePrepared(simple);
                return;
            }
            return;
        }
        switch (i) {
            case 1:
                log("distributor -> get capability", 3);
                onMeshMessagePrepared(FDCapabilitiesGetMessage.getSimple(this.distributorAddress, this.appKeyIndex));
                break;
            case 2:
            case 3:
                if (this.deviceIndex >= this.updatingDevices.size()) {
                    log("current step complete: " + this.step);
                    removeFailedDevices();
                    if (this.updatingDevices.size() != 0) {
                        this.deviceIndex = 0;
                        log("next step: " + (this.step + 1));
                        this.step = this.step + 1;
                        nextAction();
                        break;
                    } else {
                        onInitComplete(false, "all device failed when initiate");
                        break;
                    }
                } else {
                    int i4 = this.updatingDevices.get(this.deviceIndex).meshAddress;
                    log(String.format("action executing: " + this.step + " -- %04X", Integer.valueOf(i4)));
                    int i5 = this.step;
                    if (i5 != 2) {
                        if (i5 == 3) {
                            log(String.format("node -> sub set %04X", Integer.valueOf(i4)), 3);
                            onMeshMessagePrepared(ModelSubscriptionSetMessage.getSimple(i4, 0, this.updatingDevices.get(this.deviceIndex).updatingEleAddress, this.groupAddress, MeshSigModel.SIG_MD_OBJ_TRANSFER_S.modelId, true));
                            break;
                        }
                    } else {
                        log(String.format("node -> metadata check %04X", Integer.valueOf(i4)), 3);
                        onMeshMessagePrepared(FirmwareMetadataCheckMessage.getSimple(i4, this.appKeyIndex, this.metadataIndex, this.metadata));
                        break;
                    }
                }
                break;
            case 4:
                log(String.format("group -> update info get %04X", Integer.valueOf(this.groupAddress)), 3);
                MeshMessage simple2 = FirmwareUpdateInfoGetMessage.getSimple(this.groupAddress, this.appKeyIndex);
                ArrayList arrayList2 = new ArrayList();
                Iterator<MeshUpdatingDevice> it2 = this.updatingDevices.iterator();
                while (it2.hasNext()) {
                    arrayList2.add(Integer.valueOf(it2.next().meshAddress));
                }
                simple2.setResponseMax(arrayList2.size());
                simple2.setBrokerConfig(new MulticastMessageBroker.Config(arrayList2));
                onMeshMessagePrepared(simple2);
                break;
            case 5:
                log("distributor -> add receivers", 3);
                ArrayList arrayList3 = new ArrayList();
                Iterator<MeshUpdatingDevice> it3 = this.updatingDevices.iterator();
                while (it3.hasNext()) {
                    arrayList3.add(new FDReceiversAddMessage.ReceiverEntry(it3.next().meshAddress, 0));
                }
                onMeshMessagePrepared(FDReceiversAddMessage.getSimple(this.distributorAddress, this.appKeyIndex, arrayList3));
                break;
            case 6:
                log("distributor -> upload start", 3);
                FDUploadStartMessage simple3 = FDUploadStartMessage.getSimple(this.distributorAddress, this.appKeyIndex);
                simple3.uploadTTL = 255;
                simple3.uploadTimeoutBase = 0;
                simple3.uploadBLOBID = this.blobId;
                simple3.uploadFirmwareSize = this.firmwareSize;
                simple3.uploadFirmwareMetadataLength = this.metadata.length;
                simple3.uploadFirmwareMetadata = this.metadata;
                simple3.uploadFirmwareID = this.firmwareId;
                onMeshMessagePrepared(simple3);
                break;
            case 7:
                log("start blob transfer from initiator to distributor", 3);
                this.transfer.begin(false);
                break;
            case 8:
                log("distributor -> distribute start", 3);
                FDStartMessage simple4 = FDStartMessage.getSimple(this.distributorAddress, this.appKeyIndex);
                simple4.distributionAppKeyIndex = this.appKeyIndex;
                simple4.distributionTTL = 255;
                simple4.distributionTimeoutBase = 0;
                simple4.distributionTransferMode = TransferMode.PUSH.value;
                simple4.updatePolicy = this.updatePolicy.value;
                simple4.distributionImageIndex = 0;
                if (this.updatingDevices.size() == 1 && this.updatingDevices.get(0).isLpn) {
                    simple4.distributionMulticastAddress = 0;
                } else {
                    simple4.distributionMulticastAddress = this.groupAddress;
                }
                log(String.format("distribute start address: %04X", Integer.valueOf(simple4.distributionMulticastAddress)));
                onMeshMessagePrepared(simple4);
                break;
        }
    }

    public void onMessageNotification(NotificationMessage notificationMessage) {
        Opcode opcodeValueOf = Opcode.valueOf(notificationMessage.getOpcode());
        log("message notification: " + opcodeValueOf);
        int i = this.step;
        if (i == 0) {
            log("notification when idle");
        }
        if (i == 7) {
            log("notification trans to blob-transfer ");
            this.transfer.onTransferNotification(notificationMessage);
            return;
        }
        if (opcodeValueOf == null) {
            return;
        }
        int src = notificationMessage.getSrc();
        int i2 = this.step;
        if (i2 == 4 || i2 == 2 || i2 == 3) {
            int size = this.updatingDevices.size();
            int i3 = this.deviceIndex;
            if (size <= i3) {
                log("node index overflow");
                return;
            } else if (this.updatingDevices.get(i3).meshAddress != src) {
                log("initiator unexpected notification src");
                return;
            }
        }
        switch (AnonymousClass1.$SwitchMap$com$telink$ble$mesh$core$message$Opcode[opcodeValueOf.ordinal()]) {
            case 1:
                onCapStatus((FDCapabilitiesStatusMessage) notificationMessage.getStatusMessage());
                break;
            case 2:
                onFirmwareInfoStatus((FirmwareUpdateInfoStatusMessage) notificationMessage.getStatusMessage());
                break;
            case 3:
                onMetadataStatus((FirmwareMetadataStatusMessage) notificationMessage.getStatusMessage());
                break;
            case 4:
                onSubscriptionStatus((ModelSubscriptionStatusMessage) notificationMessage.getStatusMessage());
                break;
            case 5:
                onRevStatus((FDReceiversStatusMessage) notificationMessage.getStatusMessage());
                break;
            case 6:
                onUploadStatus((FDUploadStatusMessage) notificationMessage.getStatusMessage());
                break;
            case 7:
                onFDStatus((FDStatusMessage) notificationMessage.getStatusMessage());
                break;
        }
    }

    /* renamed from: com.telink.ble.mesh.core.access.fu.FUInitiator$1, reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$com$telink$ble$mesh$core$message$Opcode;

        static {
            int[] iArr = new int[Opcode.values().length];
            $SwitchMap$com$telink$ble$mesh$core$message$Opcode = iArr;
            try {
                iArr[Opcode.FD_CAPABILITIES_STATUS.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$message$Opcode[Opcode.FIRMWARE_UPDATE_INFORMATION_STATUS.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$message$Opcode[Opcode.FIRMWARE_UPDATE_FIRMWARE_METADATA_STATUS.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$message$Opcode[Opcode.CFG_MODEL_SUB_STATUS.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$message$Opcode[Opcode.FD_RECEIVERS_STATUS.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$message$Opcode[Opcode.FD_UPLOAD_STATUS.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$message$Opcode[Opcode.FD_STATUS.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    public void onInitiateCommandFailed(int i) {
        if ((this.step == 1 && i == Opcode.FD_CAPABILITIES_GET.value) || ((this.step == 5 && i == Opcode.FD_RECEIVERS_ADD.value) || ((this.step == 6 && i == Opcode.FD_UPLOAD_STATUS.value) || (this.step == 8 && i == Opcode.FD_START.value)))) {
            onInitComplete(false, "distribution command fail");
            return;
        }
        if ((this.step == 4 && i == Opcode.FIRMWARE_UPDATE_INFORMATION_GET.value) || ((this.step == 2 && i == Opcode.FIRMWARE_UPDATE_FIRMWARE_METADATA_STATUS.value) || (this.step == 3 && i == Opcode.CFG_MODEL_SUB_STATUS.value))) {
            onDeviceFail(this.updatingDevices.get(this.deviceIndex), "updating node init command fail");
            this.deviceIndex++;
            nextAction();
        } else if (this.step == 7) {
            this.transfer.onTransferCommandFail(i);
        }
    }

    private void onFDStatus(FDStatusMessage fDStatusMessage) {
        if (this.step != 8) {
            log("not at STEP_UPDATE_START");
            return;
        }
        if (fDStatusMessage.status == DistributionStatus.SUCCESS.code) {
            onInitComplete(true, "initiate distributor success");
            return;
        }
        onInitComplete(false, "initiate distributor fail: distribution status - " + DistributionStatus.valueOf(fDStatusMessage.status).desc);
    }

    private void onCapStatus(FDCapabilitiesStatusMessage fDCapabilitiesStatusMessage) {
        int i = this.step;
        if (i != 1) {
            log("not at STEP_DST_CAP_GET");
        } else {
            this.step = i + 1;
            nextAction();
        }
    }

    private void onFirmwareInfoStatus(FirmwareUpdateInfoStatusMessage firmwareUpdateInfoStatusMessage) {
        log("firmware info status: " + firmwareUpdateInfoStatusMessage.toString());
        if (this.step != 4) {
            log("not at STEP_GET_FIRMWARE_INFO");
            return;
        }
        firmwareUpdateInfoStatusMessage.getFirstIndex();
        firmwareUpdateInfoStatusMessage.getListCount();
        firmwareUpdateInfoStatusMessage.getFirmwareInformationList();
        if (this.isUpdatingLpn) {
            this.deviceIndex++;
            nextAction();
        }
    }

    public void onMulticastMessageComplete(int i, List<Integer> list) {
        if (this.step != 4 || this.isUpdatingLpn) {
            log("multi complete -> not at STEP_GET_FIRMWARE_INFO or not updating lpn , state : " + this.step + " isUpdatingLpn : " + this.isUpdatingLpn);
            return;
        }
        if (list.size() == 0) {
            log("all nodes have responded the update info status");
        } else {
            Iterator<MeshUpdatingDevice> it = this.updatingDevices.iterator();
            while (it.hasNext()) {
                MeshUpdatingDevice next = it.next();
                if (list.contains(Integer.valueOf(next.meshAddress))) {
                    next.state = 2;
                    FUActionHandler fUActionHandler = this.actionHandler;
                    if (fUActionHandler != null) {
                        fUActionHandler.onDeviceUpdate(next, "update info status no reply from the device");
                    }
                    it.remove();
                }
            }
        }
        this.step++;
        nextAction();
    }

    private void onMetadataStatus(FirmwareMetadataStatusMessage firmwareMetadataStatusMessage) {
        UpdateStatus updateStatusValueOf = UpdateStatus.valueOf(firmwareMetadataStatusMessage.getStatus());
        if (this.step != 2) {
            log("not at STEP_UPDATE_METADATA_CHECK");
            return;
        }
        if (updateStatusValueOf != UpdateStatus.SUCCESS) {
            onDeviceFail(this.updatingDevices.get(this.deviceIndex), "metadata check error: " + updateStatusValueOf.desc);
        } else {
            MeshUpdatingDevice meshUpdatingDevice = this.updatingDevices.get(this.deviceIndex);
            meshUpdatingDevice.additionalInformation = AdditionalInformation.valueOf(firmwareMetadataStatusMessage.getAdditionalInformation());
            meshUpdatingDevice.state = 3;
            FUActionHandler fUActionHandler = this.actionHandler;
            if (fUActionHandler != null) {
                fUActionHandler.onDeviceUpdate(meshUpdatingDevice, "device metadata check complete");
            }
        }
        this.deviceIndex++;
        nextAction();
    }

    private void onSubscriptionStatus(ModelSubscriptionStatusMessage modelSubscriptionStatusMessage) {
        log("subscription status: " + modelSubscriptionStatusMessage.toString());
        if (this.step != 3) {
            log("not at STEP_SUB_SET");
            return;
        }
        if (modelSubscriptionStatusMessage.getStatus() != ConfigStatus.SUCCESS.code) {
            onDeviceFail(this.updatingDevices.get(this.deviceIndex), "grouping status err " + ((int) modelSubscriptionStatusMessage.getStatus()));
        }
        this.deviceIndex++;
        nextAction();
    }

    private void onRevStatus(FDReceiversStatusMessage fDReceiversStatusMessage) {
        int i = this.step;
        if (i != 5) {
            log("not at STEP_DST_RECEIVERS_ADD");
        } else {
            this.step = i + 1;
            nextAction();
        }
    }

    private void onUploadStatus(FDUploadStatusMessage fDUploadStatusMessage) {
        log("upload status: " + fDUploadStatusMessage.toString());
        int i = this.step;
        if (i != 6) {
            log("not at STEP_DST_UPLOAD_START");
        } else {
            this.step = i + 1;
            nextAction();
        }
    }

    @Override // com.telink.ble.mesh.core.access.fu.BlobTransferCallback
    public void onTransferProgressUpdate(int i, BlobTransferType blobTransferType) {
        this.actionHandler.onTransferProgress(i, blobTransferType);
    }

    @Override // com.telink.ble.mesh.core.access.fu.BlobTransferCallback
    public void onTransferStart(TransferMode transferMode) {
        this.actionHandler.onTransferStart(transferMode);
    }

    @Override // com.telink.ble.mesh.core.access.fu.BlobTransferCallback
    public void onTransferComplete(boolean z, String str) {
        log("initiator transfer complete: success?" + z);
        this.step = this.step + 1;
        nextAction();
    }

    @Override // com.telink.ble.mesh.core.access.fu.BlobTransferCallback
    public void onTransferringDeviceFail(int i, String str) {
        log(String.format("node updating fail: %04X -- " + str, Integer.valueOf(i)));
        MeshUpdatingDevice deviceByAddress = getDeviceByAddress(i);
        if (deviceByAddress != null) {
            onDeviceFail(deviceByAddress, String.format("node updating fail: %04X -- ", Integer.valueOf(deviceByAddress.meshAddress)));
        }
    }

    @Override // com.telink.ble.mesh.core.access.fu.BlobTransferCallback
    public boolean onMeshMessagePrepared(MeshMessage meshMessage) {
        MeshLogger.d("initiator send message to : " + meshMessage.getDestinationAddress());
        return this.actionHandler.onMessagePrepared(meshMessage);
    }

    @Override // com.telink.ble.mesh.core.access.fu.BlobTransferCallback
    public void onTransferLog(String str, String str2, int i) {
        this.actionHandler.onActionLog(str, str2, i);
    }

    private void onDeviceFail(MeshUpdatingDevice meshUpdatingDevice, String str) {
        meshUpdatingDevice.state = 2;
        FUActionHandler fUActionHandler = this.actionHandler;
        if (fUActionHandler != null) {
            fUActionHandler.onDeviceUpdate(meshUpdatingDevice, str);
        }
    }

    private void removeFailedDevices() {
        Iterator<MeshUpdatingDevice> it = this.updatingDevices.iterator();
        while (it.hasNext()) {
            if (it.next().state == 2) {
                it.remove();
            }
        }
    }

    private MeshUpdatingDevice getDeviceByAddress(int i) {
        for (MeshUpdatingDevice meshUpdatingDevice : this.updatingDevices) {
            if (meshUpdatingDevice.meshAddress == i) {
                return meshUpdatingDevice;
            }
        }
        return null;
    }

    private void log(String str) {
        log(str, 1);
    }

    private void log(String str, int i) {
        this.actionHandler.onActionLog("FU-Initiator", str, i);
    }
}
