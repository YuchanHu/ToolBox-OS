package com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class BlobBlockStartMessage extends UpdatingMessage {
    private int blockNumber;
    private int chunkSize;

    public BlobBlockStartMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.BLOB_BLOCK_START.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.BLOB_BLOCK_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.blockNumber).putShort((short) this.chunkSize).array();
    }

    public void setBlockNumber(int i) {
        this.blockNumber = i;
    }

    public void setChunkSize(int i) {
        this.chunkSize = i;
    }

    public static BlobBlockStartMessage getSimple(int i, int i2, int i3, int i4) {
        BlobBlockStartMessage blobBlockStartMessage = new BlobBlockStartMessage(i, i2);
        blobBlockStartMessage.setResponseMax(1);
        blobBlockStartMessage.blockNumber = i3;
        blobBlockStartMessage.chunkSize = i4;
        return blobBlockStartMessage;
    }
}
