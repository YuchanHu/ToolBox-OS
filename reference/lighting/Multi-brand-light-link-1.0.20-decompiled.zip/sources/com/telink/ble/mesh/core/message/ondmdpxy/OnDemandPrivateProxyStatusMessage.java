package com.telink.ble.mesh.core.message.ondmdpxy;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class OnDemandPrivateProxyStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<OnDemandPrivateProxyStatusMessage> CREATOR = new Parcelable.Creator<OnDemandPrivateProxyStatusMessage>() { // from class: com.telink.ble.mesh.core.message.ondmdpxy.OnDemandPrivateProxyStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ OnDemandPrivateProxyStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ OnDemandPrivateProxyStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public OnDemandPrivateProxyStatusMessage createFromParcel(Parcel parcel) {
            return new OnDemandPrivateProxyStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public OnDemandPrivateProxyStatusMessage[] newArray(int i) {
            return new OnDemandPrivateProxyStatusMessage[i];
        }
    };
    public byte privateProxy;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public OnDemandPrivateProxyStatusMessage() {
    }

    protected OnDemandPrivateProxyStatusMessage(Parcel parcel) {
        this.privateProxy = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.privateProxy = bArr[0];
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.privateProxy);
    }
}
