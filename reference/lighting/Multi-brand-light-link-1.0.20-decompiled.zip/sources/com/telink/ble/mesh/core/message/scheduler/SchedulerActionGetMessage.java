package com.telink.ble.mesh.core.message.scheduler;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;

/* loaded from: classes.dex */
public class SchedulerActionGetMessage extends GenericMessage {
    private byte index;

    public static SchedulerActionGetMessage getSimple(int i, int i2, byte b, int i3) {
        SchedulerActionGetMessage schedulerActionGetMessage = new SchedulerActionGetMessage(i, i2);
        schedulerActionGetMessage.index = b;
        schedulerActionGetMessage.setResponseMax(i3);
        return schedulerActionGetMessage;
    }

    public SchedulerActionGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.SCHD_ACTION_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.SCHD_ACTION_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return new byte[]{this.index};
    }

    public void setIndex(byte b) {
        this.index = b;
    }
}
