package com.telink.ble.mesh.core.access.fu;

import com.telink.ble.mesh.entity.MeshUpdatingDevice;

/* loaded from: classes.dex */
public interface FUCallback {
    void onDeviceStateUpdate(MeshUpdatingDevice meshUpdatingDevice, String str);

    void onLog(String str, String str2, int i);

    void onStateUpdated(FUState fUState, String str);

    void onTransferProgress(int i, BlobTransferType blobTransferType);
}
