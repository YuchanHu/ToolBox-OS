package com.telink.ble.mesh.core.ble;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.AdvertisingSetParameters;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.os.Handler;
import android.os.ParcelUuid;
import com.telink.ble.mesh.util.MeshLogger;

/* loaded from: classes.dex */
public class BleAdvertiser {
    public static final int CODE_ADV_START_FAIL = 6;
    private static final long MIN_ADV_TIMEOUT = 2000;
    AdvertiseSettings advertiseSettings;
    private AdvertiserCallback advertiserCallback;
    AdvertisingSetParameters parameters;
    private boolean isAdvertising = false;
    private Handler mDelayHandler = new Handler();
    private final Runnable ADV_TIMEOUT_TASK = new Runnable() { // from class: com.telink.ble.mesh.core.ble.BleAdvertiser.1
        @Override // java.lang.Runnable
        public void run() {
            MeshLogger.d("stop by timer ");
            if (BleAdvertiser.access$000(BleAdvertiser.this) != null) {
                BleAdvertiser.access$000(BleAdvertiser.this).onAdvertiseTimeout();
            }
            BleAdvertiser.this.stopAdvertising();
        }
    };
    private final AdvertiseCallback ADV_CB = new AdvertiseCallback() { // from class: com.telink.ble.mesh.core.ble.BleAdvertiser.2
        @Override // android.bluetooth.le.AdvertiseCallback
        public void onStartSuccess(AdvertiseSettings advertiseSettings) {
            super.onStartSuccess(advertiseSettings);
            MeshLogger.d("adv start success");
            if (BleAdvertiser.access$000(BleAdvertiser.this) != null) {
                BleAdvertiser.access$000(BleAdvertiser.this).onStartedAdvertise();
            }
        }

        @Override // android.bluetooth.le.AdvertiseCallback
        public void onStartFailure(int i) {
            super.onStartFailure(i);
            MeshLogger.d("adv start fail:" + i);
        }
    };
    BluetoothLeAdvertiser advertiser = BluetoothAdapter.getDefaultAdapter().getBluetoothLeAdvertiser();

    public interface AdvertiserCallback {
        void onAdvertiseFail(int i);

        void onAdvertiseTimeout();

        void onStartedAdvertise();

        void onStoppedAdvertise();
    }

    static /* synthetic */ AdvertiserCallback access$000(BleAdvertiser bleAdvertiser) {
        return bleAdvertiser.advertiserCallback;
    }

    public BleAdvertiser() {
        AdvertiseSettings.Builder builder = new AdvertiseSettings.Builder();
        builder.setAdvertiseMode(2);
        builder.setTxPowerLevel(3);
        builder.setConnectable(false);
        builder.setTimeout(0);
        this.advertiseSettings = builder.build();
    }

    public void setAdvertiserCallback(AdvertiserCallback advertiserCallback) {
        this.advertiserCallback = advertiserCallback;
    }

    public void resetAdvertiser() {
        this.advertiser = BluetoothAdapter.getDefaultAdapter().getBluetoothLeAdvertiser();
    }

    public void startAdvertise(ParcelUuid parcelUuid, long j) {
        if (this.advertiser == null) {
            MeshLogger.d("advertiser null");
            return;
        }
        if (j <= MIN_ADV_TIMEOUT) {
            j = 2000;
        }
        this.mDelayHandler.removeCallbacks(this.ADV_TIMEOUT_TASK);
        this.mDelayHandler.postDelayed(this.ADV_TIMEOUT_TASK, j);
        AdvertiseData advertiseDataBuildAdvertiseData = buildAdvertiseData(parcelUuid);
        this.advertiser.stopAdvertising(this.ADV_CB);
        this.advertiser.startAdvertising(this.advertiseSettings, advertiseDataBuildAdvertiseData, this.ADV_CB);
    }

    public void startAdvertise(ParcelUuid parcelUuid, byte[] bArr, long j) {
        if (this.advertiser == null) {
            MeshLogger.d("advertiser null");
            return;
        }
        if (j <= MIN_ADV_TIMEOUT) {
            j = 2000;
        }
        this.mDelayHandler.removeCallbacks(this.ADV_TIMEOUT_TASK);
        this.mDelayHandler.postDelayed(this.ADV_TIMEOUT_TASK, j);
        AdvertiseData advertiseDataBuildAdvertiseData = buildAdvertiseData(parcelUuid, bArr);
        this.advertiser.stopAdvertising(this.ADV_CB);
        this.advertiser.startAdvertising(this.advertiseSettings, advertiseDataBuildAdvertiseData, this.ADV_CB);
    }

    private AdvertiseData buildAdvertiseData(ParcelUuid parcelUuid) {
        AdvertiseData.Builder builder = new AdvertiseData.Builder();
        BluetoothAdapter.getDefaultAdapter().setName("tlk");
        builder.setIncludeDeviceName(true);
        builder.addServiceUuid(parcelUuid);
        return builder.build();
    }

    private AdvertiseData buildAdvertiseData(ParcelUuid parcelUuid, byte[] bArr) {
        AdvertiseData.Builder builder = new AdvertiseData.Builder();
        builder.addServiceData(parcelUuid, bArr);
        return builder.build();
    }

    public void clear() {
        if (this.advertiser != null) {
            stopAdvertising();
        }
        Handler handler = this.mDelayHandler;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
    }

    public synchronized void stopAdvertising() {
        MeshLogger.d("stop advertising");
        this.advertiser.stopAdvertising(this.ADV_CB);
        this.isAdvertising = false;
        AdvertiserCallback advertiserCallback = this.advertiserCallback;
        if (advertiserCallback != null) {
            advertiserCallback.onStoppedAdvertise();
        }
    }
}
