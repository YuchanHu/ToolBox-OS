package com.telink.ble.mesh.core.networking;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class NonceGenerator {
    private static final int NONCE_LENGTH = 13;
    private static final byte NONCE_PADDING = 0;
    private static final byte NONCE_TYPE_APPLICATION = 1;
    private static final byte NONCE_TYPE_DEVICE = 2;
    private static final byte NONCE_TYPE_NETWORK = 0;
    private static final byte NONCE_TYPE_PROXY = 3;
    private static final byte NONCE_TYPE_SOLICITATION = 4;

    public static byte[] generateNetworkNonce(byte b, byte[] bArr, int i, int i2) {
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(13).order(ByteOrder.BIG_ENDIAN);
        byteBufferOrder.put((byte) 0);
        byteBufferOrder.put(b);
        byteBufferOrder.put(bArr);
        byteBufferOrder.putShort((short) i);
        byteBufferOrder.put(new byte[]{0, 0});
        byteBufferOrder.putInt(i2);
        return byteBufferOrder.array();
    }

    public static byte[] generateAccessNonce(byte b, byte[] bArr, int i, int i2, int i3, AccessType accessType) {
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(13).order(ByteOrder.BIG_ENDIAN);
        byteBufferOrder.put(accessType == AccessType.APPLICATION ? (byte) 1 : (byte) 2);
        byteBufferOrder.put((byte) (b << 7));
        byteBufferOrder.put(bArr);
        byteBufferOrder.putShort((short) i);
        byteBufferOrder.putShort((short) i2);
        byteBufferOrder.putInt(i3);
        return byteBufferOrder.array();
    }

    public static byte[] generateProxyNonce(byte[] bArr, int i, int i2) {
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(13);
        byteBufferAllocate.put((byte) 3);
        byteBufferAllocate.put((byte) 0);
        byteBufferAllocate.put(bArr);
        byteBufferAllocate.putShort((short) i);
        byteBufferAllocate.put(new byte[]{0, 0});
        byteBufferAllocate.putInt(i2);
        return byteBufferAllocate.array();
    }

    public static byte[] generateSolicitationNonce(byte[] bArr, int i) {
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(13);
        byteBufferAllocate.put((byte) 4);
        byteBufferAllocate.put((byte) 0);
        byteBufferAllocate.put(bArr);
        byteBufferAllocate.putShort((short) i);
        byteBufferAllocate.put(new byte[6]);
        return byteBufferAllocate.array();
    }
}
