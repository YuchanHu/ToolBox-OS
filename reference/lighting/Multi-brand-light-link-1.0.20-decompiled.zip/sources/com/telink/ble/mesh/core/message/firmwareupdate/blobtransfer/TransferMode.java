package com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer;

/* loaded from: classes.dex */
public enum TransferMode {
    NONE(0, "No Active Transfer"),
    PUSH(1, "Push BLOB Transfer Mode"),
    PULL(2, "Pull BLOB Transfer Mode"),
    Prohibited(3, "Prohibited");

    public final String desc;
    public final int value;

    TransferMode(int i, String str) {
        this.value = i;
        this.desc = str;
    }

    public static TransferMode valueOf(int i) {
        for (TransferMode transferMode : values()) {
            if (transferMode.value == i) {
                return transferMode;
            }
        }
        return Prohibited;
    }
}
