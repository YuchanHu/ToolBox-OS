package com.telink.ble.mesh.core.message.generic;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class LevelStatusMessage extends StatusMessage {
    public static final Parcelable.Creator<LevelStatusMessage> CREATOR = new Parcelable.Creator<LevelStatusMessage>() { // from class: com.telink.ble.mesh.core.message.generic.LevelStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ LevelStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ LevelStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LevelStatusMessage createFromParcel(Parcel parcel) {
            return new LevelStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LevelStatusMessage[] newArray(int i) {
            return new LevelStatusMessage[i];
        }
    };
    private static final int DATA_LEN_COMPLETE = 5;
    private boolean isComplete = false;
    private int presentLevel;
    private byte remainingTime;
    private int targetLevel;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public LevelStatusMessage() {
    }

    protected LevelStatusMessage(Parcel parcel) {
        this.presentLevel = parcel.readInt();
        this.targetLevel = parcel.readInt();
        this.remainingTime = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.presentLevel = MeshUtils.bytes2Integer(bArr, 0, 2, ByteOrder.LITTLE_ENDIAN);
        if (bArr.length >= 5) {
            this.isComplete = true;
            this.targetLevel = MeshUtils.bytes2Integer(bArr, 2, 2, ByteOrder.LITTLE_ENDIAN);
            this.remainingTime = bArr[4];
        }
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.presentLevel);
        parcel.writeInt(this.targetLevel);
        parcel.writeByte(this.remainingTime);
    }

    public int getPresentLevel() {
        return this.presentLevel;
    }

    public int getTargetLevel() {
        return this.targetLevel;
    }

    public byte getRemainingTime() {
        return this.remainingTime;
    }

    public boolean isComplete() {
        return this.isComplete;
    }
}
