package com.telink.ble.mesh.foundation;

import android.os.HandlerThread;
import com.telink.ble.mesh.core.access.AccessBridge;
import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.NotificationMessage;
import com.telink.ble.mesh.util.MeshLogger;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class MulticastMessageBroker {
    public static final int ACCESS_ST_BRK_MSG_COMPLETE = 4;
    public static final int ACCESS_ST_NODE_LOST = 3;
    private static final int BRK_ST_IDLE = 0;
    private static final int BRK_ST_SENDING_MULTICAST = 1;
    private static final int BRK_ST_SENDING_UNICAST = 2;
    private AccessBridge accessBridge;
    private MeshMessage brokerMessage;
    private int multicastRetryMax;
    private MeshMessage sendingMessage;
    private final String LOG_TAG = "MulticastMsgBroker";
    private int state = 0;
    private int threshold = 2;
    private int multicastRetryCount = 0;
    private List<Integer> remainingNodes = new ArrayList();

    public static class Result {
        public int opcode;
        public List<Integer> remainingNodes;
    }

    public void onMessageNotification(NotificationMessage notificationMessage) {
    }

    public MulticastMessageBroker(HandlerThread handlerThread) {
    }

    public void register(AccessBridge accessBridge) {
        this.accessBridge = accessBridge;
    }

    public boolean sendMessage(MeshMessage meshMessage) {
        log("send multicast broker message");
        this.brokerMessage = meshMessage.clone();
        Config brokerConfig = meshMessage.getBrokerConfig();
        this.threshold = brokerConfig.threshold;
        this.multicastRetryMax = brokerConfig.multicastRetryMax;
        this.multicastRetryCount = 0;
        this.remainingNodes.clear();
        this.remainingNodes.addAll(brokerConfig.innerNodes);
        boolean zOnMessagePrepared = onMessagePrepared(this.brokerMessage);
        if (zOnMessagePrepared) {
            updateState(1);
        }
        return zOnMessagePrepared;
    }

    boolean isBrokerBusy() {
        return this.state != 0;
    }

    private boolean onMessagePrepared(MeshMessage meshMessage) {
        log("onMessagePrepared ");
        if (meshMessage.useMultiMessageBroker()) {
            meshMessage.setBrokerConfig(null);
        }
        this.sendingMessage = meshMessage;
        boolean zOnAccessMessagePrepared = this.accessBridge.onAccessMessagePrepared(meshMessage, 5);
        if (!zOnAccessMessagePrepared) {
            onComplete("send message err");
        }
        return zOnAccessMessagePrepared;
    }

    public void onMessageComplete(boolean z, int i, Integer[] numArr) {
        MeshMessage meshMessage;
        log("message complete");
        if (isBrokerBusy() && (meshMessage = this.sendingMessage) != null && meshMessage.getOpcode() == i) {
            for (Integer num : numArr) {
                this.remainingNodes.remove(num);
            }
            int size = this.remainingNodes.size();
            if (size == 0) {
                onComplete("all nodes replied");
                return;
            }
            int i2 = this.state;
            if (i2 != 1) {
                if (i2 == 2) {
                    int destinationAddress = this.sendingMessage.getDestinationAddress();
                    if (!z) {
                        this.remainingNodes.remove(Integer.valueOf(destinationAddress));
                        log("node lost");
                        updateAccessState(3, String.format("node lost at %04X", Integer.valueOf(destinationAddress)), Integer.valueOf(destinationAddress));
                    }
                    sendUnicastMessage();
                    return;
                }
                return;
            }
            if (size <= this.threshold) {
                updateState(2);
                sendUnicastMessage();
            } else {
                if (this.multicastRetryCount >= this.multicastRetryMax) {
                    onComplete("fail : multicast message retry max");
                    return;
                }
                log("retry multicast message");
                this.multicastRetryCount++;
                onMessagePrepared(this.brokerMessage);
            }
        }
    }

    private void updateState(int i) {
        this.state = i;
    }

    private void sendUnicastMessage() {
        if (this.remainingNodes.size() == 0) {
            onComplete("no remaining nodes");
            return;
        }
        log("send unicast message");
        int iIntValue = this.remainingNodes.get(0).intValue();
        MeshMessage meshMessageClone = this.brokerMessage.clone();
        meshMessageClone.setDestinationAddress(iIntValue);
        meshMessageClone.setRetryCnt(1);
        onMessagePrepared(meshMessageClone);
    }

    private void onComplete(String str) {
        log("onComplete - " + str);
        Result result = new Result();
        result.opcode = this.brokerMessage.getOpcode();
        result.remainingNodes = new ArrayList(this.remainingNodes);
        updateAccessState(4, str, result);
        clear();
    }

    private void updateAccessState(int i, String str, Object obj) {
        this.accessBridge.onAccessStateChanged(i, str, 5, obj);
    }

    private void clear() {
        this.state = 0;
        this.sendingMessage = null;
        this.brokerMessage = null;
    }

    public static class Config {
        public List<Integer> innerNodes;
        public int multicastRetryMax;
        public int threshold;

        public Config() {
            this.innerNodes = null;
            this.threshold = 2;
            this.multicastRetryMax = 1;
        }

        public Config(List<Integer> list) {
            this.threshold = 2;
            this.multicastRetryMax = 1;
            this.innerNodes = list;
        }
    }

    private void log(String str) {
        log(str, 1);
    }

    private void log(String str, int i) {
        MeshLogger.log(str, "MulticastMsgBroker", i);
    }
}
