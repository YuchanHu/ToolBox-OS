package com.telink.ble.mesh.core.message.aggregator;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.StatusMessage;
import com.telink.ble.mesh.util.MeshLogger;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class OpcodeAggregatorStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<OpcodeAggregatorStatusMessage> CREATOR = new Parcelable.Creator<OpcodeAggregatorStatusMessage>() { // from class: com.telink.ble.mesh.core.message.aggregator.OpcodeAggregatorStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ OpcodeAggregatorStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ OpcodeAggregatorStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public OpcodeAggregatorStatusMessage createFromParcel(Parcel parcel) {
            return new OpcodeAggregatorStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public OpcodeAggregatorStatusMessage[] newArray(int i) {
            return new OpcodeAggregatorStatusMessage[i];
        }
    };
    public int elementAddress;
    public byte status;
    public List<AggregatorItem> statusItems;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public OpcodeAggregatorStatusMessage() {
    }

    protected OpcodeAggregatorStatusMessage(Parcel parcel) {
        this.status = parcel.readByte();
        this.elementAddress = parcel.readInt();
        this.statusItems = parcel.createTypedArrayList(AggregatorItem.CREATOR);
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        int i;
        this.status = bArr[0];
        this.elementAddress = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.LITTLE_ENDIAN);
        this.statusItems = new ArrayList();
        int i2 = 3;
        while (bArr.length > i2) {
            int i3 = bArr[i2];
            if ((i3 & 1) == 1) {
                i = ((i3 & 255) >> 1) | ((bArr[i2 + 1] & 255) << 8);
                i2 += 2;
            } else {
                i = (i3 & 255) >> 1;
                i2++;
            }
            if (i == 0) {
                MeshLogger.w("parse err: aggregatorItem len 0");
            } else {
                byte[] bArr2 = new byte[i];
                System.arraycopy(bArr, i2, bArr2, 0, i);
                AggregatorItem aggregatorItemFromBytes = AggregatorItem.fromBytes(bArr2);
                MeshLogger.d("parsed Aggregator Item : " + aggregatorItemFromBytes.toString());
                this.statusItems.add(aggregatorItemFromBytes);
                i2 += i;
            }
        }
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.status);
        parcel.writeInt(this.elementAddress);
        parcel.writeTypedList(this.statusItems);
    }

    public String toString() {
        return "OpcodeAggregatorStatusMessage{status=" + ((int) this.status) + ", elementAddress=" + this.elementAddress + ", statusItems=" + this.statusItems + '}';
    }
}
