package com.telink.ble.mesh.foundation.event;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.foundation.Event;

/* loaded from: classes.dex */
public class MeshEvent extends Event<String> {
    public static final Parcelable.Creator<MeshEvent> CREATOR = new Parcelable.Creator<MeshEvent>() { // from class: com.telink.ble.mesh.foundation.event.MeshEvent.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ MeshEvent createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ MeshEvent[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public MeshEvent createFromParcel(Parcel parcel) {
            return new MeshEvent(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public MeshEvent[] newArray(int i) {
            return new MeshEvent[i];
        }
    };
    public static final String EVENT_TYPE_DISCONNECTED = "com.telink.ble.mesh.EVENT_TYPE_DISCONNECTED";
    public static final String EVENT_TYPE_MESH_EMPTY = "com.telink.ble.mesh.MESH_EMPTY";
    public static final String EVENT_TYPE_MESH_RESET = "com.telink.sig.mesh.EVENT_TYPE_MESH_RESET";
    private String desc;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public MeshEvent(Object obj, String str, String str2) {
        super(obj, str);
        this.desc = str2;
    }

    protected MeshEvent(Parcel parcel) {
        this.desc = parcel.readString();
    }

    public String getDesc() {
        return this.desc;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.desc);
    }
}
