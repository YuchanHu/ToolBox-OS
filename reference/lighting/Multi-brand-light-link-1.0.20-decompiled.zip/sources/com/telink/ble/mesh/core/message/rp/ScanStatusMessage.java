package com.telink.ble.mesh.core.message.rp;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class ScanStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<ScanStatusMessage> CREATOR = new Parcelable.Creator<ScanStatusMessage>() { // from class: com.telink.ble.mesh.core.message.rp.ScanStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ScanStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ScanStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ScanStatusMessage createFromParcel(Parcel parcel) {
            return new ScanStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ScanStatusMessage[] newArray(int i) {
            return new ScanStatusMessage[i];
        }
    };
    private byte rpScanningState;
    private byte scannedItemsLimit;
    private byte status;
    private byte timeout;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public ScanStatusMessage() {
    }

    protected ScanStatusMessage(Parcel parcel) {
        this.status = parcel.readByte();
        this.rpScanningState = parcel.readByte();
        this.scannedItemsLimit = parcel.readByte();
        this.timeout = parcel.readByte();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.status);
        parcel.writeByte(this.rpScanningState);
        parcel.writeByte(this.scannedItemsLimit);
        parcel.writeByte(this.timeout);
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.status = bArr[0];
        this.rpScanningState = bArr[1];
        this.scannedItemsLimit = bArr[2];
        this.timeout = bArr[3];
    }

    public byte getStatus() {
        return this.status;
    }

    public byte getRpScanningState() {
        return this.rpScanningState;
    }

    public byte getScannedItemsLimit() {
        return this.scannedItemsLimit;
    }

    public byte getTimeout() {
        return this.timeout;
    }
}
