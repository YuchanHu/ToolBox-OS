package com.telink.ble.mesh.core.access;

import android.os.Handler;
import android.os.HandlerThread;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.NotificationMessage;
import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.rp.LinkCloseMessage;
import com.telink.ble.mesh.core.message.rp.LinkOpenMessage;
import com.telink.ble.mesh.core.message.rp.LinkStatusMessage;
import com.telink.ble.mesh.core.message.rp.ProvisioningPDUOutboundReportMessage;
import com.telink.ble.mesh.core.message.rp.ProvisioningPDUReportMessage;
import com.telink.ble.mesh.core.message.rp.ProvisioningPduSendMessage;
import com.telink.ble.mesh.core.provisioning.ProvisioningBridge;
import com.telink.ble.mesh.core.provisioning.ProvisioningController;
import com.telink.ble.mesh.entity.RemoteProvisioningDevice;
import com.telink.ble.mesh.util.Arrays;
import com.telink.ble.mesh.util.MeshLogger;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SignatureException;
import java.security.cert.CertificateException;

/* loaded from: classes.dex */
public class RemoteProvisioningController implements ProvisioningBridge {
    private static final int OUTBOUND_INIT_VALUE = 1;
    private static final long OUTBOUND_WAITING_TIMEOUT = 500;
    public static final int STATE_CAPABILITY_RECEIVED = 3;
    public static final int STATE_INIT = 0;
    public static final int STATE_LINK_CLOSING = 6;
    public static final int STATE_LINK_OPENING = 1;
    public static final int STATE_PROVISIONING = 2;
    public static final int STATE_PROVISION_FAIL = 5;
    public static final int STATE_PROVISION_SUCCESS = 4;
    private AccessBridge accessBridge;
    private Handler delayHandler;
    private ProvisioningController provisioningController;
    private RemoteProvisioningDevice provisioningDevice;
    private int state;
    private final String LOG_TAG = "RemotePv";
    private int outboundNumber = 1;
    private int inboundPDUNumber = 0;
    private boolean outboundReportWaiting = false;
    private final Object WAITING_LOCK = new Object();
    private byte[] cachePdu = null;
    private byte[] transmittingPdu = null;
    private boolean provisionSuccess = false;
    private Runnable resendProvisionPduTask = new Runnable() { // from class: com.telink.ble.mesh.core.access.RemoteProvisioningController.1
        @Override // java.lang.Runnable
        public void run() {
            RemoteProvisioningController.access$100(RemoteProvisioningController.this, "resend provision pdu: waitingOutbound?" + RemoteProvisioningController.access$000(RemoteProvisioningController.this));
            if (RemoteProvisioningController.access$200(RemoteProvisioningController.this) != null) {
                synchronized (RemoteProvisioningController.access$300(RemoteProvisioningController.this)) {
                    if (RemoteProvisioningController.access$000(RemoteProvisioningController.this)) {
                        RemoteProvisioningController.access$002(RemoteProvisioningController.this, false);
                        RemoteProvisioningController remoteProvisioningController = RemoteProvisioningController.this;
                        remoteProvisioningController.onCommandPrepared((byte) 3, RemoteProvisioningController.access$200(remoteProvisioningController));
                    }
                }
                return;
            }
            RemoteProvisioningController.access$100(RemoteProvisioningController.this, "transmitting pdu error");
        }
    };

    static /* synthetic */ boolean access$000(RemoteProvisioningController remoteProvisioningController) {
        return remoteProvisioningController.outboundReportWaiting;
    }

    static /* synthetic */ boolean access$002(RemoteProvisioningController remoteProvisioningController, boolean z) {
        remoteProvisioningController.outboundReportWaiting = z;
        return z;
    }

    static /* synthetic */ void access$100(RemoteProvisioningController remoteProvisioningController, String str) {
        remoteProvisioningController.log(str);
    }

    static /* synthetic */ byte[] access$200(RemoteProvisioningController remoteProvisioningController) {
        return remoteProvisioningController.transmittingPdu;
    }

    static /* synthetic */ Object access$300(RemoteProvisioningController remoteProvisioningController) {
        return remoteProvisioningController.WAITING_LOCK;
    }

    public RemoteProvisioningController(HandlerThread handlerThread) {
        this.delayHandler = new Handler(handlerThread.getLooper());
    }

    public void register(AccessBridge accessBridge) {
        this.accessBridge = accessBridge;
    }

    public void begin(ProvisioningController provisioningController, RemoteProvisioningDevice remoteProvisioningDevice) {
        log(String.format("remote provisioning begin: server -- %04X  uuid -- %s  allocatedAdr -- %04X", Integer.valueOf(remoteProvisioningDevice.getServerAddress()), Arrays.bytesToHexString(remoteProvisioningDevice.getUuid()), Integer.valueOf(remoteProvisioningDevice.getUnicastAddress())));
        this.outboundNumber = 1;
        this.inboundPDUNumber = -1;
        this.cachePdu = null;
        this.outboundReportWaiting = false;
        this.provisionSuccess = false;
        this.state = 0;
        this.provisioningController = provisioningController;
        this.provisioningDevice = remoteProvisioningDevice;
        linkOpen();
    }

    public void continueProvision(int i) throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, InvalidAlgorithmParameterException {
        this.provisioningController.continueProvision(i);
    }

    public void clear() {
        this.state = 0;
        this.cachePdu = null;
        this.transmittingPdu = null;
        this.provisioningController = null;
        Handler handler = this.delayHandler;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
    }

    public RemoteProvisioningDevice getProvisioningDevice() {
        return this.provisioningDevice;
    }

    private void startProvisioningFlow() {
        this.state = 2;
        ProvisioningController provisioningController = this.provisioningController;
        if (provisioningController != null) {
            provisioningController.setProvisioningBridge(this);
            this.provisioningController.begin(this.provisioningDevice);
        }
    }

    private void linkOpen() {
        LinkOpenMessage simple = LinkOpenMessage.getSimple(this.provisioningDevice.getServerAddress(), 1, this.provisioningDevice.getUuid());
        simple.setRetryCnt(8);
        this.state = 1;
        onMeshMessagePrepared(simple);
    }

    private void linkClose(boolean z) {
        this.state = 6;
        onMeshMessagePrepared(LinkCloseMessage.getSimple(this.provisioningDevice.getServerAddress(), 1, z ? (byte) 0 : (byte) 2));
    }

    private void onLinkStatus(LinkStatusMessage linkStatusMessage) {
        log("link status : " + linkStatusMessage.toString());
        int i = this.state;
        if (i == 1) {
            startProvisioningFlow();
            return;
        }
        if (i == 2) {
            log("link status when provisioning");
        } else if (i == 6) {
            this.state = this.provisionSuccess ? 4 : 5;
            onRemoteProvisioningComplete();
        }
    }

    private void onProvisioningPduNotify(ProvisioningPDUReportMessage provisioningPDUReportMessage) throws IllegalStateException, NoSuchAlgorithmException, SignatureException, InvalidKeyException, CertificateException, NoSuchProviderException, InvalidAlgorithmParameterException {
        log("provisioning pdu report : " + provisioningPDUReportMessage.toString() + " -- " + this.inboundPDUNumber);
        byte[] provisioningPDU = provisioningPDUReportMessage.getProvisioningPDU();
        if ((provisioningPDUReportMessage.getInboundPDUNumber() & FUDistributor.UPDATE_TTL) <= this.inboundPDUNumber) {
            log("repeated provisioning pdu received");
            return;
        }
        ProvisioningController provisioningController = this.provisioningController;
        if (provisioningController != null) {
            provisioningController.pushNotification(provisioningPDU);
        }
    }

    private void resendProvisionPdu() {
        this.delayHandler.removeCallbacks(this.resendProvisionPduTask);
        this.delayHandler.postDelayed(this.resendProvisionPduTask, 2000L);
    }

    private void onOutboundReport(ProvisioningPDUOutboundReportMessage provisioningPDUOutboundReportMessage) {
        int outboundPDUNumber = provisioningPDUOutboundReportMessage.getOutboundPDUNumber() & FUDistributor.UPDATE_TTL;
        log("outbound report message received: " + outboundPDUNumber + " waiting? " + this.outboundReportWaiting);
        if (this.outboundNumber == outboundPDUNumber) {
            synchronized (this.WAITING_LOCK) {
                this.delayHandler.removeCallbacks(this.resendProvisionPduTask);
                this.transmittingPdu = null;
                this.outboundReportWaiting = false;
                log("stop outbound waiting: " + this.outboundNumber);
                this.outboundNumber = this.outboundNumber + 1;
                byte[] bArr = this.cachePdu;
                if (bArr != null) {
                    onCommandPrepared((byte) 3, bArr);
                    this.cachePdu = null;
                } else {
                    log("no cached provisioning pdu: waiting for provisioning response");
                }
            }
            return;
        }
        if (this.outboundReportWaiting) {
            log("outbound number not pair");
        }
    }

    public void onMessageNotification(NotificationMessage notificationMessage) throws IllegalStateException, NoSuchAlgorithmException, SignatureException, InvalidKeyException, CertificateException, NoSuchProviderException, InvalidAlgorithmParameterException {
        Opcode opcodeValueOf = Opcode.valueOf(notificationMessage.getOpcode());
        if (opcodeValueOf == null) {
            return;
        }
        int i = AnonymousClass2.$SwitchMap$com$telink$ble$mesh$core$message$Opcode[opcodeValueOf.ordinal()];
        if (i == 1) {
            onLinkStatus((LinkStatusMessage) notificationMessage.getStatusMessage());
        } else if (i == 2) {
            onProvisioningPduNotify((ProvisioningPDUReportMessage) notificationMessage.getStatusMessage());
        } else {
            if (i != 3) {
                return;
            }
            onOutboundReport((ProvisioningPDUOutboundReportMessage) notificationMessage.getStatusMessage());
        }
    }

    /* renamed from: com.telink.ble.mesh.core.access.RemoteProvisioningController$2, reason: invalid class name */
    static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] $SwitchMap$com$telink$ble$mesh$core$message$Opcode;

        static {
            int[] iArr = new int[Opcode.values().length];
            $SwitchMap$com$telink$ble$mesh$core$message$Opcode = iArr;
            try {
                iArr[Opcode.REMOTE_PROV_LINK_STS.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$message$Opcode[Opcode.REMOTE_PROV_PDU_REPORT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$message$Opcode[Opcode.REMOTE_PROV_PDU_OUTBOUND_REPORT.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    public void onRemoteProvisioningCommandComplete(boolean z, int i, int i2, int i3) {
        if (z) {
            return;
        }
        onCommandError(i);
    }

    private void onCommandError(int i) {
        if (i == Opcode.REMOTE_PROV_LINK_OPEN.value) {
            onProvisioningComplete(false, "link open err");
            return;
        }
        if (i == Opcode.REMOTE_PROV_LINK_CLOSE.value) {
            this.state = this.provisionSuccess ? 4 : 5;
            onRemoteProvisioningComplete();
        } else if (i == Opcode.REMOTE_PROV_PDU_SEND.value) {
            log("provisioning pdu send error");
            onProvisioningComplete(false, "provision pdu send error");
        }
    }

    private void onProvisioningComplete(boolean z, String str) {
        ProvisioningController provisioningController;
        this.delayHandler.removeCallbacksAndMessages(null);
        this.provisionSuccess = z;
        if (!z && (provisioningController = this.provisioningController) != null) {
            provisioningController.clear();
        }
        linkClose(z);
    }

    private void onRemoteProvisioningComplete() {
        AccessBridge accessBridge = this.accessBridge;
        if (accessBridge != null) {
            accessBridge.onAccessStateChanged(this.state, "remote provisioning complete", 3, this.provisioningDevice);
        }
    }

    private void onMeshMessagePrepared(MeshMessage meshMessage) {
        log("remote provisioning message prepared: " + meshMessage.getClass().getSimpleName() + String.format(" opcode: 0x%04X -- dst: 0x%04X -- params: ", Integer.valueOf(meshMessage.getOpcode()), Integer.valueOf(meshMessage.getDestinationAddress())) + Arrays.bytesToHexString(meshMessage.getParams()));
        AccessBridge accessBridge = this.accessBridge;
        if (accessBridge != null) {
            if (!accessBridge.onAccessMessagePrepared(meshMessage, 3)) {
                log(String.format("remote provisioning message send error : %04X", Integer.valueOf(meshMessage.getOpcode())));
                if (meshMessage.getOpcode() == Opcode.REMOTE_PROV_PDU_SEND.value) {
                    synchronized (this.WAITING_LOCK) {
                        this.outboundReportWaiting = true;
                    }
                    resendProvisionPdu();
                    return;
                }
                onCommandError(meshMessage.getOpcode());
                return;
            }
            if (meshMessage.getOpcode() == Opcode.REMOTE_PROV_PDU_SEND.value) {
                synchronized (this.WAITING_LOCK) {
                    this.outboundReportWaiting = true;
                }
                resendProvisionPdu();
            }
        }
    }

    @Override // com.telink.ble.mesh.core.provisioning.ProvisioningBridge
    public void onProvisionStateChanged(int i, String str) {
        log("provisioning state changed: " + i + " -- " + str);
        if (i == 4107) {
            onProvisioningComplete(true, str);
        } else if (i == 4108) {
            onProvisioningComplete(false, str);
        } else if (i == 4098) {
            onCapabilityReceived();
        }
    }

    private void onCapabilityReceived() {
        AccessBridge accessBridge = this.accessBridge;
        if (accessBridge != null) {
            accessBridge.onAccessStateChanged(3, "provision capability received", 3, this.provisioningDevice);
        }
    }

    @Override // com.telink.ble.mesh.core.provisioning.ProvisioningBridge
    public void onCommandPrepared(byte b, byte[] bArr) {
        if (b != 3) {
            return;
        }
        synchronized (this.WAITING_LOCK) {
            if (this.outboundReportWaiting) {
                if (this.cachePdu == null) {
                    this.cachePdu = bArr;
                } else {
                    log("cache pdu already exists");
                }
                return;
            }
            this.transmittingPdu = (byte[]) bArr.clone();
            ProvisioningPduSendMessage simple = ProvisioningPduSendMessage.getSimple(this.provisioningDevice.getServerAddress(), 0, (byte) this.outboundNumber, this.transmittingPdu);
            simple.setRetryCnt(8);
            log("send provisioning pdu: " + this.outboundNumber);
            onMeshMessagePrepared(simple);
        }
    }

    private void log(String str) {
        log(str, 1);
    }

    private void log(String str, int i) {
        MeshLogger.log(str, "RemotePv", i);
    }
}
