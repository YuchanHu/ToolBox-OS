package com.telink.ble.mesh.core.message.sensor;

import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class SensorCadenceGetMessage extends GenericMessage {
    private int propertyID;

    public static SensorCadenceGetMessage getSimple(int i, int i2, int i3) {
        SensorCadenceGetMessage sensorCadenceGetMessage = new SensorCadenceGetMessage(i, i2);
        sensorCadenceGetMessage.propertyID = i3;
        sensorCadenceGetMessage.setResponseMax(1);
        return sensorCadenceGetMessage;
    }

    public SensorCadenceGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.SENSOR_CANDECE_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.SENSOR_CANDECE_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return MeshUtils.integer2Bytes(this.propertyID, 2, ByteOrder.LITTLE_ENDIAN);
    }

    public void setPropertyID(int i) {
        this.propertyID = i;
    }
}
