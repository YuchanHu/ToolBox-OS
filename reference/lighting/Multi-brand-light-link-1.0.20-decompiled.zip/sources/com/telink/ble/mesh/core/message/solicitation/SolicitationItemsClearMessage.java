package com.telink.ble.mesh.core.message.solicitation;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.config.ConfigMessage;

/* loaded from: classes.dex */
public class SolicitationItemsClearMessage extends ConfigMessage {
    public boolean ack;
    public byte[] addressRange;

    public SolicitationItemsClearMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.SOLI_PDU_RPL_ITEM_CLEAR : Opcode.SOLI_PDU_RPL_ITEM_CLEAR_NACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        if (this.ack) {
            return Opcode.SOLI_PDU_RPL_ITEM_STATUS.value;
        }
        return -1;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return this.addressRange;
    }
}
