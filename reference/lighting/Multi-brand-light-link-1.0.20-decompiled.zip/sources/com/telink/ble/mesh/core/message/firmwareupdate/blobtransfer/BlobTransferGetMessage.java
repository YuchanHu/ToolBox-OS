package com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;

/* loaded from: classes.dex */
public class BlobTransferGetMessage extends UpdatingMessage {
    public BlobTransferGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.BLOB_TRANSFER_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.BLOB_TRANSFER_STATUS.value;
    }

    public static BlobTransferGetMessage getSimple(int i, int i2) {
        BlobTransferGetMessage blobTransferGetMessage = new BlobTransferGetMessage(i, i2);
        blobTransferGetMessage.setResponseMax(1);
        return blobTransferGetMessage;
    }
}
