package com.telink.ble.mesh.foundation.event;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.entity.FastProvisioningDevice;
import com.telink.ble.mesh.foundation.Event;

/* loaded from: classes.dex */
public class FastProvisioningEvent extends Event<String> {
    public static final Parcelable.Creator<FastProvisioningEvent> CREATOR = new Parcelable.Creator<FastProvisioningEvent>() { // from class: com.telink.ble.mesh.foundation.event.FastProvisioningEvent.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FastProvisioningEvent createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FastProvisioningEvent[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FastProvisioningEvent createFromParcel(Parcel parcel) {
            return new FastProvisioningEvent(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FastProvisioningEvent[] newArray(int i) {
            return new FastProvisioningEvent[i];
        }
    };
    public static final String EVENT_TYPE_FAST_PROVISIONING_CONNECTING = "com.telink.sig.mesh.EVENT_TYPE_FAST_PROVISIONING_CONNECTING";
    public static final String EVENT_TYPE_FAST_PROVISIONING_FAIL = "com.telink.sig.mesh.EVENT_TYPE_FAST_PROVISIONING_FAIL";
    public static final String EVENT_TYPE_FAST_PROVISIONING_GET_ADDRESS = "com.telink.sig.mesh.EVENT_TYPE_FAST_PROVISIONING_GET_ADDRESS";
    public static final String EVENT_TYPE_FAST_PROVISIONING_GET_ADDRESS_RSP = "com.telink.sig.mesh.EVENT_TYPE_FAST_PROVISIONING_GET_ADDRESS_RSP";
    public static final String EVENT_TYPE_FAST_PROVISIONING_RESET_NWK = "com.telink.sig.mesh.EVENT_TYPE_FAST_PROVISIONING_RESET_NWK";
    public static final String EVENT_TYPE_FAST_PROVISIONING_SET_ADDRESS = "com.telink.sig.mesh.EVENT_TYPE_FAST_PROVISIONING_SET_ADDRESS";
    public static final String EVENT_TYPE_FAST_PROVISIONING_SET_ADDRESS_FAIL = "com.telink.sig.mesh.EVENT_TYPE_FAST_PROVISIONING_SET_ADDRESS_FAIL";
    public static final String EVENT_TYPE_FAST_PROVISIONING_SET_ADDRESS_SUCCESS = "com.telink.sig.mesh.EVENT_TYPE_FAST_PROVISIONING_SET_ADDRESS_SUCCESS";
    public static final String EVENT_TYPE_FAST_PROVISIONING_SET_DATA = "com.telink.sig.mesh.EVENT_TYPE_FAST_PROVISIONING_SET_DATA";
    public static final String EVENT_TYPE_FAST_PROVISIONING_SUCCESS = "com.telink.sig.mesh.EVENT_TYPE_FAST_PROVISIONING_SUCCESS";
    private String desc;
    private FastProvisioningDevice fastProvisioningDevice;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public FastProvisioningEvent(Object obj, String str) {
        super(obj, str);
    }

    protected FastProvisioningEvent(Parcel parcel) {
        this.fastProvisioningDevice = (FastProvisioningDevice) parcel.readParcelable(FastProvisioningDevice.class.getClassLoader());
        this.desc = parcel.readString();
    }

    public String getDesc() {
        return this.desc;
    }

    public void setDesc(String str) {
        this.desc = str;
    }

    public FastProvisioningDevice getFastProvisioningDevice() {
        return this.fastProvisioningDevice;
    }

    public void setFastProvisioningDevice(FastProvisioningDevice fastProvisioningDevice) {
        this.fastProvisioningDevice = fastProvisioningDevice;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.fastProvisioningDevice, i);
        parcel.writeString(this.desc);
    }
}
