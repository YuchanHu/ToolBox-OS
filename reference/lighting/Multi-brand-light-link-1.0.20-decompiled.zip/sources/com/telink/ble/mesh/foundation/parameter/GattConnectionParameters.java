package com.telink.ble.mesh.foundation.parameter;

import com.telink.ble.mesh.entity.ConnectionFilter;

/* loaded from: classes.dex */
public class GattConnectionParameters extends Parameters {
    public GattConnectionParameters(ConnectionFilter connectionFilter) {
        set(Parameters.COMMON_PROXY_FILTER_INIT_NEEDED, true);
        set(Parameters.ACTION_CONNECTION_FILTER, connectionFilter);
    }
}
