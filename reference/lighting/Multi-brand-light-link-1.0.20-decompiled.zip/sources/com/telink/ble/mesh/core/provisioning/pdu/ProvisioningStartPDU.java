package com.telink.ble.mesh.core.provisioning.pdu;

import com.telink.ble.mesh.core.provisioning.AuthenticationMethod;

/* loaded from: classes.dex */
public class ProvisioningStartPDU implements ProvisioningStatePDU {
    private static final int LEN = 5;
    public byte algorithm;
    public byte authenticationAction;
    public byte authenticationMethod;
    public byte authenticationSize;
    public byte publicKey;

    @Override // com.telink.ble.mesh.core.provisioning.pdu.ProvisioningStatePDU
    public byte getState() {
        return (byte) 2;
    }

    public static ProvisioningStartPDU getSimple(boolean z, boolean z2) {
        byte b;
        ProvisioningStartPDU provisioningStartPDU = new ProvisioningStartPDU();
        provisioningStartPDU.algorithm = (byte) 0;
        provisioningStartPDU.publicKey = z ? (byte) 1 : (byte) 0;
        if (z2) {
            b = AuthenticationMethod.StaticOOB.value;
        } else {
            b = AuthenticationMethod.NoOOB.value;
        }
        provisioningStartPDU.authenticationMethod = b;
        provisioningStartPDU.authenticationAction = (byte) 0;
        provisioningStartPDU.authenticationSize = (byte) 0;
        return provisioningStartPDU;
    }

    public void setAlgorithm(byte b) {
        this.algorithm = b;
    }

    public void setPublicKey(boolean z) {
        this.publicKey = z ? (byte) 1 : (byte) 0;
    }

    @Override // com.telink.ble.mesh.core.provisioning.pdu.PDU
    public byte[] toBytes() {
        return new byte[]{this.algorithm, this.publicKey, this.authenticationMethod, this.authenticationAction, this.authenticationSize};
    }
}
