package com.telink.ble.mesh.core.message.sarconfig;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.config.ConfigMessage;

/* loaded from: classes.dex */
public class SarReceiverGetMessage extends ConfigMessage {
    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return null;
    }

    public SarReceiverGetMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.CFG_SAR_RECEIVER_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_SAR_RECEIVER_STATUS.value;
    }
}
