package com.telink.ble.mesh.foundation.event;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.entity.ProvisioningDevice;
import com.telink.ble.mesh.foundation.Event;

/* loaded from: classes.dex */
public class ProvisioningEvent extends Event<String> implements Parcelable {
    public static final Parcelable.Creator<ProvisioningEvent> CREATOR = new Parcelable.Creator<ProvisioningEvent>() { // from class: com.telink.ble.mesh.foundation.event.ProvisioningEvent.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ProvisioningEvent createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ProvisioningEvent[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ProvisioningEvent createFromParcel(Parcel parcel) {
            return new ProvisioningEvent(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ProvisioningEvent[] newArray(int i) {
            return new ProvisioningEvent[i];
        }
    };
    public static final String EVENT_TYPE_CAPABILITY_RECEIVED = "com.telink.ble.mesh.EVENT_TYPE_CAPABILITY_RECEIVED";
    public static final String EVENT_TYPE_PROVISION_BEGIN = "com.telink.ble.mesh.EVENT_TYPE_PROVISION_BEGIN";
    public static final String EVENT_TYPE_PROVISION_FAIL = "com.telink.ble.mesh.EVENT_TYPE_PROVISION_FAIL";
    public static final String EVENT_TYPE_PROVISION_GET_REVISION = "com.telink.ble.mesh.EVENT_TYPE_PROVISION_GET_REVISION";
    public static final String EVENT_TYPE_PROVISION_SUCCESS = "com.telink.ble.mesh.EVENT_TYPE_PROVISION_SUCCESS";
    private String desc;
    private ProvisioningDevice provisioningDevice;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public ProvisioningEvent(Object obj, String str) {
        super(obj, str);
    }

    public ProvisioningEvent(Object obj, String str, ProvisioningDevice provisioningDevice) {
        super(obj, str);
        this.provisioningDevice = provisioningDevice;
    }

    public ProvisioningEvent(Object obj, String str, ProvisioningDevice provisioningDevice, String str2) {
        super(obj, str);
        this.provisioningDevice = provisioningDevice;
        this.desc = str2;
    }

    protected ProvisioningEvent(Parcel parcel) {
        this.provisioningDevice = (ProvisioningDevice) parcel.readParcelable(ProvisioningDevice.class.getClassLoader());
        this.desc = parcel.readString();
    }

    public ProvisioningDevice getProvisioningDevice() {
        return this.provisioningDevice;
    }

    public String getDesc() {
        return this.desc;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.provisioningDevice, i);
        parcel.writeString(this.desc);
    }
}
