package com.telink.ble.mesh.core.proxy;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ProxyAddAddressMessage extends ProxyConfigurationMessage {
    private int[] addressArray;

    @Override // com.telink.ble.mesh.core.proxy.ProxyConfigurationMessage
    public byte getOpcode() {
        return (byte) 1;
    }

    public ProxyAddAddressMessage(int[] iArr) {
        this.addressArray = iArr;
    }

    @Override // com.telink.ble.mesh.core.proxy.ProxyConfigurationMessage
    public byte[] toByteArray() {
        ByteBuffer byteBufferPut = ByteBuffer.allocate((this.addressArray.length * 2) + 1).order(ByteOrder.BIG_ENDIAN).put(getOpcode());
        for (int i : this.addressArray) {
            byteBufferPut.putShort((short) i);
        }
        return byteBufferPut.array();
    }
}
