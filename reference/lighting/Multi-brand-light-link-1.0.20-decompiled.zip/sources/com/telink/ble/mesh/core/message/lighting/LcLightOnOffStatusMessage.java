package com.telink.ble.mesh.core.message.lighting;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class LcLightOnOffStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<LcLightOnOffStatusMessage> CREATOR = new Parcelable.Creator<LcLightOnOffStatusMessage>() { // from class: com.telink.ble.mesh.core.message.lighting.LcLightOnOffStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ LcLightOnOffStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ LcLightOnOffStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LcLightOnOffStatusMessage createFromParcel(Parcel parcel) {
            return new LcLightOnOffStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LcLightOnOffStatusMessage[] newArray(int i) {
            return new LcLightOnOffStatusMessage[i];
        }
    };
    private static final int DATA_LEN_COMPLETE = 3;
    private boolean isComplete;
    private byte presentLightOnOff;
    private byte remainingTime;
    private byte targetLightOnOff;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public LcLightOnOffStatusMessage() {
        this.isComplete = false;
    }

    protected LcLightOnOffStatusMessage(Parcel parcel) {
        this.isComplete = false;
        this.presentLightOnOff = parcel.readByte();
        this.targetLightOnOff = parcel.readByte();
        this.remainingTime = parcel.readByte();
        this.isComplete = parcel.readByte() != 0;
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.presentLightOnOff = bArr[0];
        if (bArr.length >= 3) {
            this.isComplete = true;
            this.targetLightOnOff = bArr[1];
            this.remainingTime = bArr[2];
        }
    }

    public byte getPresentLightOnOff() {
        return this.presentLightOnOff;
    }

    public byte getTargetLightness() {
        return this.targetLightOnOff;
    }

    public byte getRemainingTime() {
        return this.remainingTime;
    }

    public boolean isComplete() {
        return this.isComplete;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.presentLightOnOff);
        parcel.writeByte(this.targetLightOnOff);
        parcel.writeByte(this.remainingTime);
        parcel.writeByte(this.isComplete ? (byte) 1 : (byte) 0);
    }
}
