package com.telink.ble.mesh.core.message.time;

import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.networking.AccessType;

/* loaded from: classes.dex */
public abstract class TimeMessage extends MeshMessage {
    public TimeMessage(int i, int i2) {
        this.destinationAddress = i;
        this.appKeyIndex = i2;
        this.accessType = AccessType.APPLICATION;
    }
}
