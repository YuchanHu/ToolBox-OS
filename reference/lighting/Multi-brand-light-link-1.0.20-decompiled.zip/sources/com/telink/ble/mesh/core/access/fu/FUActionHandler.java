package com.telink.ble.mesh.core.access.fu;

import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.TransferMode;
import com.telink.ble.mesh.entity.MeshUpdatingDevice;

/* loaded from: classes.dex */
interface FUActionHandler {
    void onActionComplete(boolean z, FUAction fUAction, String str);

    void onActionLog(String str, String str2, int i);

    void onDeviceUpdate(MeshUpdatingDevice meshUpdatingDevice, String str);

    boolean onMessagePrepared(MeshMessage meshMessage);

    void onTransferProgress(int i, BlobTransferType blobTransferType);

    void onTransferStart(TransferMode transferMode);
}
