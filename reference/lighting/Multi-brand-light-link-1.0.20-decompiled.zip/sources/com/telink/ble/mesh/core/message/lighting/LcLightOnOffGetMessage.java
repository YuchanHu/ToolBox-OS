package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class LcLightOnOffGetMessage extends LightingMessage {
    public static LcLightOnOffGetMessage getSimple(int i, int i2, int i3) {
        LcLightOnOffGetMessage lcLightOnOffGetMessage = new LcLightOnOffGetMessage(i, i2);
        lcLightOnOffGetMessage.setResponseMax(i3);
        return lcLightOnOffGetMessage;
    }

    public LcLightOnOffGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.LIGHT_LC_ONOFF_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.LIGHT_LC_ONOFF_STATUS.value;
    }
}
