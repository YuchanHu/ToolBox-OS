package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class NetKeyStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<NetKeyStatusMessage> CREATOR = new Parcelable.Creator<NetKeyStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.NetKeyStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ NetKeyStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ NetKeyStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public NetKeyStatusMessage createFromParcel(Parcel parcel) {
            return new NetKeyStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public NetKeyStatusMessage[] newArray(int i) {
            return new NetKeyStatusMessage[i];
        }
    };
    private int netKeyIndex;
    private int status;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public NetKeyStatusMessage() {
    }

    protected NetKeyStatusMessage(Parcel parcel) {
        this.status = parcel.readInt();
        this.netKeyIndex = parcel.readInt();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.status = bArr[0] & FUDistributor.UPDATE_TTL;
        this.netKeyIndex = MeshUtils.bytes2Integer(bArr, 1, 2, ByteOrder.LITTLE_ENDIAN);
    }

    public int getStatus() {
        return this.status;
    }

    public int getNetKeyIndex() {
        return this.netKeyIndex;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.status);
        parcel.writeInt(this.netKeyIndex);
    }
}
