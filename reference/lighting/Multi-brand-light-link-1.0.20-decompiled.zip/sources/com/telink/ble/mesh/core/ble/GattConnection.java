package com.telink.ble.mesh.core.ble;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import com.telink.ble.mesh.core.ble.GattRequest;
import com.telink.ble.mesh.core.proxy.ProxyPDU;
import com.telink.ble.mesh.util.Arrays;
import com.telink.ble.mesh.util.MeshLogger;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;

/* loaded from: classes.dex */
public class GattConnection extends BluetoothGattCallback {
    private static final int CONNECTION_TIMEOUT = 30000;
    private static final int CONN_STATE_CONNECTED = 2;
    private static final int CONN_STATE_CONNECTING = 1;
    private static final int CONN_STATE_DISCONNECTING = 3;
    private static final int CONN_STATE_IDLE = 0;
    private static final int DISCONNECTION_TIMEOUT = 2000;
    private static final int MTU_SIZE_DEFAULT = 23;
    private static final int MTU_SIZE_MAX = 517;
    private final Object COMMAND_PROCESSING_LOCK;
    private final Object CONNECTION_STATE_LOCK;
    private final String LOG_TAG;
    private long commandTimeoutMill;
    private final boolean discardStaleCallbacks;
    private AtomicBoolean isConnectWaiting;
    private boolean isRequestProcessing;
    private BluetoothDevice mBluetoothDevice;
    protected final Runnable mCommandTimeoutRunnable;
    private ConnectionCallback mConnectionCallback;
    private int mConnectionState;
    protected final Runnable mConnectionTimeoutRunnable;
    private Context mContext;
    protected final Runnable mDisconnectionTimeoutRunnable;
    private volatile BluetoothGatt mGatt;
    private final Queue<GattRequest> mGattRequestQueue;
    private Handler mHandler;
    protected final Handler mRequestTimeoutHandler;
    protected List<BluetoothGattService> mServices;
    protected final Runnable mServicesDiscoveringRunnable;
    private volatile int mtu;
    private byte[] proxyNotificationSegBuffer;
    boolean refreshed;

    public interface ConnectionCallback {
        void onConnected();

        void onDisconnected();

        void onNotify(UUID uuid, UUID uuid2, byte[] bArr);

        void onServicesDiscovered(List<BluetoothGattService> list);
    }

    private boolean gattStatusSuccess(int i) {
        return i == 0;
    }

    static /* synthetic */ Queue access$1000(GattConnection gattConnection) {
        return gattConnection.mGattRequestQueue;
    }

    static /* synthetic */ boolean access$1100(GattConnection gattConnection, GattRequest gattRequest) {
        return gattConnection.onRequestTimeout(gattRequest);
    }

    static /* synthetic */ void access$1200(GattConnection gattConnection, GattRequest gattRequest) {
        gattConnection.processRequest(gattRequest);
    }

    static /* synthetic */ void access$1300(GattConnection gattConnection) {
        gattConnection.onRequestComplete();
    }

    static /* synthetic */ boolean access$400(GattConnection gattConnection) {
        return gattConnection.discardStaleCallbacks;
    }

    static /* synthetic */ BluetoothGatt access$500(GattConnection gattConnection) {
        return gattConnection.mGatt;
    }

    static /* synthetic */ void access$600(GattConnection gattConnection) {
        gattConnection.onDisconnected();
    }

    static /* synthetic */ void access$700(GattConnection gattConnection, String str) {
        gattConnection.log(str);
    }

    static /* synthetic */ Object access$800(GattConnection gattConnection) {
        return gattConnection.CONNECTION_STATE_LOCK;
    }

    static /* synthetic */ int access$902(GattConnection gattConnection, int i) {
        gattConnection.mConnectionState = i;
        return i;
    }

    public GattConnection(Context context, HandlerThread handlerThread) {
        this(context, handlerThread, false);
    }

    public GattConnection(Context context, HandlerThread handlerThread, boolean z) {
        this.LOG_TAG = "GATT";
        this.CONNECTION_STATE_LOCK = new Object();
        this.mConnectionTimeoutRunnable = new ConnectionTimeoutRunnable(this, null);
        this.mDisconnectionTimeoutRunnable = new DisconnectionTimeoutRunnable(this, null);
        this.mServicesDiscoveringRunnable = new ServicesDiscoveringRunnable(this, null);
        this.mCommandTimeoutRunnable = new CommandTimeoutRunnable(this, null);
        this.mRequestTimeoutHandler = new Handler(Looper.getMainLooper());
        this.mGattRequestQueue = new ConcurrentLinkedQueue();
        this.COMMAND_PROCESSING_LOCK = new Object();
        this.isRequestProcessing = false;
        this.isConnectWaiting = new AtomicBoolean(false);
        this.commandTimeoutMill = 10000L;
        this.mtu = 23;
        this.refreshed = false;
        this.discardStaleCallbacks = z;
        this.mContext = context.getApplicationContext();
        if (handlerThread == null) {
            this.mHandler = new Handler();
        } else {
            this.mHandler = new Handler(handlerThread.getLooper());
        }
    }

    public void setConnectionCallback(ConnectionCallback connectionCallback) {
        this.mConnectionCallback = connectionCallback;
    }

    public boolean isConnected() {
        boolean z;
        synchronized (this.CONNECTION_STATE_LOCK) {
            z = this.mConnectionState == 2;
        }
        return z;
    }

    public boolean isDisconnected() {
        boolean z;
        synchronized (this.CONNECTION_STATE_LOCK) {
            z = this.mConnectionState == 0;
        }
        return z;
    }

    public boolean isPsmUuidSupport() {
        BluetoothGattService service;
        return (this.mGatt == null || (service = this.mGatt.getService(UUIDInfo.SERVICE_OTS)) == null || service.getCharacteristic(UUIDInfo.CHARACTERISTIC_IOS_PSM) == null) ? false : true;
    }

    public boolean isProxyNodeConnected() {
        return isProxyNodeConnected(false);
    }

    public boolean isProxyNodeConnected(boolean z) {
        return isConnected() && getProxyService(z) != null;
    }

    public boolean isUnPvNodeConnected() {
        return isConnected() && getProvisionService() != null;
    }

    public void proxyInit() {
        enableProxyNotify();
    }

    public void provisionInit() {
        enableProvisionNotify();
        enableProxyNotify();
    }

    public void sendMeshData(byte b, byte[] bArr) {
        byte[] bArr2;
        int i = this.mtu;
        int i2 = i - 3;
        boolean z = b == 3;
        int i3 = i - 4;
        if (bArr.length > i3) {
            int iCeil = (int) Math.ceil(bArr.length / i3);
            int i4 = 0;
            while (i4 < iCeil) {
                if (i4 != iCeil - 1) {
                    bArr2 = new byte[i2];
                    bArr2[0] = (byte) (i4 == 0 ? b | ProxyPDU.SAR_SEG_FIRST : b | ProxyPDU.SAR_SEG_CONTINUE);
                    System.arraycopy(bArr, i3 * i4, bArr2, 1, i3);
                } else {
                    byte b2 = (byte) (b | ProxyPDU.SAR_SEG_LAST);
                    int i5 = i3 * i4;
                    int length = bArr.length - i5;
                    byte[] bArr3 = new byte[length + 1];
                    bArr3[0] = b2;
                    System.arraycopy(bArr, i5, bArr3, 1, length);
                    bArr2 = bArr3;
                }
                log("send segment pkt: " + Arrays.bytesToHexString(bArr2, ":"));
                if (z) {
                    sendPvRequest(bArr2);
                } else {
                    sendProxyRequest(bArr2);
                }
                i4++;
            }
            return;
        }
        byte[] bArr4 = new byte[bArr.length + 1];
        bArr4[0] = b;
        System.arraycopy(bArr, 0, bArr4, 1, bArr.length);
        log("send unsegment pkt: " + Arrays.bytesToHexString(bArr4, ":"));
        if (z) {
            sendPvRequest(bArr4);
        } else {
            sendProxyRequest(bArr4);
        }
    }

    public void enableProvisionNotify() {
        BluetoothGattService provisionService = getProvisionService();
        if (provisionService == null) {
            log("provision service not found");
            return;
        }
        GattRequest gattRequestNewInstance = GattRequest.newInstance();
        gattRequestNewInstance.type = GattRequest.RequestType.ENABLE_NOTIFY;
        gattRequestNewInstance.serviceUUID = provisionService.getUuid();
        gattRequestNewInstance.characteristicUUID = UUIDInfo.CHARACTERISTIC_PB_OUT;
        sendRequest(gattRequestNewInstance);
        log("write ccc to provision service");
        GattRequest gattRequestNewInstance2 = GattRequest.newInstance();
        gattRequestNewInstance2.serviceUUID = provisionService.getUuid();
        gattRequestNewInstance2.characteristicUUID = UUIDInfo.CHARACTERISTIC_PB_OUT;
        gattRequestNewInstance2.descriptorUUID = UUIDInfo.DESCRIPTOR_CFG_UUID;
        gattRequestNewInstance2.data = new byte[]{1, 0};
        gattRequestNewInstance2.type = GattRequest.RequestType.WRITE_DESCRIPTOR;
        sendRequest(gattRequestNewInstance2);
    }

    public void enableProxyNotify() {
        BluetoothGattService proxyService = getProxyService(false);
        if (proxyService == null) {
            log("proxy service not found");
            return;
        }
        log("enable proxy notify");
        GattRequest gattRequestNewInstance = GattRequest.newInstance();
        gattRequestNewInstance.type = GattRequest.RequestType.ENABLE_NOTIFY;
        gattRequestNewInstance.serviceUUID = proxyService.getUuid();
        gattRequestNewInstance.characteristicUUID = UUIDInfo.CHARACTERISTIC_PROXY_OUT;
        sendRequest(gattRequestNewInstance);
        log("write ccc to proxy service");
        GattRequest gattRequestNewInstance2 = GattRequest.newInstance();
        gattRequestNewInstance2.serviceUUID = proxyService.getUuid();
        gattRequestNewInstance2.characteristicUUID = UUIDInfo.CHARACTERISTIC_PROXY_OUT;
        gattRequestNewInstance2.descriptorUUID = UUIDInfo.DESCRIPTOR_CFG_UUID;
        gattRequestNewInstance2.data = new byte[]{1, 0};
        gattRequestNewInstance2.type = GattRequest.RequestType.WRITE_DESCRIPTOR;
        sendRequest(gattRequestNewInstance2);
    }

    public boolean getOnlineStatus() {
        GattRequest gattRequestNewInstance = GattRequest.newInstance();
        if (!isConnected() || !checkOnlineStatusService()) {
            return false;
        }
        gattRequestNewInstance.serviceUUID = UUIDInfo.SERVICE_ONLINE_STATUS;
        gattRequestNewInstance.characteristicUUID = UUIDInfo.CHARACTERISTIC_ONLINE_STATUS;
        gattRequestNewInstance.data = new byte[]{1};
        gattRequestNewInstance.type = GattRequest.RequestType.WRITE_NO_RESPONSE;
        sendRequest(gattRequestNewInstance);
        return true;
    }

    private void sendPvRequest(byte[] bArr) {
        GattRequest gattRequestNewInstance = GattRequest.newInstance();
        gattRequestNewInstance.characteristicUUID = UUIDInfo.CHARACTERISTIC_PB_IN;
        BluetoothGattService provisionService = getProvisionService();
        if (provisionService == null) {
            return;
        }
        gattRequestNewInstance.serviceUUID = provisionService.getUuid();
        gattRequestNewInstance.data = (byte[]) bArr.clone();
        gattRequestNewInstance.type = GattRequest.RequestType.WRITE_NO_RESPONSE;
        sendRequest(gattRequestNewInstance);
    }

    private void sendProxyRequest(byte[] bArr) {
        GattRequest gattRequestNewInstance = GattRequest.newInstance();
        BluetoothGattService proxyService = getProxyService(false);
        if (proxyService == null) {
            return;
        }
        gattRequestNewInstance.serviceUUID = proxyService.getUuid();
        gattRequestNewInstance.characteristicUUID = UUIDInfo.CHARACTERISTIC_PROXY_IN;
        gattRequestNewInstance.data = (byte[]) bArr.clone();
        gattRequestNewInstance.type = GattRequest.RequestType.WRITE_NO_RESPONSE;
        sendRequest(gattRequestNewInstance);
    }

    public void enableOnlineStatus() {
        if (checkOnlineStatusService()) {
            GattRequest gattRequestNewInstance = GattRequest.newInstance();
            gattRequestNewInstance.type = GattRequest.RequestType.ENABLE_NOTIFY;
            gattRequestNewInstance.serviceUUID = UUIDInfo.SERVICE_ONLINE_STATUS;
            gattRequestNewInstance.characteristicUUID = UUIDInfo.CHARACTERISTIC_ONLINE_STATUS;
            sendRequest(gattRequestNewInstance);
        }
    }

    private boolean checkOnlineStatusService() {
        List<BluetoothGattService> list = this.mServices;
        if (list == null) {
            return false;
        }
        for (BluetoothGattService bluetoothGattService : list) {
            if (bluetoothGattService.getUuid().equals(UUIDInfo.SERVICE_ONLINE_STATUS)) {
                Iterator<BluetoothGattCharacteristic> it = bluetoothGattService.getCharacteristics().iterator();
                while (it.hasNext()) {
                    if (it.next().getUuid().equals(UUIDInfo.CHARACTERISTIC_ONLINE_STATUS)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private BluetoothGattService getProvisionService() {
        List<BluetoothGattService> list = this.mServices;
        if (list == null) {
            return null;
        }
        for (BluetoothGattService bluetoothGattService : list) {
            if (bluetoothGattService.getUuid().equals(UUIDInfo.SERVICE_PROVISION) || bluetoothGattService.getUuid().equals(UUIDInfo.SERVICE_MESH_FLEX)) {
                Iterator<BluetoothGattCharacteristic> it = bluetoothGattService.getCharacteristics().iterator();
                while (it.hasNext()) {
                    if (it.next().getUuid().equals(UUIDInfo.CHARACTERISTIC_PB_IN)) {
                        return bluetoothGattService;
                    }
                }
            }
        }
        return null;
    }

    private BluetoothGattService getProxyService(boolean z) {
        List<BluetoothGattService> list = this.mServices;
        if (list == null) {
            return null;
        }
        for (BluetoothGattService bluetoothGattService : list) {
            if (bluetoothGattService.getUuid().equals(UUIDInfo.SERVICE_PROXY) || (!z && bluetoothGattService.getUuid().equals(UUIDInfo.SERVICE_MESH_FLEX))) {
                Iterator<BluetoothGattCharacteristic> it = bluetoothGattService.getCharacteristics().iterator();
                while (it.hasNext()) {
                    if (it.next().getUuid().equals(UUIDInfo.CHARACTERISTIC_PROXY_IN)) {
                        return bluetoothGattService;
                    }
                }
            }
        }
        return null;
    }

    public void connect(BluetoothDevice bluetoothDevice) {
        if (bluetoothDevice.equals(this.mBluetoothDevice)) {
            connect();
            return;
        }
        this.mBluetoothDevice = bluetoothDevice;
        if (disconnect()) {
            log(" waiting for disconnect -- ");
            this.isConnectWaiting.set(true);
        } else {
            log(" already disconnected -- ");
            connect();
        }
    }

    public void connect() {
        synchronized (this.CONNECTION_STATE_LOCK) {
            int i = this.mConnectionState;
            if (i == 2) {
                onConnected();
                List<BluetoothGattService> list = this.mServices;
                if (list != null) {
                    onServicesDiscoveredComplete(list);
                }
            } else if (i == 0) {
                this.mtu = 23;
                this.mConnectionState = 1;
                this.mGatt = this.mBluetoothDevice.connectGatt(this.mContext, false, this, 2);
                if (this.mGatt == null) {
                    disconnect();
                    this.mConnectionState = 0;
                    onDisconnected();
                } else {
                    this.mHandler.postDelayed(this.mConnectionTimeoutRunnable, 30000L);
                }
            }
        }
    }

    public boolean disconnect() throws NoSuchMethodException, SecurityException {
        clear();
        synchronized (this.CONNECTION_STATE_LOCK) {
            if (this.mConnectionState == 0) {
                return false;
            }
            if (this.mGatt != null) {
                int i = this.mConnectionState;
                if (i == 2) {
                    this.mConnectionState = 3;
                    this.mGatt.disconnect();
                } else if (i == 1) {
                    this.mGatt.disconnect();
                    this.mGatt.close();
                    if (this.discardStaleCallbacks) {
                        this.mGatt = null;
                    }
                    this.mConnectionState = 0;
                    return false;
                }
                startDisconnectionCheck();
                return true;
            }
            this.mConnectionState = 0;
            return false;
        }
    }

    private void startDisconnectionCheck() {
        this.mHandler.removeCallbacks(this.mDisconnectionTimeoutRunnable);
        this.mHandler.postDelayed(this.mDisconnectionTimeoutRunnable, 2000L);
    }

    private void startServicesDiscovering() {
        long j = this.mBluetoothDevice.getBondState() == 12 ? 1600L : 300L;
        this.mHandler.removeCallbacks(this.mServicesDiscoveringRunnable);
        this.mHandler.postDelayed(this.mServicesDiscoveringRunnable, j);
    }

    private void clear() throws NoSuchMethodException, SecurityException {
        refreshCache();
        cancelCommandTimeoutTask();
        this.mGattRequestQueue.clear();
        this.isRequestProcessing = false;
        this.mHandler.removeCallbacksAndMessages(null);
    }

    private void onConnected() {
        this.mHandler.removeCallbacks(this.mConnectionTimeoutRunnable);
        ConnectionCallback connectionCallback = this.mConnectionCallback;
        if (connectionCallback != null) {
            connectionCallback.onConnected();
        }
    }

    public void requestConnectionPriority(int i) {
        if (this.mGatt != null) {
            this.mGatt.requestConnectionPriority(i);
        }
    }

    public boolean refreshCache() throws NoSuchMethodException, SecurityException {
        if (this.mGatt == null) {
            log("refresh error: gatt null");
            return false;
        }
        log("Device#refreshCache#prepare");
        try {
            final BluetoothGatt bluetoothGatt = this.mGatt;
            Method method = bluetoothGatt.getClass().getMethod("refresh", null);
            if (method != null) {
                boolean zBooleanValue = ((Boolean) method.invoke(bluetoothGatt, null)).booleanValue();
                if (zBooleanValue) {
                    this.mHandler.postDelayed(new Runnable() { // from class: com.telink.ble.mesh.core.ble.GattConnection.1
                        @Override // java.lang.Runnable
                        public void run() {
                            if (!GattConnection.access$400(GattConnection.this) || bluetoothGatt == GattConnection.access$500(GattConnection.this)) {
                                bluetoothGatt.discoverServices();
                            }
                        }
                    }, 0L);
                }
                return zBooleanValue;
            }
        } catch (Exception unused) {
            log("An exception occurs while refreshing device");
        }
        return false;
    }

    private void onServicesDiscoveredComplete(List<BluetoothGattService> list) {
        log("service discover complete");
        ConnectionCallback connectionCallback = this.mConnectionCallback;
        if (connectionCallback != null) {
            connectionCallback.onServicesDiscovered(list);
        }
        this.mGatt.requestMtu(MTU_SIZE_MAX);
    }

    private void printServiceInfo(List<BluetoothGattService> list) {
        StringBuilder sb = new StringBuilder("\n");
        for (BluetoothGattService bluetoothGattService : list) {
            sb.append(bluetoothGattService.getUuid().toString());
            sb.append("\n");
            for (BluetoothGattCharacteristic bluetoothGattCharacteristic : bluetoothGattService.getCharacteristics()) {
                sb.append("chara: \t");
                sb.append(bluetoothGattCharacteristic.getUuid().toString());
                sb.append("\n");
            }
        }
        log("services: " + ((Object) sb));
    }

    private void onDisconnected() {
        this.mHandler.removeCallbacks(this.mDisconnectionTimeoutRunnable);
        this.mHandler.removeCallbacks(this.mServicesDiscoveringRunnable);
        this.mServices = null;
        if (this.discardStaleCallbacks) {
            this.mGatt = null;
            this.proxyNotificationSegBuffer = null;
            this.refreshed = false;
        }
        if (this.isConnectWaiting.get()) {
            this.isConnectWaiting.set(false);
            connect();
        } else {
            ConnectionCallback connectionCallback = this.mConnectionCallback;
            if (connectionCallback != null) {
                connectionCallback.onDisconnected();
            }
        }
    }

    public String getMacAddress() {
        BluetoothDevice bluetoothDevice = this.mBluetoothDevice;
        if (bluetoothDevice == null) {
            return null;
        }
        return bluetoothDevice.getAddress();
    }

    public String getDeviceName() {
        BluetoothDevice bluetoothDevice = this.mBluetoothDevice;
        if (bluetoothDevice == null) {
            return null;
        }
        return bluetoothDevice.getName();
    }

    public int getMtu() {
        return this.mtu;
    }

    public boolean sendRequest(GattRequest gattRequest) {
        synchronized (this.CONNECTION_STATE_LOCK) {
            if (this.mConnectionState != 2) {
                return false;
            }
            synchronized (this.mGattRequestQueue) {
                this.mGattRequestQueue.add(gattRequest);
            }
            postRequest();
            return true;
        }
    }

    private synchronized void postRequest() {
        GattRequest gattRequestPeek;
        synchronized (this.COMMAND_PROCESSING_LOCK) {
            if (this.isRequestProcessing) {
                return;
            }
            synchronized (this.mGattRequestQueue) {
                if (!this.mGattRequestQueue.isEmpty() && (gattRequestPeek = this.mGattRequestQueue.peek()) != null) {
                    synchronized (this.COMMAND_PROCESSING_LOCK) {
                        this.isRequestProcessing = true;
                    }
                    processRequest(gattRequestPeek);
                }
            }
        }
    }

    private void processRequest(GattRequest gattRequest) {
        GattRequest.RequestType requestType = gattRequest.type;
        log("process request : " + gattRequest.toString(), 0);
        switch (AnonymousClass2.$SwitchMap$com$telink$ble$mesh$core$ble$GattRequest$RequestType[requestType.ordinal()]) {
            case 1:
                postCommandTimeoutTask();
                readCharacteristic(gattRequest);
                break;
            case 2:
                postCommandTimeoutTask();
                writeCharacteristic(gattRequest, 2);
                break;
            case 3:
                postCommandTimeoutTask();
                writeCharacteristic(gattRequest, 1);
                break;
            case 4:
                postCommandTimeoutTask();
                readDescriptor(gattRequest);
                break;
            case 5:
                postCommandTimeoutTask();
                writeDescriptor(gattRequest);
                break;
            case 6:
                enableNotification(gattRequest);
                break;
            case 7:
                disableNotification(gattRequest);
                break;
        }
    }

    /* renamed from: com.telink.ble.mesh.core.ble.GattConnection$2, reason: invalid class name */
    static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] $SwitchMap$com$telink$ble$mesh$core$ble$GattRequest$RequestType;

        static {
            int[] iArr = new int[GattRequest.RequestType.values().length];
            $SwitchMap$com$telink$ble$mesh$core$ble$GattRequest$RequestType = iArr;
            try {
                iArr[GattRequest.RequestType.READ.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$ble$GattRequest$RequestType[GattRequest.RequestType.WRITE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$ble$GattRequest$RequestType[GattRequest.RequestType.WRITE_NO_RESPONSE.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$ble$GattRequest$RequestType[GattRequest.RequestType.READ_DESCRIPTOR.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$ble$GattRequest$RequestType[GattRequest.RequestType.WRITE_DESCRIPTOR.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$ble$GattRequest$RequestType[GattRequest.RequestType.ENABLE_NOTIFY.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$ble$GattRequest$RequestType[GattRequest.RequestType.DISABLE_NOTIFY.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    private void postCommandTimeoutTask() {
        if (this.commandTimeoutMill <= 0) {
            return;
        }
        this.mRequestTimeoutHandler.removeCallbacksAndMessages(null);
        this.mRequestTimeoutHandler.postDelayed(this.mCommandTimeoutRunnable, this.commandTimeoutMill);
    }

    private void cancelCommandTimeoutTask() {
        this.mRequestTimeoutHandler.removeCallbacksAndMessages(null);
    }

    private void onNotify(BluetoothGattCharacteristic bluetoothGattCharacteristic, byte[] bArr) {
        UUID uuid = bluetoothGattCharacteristic.getUuid();
        UUID uuid2 = bluetoothGattCharacteristic.getService().getUuid();
        if (!uuid.equals(UUIDInfo.CHARACTERISTIC_PB_OUT) && !uuid.equals(UUIDInfo.CHARACTERISTIC_PROXY_OUT)) {
            ConnectionCallback connectionCallback = this.mConnectionCallback;
            if (connectionCallback != null) {
                connectionCallback.onNotify(uuid2, uuid, bArr);
                return;
            }
            return;
        }
        log("on notify -- " + Arrays.bytesToHexString(bArr, ":"), 0);
        if (bArr == null || bArr.length == 0) {
            log("empty packet received!", 3);
            return;
        }
        byte[] completePacket = getCompletePacket(bArr);
        if (completePacket == null) {
            log("waiting for segment pkt", 0);
            return;
        }
        log("completed notification data: " + Arrays.bytesToHexString(completePacket, ":"));
        if (completePacket.length <= 1) {
            log("complete notification length err", 3);
            return;
        }
        ConnectionCallback connectionCallback2 = this.mConnectionCallback;
        if (connectionCallback2 != null) {
            connectionCallback2.onNotify(uuid2, uuid, completePacket);
        }
    }

    private byte[] getCompletePacket(byte[] bArr) {
        byte b = bArr[0];
        byte b2 = (byte) (b & ProxyPDU.SAR_SEG_LAST);
        if (b2 == -128 || b2 == -64) {
            byte[] bArr2 = this.proxyNotificationSegBuffer;
            if (bArr2 != null) {
                if ((bArr2[0] & 63) == (b & 63) && bArr.length > 1) {
                    byte[] bArr3 = new byte[(bArr2.length + bArr.length) - 1];
                    System.arraycopy(bArr2, 0, bArr3, 0, bArr2.length);
                    System.arraycopy(bArr, 1, bArr3, this.proxyNotificationSegBuffer.length, bArr.length - 1);
                    if (b2 == -128) {
                        this.proxyNotificationSegBuffer = bArr3;
                        return null;
                    }
                    this.proxyNotificationSegBuffer = null;
                    return bArr3;
                }
                log("other segment ", 3);
            } else {
                log("segment first pkt no found", 3);
            }
        } else {
            if (b2 == 0) {
                return bArr;
            }
            if (b2 == 64) {
                bArr[0] = (byte) (b & 63);
                this.proxyNotificationSegBuffer = bArr;
                return null;
            }
        }
        return null;
    }

    private void onRequestError(String str) {
        GattRequest gattRequestPoll;
        GattRequest.Callback callback;
        log("request error: " + str);
        synchronized (this.mGattRequestQueue) {
            gattRequestPoll = this.mGattRequestQueue.poll();
        }
        if (gattRequestPoll == null || (callback = gattRequestPoll.callback) == null) {
            return;
        }
        callback.error(gattRequestPoll, str);
    }

    private boolean onRequestTimeout(GattRequest gattRequest) {
        log("gatt request timeout", 0);
        GattRequest.Callback callback = gattRequest.callback;
        if (callback != null) {
            return callback.timeout(gattRequest);
        }
        return false;
    }

    private void onRequestSuccess(byte[] bArr) {
        GattRequest gattRequestPoll = this.mGattRequestQueue.poll();
        if (gattRequestPoll != null) {
            log("request success: tag - " + gattRequestPoll.tag, 0);
            GattRequest.Callback callback = gattRequestPoll.callback;
            if (callback != null) {
                callback.success(gattRequestPoll, bArr);
                return;
            }
            return;
        }
        log("request not found");
    }

    private void onRequestComplete() {
        log("gatt request completed", 0);
        synchronized (this.COMMAND_PROCESSING_LOCK) {
            if (this.isRequestProcessing) {
                this.isRequestProcessing = false;
            }
        }
        postRequest();
    }

    public void enableNotification(GattRequest gattRequest) {
        String str;
        UUID uuid = gattRequest.serviceUUID;
        UUID uuid2 = gattRequest.characteristicUUID;
        BluetoothGattService service = this.mGatt.getService(uuid);
        boolean z = false;
        if (service != null) {
            BluetoothGattCharacteristic bluetoothGattCharacteristicFindNotifyCharacteristic = findNotifyCharacteristic(service, uuid2);
            if (bluetoothGattCharacteristicFindNotifyCharacteristic != null) {
                if (this.mGatt.setCharacteristicNotification(bluetoothGattCharacteristicFindNotifyCharacteristic, true)) {
                    str = "";
                    z = true;
                } else {
                    str = "enable notification error";
                }
            } else {
                str = "no characteristic";
            }
        } else {
            str = "service is not offered by the remote device";
        }
        if (!z) {
            onRequestError("enable notification error: " + str + " - " + uuid2);
        } else {
            onRequestSuccess(null);
        }
        onRequestComplete();
    }

    private void disableNotification(GattRequest gattRequest) {
        String str;
        UUID uuid = gattRequest.serviceUUID;
        UUID uuid2 = gattRequest.characteristicUUID;
        BluetoothGattService service = this.mGatt.getService(uuid);
        boolean z = false;
        if (service != null) {
            BluetoothGattCharacteristic bluetoothGattCharacteristicFindNotifyCharacteristic = findNotifyCharacteristic(service, uuid2);
            if (bluetoothGattCharacteristicFindNotifyCharacteristic != null) {
                if (this.mGatt.setCharacteristicNotification(bluetoothGattCharacteristicFindNotifyCharacteristic, false)) {
                    z = true;
                    str = "";
                } else {
                    str = "disable notification error";
                }
            } else {
                str = "no characteristic";
            }
        } else {
            str = "service is not offered by the remote device";
        }
        if (!z) {
            String str2 = "disable notification error: " + str + " - " + uuid2;
            log(str2);
            onRequestError(str2);
        } else {
            onRequestSuccess(null);
        }
        onRequestComplete();
    }

    private void readDescriptor(GattRequest gattRequest) {
        String str;
        UUID uuid = gattRequest.serviceUUID;
        UUID uuid2 = gattRequest.characteristicUUID;
        UUID uuid3 = gattRequest.descriptorUUID;
        BluetoothGattService service = this.mGatt.getService(uuid);
        boolean z = false;
        if (service != null) {
            BluetoothGattCharacteristic characteristic = service.getCharacteristic(uuid2);
            if (characteristic != null) {
                BluetoothGattDescriptor descriptor = characteristic.getDescriptor(uuid3);
                if (descriptor != null) {
                    if (this.mGatt.readDescriptor(descriptor)) {
                        z = true;
                        str = "";
                    } else {
                        str = "read descriptor error";
                    }
                } else {
                    str = "read descriptor error - descriptor not found";
                }
            } else {
                str = "read characteristic error - characteristic not found";
            }
        } else {
            str = "service is not offered by the remote device";
        }
        if (z) {
            return;
        }
        onRequestError(str);
        onRequestComplete();
    }

    private void writeDescriptor(GattRequest gattRequest) {
        String str;
        UUID uuid = gattRequest.serviceUUID;
        UUID uuid2 = gattRequest.characteristicUUID;
        UUID uuid3 = gattRequest.descriptorUUID;
        byte[] bArr = gattRequest.data;
        BluetoothGattService service = this.mGatt.getService(uuid);
        boolean z = false;
        if (service != null) {
            BluetoothGattCharacteristic characteristic = service.getCharacteristic(uuid2);
            if (characteristic != null) {
                BluetoothGattDescriptor descriptor = characteristic.getDescriptor(uuid3);
                if (descriptor != null) {
                    descriptor.setValue(bArr);
                    if (this.mGatt.writeDescriptor(descriptor)) {
                        z = true;
                        str = "";
                    } else {
                        str = "write descriptor error";
                    }
                } else {
                    str = "no descriptor";
                }
            } else {
                str = "no characteristic";
            }
        } else {
            str = "service is not offered by the remote device";
        }
        if (z) {
            return;
        }
        onRequestError(str);
        onRequestComplete();
    }

    private void readCharacteristic(GattRequest gattRequest) {
        String str;
        UUID uuid = gattRequest.serviceUUID;
        UUID uuid2 = gattRequest.characteristicUUID;
        BluetoothGattService service = this.mGatt.getService(uuid);
        boolean z = false;
        if (service != null) {
            BluetoothGattCharacteristic characteristic = service.getCharacteristic(uuid2);
            if (characteristic != null) {
                if (this.mGatt.readCharacteristic(characteristic)) {
                    z = true;
                    str = "";
                } else {
                    str = "read characteristic error";
                }
            } else {
                str = "read characteristic error - characteristic not found";
            }
        } else {
            str = "service is not offered by the remote device";
        }
        if (z) {
            return;
        }
        onRequestError(str);
        onRequestComplete();
    }

    private void writeCharacteristic(GattRequest gattRequest, int i) {
        String str;
        UUID uuid = gattRequest.serviceUUID;
        UUID uuid2 = gattRequest.characteristicUUID;
        byte[] bArr = gattRequest.data;
        BluetoothGattService service = this.mGatt.getService(uuid);
        boolean z = false;
        if (service != null) {
            BluetoothGattCharacteristic bluetoothGattCharacteristicFindWritableCharacteristic = findWritableCharacteristic(service, uuid2, i);
            if (bluetoothGattCharacteristicFindWritableCharacteristic != null) {
                bluetoothGattCharacteristicFindWritableCharacteristic.setValue(bArr);
                bluetoothGattCharacteristicFindWritableCharacteristic.setWriteType(i);
                if (this.mGatt.writeCharacteristic(bluetoothGattCharacteristicFindWritableCharacteristic)) {
                    z = true;
                    str = "";
                } else {
                    str = "write characteristic error";
                }
            } else {
                str = "no characteristic";
            }
        } else {
            str = "service is not offered by the remote device";
        }
        if (z) {
            return;
        }
        onRequestError(str);
        onRequestComplete();
    }

    private void requestMtu(GattRequest gattRequest) {
        boolean z;
        String str;
        UUID uuid = gattRequest.serviceUUID;
        UUID uuid2 = gattRequest.characteristicUUID;
        byte[] bArr = gattRequest.data;
        if (this.mGatt.requestMtu(gattRequest.mtu)) {
            z = true;
            str = "";
        } else {
            z = false;
            str = "write characteristic error";
        }
        if (z) {
            return;
        }
        onRequestError(str);
        onRequestComplete();
    }

    private BluetoothGattCharacteristic findWritableCharacteristic(BluetoothGattService bluetoothGattService, UUID uuid, int i) {
        int i2 = i == 1 ? 4 : 8;
        for (BluetoothGattCharacteristic bluetoothGattCharacteristic : bluetoothGattService.getCharacteristics()) {
            if ((bluetoothGattCharacteristic.getProperties() & i2) != 0 && uuid.equals(bluetoothGattCharacteristic.getUuid())) {
                return bluetoothGattCharacteristic;
            }
        }
        return null;
    }

    private BluetoothGattCharacteristic findNotifyCharacteristic(BluetoothGattService bluetoothGattService, UUID uuid) {
        BluetoothGattCharacteristic next;
        List<BluetoothGattCharacteristic> characteristics = bluetoothGattService.getCharacteristics();
        Iterator<BluetoothGattCharacteristic> it = characteristics.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            if ((next.getProperties() & 16) != 0 && uuid.equals(next.getUuid())) {
                break;
            }
        }
        if (next != null) {
            return next;
        }
        for (BluetoothGattCharacteristic bluetoothGattCharacteristic : characteristics) {
            if ((bluetoothGattCharacteristic.getProperties() & 32) != 0 && uuid.equals(bluetoothGattCharacteristic.getUuid())) {
                return bluetoothGattCharacteristic;
            }
        }
        return next;
    }

    @Override // android.bluetooth.BluetoothGattCallback
    public void onPhyUpdate(BluetoothGatt bluetoothGatt, int i, int i2, int i3) {
        super.onPhyUpdate(bluetoothGatt, i, i2, i3);
        log(String.format(Locale.getDefault(), "onPhyUpdate txPhy-%d rxPhy-%d status-%d", Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3)));
    }

    @Override // android.bluetooth.BluetoothGattCallback
    public void onPhyRead(BluetoothGatt bluetoothGatt, int i, int i2, int i3) {
        super.onPhyRead(bluetoothGatt, i, i2, i3);
    }

    @Override // android.bluetooth.BluetoothGattCallback
    public void onConnectionStateChange(BluetoothGatt bluetoothGatt, int i, int i2) {
        if (!this.discardStaleCallbacks || bluetoothGatt == this.mGatt) {
            log("onConnectionStateChange  status :" + i + " state : " + i2);
            if (i2 == 2) {
                synchronized (this.CONNECTION_STATE_LOCK) {
                    this.mConnectionState = 2;
                }
                onConnected();
                startServicesDiscovering();
                return;
            }
            synchronized (this.CONNECTION_STATE_LOCK) {
                log("Close");
                if (this.mGatt != null) {
                    this.mGatt.close();
                }
                clear();
                this.mConnectionState = 0;
                onDisconnected();
            }
        }
    }

    public void onConnectionUpdated(BluetoothGatt bluetoothGatt, int i, int i2, int i3, int i4) {
        log(String.format(Locale.getDefault(), "gatt connect updated : interval=%d latency=%d timeout=%d st=%d", Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3), Integer.valueOf(i4)));
    }

    @Override // android.bluetooth.BluetoothGattCallback
    public void onServicesDiscovered(BluetoothGatt bluetoothGatt, int i) throws NoSuchMethodException, SecurityException {
        if (!this.discardStaleCallbacks || bluetoothGatt == this.mGatt) {
            if (i == 0) {
                List<BluetoothGattService> services = bluetoothGatt.getServices();
                this.mServices = services;
                printServices(services);
                if (!this.refreshed) {
                    boolean zRefreshCache = refreshCache();
                    this.refreshed = true;
                    if (!this.discardStaleCallbacks || zRefreshCache) {
                        return;
                    }
                }
                onServicesDiscoveredComplete(services);
                return;
            }
            log("Service discovery failed");
            disconnect();
        }
    }

    private void printServices(List<BluetoothGattService> list) {
        StringBuilder sb = new StringBuilder("\n");
        for (BluetoothGattService bluetoothGattService : list) {
            sb.append(bluetoothGattService.getUuid().toString());
            sb.append("\n");
            for (BluetoothGattCharacteristic bluetoothGattCharacteristic : bluetoothGattService.getCharacteristics()) {
                sb.append("chara: \t");
                sb.append(bluetoothGattCharacteristic.getUuid().toString());
                sb.append("\n");
            }
        }
        MeshLogger.d("services: " + sb.toString());
    }

    @Override // android.bluetooth.BluetoothGattCallback
    public void onCharacteristicRead(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic bluetoothGattCharacteristic, int i) {
        if (!this.discardStaleCallbacks || bluetoothGatt == this.mGatt) {
            super.onCharacteristicRead(bluetoothGatt, bluetoothGattCharacteristic, i);
            cancelCommandTimeoutTask();
            if (gattStatusSuccess(i)) {
                onRequestSuccess(bluetoothGattCharacteristic.getValue());
            } else {
                onRequestError("read characteristic failed");
            }
            onRequestComplete();
        }
    }

    @Override // android.bluetooth.BluetoothGattCallback
    public void onCharacteristicWrite(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic bluetoothGattCharacteristic, int i) {
        if (!this.discardStaleCallbacks || bluetoothGatt == this.mGatt) {
            super.onCharacteristicWrite(bluetoothGatt, bluetoothGattCharacteristic, i);
            cancelCommandTimeoutTask();
            if (gattStatusSuccess(i)) {
                onRequestSuccess(null);
            } else {
                onRequestError("write characteristic fail");
            }
            onRequestComplete();
        }
    }

    @Override // android.bluetooth.BluetoothGattCallback
    public void onCharacteristicChanged(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic bluetoothGattCharacteristic) {
        if (!this.discardStaleCallbacks || bluetoothGatt == this.mGatt) {
            super.onCharacteristicChanged(bluetoothGatt, bluetoothGattCharacteristic);
            onNotify(bluetoothGattCharacteristic, bluetoothGattCharacteristic.getValue());
        }
    }

    @Override // android.bluetooth.BluetoothGattCallback
    public void onDescriptorRead(BluetoothGatt bluetoothGatt, BluetoothGattDescriptor bluetoothGattDescriptor, int i) {
        if (!this.discardStaleCallbacks || bluetoothGatt == this.mGatt) {
            super.onDescriptorRead(bluetoothGatt, bluetoothGattDescriptor, i);
            cancelCommandTimeoutTask();
            if (gattStatusSuccess(i)) {
                onRequestSuccess(bluetoothGattDescriptor.getValue());
            } else {
                onRequestError("read descriptor fail");
            }
            onRequestComplete();
        }
    }

    @Override // android.bluetooth.BluetoothGattCallback
    public void onDescriptorWrite(BluetoothGatt bluetoothGatt, BluetoothGattDescriptor bluetoothGattDescriptor, int i) {
        if (!this.discardStaleCallbacks || bluetoothGatt == this.mGatt) {
            super.onDescriptorWrite(bluetoothGatt, bluetoothGattDescriptor, i);
            cancelCommandTimeoutTask();
            if (gattStatusSuccess(i)) {
                onRequestSuccess(null);
            } else {
                onRequestError("write descriptor fail");
            }
            onRequestComplete();
        }
    }

    @Override // android.bluetooth.BluetoothGattCallback
    public void onReliableWriteCompleted(BluetoothGatt bluetoothGatt, int i) {
        super.onReliableWriteCompleted(bluetoothGatt, i);
    }

    @Override // android.bluetooth.BluetoothGattCallback
    public void onReadRemoteRssi(BluetoothGatt bluetoothGatt, int i, int i2) {
        super.onReadRemoteRssi(bluetoothGatt, i, i2);
    }

    @Override // android.bluetooth.BluetoothGattCallback
    public void onMtuChanged(BluetoothGatt bluetoothGatt, int i, int i2) {
        if (!this.discardStaleCallbacks || bluetoothGatt == this.mGatt) {
            log("onMtuChanged: " + i);
            super.onMtuChanged(bluetoothGatt, i, i2);
            if (gattStatusSuccess(i2)) {
                this.mtu = i;
            }
            cancelCommandTimeoutTask();
            if (i2 == 0) {
                onRequestSuccess(null);
            } else {
                onRequestError("request mtu callback fail");
            }
            MeshLogger.d("mtu changed : " + i);
            onRequestComplete();
        }
    }

    private final class ConnectionTimeoutRunnable implements Runnable {
        private ConnectionTimeoutRunnable() {
        }

        /* synthetic */ ConnectionTimeoutRunnable(GattConnection gattConnection, AnonymousClass1 anonymousClass1) {
            this();
        }

        @Override // java.lang.Runnable
        public void run() {
            if (GattConnection.this.disconnect()) {
                return;
            }
            GattConnection.access$600(GattConnection.this);
        }
    }

    private final class DisconnectionTimeoutRunnable implements Runnable {
        private DisconnectionTimeoutRunnable() {
        }

        /* synthetic */ DisconnectionTimeoutRunnable(GattConnection gattConnection, AnonymousClass1 anonymousClass1) {
            this();
        }

        @Override // java.lang.Runnable
        public void run() {
            GattConnection.access$700(GattConnection.this, "disconnection timeout");
            synchronized (GattConnection.access$800(GattConnection.this)) {
                if (GattConnection.access$500(GattConnection.this) != null) {
                    GattConnection.access$500(GattConnection.this).disconnect();
                    GattConnection.access$500(GattConnection.this).close();
                }
                GattConnection.access$902(GattConnection.this, 0);
                GattConnection.access$600(GattConnection.this);
            }
        }
    }

    private final class ServicesDiscoveringRunnable implements Runnable {
        private ServicesDiscoveringRunnable() {
        }

        /* synthetic */ ServicesDiscoveringRunnable(GattConnection gattConnection, AnonymousClass1 anonymousClass1) {
            this();
        }

        @Override // java.lang.Runnable
        public void run() throws NoSuchMethodException, SecurityException {
            if (GattConnection.access$500(GattConnection.this) == null || !GattConnection.access$500(GattConnection.this).discoverServices()) {
                GattConnection.this.disconnect();
            } else {
                GattConnection.access$700(GattConnection.this, "start services discovering");
            }
        }
    }

    private final class CommandTimeoutRunnable implements Runnable {
        private CommandTimeoutRunnable() {
        }

        /* synthetic */ CommandTimeoutRunnable(GattConnection gattConnection, AnonymousClass1 anonymousClass1) {
            this();
        }

        @Override // java.lang.Runnable
        public void run() {
            synchronized (GattConnection.access$1000(GattConnection.this)) {
                GattRequest gattRequest = (GattRequest) GattConnection.access$1000(GattConnection.this).peek();
                if (gattRequest != null) {
                    boolean zAccess$1100 = GattConnection.access$1100(GattConnection.this, gattRequest);
                    GattConnection.access$700(GattConnection.this, "retry timeout request ? " + zAccess$1100);
                    if (zAccess$1100) {
                        GattConnection.access$1200(GattConnection.this, gattRequest);
                    } else {
                        gattRequest.clear();
                        GattConnection.access$1000(GattConnection.this).poll();
                        GattConnection.access$1300(GattConnection.this);
                    }
                }
            }
        }
    }

    private String getGattStatusDesc(int i) {
        if (i == 0) {
            return "success";
        }
        if (i == 13) {
            return "invalid attribute length";
        }
        if (i == 15) {
            return "insufficient encryption";
        }
        if (i == 143) {
            return "connection congested";
        }
        if (i == 257) {
            return "failure";
        }
        if (i == 2) {
            return "read not permitted";
        }
        if (i == 3) {
            return "write not permitted";
        }
        if (i == 5) {
            return "insufficient authentication";
        }
        if (i == 6) {
            return "request not supported";
        }
        if (i == 7) {
            return "invalid offset";
        }
        return "unknown";
    }

    private void log(String str) {
        log(str, 1);
    }

    private void log(String str, int i) {
        MeshLogger.log(str, "GATT", i);
    }
}
