package com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;
import com.telink.ble.mesh.util.Arrays;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class BlobChunkTransferMessage extends UpdatingMessage {
    private byte[] chunkData;
    private int chunkNumber;

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return -1;
    }

    public BlobChunkTransferMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.BLOB_CHUNK_TRANSFER.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(this.chunkData.length + 2).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.chunkNumber).put(this.chunkData).array();
    }

    public String toString() {
        return "BlobChunkTransferMessage{chunkNumber=" + this.chunkNumber + ", chunkData=" + Arrays.bytesToHexString(this.chunkData) + '}';
    }

    public void setChunkNumber(int i) {
        this.chunkNumber = i;
    }

    public void setChunkData(byte[] bArr) {
        this.chunkData = bArr;
    }

    public static BlobChunkTransferMessage getSimple(int i, int i2, int i3, byte[] bArr) {
        BlobChunkTransferMessage blobChunkTransferMessage = new BlobChunkTransferMessage(i, i2);
        blobChunkTransferMessage.setResponseMax(1);
        blobChunkTransferMessage.chunkNumber = i3;
        blobChunkTransferMessage.chunkData = bArr;
        return blobChunkTransferMessage;
    }
}
