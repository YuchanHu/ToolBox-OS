package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class LightnessRangeGetMessage extends LightingMessage {
    public static LightnessRangeGetMessage getSimple(int i, int i2, int i3) {
        LightnessRangeGetMessage lightnessRangeGetMessage = new LightnessRangeGetMessage(i, i2);
        lightnessRangeGetMessage.setResponseMax(i3);
        return lightnessRangeGetMessage;
    }

    public LightnessRangeGetMessage(int i, int i2) {
        super(i, i2);
    }

    public LightnessRangeGetMessage() {
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.LIGHTNESS_RANGE_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.LIGHTNESS_RANGE_STATUS.value;
    }
}
