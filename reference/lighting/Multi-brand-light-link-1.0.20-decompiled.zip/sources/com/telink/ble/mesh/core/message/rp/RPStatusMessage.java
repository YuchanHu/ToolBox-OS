package com.telink.ble.mesh.core.message.rp;

import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public abstract class RPStatusMessage extends StatusMessage {
    public static final byte CODE_INVALID_STATE = 2;
    public static final byte CODE_LIMITED_RESOURCES = 3;
    public static final byte CODE_LINK_CANNOT_OPEN = 4;
    public static final byte CODE_LINK_CLOSED_AS_CANNOT_DELIVER_PDU_OUTBOUND_REPORT = 12;
    public static final byte CODE_LINK_CLOSED_AS_CANNOT_DELIVER_PDU_REPORT = 11;
    public static final byte CODE_LINK_CLOSED_AS_CANNOT_RECEIVE_PDU = 9;
    public static final byte CODE_LINK_CLOSED_AS_CANNOT_SEND_PDU = 10;
    public static final byte CODE_LINK_CLOSED_BY_CLIENT = 8;
    public static final byte CODE_LINK_CLOSED_BY_DEVICE = 6;
    public static final byte CODE_LINK_CLOSED_BY_SERVER = 7;
    public static final byte CODE_LINK_OPEN_FAILED = 5;
    public static final byte CODE_SCANNING_CANNOT_START = 1;
    public static final byte CODE_SUCCESS = 0;
}
