package com.telink.ble.mesh.core.message.rp;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;
import com.telink.ble.mesh.util.Arrays;

/* loaded from: classes.dex */
public class ProvisioningPDUReportMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<ProvisioningPDUReportMessage> CREATOR = new Parcelable.Creator<ProvisioningPDUReportMessage>() { // from class: com.telink.ble.mesh.core.message.rp.ProvisioningPDUReportMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ProvisioningPDUReportMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ProvisioningPDUReportMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ProvisioningPDUReportMessage createFromParcel(Parcel parcel) {
            return new ProvisioningPDUReportMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ProvisioningPDUReportMessage[] newArray(int i) {
            return new ProvisioningPDUReportMessage[i];
        }
    };
    private byte inboundPDUNumber;
    private byte[] provisioningPDU;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public ProvisioningPDUReportMessage() {
    }

    protected ProvisioningPDUReportMessage(Parcel parcel) {
        this.inboundPDUNumber = parcel.readByte();
        this.provisioningPDU = parcel.createByteArray();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.inboundPDUNumber = bArr[0];
        if (bArr.length > 1) {
            int length = bArr.length - 1;
            byte[] bArr2 = new byte[length];
            this.provisioningPDU = bArr2;
            System.arraycopy(bArr, 1, bArr2, 0, length);
        }
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.inboundPDUNumber);
        parcel.writeByteArray(this.provisioningPDU);
    }

    public byte getInboundPDUNumber() {
        return this.inboundPDUNumber;
    }

    public byte[] getProvisioningPDU() {
        return this.provisioningPDU;
    }

    public String toString() {
        return "ProvisioningPDUReportMessage{inboundPDUNumber=" + ((int) this.inboundPDUNumber) + ", provisioningPDU=" + Arrays.bytesToHexString(this.provisioningPDU) + '}';
    }
}
