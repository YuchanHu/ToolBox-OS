package com.telink.ble.mesh.core.message.scene;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;

/* loaded from: classes.dex */
public class SceneStoreMessage extends GenericMessage {
    private boolean ack;
    private int sceneNumber;

    public static SceneStoreMessage getSimple(int i, int i2, int i3, boolean z, int i4) {
        SceneStoreMessage sceneStoreMessage = new SceneStoreMessage(i, i2);
        sceneStoreMessage.sceneNumber = i3;
        sceneStoreMessage.ack = z;
        sceneStoreMessage.setResponseMax(i4);
        return sceneStoreMessage;
    }

    public SceneStoreMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return this.ack ? Opcode.SCENE_REG_STATUS.value : super.getResponseOpcode();
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.SCENE_STORE : Opcode.SCENE_STORE_NOACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        int i = this.sceneNumber;
        return new byte[]{(byte) i, (byte) (i >> 8)};
    }

    public void setSceneNumber(int i) {
        this.sceneNumber = i;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }
}
