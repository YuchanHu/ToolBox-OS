package com.telink.ble.mesh.core.message.fastpv;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class MeshSetAddressMessage extends GenericMessage {
    private byte[] mac;
    private int newMeshAddress;

    public MeshSetAddressMessage(int i, int i2) {
        super(i, i2);
    }

    public static MeshSetAddressMessage getSimple(int i, int i2, byte[] bArr, int i3) {
        MeshSetAddressMessage meshSetAddressMessage = new MeshSetAddressMessage(i, i2);
        meshSetAddressMessage.setResponseMax(1);
        meshSetAddressMessage.mac = bArr;
        meshSetAddressMessage.newMeshAddress = i3;
        return meshSetAddressMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.VD_MESH_ADDR_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.VD_MESH_ADDR_SET_STS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).put(this.mac).putShort((short) this.newMeshAddress).array();
    }

    public void setMac(byte[] bArr) {
        this.mac = bArr;
    }

    public void setNewMeshAddress(int i) {
        this.newMeshAddress = i;
    }
}
