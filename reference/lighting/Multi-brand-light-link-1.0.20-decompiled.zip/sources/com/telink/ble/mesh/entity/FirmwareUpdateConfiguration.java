package com.telink.ble.mesh.entity;

import com.telink.ble.mesh.core.access.fu.BlobTransferType;
import com.telink.ble.mesh.core.access.fu.DistributorType;
import com.telink.ble.mesh.core.access.fu.FUCallback;
import com.telink.ble.mesh.core.access.fu.FUState;
import com.telink.ble.mesh.core.access.fu.UpdatePolicy;
import com.telink.ble.mesh.core.networking.ExtendBearerMode;
import java.util.Arrays;
import java.util.List;

/* loaded from: classes.dex */
public class FirmwareUpdateConfiguration {
    private int appKeyIndex;
    private FUCallback callback;
    private ExtendBearerMode extendBearerMode;
    private byte[] firmwareData;
    private int groupAddress;
    private byte[] metadata;
    private int proxyAddress;
    private List<MeshUpdatingDevice> updatingDevices;
    private long blobId = -8613303245920329199L;
    private byte[] firmwareId = {1, 2, 3, 4};
    private int firmwareIndex = 0;
    private DistributorType distributorType = DistributorType.PHONE;
    private UpdatePolicy updatePolicy = UpdatePolicy.VerifyAndApply;
    private boolean isContinue = false;
    private int distributorAddress = 0;
    private long networkInterval = 240;

    public FirmwareUpdateConfiguration(List<MeshUpdatingDevice> list, byte[] bArr, byte[] bArr2, int i, int i2) {
        this.updatingDevices = list;
        this.firmwareData = bArr;
        this.metadata = bArr2;
        this.appKeyIndex = i;
        this.groupAddress = i2;
    }

    public List<MeshUpdatingDevice> getUpdatingDevices() {
        return this.updatingDevices;
    }

    public byte[] getFirmwareData() {
        return this.firmwareData;
    }

    public int getAppKeyIndex() {
        return this.appKeyIndex;
    }

    public int getGroupAddress() {
        return this.groupAddress;
    }

    public long getBlobId() {
        return this.blobId;
    }

    public ExtendBearerMode getExtendBearerMode() {
        return this.extendBearerMode;
    }

    public void setExtendBearerMode(ExtendBearerMode extendBearerMode) {
        this.extendBearerMode = extendBearerMode;
    }

    public byte[] getMetadata() {
        return this.metadata;
    }

    public byte[] getFirmwareId() {
        return this.firmwareId;
    }

    public void setFirmwareId(byte[] bArr) {
        this.firmwareId = bArr;
    }

    public int getFirmwareIndex() {
        return this.firmwareIndex;
    }

    public void setFirmwareIndex(int i) {
        this.firmwareIndex = i;
    }

    public FUCallback getCallback() {
        return this.callback;
    }

    public void setCallback(FUCallback fUCallback) {
        this.callback = fUCallback;
    }

    public UpdatePolicy getUpdatePolicy() {
        return this.updatePolicy;
    }

    public DistributorType getDistributorType() {
        return this.distributorType;
    }

    public void setDistributorType(DistributorType distributorType) {
        this.distributorType = distributorType;
    }

    public void setUpdatePolicy(UpdatePolicy updatePolicy) {
        this.updatePolicy = updatePolicy;
    }

    public boolean isContinue() {
        return this.isContinue;
    }

    public void setContinue(boolean z) {
        this.isContinue = z;
    }

    public int getDistributorAddress() {
        return this.distributorAddress;
    }

    public void setDistributorAddress(int i) {
        this.distributorAddress = i;
    }

    public void dispatchTransferProgress(int i, BlobTransferType blobTransferType) {
        FUCallback fUCallback = this.callback;
        if (fUCallback != null) {
            fUCallback.onTransferProgress(i, blobTransferType);
        }
    }

    public long getNetworkInterval() {
        return this.networkInterval;
    }

    public void setNetworkInterval(long j) {
        this.networkInterval = j;
    }

    public void dispatchLogInfo(String str, String str2, int i) {
        FUCallback fUCallback = this.callback;
        if (fUCallback != null) {
            fUCallback.onLog(str, str2, i);
        }
    }

    public void dispatchFUState(FUState fUState, String str) {
        FUCallback fUCallback = this.callback;
        if (fUCallback != null) {
            fUCallback.onStateUpdated(fUState, str);
        }
    }

    public void dispatchDeviceState(MeshUpdatingDevice meshUpdatingDevice, String str) {
        FUCallback fUCallback = this.callback;
        if (fUCallback != null) {
            fUCallback.onDeviceStateUpdate(meshUpdatingDevice, str);
        }
    }

    public int getProxyAddress() {
        return this.proxyAddress;
    }

    public void setProxyAddress(int i) {
        this.proxyAddress = i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("FirmwareUpdateConfiguration{updatingDevices=");
        sb.append(this.updatingDevices.size());
        sb.append(", firmwareData=");
        byte[] bArr = this.firmwareData;
        sb.append(bArr == null ? 0 : bArr.length);
        sb.append(", metadata=");
        sb.append(Arrays.toString(this.metadata));
        sb.append(", appKeyIndex=");
        sb.append(this.appKeyIndex);
        sb.append(", groupAddress=");
        sb.append(this.groupAddress);
        sb.append(", blobId=");
        sb.append(this.blobId);
        sb.append(", firmwareId=");
        sb.append(Arrays.toString(this.firmwareId));
        sb.append(", firmwareIndex=");
        sb.append(this.firmwareIndex);
        sb.append(", distributorType=");
        sb.append(this.distributorType);
        sb.append(", callback=");
        sb.append(this.callback);
        sb.append(", updatePolicy=");
        sb.append(this.updatePolicy);
        sb.append(", isContinue=");
        sb.append(this.isContinue);
        sb.append(", distributorAddress=");
        sb.append(this.distributorAddress);
        sb.append(", proxyAddress=");
        sb.append(this.proxyAddress);
        sb.append('}');
        return sb.toString();
    }

    public String getBriefDesc(ExtendBearerMode extendBearerMode) {
        StringBuilder sb = new StringBuilder("FU Params{updatingDevices=");
        sb.append(this.updatingDevices.size());
        sb.append(", firmwareData=");
        byte[] bArr = this.firmwareData;
        sb.append(bArr == null ? 0 : bArr.length);
        sb.append(", metadata=");
        sb.append(Arrays.toString(this.metadata));
        sb.append(", appKeyIndex=");
        sb.append(this.appKeyIndex);
        sb.append(", groupAddress=");
        sb.append(String.format("%04x", Integer.valueOf(this.groupAddress)));
        sb.append(", blobId=");
        sb.append(String.format("%16x", Long.valueOf(this.blobId)));
        sb.append(", firmwareId=");
        sb.append(Arrays.toString(this.firmwareId));
        sb.append(", firmwareIndex=");
        sb.append(this.firmwareIndex);
        sb.append(", distributorType=");
        sb.append(this.distributorType);
        sb.append(", updatePolicy=");
        sb.append(this.updatePolicy);
        sb.append(", isContinue=");
        sb.append(this.isContinue);
        sb.append(", distributorAddress=");
        sb.append(String.format("%04x", Integer.valueOf(this.distributorAddress)));
        sb.append(", proxyAddress=");
        sb.append(String.format("%04x", Integer.valueOf(this.proxyAddress)));
        sb.append(", extendBearerMode=");
        sb.append(extendBearerMode);
        sb.append(", networkInterval=");
        sb.append(this.networkInterval);
        sb.append('}');
        return sb.toString();
    }
}
