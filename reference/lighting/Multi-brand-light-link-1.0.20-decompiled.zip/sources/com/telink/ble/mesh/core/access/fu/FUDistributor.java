package com.telink.ble.mesh.core.access.fu;

import android.os.HandlerThread;
import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.NotificationMessage;
import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.FirmwareUpdateApplyMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.FirmwareUpdateCancelMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.FirmwareUpdateGetMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.FirmwareUpdateStartMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.FirmwareUpdateStatusMessage;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatePhase;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdateStatus;
import com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.TransferMode;
import com.telink.ble.mesh.entity.FirmwareUpdateConfiguration;
import com.telink.ble.mesh.entity.MeshUpdatingDevice;
import java.util.Iterator;
import java.util.List;
import java.util.function.IntSupplier;

/* loaded from: classes.dex */
class FUDistributor implements BlobTransferCallback {
    public static final int STEP_BLOB_TRANSFER = 3;
    public static final int STEP_IDLE = 0;
    public static final int STEP_UPDATE_APPLY = 5;
    public static final int STEP_UPDATE_CONTINUE = 16;
    public static final int STEP_UPDATE_GET = 4;
    public static final int STEP_UPDATE_START = 2;
    public static final int STEP_UPDATE_STOP = 17;
    public static final byte UPDATE_TTL = -1;
    private FUActionHandler actionHandler;
    private long blobId;
    private int connectedAddress;
    private boolean isContinue;
    private int nodeIndex;
    private List<MeshUpdatingDevice> nodes;
    private BlobTransfer transfer;
    private final String LOG_TAG = "FU-Distributor";
    public int step = 0;
    private int appKeyIndex = 0;
    private byte[] metadata = new byte[8];

    FUDistributor(HandlerThread handlerThread, FUActionHandler fUActionHandler, IntSupplier intSupplier) {
        this.transfer = new BlobTransfer(handlerThread, this, intSupplier);
        this.actionHandler = fUActionHandler;
    }

    void begin(FirmwareUpdateConfiguration firmwareUpdateConfiguration, int i, boolean z) {
        BlobTransferType blobTransferType;
        this.appKeyIndex = firmwareUpdateConfiguration.getAppKeyIndex();
        this.connectedAddress = i;
        this.isContinue = z;
        log("distribute begin - " + firmwareUpdateConfiguration.getUpdatingDevices().size() + " -- isContinue? " + z);
        List<MeshUpdatingDevice> updatingDevices = firmwareUpdateConfiguration.getUpdatingDevices();
        this.nodes = updatingDevices;
        if (updatingDevices.size() == 1 && this.nodes.get(0).meshAddress == i) {
            blobTransferType = BlobTransferType.GATT_DIST;
        } else {
            blobTransferType = BlobTransferType.MESH_DIST;
            i = -1;
        }
        this.transfer.resetParams(firmwareUpdateConfiguration, blobTransferType, i);
        this.metadata = firmwareUpdateConfiguration.getMetadata();
        this.blobId = firmwareUpdateConfiguration.getBlobId();
        if (z) {
            this.step = 16;
        } else {
            this.step = 2;
            this.actionHandler.onTransferProgress(0, blobTransferType);
        }
        this.nodeIndex = 0;
        nextAction();
    }

    BlobTransfer getTransfer() {
        return this.transfer;
    }

    void stop() {
        if (this.step != 0) {
            this.transfer.clear();
            this.step = 17;
            this.nodeIndex = 0;
            nextAction();
        }
    }

    void clear() {
        this.transfer.clear();
        this.step = 0;
    }

    boolean isRunning() {
        return this.step != 0;
    }

    void holdTransfer() {
        log("hold transfer :" + this.step);
        if (this.step == 3) {
            this.transfer.hold();
        }
    }

    public void onDistributeCommandFailed(int i) {
        if ((this.step == 2 && i == Opcode.FIRMWARE_UPDATE_START.value) || ((this.step == 5 && i == Opcode.FIRMWARE_UPDATE_APPLY.value) || (this.step == 4 && i == Opcode.FIRMWARE_UPDATE_GET.value))) {
            onDeviceFail(this.nodes.get(this.nodeIndex), "command send to updating node fail");
            this.nodeIndex++;
            nextAction();
        } else if (this.step == 3) {
            this.transfer.onTransferCommandFail(i);
        }
    }

    @Override // com.telink.ble.mesh.core.access.fu.BlobTransferCallback
    public void onTransferProgressUpdate(int i, BlobTransferType blobTransferType) {
        this.actionHandler.onTransferProgress(i, blobTransferType);
    }

    @Override // com.telink.ble.mesh.core.access.fu.BlobTransferCallback
    public void onTransferStart(TransferMode transferMode) {
        this.actionHandler.onTransferStart(transferMode);
    }

    @Override // com.telink.ble.mesh.core.access.fu.BlobTransferCallback
    public void onTransferComplete(boolean z, String str) {
        log("distribute blob transfer complete : success?" + z);
        if (z) {
            nextStep();
            return;
        }
        onDistributeComplete(false, "blob transfer fail when distribute - " + str);
    }

    @Override // com.telink.ble.mesh.core.access.fu.BlobTransferCallback
    public void onTransferringDeviceFail(int i, String str) {
        for (MeshUpdatingDevice meshUpdatingDevice : this.nodes) {
            if (meshUpdatingDevice.meshAddress == i) {
                onDeviceFail(meshUpdatingDevice, str);
                return;
            }
        }
    }

    @Override // com.telink.ble.mesh.core.access.fu.BlobTransferCallback
    public boolean onMeshMessagePrepared(MeshMessage meshMessage) {
        return this.actionHandler.onMessagePrepared(meshMessage);
    }

    @Override // com.telink.ble.mesh.core.access.fu.BlobTransferCallback
    public void onTransferLog(String str, String str2, int i) {
        this.actionHandler.onActionLog(str, str2, i);
    }

    private void onDistributeComplete(boolean z, String str) {
        if (z) {
            this.actionHandler.onTransferProgress(100, BlobTransferType.MESH_DIST);
        }
        log("distribute complete : success ? " + z + " -- " + str);
        this.step = 0;
        this.actionHandler.onActionComplete(z, FUAction.DISTRIBUTE, str);
    }

    private void nextStep() {
        this.step++;
        log("next step: " + this.step);
        this.nodeIndex = 0;
        nextAction();
    }

    private void nextAction() {
        if (this.nodeIndex >= this.nodes.size()) {
            log("current step complete: " + this.step);
            int i = this.step;
            if (i == 5) {
                onDistributeComplete(true, "update apply complete");
                return;
            }
            if (i == 17) {
                onDistributeComplete(false, "update stopped");
                return;
            }
            removeFailedDevices();
            if (this.nodes.size() != 0) {
                nextStep();
                return;
            } else {
                onDistributeComplete(false, "all nodes failed when executing action");
                return;
            }
        }
        int i2 = this.nodes.get(this.nodeIndex).meshAddress;
        log(String.format("action executing: " + this.step + " -- %04X", Integer.valueOf(i2)));
        int i3 = this.step;
        if (i3 == 2) {
            FirmwareUpdateStartMessage firmwareUpdateStartMessage = new FirmwareUpdateStartMessage(i2, this.appKeyIndex);
            firmwareUpdateStartMessage.metadata = this.metadata;
            firmwareUpdateStartMessage.updateBLOBID = this.blobId;
            firmwareUpdateStartMessage.updateTtl = (byte) -1;
            firmwareUpdateStartMessage.updateTimeoutBase = 0;
            firmwareUpdateStartMessage.updateFirmwareImageIndex = 0;
            onMeshMessagePrepared(firmwareUpdateStartMessage);
            return;
        }
        if (i3 == 4) {
            onMeshMessagePrepared(FirmwareUpdateGetMessage.getSimple(i2, this.appKeyIndex));
            return;
        }
        if (i3 == 5) {
            onMeshMessagePrepared(FirmwareUpdateApplyMessage.getSimple(i2, this.appKeyIndex));
            return;
        }
        if (i3 == 3) {
            log("blob transfer start");
            this.transfer.begin(this.isContinue);
        } else if (i3 == 16) {
            onMeshMessagePrepared(FirmwareUpdateGetMessage.getSimple(this.connectedAddress, this.appKeyIndex));
        } else if (i3 == 17) {
            onMeshMessagePrepared(FirmwareUpdateCancelMessage.getSimple(i2, this.appKeyIndex));
        }
    }

    public void onMessageNotification(NotificationMessage notificationMessage) {
        Opcode opcodeValueOf = Opcode.valueOf(notificationMessage.getOpcode());
        log("message notification: " + opcodeValueOf);
        if (this.step == 0) {
            log("notification when idle");
            return;
        }
        if (opcodeValueOf == null) {
            return;
        }
        int src = notificationMessage.getSrc();
        if (this.step == 2) {
            int size = this.nodes.size();
            int i = this.nodeIndex;
            if (size <= i) {
                log("node index overflow");
                return;
            } else if (this.nodes.get(i).meshAddress != src) {
                log("distributor unexpected notification src");
                return;
            }
        }
        if (opcodeValueOf == Opcode.FIRMWARE_UPDATE_STATUS) {
            onFirmwareUpdateStatus((FirmwareUpdateStatusMessage) notificationMessage.getStatusMessage());
        } else if (this.step == 3) {
            this.transfer.onTransferNotification(notificationMessage);
        }
    }

    public void onMulticastMessageComplete(int i, List<Integer> list) {
        if (this.step != 3) {
            log("multi complete -> distributor -> not at blob transfer");
        } else {
            this.transfer.onMulticastMessageComplete(i);
        }
    }

    private void onDeviceApplySuccess(MeshUpdatingDevice meshUpdatingDevice) {
        log("device apply success");
    }

    private void onFirmwareUpdateStatus(FirmwareUpdateStatusMessage firmwareUpdateStatusMessage) {
        log("firmware update status: " + firmwareUpdateStatusMessage.toString());
        if (UpdateStatus.valueOf(firmwareUpdateStatusMessage.getStatus() & 255) != UpdateStatus.SUCCESS) {
            onDeviceFail(this.nodes.get(this.nodeIndex), "firmware update status err");
            this.nodeIndex++;
            nextAction();
            return;
        }
        UpdatePhase updatePhaseValueOf = UpdatePhase.valueOf(firmwareUpdateStatusMessage.getPhase() & 255);
        int i = this.step;
        if (i == 16) {
            if (updatePhaseValueOf == UpdatePhase.TRANSFER_ACTIVE || updatePhaseValueOf == UpdatePhase.APPLY_SUCCESS) {
                this.step = 3;
                nextAction();
                return;
            } else {
                onDistributeComplete(false, "continue distribute error : device may have been rebooted");
                return;
            }
        }
        if (i == 2 || i == 4 || i == 5 || i == 17) {
            if (i == 5) {
                if (updatePhaseValueOf == UpdatePhase.VERIFICATION_SUCCEEDED || updatePhaseValueOf == UpdatePhase.APPLYING_UPDATE) {
                    onDeviceApplySuccess(this.nodes.get(this.nodeIndex));
                } else {
                    onDeviceFail(this.nodes.get(this.nodeIndex), "phase error when update apply");
                }
            }
            this.nodeIndex++;
            nextAction();
        }
    }

    private void onDeviceFail(MeshUpdatingDevice meshUpdatingDevice, String str) {
        log(String.format("node updating fail: %04X -- " + str, Integer.valueOf(meshUpdatingDevice.meshAddress)));
        meshUpdatingDevice.state = 2;
        FUActionHandler fUActionHandler = this.actionHandler;
        if (fUActionHandler != null) {
            fUActionHandler.onDeviceUpdate(meshUpdatingDevice, String.format("node updating fail: %04X -- ", Integer.valueOf(meshUpdatingDevice.meshAddress)));
        }
    }

    private void removeFailedDevices() {
        Iterator<MeshUpdatingDevice> it = this.nodes.iterator();
        while (it.hasNext()) {
            if (it.next().state == 2) {
                it.remove();
            }
        }
    }

    private void log(String str, int i) {
        this.actionHandler.onActionLog("FU-Distributor", str, i);
    }

    private void log(String str) {
        log(str, 1);
    }
}
