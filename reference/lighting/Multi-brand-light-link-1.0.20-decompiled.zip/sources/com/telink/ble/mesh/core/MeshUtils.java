package com.telink.ble.mesh.core;

import android.os.ParcelUuid;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.ble.MeshScanRecord;
import com.telink.ble.mesh.core.ble.UUIDInfo;
import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.message.StatusMessage;
import com.telink.ble.mesh.core.message.aggregator.AggregatorItem;
import com.telink.ble.mesh.core.message.aggregator.OpcodeAggregatorStatusMessage;
import com.telink.ble.mesh.core.networking.AccessLayerPDU;
import com.telink.ble.mesh.util.Arrays;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.zip.CRC32;

/* loaded from: classes.dex */
public final class MeshUtils {
    public static final int ADDRESS_ALL_PROXY = 65532;
    public static final int ADDRESS_BROADCAST = 65535;
    public static final String CHARS = "123456789aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ+-*/<>/?!@#$%^&;'[]{}|,.";
    private static final String FORMAT_1_BYTES = "%02X";
    private static final String FORMAT_2_BYTES = "%04X";
    private static final String FORMAT_3_BYTES = "%06X";
    private static final String FORMAT_4_BYTES = "%08X";
    public static final long IV_MISSING = 4294967295L;
    public static final int LOCAL_MESSAGE_ADDRESS = 0;
    public static final long TAI_OFFSET_SECOND = 946684800;
    public static final int UNICAST_ADDRESS_MAX = 32767;
    public static final int UNICAST_ADDRESS_MIN = 1;
    public static final long UNSIGNED_INTEGER_MAX = 4294967295L;
    private static SecureRandom rng;
    public static final ParcelUuid OTS_UUID = new ParcelUuid(UUIDInfo.SERVICE_OTS);
    public static final ParcelUuid SOL_UUID = new ParcelUuid(UUIDInfo.SERVICE_MESH_PROXY_SOLICITATION);
    private static final SimpleDateFormat COMPLETE_DATE_FORMAT = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss", Locale.getDefault());

    public static int bit(int i) {
        return 1 << i;
    }

    public static int getMicSize(byte b) {
        return b == 0 ? 4 : 8;
    }

    public static long unsignedIntegerCompare(int i, int i2) {
        return (i & 4294967295L) - (i2 & 4294967295L);
    }

    public static boolean validGroupAddress(int i) {
        int i2 = i & 65535;
        return i2 < 65280 && i2 >= 49152;
    }

    public static boolean validUnicastAddress(int i) {
        int i2 = i & 65535;
        return i2 <= 32767 && i2 >= 1;
    }

    private MeshUtils() {
    }

    public static byte[] generateRandom(int i) {
        byte[] bArr = new byte[i];
        synchronized (MeshUtils.class) {
            if (rng == null) {
                rng = new SecureRandom();
            }
        }
        rng.nextBytes(bArr);
        return bArr;
    }

    public static long getTaiTime() {
        return (Calendar.getInstance().getTimeInMillis() / 1000) - TAI_OFFSET_SECOND;
    }

    public static byte[] generateChars(int i) {
        byte[] bArr = new byte[i];
        for (int i2 = 0; i2 < i; i2++) {
            bArr[i2] = (byte) CHARS.charAt((int) Math.round(Math.random() * 84));
        }
        return bArr;
    }

    public static int bytes2Integer(byte[] bArr, ByteOrder byteOrder) {
        int i;
        int i2;
        int iMin = Math.min(bArr.length, 4);
        int i3 = 0;
        for (int i4 = 0; i4 < iMin; i4++) {
            if (byteOrder == ByteOrder.LITTLE_ENDIAN) {
                i = bArr[i4] & FUDistributor.UPDATE_TTL;
                i2 = i4 * 8;
            } else if (byteOrder == ByteOrder.BIG_ENDIAN) {
                i = bArr[i4] & FUDistributor.UPDATE_TTL;
                i2 = ((iMin - i4) - 1) * 8;
            }
            i3 |= i << i2;
        }
        return i3;
    }

    public static int bytes2Integer(byte[] bArr, int i, int i2, ByteOrder byteOrder) {
        int i3;
        int i4;
        int iMin = Math.min(4, i2);
        int i5 = 0;
        for (int i6 = 0; i6 < iMin; i6++) {
            if (byteOrder == ByteOrder.LITTLE_ENDIAN) {
                i3 = bArr[i6 + i] & 255;
                i4 = i6 * 8;
            } else if (byteOrder == ByteOrder.BIG_ENDIAN) {
                i3 = bArr[i6 + i] & 255;
                i4 = ((iMin - i6) - 1) * 8;
            }
            i5 |= i3 << i4;
        }
        return i5;
    }

    public static long bytes2Long(byte[] bArr, int i, int i2, ByteOrder byteOrder) {
        int i3;
        int i4;
        int iMin = Math.min(8, i2);
        long j = 0;
        for (int i5 = 0; i5 < iMin; i5++) {
            if (byteOrder == ByteOrder.LITTLE_ENDIAN) {
                i3 = bArr[i5 + i] & 255;
                i4 = i5 * 8;
            } else if (byteOrder == ByteOrder.BIG_ENDIAN) {
                i3 = bArr[i5 + i] & 255;
                i4 = ((iMin - i5) - 1) * 8;
            }
            j |= i3 << i4;
        }
        return j;
    }

    public static byte[] integer2Bytes(int i, int i2, ByteOrder byteOrder) {
        if (i2 > 4) {
            i2 = 4;
        }
        byte[] bArr = new byte[i2];
        for (int i3 = 0; i3 < i2; i3++) {
            if (byteOrder == ByteOrder.LITTLE_ENDIAN) {
                bArr[i3] = (byte) (i >> (i3 * 8));
            } else {
                bArr[(i2 - i3) - 1] = (byte) (i >> (i3 * 8));
            }
        }
        return bArr;
    }

    public static int hexToIntL(String str) {
        return bytes2Integer(Arrays.hexToBytes(str), ByteOrder.LITTLE_ENDIAN);
    }

    public static int hexToIntB(String str) {
        return Integer.valueOf(str, 16).intValue();
    }

    public static String intToHex1(int i) {
        return String.format(FORMAT_1_BYTES, Integer.valueOf(i));
    }

    public static String intToHex2(int i) {
        return String.format(FORMAT_2_BYTES, Integer.valueOf(i));
    }

    public static String intToHex3(int i) {
        return String.format(FORMAT_3_BYTES, Integer.valueOf(i));
    }

    public static String intToHex4(int i) {
        return String.format(FORMAT_4_BYTES, Integer.valueOf(i));
    }

    public static byte[] sequenceNumber2Buffer(int i) {
        return integer2Bytes(i, 3, ByteOrder.BIG_ENDIAN);
    }

    public static byte generateAid(byte[] bArr) {
        return Encipher.k4(bArr);
    }

    public static double mathLog2(int i) {
        return Math.log(i) / Math.log(2.0d);
    }

    public static String intToHex(int i) {
        if (i <= -1) {
            return String.format(FORMAT_4_BYTES, Integer.valueOf(i));
        }
        if (i <= 255) {
            return String.format(FORMAT_1_BYTES, Integer.valueOf(i));
        }
        if (i <= 65535) {
            return String.format(FORMAT_2_BYTES, Integer.valueOf(i));
        }
        return String.format(FORMAT_3_BYTES, Integer.valueOf(i));
    }

    public static String intToHex(int i, int i2) {
        if (i2 == 1) {
            return String.format(FORMAT_1_BYTES, Integer.valueOf(i));
        }
        if (i2 == 2) {
            return String.format(FORMAT_2_BYTES, Integer.valueOf(i));
        }
        if (i2 == 3) {
            return String.format(FORMAT_3_BYTES, Integer.valueOf(i));
        }
        return String.format(FORMAT_4_BYTES, Integer.valueOf(i));
    }

    public static boolean hexListContains(List<String> list, String str) {
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            if (it.next().equalsIgnoreCase(str)) {
                return true;
            }
        }
        return false;
    }

    public static boolean hexListContains(List<String> list, int i) {
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            if (hexToIntB(it.next()) == i) {
                return true;
            }
        }
        return false;
    }

    public static byte[] getMeshServiceData(byte[] bArr, boolean z) {
        return MeshScanRecord.parseFromBytes(bArr).getServiceData(ParcelUuid.fromString((z ? UUIDInfo.SERVICE_PROVISION : UUIDInfo.SERVICE_PROXY).toString()));
    }

    public static List<Integer> parseMissingBitField(byte[] bArr, int i) {
        ArrayList arrayList = new ArrayList();
        int i2 = 0;
        while (i < bArr.length) {
            byte b = bArr[i];
            for (int i3 = 0; i3 < 8; i3++) {
                if (((b >> i3) & 1) == 1) {
                    arrayList.add(Integer.valueOf(i2 + i3));
                }
            }
            i++;
            i2 += 8;
        }
        return arrayList;
    }

    public static boolean isCertSupported(int i) {
        return (i & bit(7)) != 0;
    }

    public static boolean isPvRecordSupported(int i) {
        return (i & bit(8)) != 0;
    }

    public static byte[] uuidToByteArray(String str) {
        return uuidToByteArray(UUID.fromString(str));
    }

    public static byte[] uuidToByteArray(UUID uuid) {
        ByteBuffer byteBufferWrap = ByteBuffer.wrap(new byte[16]);
        byteBufferWrap.putLong(uuid.getMostSignificantBits());
        byteBufferWrap.putLong(uuid.getLeastSignificantBits());
        return byteBufferWrap.array();
    }

    public static String byteArrayToUuid(byte[] bArr) {
        ByteBuffer byteBufferWrap = ByteBuffer.wrap(bArr);
        return new UUID(byteBufferWrap.getLong(), byteBufferWrap.getLong()).toString();
    }

    public static byte[] aggregateMessages(int i, List<MeshMessage> list) {
        byte[] bArrInteger2Bytes = integer2Bytes(i, 2, ByteOrder.LITTLE_ENDIAN);
        for (MeshMessage meshMessage : list) {
            byte[] byteArray = new AccessLayerPDU(meshMessage.getOpcode(), meshMessage.getParams()).toByteArray();
            int length = byteArray.length;
            boolean z = length > 127;
            ByteBuffer byteBufferPut = ByteBuffer.allocate((z ? 2 : 1) + length + bArrInteger2Bytes.length).order(ByteOrder.LITTLE_ENDIAN).put(bArrInteger2Bytes);
            int i2 = length << 1;
            if (z) {
                byteBufferPut.putShort((short) i2);
            } else {
                byteBufferPut.put((byte) i2);
            }
            byteBufferPut.put(byteArray);
            bArrInteger2Bytes = byteBufferPut.array();
        }
        return bArrInteger2Bytes;
    }

    public static List<StatusMessage> parseOpcodeAggregatorStatus(OpcodeAggregatorStatusMessage opcodeAggregatorStatusMessage) {
        List<AggregatorItem> list = opcodeAggregatorStatusMessage.statusItems;
        if (list == null || list.size() == 0) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (AggregatorItem aggregatorItem : list) {
            arrayList.add(StatusMessage.createByAccessMessage(aggregatorItem.opcode, aggregatorItem.parameters));
        }
        return arrayList;
    }

    public static byte[] getUnicastRange(int i, int i2) {
        if (i2 == 1) {
            return integer2Bytes(i << 1, 2, ByteOrder.LITTLE_ENDIAN);
        }
        return ByteBuffer.allocate(3).order(ByteOrder.LITTLE_ENDIAN).putShort((short) ((i << 1) | 1)).put((byte) i2).array();
    }

    public static String getGattConnectionDesc(int i) {
        if (i == 0) {
            return "disconnected";
        }
        if (i == 1) {
            return "connecting...";
        }
        if (i == 2) {
            return "connected";
        }
        if (i == 3) {
            return "disconnecting...";
        }
        return "unknown";
    }

    public static int crc32(byte[] bArr) {
        CRC32 crc32 = new CRC32();
        crc32.update(bArr);
        return (int) crc32.getValue();
    }

    public static int crc32(byte[] bArr, int i, int i2) {
        CRC32 crc32 = new CRC32();
        crc32.update(bArr, i, i2);
        return (int) crc32.getValue();
    }

    public static String getTimeFormat(long j) {
        return COMPLETE_DATE_FORMAT.format(new Date(j));
    }
}
