package com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.charset.Charset;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class BlobPartialBlockReportMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<BlobPartialBlockReportMessage> CREATOR = new Parcelable.Creator<BlobPartialBlockReportMessage>() { // from class: com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer.BlobPartialBlockReportMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BlobPartialBlockReportMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ BlobPartialBlockReportMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BlobPartialBlockReportMessage createFromParcel(Parcel parcel) {
            return new BlobPartialBlockReportMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BlobPartialBlockReportMessage[] newArray(int i) {
            return new BlobPartialBlockReportMessage[i];
        }
    };
    private ArrayList<Integer> encodedMissingChunks;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public BlobPartialBlockReportMessage() {
    }

    protected BlobPartialBlockReportMessage(Parcel parcel) {
        ArrayList<Integer> arrayList = new ArrayList<>();
        this.encodedMissingChunks = arrayList;
        parcel.readList(arrayList, null);
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.encodedMissingChunks = new ArrayList<>();
        for (char c : new String(bArr, Charset.forName("UTF-8")).toCharArray()) {
            this.encodedMissingChunks.add(Integer.valueOf(c & 65535));
        }
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeList(this.encodedMissingChunks);
    }

    public ArrayList<Integer> getEncodedMissingChunks() {
        return this.encodedMissingChunks;
    }
}
