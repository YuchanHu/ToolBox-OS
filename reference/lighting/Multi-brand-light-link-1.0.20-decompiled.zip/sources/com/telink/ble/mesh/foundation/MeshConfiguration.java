package com.telink.ble.mesh.foundation;

import android.util.SparseArray;

/* loaded from: classes.dex */
public class MeshConfiguration {
    public SparseArray<byte[]> appKeyMap;
    public SparseArray<byte[]> deviceKeyMap;
    public int ivIndex;
    public int localAddress;
    public int netKeyIndex;
    public byte[] networkKey;
    public int[] proxyFilterWhiteList;
    public int sequenceNumber;

    public int getDefaultAppKeyIndex() {
        if (this.appKeyMap.size() > 0) {
            return this.appKeyMap.keyAt(0);
        }
        return 0;
    }

    public byte[] getDefaultAppKey() {
        if (this.appKeyMap.size() > 0) {
            return this.appKeyMap.valueAt(0);
        }
        return null;
    }
}
