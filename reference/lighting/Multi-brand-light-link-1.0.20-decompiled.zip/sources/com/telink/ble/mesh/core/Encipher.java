package com.telink.ble.mesh.core;

import com.telink.ble.mesh.core.proxy.ProxyPDU;
import com.telink.ble.mesh.util.Arrays;
import com.telink.ble.mesh.util.MeshLogger;
import java.io.ByteArrayInputStream;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateFactory;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import javax.crypto.KeyAgreement;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.spongycastle.crypto.DataLengthException;
import org.spongycastle.crypto.InvalidCipherTextException;
import org.spongycastle.crypto.engines.AESEngine;
import org.spongycastle.crypto.engines.AESLightEngine;
import org.spongycastle.crypto.macs.CMac;
import org.spongycastle.crypto.modes.CCMBlockCipher;
import org.spongycastle.crypto.params.AEADParameters;
import org.spongycastle.crypto.params.KeyParameter;
import org.spongycastle.jcajce.provider.digest.SHA256;
import org.spongycastle.jce.ECNamedCurveTable;
import org.spongycastle.jce.interfaces.ECPublicKey;
import org.spongycastle.jce.provider.BouncyCastleProvider;
import org.spongycastle.jce.spec.ECNamedCurveParameterSpec;
import org.spongycastle.jce.spec.ECPublicKeySpec;
import org.spongycastle.util.BigIntegers;

/* loaded from: classes.dex */
public final class Encipher {
    private static final byte[] SALT_INPUT_K2 = "smk2".getBytes();
    private static final byte[] SALT_INPUT_K3 = "smk3".getBytes();
    private static final byte[] SALT_INPUT_K4 = "smk4".getBytes();
    private static final byte[] SALT_K3_M = {105, 100, 54, 52, 1};
    private static final byte[] SALT_K4_M = {105, 100, 54, 1};
    private static final byte[] SALT_NKIK = "nkik".getBytes();
    private static final byte[] SALT_NKBK = "nkbk".getBytes();
    private static final byte[] SALT_NKPK = "nkpk".getBytes();
    private static final byte[] SALT_ID128 = "id128".getBytes();
    private static final byte[] NODE_IDENTITY_HASH_PADDING = {0, 0, 0, 0, 0, 0};
    private static final byte[] NODE_PRIVATE_IDENTITY_HASH_PADDING = {0, 0, 0, 0, 0};
    public static final byte[] PRCK = "prck".getBytes();
    public static final byte[] PRSK = "prsk".getBytes();
    public static final byte[] PRSN = "prsn".getBytes();
    public static final byte[] PRDK = "prdk".getBytes();
    public static final byte[] PRCK256 = "prck256".getBytes();
    private static final byte[] SALT_KEY_ZERO = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    private static final byte[] SALT_KEY_ZERO_32 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    public static KeyPair generateKeyPair() throws NoSuchAlgorithmException, NoSuchProviderException, InvalidAlgorithmParameterException {
        try {
            ECNamedCurveParameterSpec parameterSpec = ECNamedCurveTable.getParameterSpec("P-256");
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("ECDH", BouncyCastleProvider.PROVIDER_NAME);
            keyPairGenerator.initialize(parameterSpec);
            return keyPairGenerator.generateKeyPair();
        } catch (Exception unused) {
            MeshLogger.log("generate key pair err!");
            return null;
        }
    }

    public static byte[] generateECDH(byte[] bArr, PrivateKey privateKey) throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException {
        try {
            BigInteger bigIntegerFromUnsignedByteArray = BigIntegers.fromUnsignedByteArray(bArr, 0, 32);
            BigInteger bigIntegerFromUnsignedByteArray2 = BigIntegers.fromUnsignedByteArray(bArr, 32, 32);
            ECNamedCurveParameterSpec parameterSpec = ECNamedCurveTable.getParameterSpec("secp256r1");
            ECPublicKey eCPublicKey = (ECPublicKey) KeyFactory.getInstance("ECDH", BouncyCastleProvider.PROVIDER_NAME).generatePublic(new ECPublicKeySpec(parameterSpec.getCurve().validatePoint(bigIntegerFromUnsignedByteArray, bigIntegerFromUnsignedByteArray2), parameterSpec));
            KeyAgreement keyAgreement = KeyAgreement.getInstance("ECDH", BouncyCastleProvider.PROVIDER_NAME);
            keyAgreement.init(privateKey);
            keyAgreement.doPhase(eCPublicKey, true);
            return keyAgreement.generateSecret();
        } catch (IllegalArgumentException | InvalidKeyException | NoSuchAlgorithmException | NoSuchProviderException | InvalidKeySpecException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static byte[] aesCmac(byte[] bArr, byte[] bArr2) {
        KeyParameter keyParameter = new KeyParameter(bArr2);
        CMac cMac = new CMac(new AESEngine());
        cMac.init(keyParameter);
        cMac.update(bArr, 0, bArr.length);
        byte[] bArr3 = new byte[16];
        cMac.doFinal(bArr3, 0);
        return bArr3;
    }

    public static byte[] generateSalt(byte[] bArr) {
        return aesCmac(bArr, SALT_KEY_ZERO);
    }

    public static byte[] s2(byte[] bArr) {
        return hMacSha256(bArr, SALT_KEY_ZERO_32);
    }

    public static byte[] ccm(byte[] bArr, byte[] bArr2, byte[] bArr3, int i, boolean z) throws IllegalStateException, DataLengthException, IllegalArgumentException {
        byte[] bArr4 = new byte[bArr.length + (z ? i : -i)];
        CCMBlockCipher cCMBlockCipher = new CCMBlockCipher(new AESEngine());
        cCMBlockCipher.init(z, new AEADParameters(new KeyParameter(bArr2), i * 8, bArr3));
        cCMBlockCipher.processBytes(bArr, 0, bArr.length, bArr4, bArr.length);
        try {
            cCMBlockCipher.doFinal(bArr4, 0);
            return bArr4;
        } catch (InvalidCipherTextException unused) {
            return null;
        }
    }

    public static byte[] aes(byte[] bArr, byte[] bArr2) {
        byte[] bArr3 = new byte[bArr.length];
        KeyParameter keyParameter = new KeyParameter(bArr2);
        AESLightEngine aESLightEngine = new AESLightEngine();
        aESLightEngine.init(true, keyParameter);
        aESLightEngine.processBlock(bArr, 0, bArr3, 0);
        return bArr3;
    }

    public static byte[] k1(byte[] bArr, byte[] bArr2, byte[] bArr3) {
        return aesCmac(bArr3, aesCmac(bArr, bArr2));
    }

    public static byte[][] calculateNetKeyK2(byte[] bArr) {
        return k2(bArr, new byte[]{0});
    }

    public static byte[][] k2(byte[] bArr, byte[] bArr2) {
        byte[] bArrAesCmac = aesCmac(bArr, generateSalt(SALT_INPUT_K2));
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(bArr2.length + 1);
        byteBufferAllocate.put(new byte[0]);
        byteBufferAllocate.put(bArr2);
        byteBufferAllocate.put((byte) 1);
        byte[] bArrAesCmac2 = aesCmac(byteBufferAllocate.array(), bArrAesCmac);
        ByteBuffer byteBufferAllocate2 = ByteBuffer.allocate(bArrAesCmac2.length + bArr2.length + 1);
        byteBufferAllocate2.put(bArrAesCmac2);
        byteBufferAllocate2.put(bArr2);
        byteBufferAllocate2.put((byte) 2);
        byte[] bArrAesCmac3 = aesCmac(byteBufferAllocate2.array(), bArrAesCmac);
        ByteBuffer byteBufferAllocate3 = ByteBuffer.allocate(bArrAesCmac3.length + bArr2.length + 1);
        byteBufferAllocate3.put(bArrAesCmac3);
        byteBufferAllocate3.put(bArr2);
        byteBufferAllocate3.put((byte) 3);
        return new byte[][]{bArrAesCmac2, bArrAesCmac3, aesCmac(byteBufferAllocate3.array(), bArrAesCmac)};
    }

    public static byte[] k3(byte[] bArr) {
        byte[] bArrAesCmac = aesCmac(SALT_K3_M, aesCmac(bArr, generateSalt(SALT_INPUT_K3)));
        byte[] bArr2 = new byte[8];
        System.arraycopy(bArrAesCmac, bArrAesCmac.length - 8, bArr2, 0, 8);
        return bArr2;
    }

    public static byte k4(byte[] bArr) {
        return (byte) (aesCmac(SALT_K4_M, aesCmac(bArr, generateSalt(SALT_INPUT_K4)))[15] & 63);
    }

    public static byte[] k5(byte[] bArr, byte[] bArr2, byte[] bArr3) {
        return hMacSha256(bArr3, hMacSha256(bArr, bArr2));
    }

    public static byte[] generateNodeIdentityHash(byte[] bArr, byte[] bArr2, int i) {
        byte[] bArr3 = NODE_IDENTITY_HASH_PADDING;
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(bArr3.length + bArr2.length + 2).order(ByteOrder.BIG_ENDIAN);
        byteBufferOrder.put(bArr3);
        byteBufferOrder.put(bArr2);
        byteBufferOrder.putShort((short) i);
        byte[] bArrAes = aes(byteBufferOrder.array(), bArr);
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(8);
        byteBufferAllocate.put(bArrAes, 8, 8);
        return byteBufferAllocate.array();
    }

    public static byte[] generatePrivateNodeIdentityHash(byte[] bArr, byte[] bArr2, int i) {
        byte[] bArr3 = NODE_PRIVATE_IDENTITY_HASH_PADDING;
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(bArr3.length + bArr2.length + 3).order(ByteOrder.BIG_ENDIAN);
        byteBufferOrder.put(bArr3).put((byte) 3);
        byteBufferOrder.put(bArr2);
        byteBufferOrder.putShort((short) i);
        byte[] bArrAes = aes(byteBufferOrder.array(), bArr);
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(8);
        byteBufferAllocate.put(bArrAes, 8, 8);
        return byteBufferAllocate.array();
    }

    public static byte[] generateIdentityKey(byte[] bArr) {
        byte[] bArrGenerateSalt = generateSalt(SALT_NKIK);
        byte[] bArr2 = SALT_ID128;
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(bArr2.length + 1);
        byteBufferAllocate.put(bArr2);
        byteBufferAllocate.put((byte) 1);
        return k1(bArr, bArrGenerateSalt, byteBufferAllocate.array());
    }

    public static byte[] generateBeaconKey(byte[] bArr) {
        byte[] bArrGenerateSalt = generateSalt(SALT_NKBK);
        byte[] bArr2 = SALT_ID128;
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(bArr2.length + 1);
        byteBufferAllocate.put(bArr2);
        byteBufferAllocate.put((byte) 1);
        return k1(bArr, bArrGenerateSalt, byteBufferAllocate.array());
    }

    public static byte[] generatePrivateBeaconKey(byte[] bArr) {
        byte[] bArrGenerateSalt = generateSalt(SALT_NKPK);
        byte[] bArr2 = SALT_ID128;
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(bArr2.length + 1);
        byteBufferAllocate.put(bArr2);
        byteBufferAllocate.put((byte) 1);
        return k1(bArr, bArrGenerateSalt, byteBufferAllocate.array());
    }

    public static byte[] decryptOnlineStatus(byte[] bArr, byte[] bArr2) {
        byte[] bArr3 = new byte[4];
        System.arraycopy(bArr, 0, bArr3, 0, 4);
        byte[] bArr4 = new byte[2];
        System.arraycopy(bArr, bArr.length - 2, bArr4, 0, 2);
        int length = bArr.length;
        int i = length - 6;
        byte[] bArr5 = new byte[i];
        System.arraycopy(bArr, 4, bArr5, 0, i);
        byte[] bArrAes = new byte[16];
        byte[] bArr6 = new byte[16];
        System.arraycopy(bArr3, 0, bArr6, 1, 4);
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = i2 & 15;
            if (i3 == 0) {
                bArrAes = aes(bArr6, bArr2);
                bArr6[0] = (byte) (bArr6[0] + 1);
            }
            bArr5[i2] = (byte) (bArr5[i2] ^ bArrAes[i3]);
        }
        byte[] bArr7 = new byte[16];
        System.arraycopy(bArr3, 0, bArr7, 0, 4);
        bArr7[4] = (byte) i;
        byte[] bArrAes2 = aes(bArr7, bArr2);
        for (int i4 = 0; i4 < i; i4++) {
            int i5 = i4 & 15;
            bArrAes2[i5] = (byte) (bArrAes2[i5] ^ bArr5[i4]);
            if (i5 == 15 || i4 == length - 7) {
                bArrAes2 = aes(bArrAes2, bArr2);
            }
        }
        for (int i6 = 0; i6 < 2; i6++) {
            if (bArr4[i6] != bArrAes2[i6]) {
                return null;
            }
        }
        System.arraycopy(bArr5, 0, bArr, 4, i);
        return bArr;
    }

    public static byte[] sha256(byte[] bArr) {
        return new SHA256.Digest().digest(bArr);
    }

    public static byte[] hMacSha256(byte[] bArr, byte[] bArr2) throws NoSuchAlgorithmException, InvalidKeyException {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(bArr2, "HmacSHA256"));
            return mac.doFinal(bArr);
        } catch (InvalidKeyException | NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static X509Certificate checkCertificate(byte[] bArr) throws NoSuchAlgorithmException, SignatureException, CertificateNotYetValidException, CertificateParsingException, InvalidKeyException, NoSuchProviderException, CertificateExpiredException {
        try {
            X509Certificate x509Certificate = (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(bArr));
            MeshLogger.d("certificate info: " + x509Certificate.toString());
            if (x509Certificate.getVersion() != 3) {
                MeshLogger.d("version check err");
                return null;
            }
            x509Certificate.checkValidity();
            x509Certificate.getSubjectAlternativeNames();
            x509Certificate.getExtendedKeyUsage();
            Signature signature = Signature.getInstance(x509Certificate.getSigAlgName(), BouncyCastleProvider.PROVIDER_NAME);
            signature.initVerify(x509Certificate);
            signature.update(x509Certificate.getTBSCertificate());
            if (signature.verify(x509Certificate.getSignature())) {
                System.out.println("signature validation pass");
                return x509Certificate;
            }
            System.out.println("signature validation failed");
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static X509Certificate checkCertificateByCa(byte[] bArr, byte[] bArr2) throws CertificateException {
        try {
            CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
            X509Certificate x509Certificate = (X509Certificate) certificateFactory.generateCertificate(new ByteArrayInputStream(bArr));
            MeshLogger.d("certificate info: " + x509Certificate.toString());
            if (x509Certificate.getVersion() != 3) {
                MeshLogger.d("version check err");
                return null;
            }
            x509Certificate.checkValidity();
            x509Certificate.getSubjectAlternativeNames();
            x509Certificate.getExtendedKeyUsage();
            x509Certificate.verify(((X509Certificate) certificateFactory.generateCertificate(new ByteArrayInputStream(bArr2))).getPublicKey());
            MeshLogger.d("signature validation pass");
            return x509Certificate;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x003c  */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0043  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static byte[] getPublicKeyInCert(java.security.cert.X509Certificate r7) {
        /*
            java.security.PublicKey r7 = r7.getPublicKey()
            java.security.interfaces.ECPublicKey r7 = (java.security.interfaces.ECPublicKey) r7
            java.security.spec.ECPoint r0 = r7.getW()
            java.math.BigInteger r0 = r0.getAffineX()
            byte[] r0 = r0.toByteArray()
            int r1 = r0.length
            r2 = 1
            r3 = 0
            r4 = 32
            if (r1 <= r4) goto L20
            byte[] r1 = new byte[r4]
            java.lang.System.arraycopy(r0, r2, r1, r3, r4)
        L1e:
            r0 = r1
            goto L2d
        L20:
            int r1 = r0.length
            if (r1 >= r4) goto L2d
            byte[] r1 = new byte[r4]
            int r5 = r0.length
            int r5 = 32 - r5
            int r6 = r0.length
            java.lang.System.arraycopy(r0, r3, r1, r5, r6)
            goto L1e
        L2d:
            java.security.spec.ECPoint r7 = r7.getW()
            java.math.BigInteger r7 = r7.getAffineY()
            byte[] r7 = r7.toByteArray()
            int r1 = r7.length
            if (r1 <= r4) goto L43
            byte[] r1 = new byte[r4]
            java.lang.System.arraycopy(r7, r2, r1, r3, r4)
        L41:
            r7 = r1
            goto L4f
        L43:
            int r1 = r7.length
            if (r1 >= r4) goto L4f
            byte[] r1 = new byte[r4]
            int r2 = r7.length
            int r4 = r4 - r2
            int r2 = r7.length
            java.lang.System.arraycopy(r7, r3, r1, r4, r2)
            goto L41
        L4f:
            int r1 = r0.length
            int r2 = r7.length
            int r1 = r1 + r2
            byte[] r1 = new byte[r1]
            int r2 = r0.length
            java.lang.System.arraycopy(r0, r3, r1, r3, r2)
            int r0 = r0.length
            int r2 = r7.length
            java.lang.System.arraycopy(r7, r3, r1, r0, r2)
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            java.lang.String r0 = "public key in cert: "
            r7.<init>(r0)
            java.lang.String r0 = com.telink.ble.mesh.util.Arrays.bytesToHexString(r1)
            r7.append(r0)
            java.lang.String r7 = r7.toString()
            com.telink.ble.mesh.util.MeshLogger.d(r7)
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.telink.ble.mesh.core.Encipher.getPublicKeyInCert(java.security.cert.X509Certificate):byte[]");
    }

    public static byte[] getStaticOOBInCert(X509Certificate x509Certificate) {
        byte[] extensionValue = x509Certificate.getExtensionValue("2.25.234763379998062148653007332685657680359");
        if (extensionValue == null || extensionValue.length < 16) {
            MeshLogger.d("static oob in cert not found");
            return null;
        }
        byte[] bArr = new byte[16];
        System.arraycopy(extensionValue, extensionValue.length - 16, bArr, 0, 16);
        MeshLogger.d("static oob in cert: " + Arrays.bytesToHexString(bArr));
        return bArr;
    }

    public static byte[] calcUuidByMac(String str) {
        return calcUuidByMac(Arrays.hexToBytes(str.replace(":", "")));
    }

    public static byte[] calcUuidByMac(byte[] bArr) throws NoSuchAlgorithmException {
        try {
            byte[] bArrHexToBytes = Arrays.hexToBytes("10b8a76bad9dd11180b400c04fd430c8");
            byte[] bArrArray = ByteBuffer.allocate(15).put(Arrays.reverse(bArr)).array();
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.update(bArrHexToBytes, 0, bArrHexToBytes.length);
            messageDigest.update(bArrArray, 0, 15);
            byte[] bArrDigest = messageDigest.digest();
            byte b = (byte) (15 & bArrDigest[7]);
            bArrDigest[7] = b;
            bArrDigest[7] = (byte) (b | 48);
            byte b2 = (byte) (bArrDigest[8] & 63);
            bArrDigest[8] = b2;
            bArrDigest[8] = (byte) (b2 | ProxyPDU.SAR_SEG_CONTINUE);
            return bArrDigest;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
}
