package com.telink.ble.mesh.core.provisioning;

/* loaded from: classes.dex */
public enum AuthenticationMethod {
    NoOOB((byte) 0),
    StaticOOB((byte) 1);

    public final byte value;

    AuthenticationMethod(byte b) {
        this.value = b;
    }
}
