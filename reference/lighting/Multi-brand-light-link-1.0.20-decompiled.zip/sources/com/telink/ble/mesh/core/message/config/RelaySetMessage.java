package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class RelaySetMessage extends ConfigMessage {
    public byte relay;
    public byte retransmitCount;
    public byte retransmitIntervalSteps;

    public RelaySetMessage(int i) {
        super(i);
    }

    public static RelaySetMessage getSimple(int i, byte b, byte b2, byte b3) {
        RelaySetMessage relaySetMessage = new RelaySetMessage(i);
        relaySetMessage.relay = b;
        relaySetMessage.retransmitCount = b2;
        relaySetMessage.retransmitIntervalSteps = b3;
        return relaySetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.CFG_RELAY_SET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.CFG_RELAY_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return new byte[]{this.relay, (byte) ((this.retransmitCount & 7) | (this.retransmitIntervalSteps << 3))};
    }
}
