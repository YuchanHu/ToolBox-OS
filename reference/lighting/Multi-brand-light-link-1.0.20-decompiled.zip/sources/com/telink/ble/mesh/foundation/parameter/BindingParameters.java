package com.telink.ble.mesh.foundation.parameter;

import com.telink.ble.mesh.core.ble.UUIDInfo;
import com.telink.ble.mesh.entity.BindingDevice;

/* loaded from: classes.dex */
public class BindingParameters extends Parameters {
    public BindingParameters(BindingDevice bindingDevice) {
        setScanFilter(createScanFilter(UUIDInfo.SERVICE_PROXY));
        set(Parameters.ACTION_BINDING_TARGET, bindingDevice);
    }
}
