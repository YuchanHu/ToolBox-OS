package com.telink.ble.mesh.core.message.privatebeacon;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.config.ConfigMessage;

/* loaded from: classes.dex */
public class PrivateGattProxyGetMessage extends ConfigMessage {
    public PrivateGattProxyGetMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.PRIVATE_GATT_PROXY_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.PRIVATE_GATT_PROXY_STATUS.value;
    }
}
