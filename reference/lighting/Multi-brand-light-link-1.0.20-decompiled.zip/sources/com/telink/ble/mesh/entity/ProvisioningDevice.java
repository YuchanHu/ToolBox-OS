package com.telink.ble.mesh.entity;

import android.bluetooth.BluetoothDevice;
import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.provisioning.pdu.ProvisioningCapabilityPDU;
import com.telink.ble.mesh.util.Arrays;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ProvisioningDevice implements Parcelable {
    public static final Parcelable.Creator<ProvisioningDevice> CREATOR = new Parcelable.Creator<ProvisioningDevice>() { // from class: com.telink.ble.mesh.entity.ProvisioningDevice.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ProvisioningDevice createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ ProvisioningDevice[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ProvisioningDevice createFromParcel(Parcel parcel) {
            return new ProvisioningDevice(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ProvisioningDevice[] newArray(int i) {
            return new ProvisioningDevice[i];
        }
    };
    private static final int DATA_PDU_LEN = 25;
    protected byte attentionDuration;
    protected byte[] authValue;
    protected boolean autoStart;
    protected boolean autoUseNoOOB;
    private BluetoothDevice bluetoothDevice;
    protected ProvisioningCapabilityPDU deviceCapability;
    protected byte[] deviceKey;
    protected byte[] deviceUUID;
    protected int ivIndex;
    protected byte ivUpdateFlag;
    protected byte keyRefreshFlag;
    protected byte[] networkKey;
    protected int networkKeyIndex;
    protected int oobInfo;
    protected int provisioningState;
    protected byte[] rootCert;
    protected int unicastAddress;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public ProvisioningDevice(BluetoothDevice bluetoothDevice, byte[] bArr, int i) {
        this.authValue = null;
        this.autoUseNoOOB = false;
        this.deviceKey = null;
        this.rootCert = null;
        this.autoStart = true;
        this.deviceCapability = null;
        this.attentionDuration = (byte) 0;
        this.bluetoothDevice = bluetoothDevice;
        this.deviceUUID = bArr;
        this.unicastAddress = i;
    }

    public ProvisioningDevice(BluetoothDevice bluetoothDevice, byte[] bArr) {
        this.authValue = null;
        this.autoUseNoOOB = false;
        this.deviceKey = null;
        this.rootCert = null;
        this.autoStart = true;
        this.deviceCapability = null;
        this.attentionDuration = (byte) 0;
        this.bluetoothDevice = bluetoothDevice;
        this.deviceUUID = bArr;
    }

    public ProvisioningDevice(BluetoothDevice bluetoothDevice, byte[] bArr, byte[] bArr2, int i, byte b, byte b2, int i2, int i3) {
        this.authValue = null;
        this.autoUseNoOOB = false;
        this.deviceKey = null;
        this.rootCert = null;
        this.autoStart = true;
        this.deviceCapability = null;
        this.attentionDuration = (byte) 0;
        this.bluetoothDevice = bluetoothDevice;
        this.deviceUUID = bArr;
        this.networkKey = bArr2;
        this.networkKeyIndex = i;
        this.keyRefreshFlag = b;
        this.ivUpdateFlag = b2;
        this.ivIndex = i2;
        this.unicastAddress = i3;
    }

    public ProvisioningDevice() {
        this.authValue = null;
        this.autoUseNoOOB = false;
        this.deviceKey = null;
        this.rootCert = null;
        this.autoStart = true;
        this.deviceCapability = null;
        this.attentionDuration = (byte) 0;
    }

    protected ProvisioningDevice(Parcel parcel) {
        this.authValue = null;
        this.autoUseNoOOB = false;
        this.deviceKey = null;
        this.rootCert = null;
        this.autoStart = true;
        this.deviceCapability = null;
        this.attentionDuration = (byte) 0;
        this.bluetoothDevice = (BluetoothDevice) parcel.readParcelable(BluetoothDevice.class.getClassLoader());
        this.deviceUUID = parcel.createByteArray();
        this.oobInfo = parcel.readInt();
        this.networkKey = parcel.createByteArray();
        this.networkKeyIndex = parcel.readInt();
        this.keyRefreshFlag = parcel.readByte();
        this.ivUpdateFlag = parcel.readByte();
        this.ivIndex = parcel.readInt();
        this.unicastAddress = parcel.readInt();
        this.authValue = parcel.createByteArray();
        this.provisioningState = parcel.readInt();
        this.deviceKey = parcel.createByteArray();
        this.rootCert = parcel.createByteArray();
    }

    public byte[] generateProvisioningData() {
        byte b = (byte) ((this.keyRefreshFlag & 1) | (this.ivUpdateFlag & 2));
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(25).order(ByteOrder.BIG_ENDIAN);
        byteBufferOrder.put(this.networkKey).putShort((short) this.networkKeyIndex).put(b).putInt(this.ivIndex).putShort((short) this.unicastAddress);
        return byteBufferOrder.array();
    }

    public int getOobInfo() {
        return this.oobInfo;
    }

    public void setOobInfo(int i) {
        this.oobInfo = i;
    }

    public BluetoothDevice getBluetoothDevice() {
        return this.bluetoothDevice;
    }

    public byte[] getDeviceUUID() {
        return this.deviceUUID;
    }

    public byte[] getNetworkKey() {
        return this.networkKey;
    }

    public void setNetworkKey(byte[] bArr) {
        this.networkKey = bArr;
    }

    public int getNetworkKeyIndex() {
        return this.networkKeyIndex;
    }

    public void setNetworkKeyIndex(int i) {
        this.networkKeyIndex = i;
    }

    public byte getKeyRefreshFlag() {
        return this.keyRefreshFlag;
    }

    public void setKeyRefreshFlag(byte b) {
        this.keyRefreshFlag = b;
    }

    public byte getIvUpdateFlag() {
        return this.ivUpdateFlag;
    }

    public void setIvUpdateFlag(byte b) {
        this.ivUpdateFlag = b;
    }

    public int getIvIndex() {
        return this.ivIndex;
    }

    public void setIvIndex(int i) {
        this.ivIndex = i;
    }

    public int getUnicastAddress() {
        return this.unicastAddress;
    }

    public byte[] getAuthValue() {
        return this.authValue;
    }

    public void setAuthValue(byte[] bArr) {
        this.authValue = bArr;
    }

    public int getProvisioningState() {
        return this.provisioningState;
    }

    public void setProvisioningState(int i) {
        this.provisioningState = i;
    }

    public byte[] getDeviceKey() {
        return this.deviceKey;
    }

    public void setDeviceKey(byte[] bArr) {
        this.deviceKey = bArr;
    }

    public ProvisioningCapabilityPDU getDeviceCapability() {
        return this.deviceCapability;
    }

    public void setDeviceCapability(ProvisioningCapabilityPDU provisioningCapabilityPDU) {
        this.deviceCapability = provisioningCapabilityPDU;
    }

    public void setUnicastAddress(int i) {
        this.unicastAddress = i;
    }

    public boolean isAutoUseNoOOB() {
        return this.autoUseNoOOB;
    }

    public void setAutoUseNoOOB(boolean z) {
        this.autoUseNoOOB = z;
    }

    public byte[] getRootCert() {
        return this.rootCert;
    }

    public void setRootCert(byte[] bArr) {
        this.rootCert = bArr;
    }

    public boolean isAutoStart() {
        return this.autoStart;
    }

    public void setAutoStart(boolean z) {
        this.autoStart = z;
    }

    public byte getAttentionDuration() {
        return this.attentionDuration;
    }

    public void setAttentionDuration(byte b) {
        this.attentionDuration = b;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.bluetoothDevice, i);
        parcel.writeByteArray(this.deviceUUID);
        parcel.writeInt(this.oobInfo);
        parcel.writeByteArray(this.networkKey);
        parcel.writeInt(this.networkKeyIndex);
        parcel.writeByte(this.keyRefreshFlag);
        parcel.writeByte(this.ivUpdateFlag);
        parcel.writeInt(this.ivIndex);
        parcel.writeInt(this.unicastAddress);
        parcel.writeByteArray(this.authValue);
        parcel.writeInt(this.provisioningState);
        parcel.writeByteArray(this.deviceKey);
        parcel.writeByteArray(this.rootCert);
    }

    public String toString() {
        return "ProvisioningDevice{deviceUUID=" + Arrays.bytesToHexString(this.deviceUUID) + ", oobInfo=0b" + Integer.toBinaryString(this.oobInfo) + ", networkKey=" + Arrays.bytesToHexString(this.networkKey) + ", networkKeyIndex=" + this.networkKeyIndex + ", keyRefreshFlag=" + ((int) this.keyRefreshFlag) + ", ivUpdateFlag=" + ((int) this.ivUpdateFlag) + ", ivIndex=0x" + Long.toHexString(this.ivIndex) + ", unicastAddress=0x" + Integer.toHexString(this.unicastAddress) + ", authValue=" + Arrays.bytesToHexString(this.authValue) + ", autoUseNoOOB=" + this.autoUseNoOOB + ", provisioningState=" + this.provisioningState + ", deviceKey=" + Arrays.bytesToHexString(this.deviceKey) + '}';
    }
}
