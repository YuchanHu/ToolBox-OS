package com.telink.ble.mesh.core.message.scene;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.generic.GenericMessage;

/* loaded from: classes.dex */
public class SceneDeleteMessage extends GenericMessage {
    private boolean ack;
    private int sceneNumber;

    public static SceneDeleteMessage getSimple(int i, int i2, int i3, boolean z, int i4) {
        SceneDeleteMessage sceneDeleteMessage = new SceneDeleteMessage(i, i2);
        sceneDeleteMessage.sceneNumber = i3;
        sceneDeleteMessage.ack = z;
        sceneDeleteMessage.setResponseMax(i4);
        return sceneDeleteMessage;
    }

    public SceneDeleteMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return this.ack ? Opcode.SCENE_REG_STATUS.value : super.getResponseOpcode();
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.SCENE_DEL : Opcode.SCENE_DEL_NOACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        int i = this.sceneNumber;
        return new byte[]{(byte) i, (byte) (i >> 8)};
    }

    public void setSceneNumber(int i) {
        this.sceneNumber = i;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }
}
