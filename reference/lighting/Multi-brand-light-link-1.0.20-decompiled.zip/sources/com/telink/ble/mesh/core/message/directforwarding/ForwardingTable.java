package com.telink.ble.mesh.core.message.directforwarding;

/* loaded from: classes.dex */
public class ForwardingTable {
    public int bearerTowardPathOrigin;
    public int bearerTowardPathTarget;
    public int dependentOriginListSize;
    public int dependentTargetListSize;
    public int entryHeader;
    public int multicastDestination;
    public int originUnicastAddrRange;
    public int targetUnicastAddrRange;
}
