package com.telink.ble.mesh.core.message.firmwareupdate;

import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class FirmwareUpdateStartMessage extends UpdatingMessage {
    public static final byte DEFAULT_UPDATE_TTL = 10;
    public byte[] metadata;
    public long updateBLOBID;
    public int updateFirmwareImageIndex;
    public int updateTimeoutBase;
    public byte updateTtl;

    public FirmwareUpdateStartMessage(int i, int i2) {
        super(i, i2);
        this.updateTtl = (byte) 10;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FIRMWARE_UPDATE_START.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FIRMWARE_UPDATE_STATUS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(this.metadata.length + 12).order(ByteOrder.LITTLE_ENDIAN).put(this.updateTtl).putShort((short) this.updateTimeoutBase).putLong(this.updateBLOBID).put((byte) this.updateFirmwareImageIndex).put(this.metadata).array();
    }

    public byte getUpdateTtl() {
        return this.updateTtl;
    }

    public void setUpdateTtl(byte b) {
        this.updateTtl = b;
    }

    public int getUpdateTimeoutBase() {
        return this.updateTimeoutBase;
    }

    public void setUpdateTimeoutBase(int i) {
        this.updateTimeoutBase = i;
    }

    public long getUpdateBLOBID() {
        return this.updateBLOBID;
    }

    public void setUpdateBLOBID(long j) {
        this.updateBLOBID = j;
    }

    public int getUpdateFirmwareImageIndex() {
        return this.updateFirmwareImageIndex;
    }

    public void setUpdateFirmwareImageIndex(int i) {
        this.updateFirmwareImageIndex = i;
    }

    public byte[] getMetadata() {
        return this.metadata;
    }

    public void setMetadata(byte[] bArr) {
        this.metadata = bArr;
    }

    public static FirmwareUpdateStartMessage getSimple(int i, int i2, int i3, long j, byte[] bArr) {
        FirmwareUpdateStartMessage firmwareUpdateStartMessage = new FirmwareUpdateStartMessage(i, i2);
        firmwareUpdateStartMessage.setResponseMax(1);
        firmwareUpdateStartMessage.updateTimeoutBase = i3;
        firmwareUpdateStartMessage.updateBLOBID = j;
        firmwareUpdateStartMessage.updateFirmwareImageIndex = 0;
        firmwareUpdateStartMessage.metadata = bArr;
        return firmwareUpdateStartMessage;
    }
}
