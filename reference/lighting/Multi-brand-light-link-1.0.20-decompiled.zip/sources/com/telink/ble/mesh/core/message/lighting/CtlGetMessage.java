package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class CtlGetMessage extends LightingMessage {
    public static CtlGetMessage getSimple(int i, int i2, int i3) {
        CtlGetMessage ctlGetMessage = new CtlGetMessage(i, i2);
        ctlGetMessage.setResponseMax(i3);
        return ctlGetMessage;
    }

    public CtlGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.LIGHT_CTL_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.LIGHT_CTL_STATUS.value;
    }
}
