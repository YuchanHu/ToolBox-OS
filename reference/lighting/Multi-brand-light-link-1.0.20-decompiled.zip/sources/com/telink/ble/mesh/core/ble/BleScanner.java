package com.telink.ble.mesh.core.ble;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.ParcelUuid;
import android.text.TextUtils;
import com.telink.ble.mesh.util.ContextUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/* loaded from: classes.dex */
public class BleScanner {
    public static final int CODE_START_FAIL = 6;
    private final Object SCANNING_STATE_LOCK;
    private boolean anyDeviceFound;
    private boolean extendedAdvertising;
    private boolean isScanning;
    private Handler mDelayHandler;
    private long mLastScanStartTime;
    private BluetoothAdapter.LeScanCallback mLeScanCallback;
    private LeScanFilter mLeScanFilter;
    private LeScanSetting mLeScanSetting;
    private BluetoothLeScanner mLeScanner;
    private ScanCallback mScanCallback;
    private ScannerCallback mScannerCallback;
    private ScannerType mScannerType;
    private Runnable scanningStartTask;
    private Runnable scanningTimeoutTask;

    public interface ScannerCallback {
        void onLeScan(BluetoothDevice bluetoothDevice, int i, byte[] bArr);

        void onScanFail(int i);

        void onScanTimeout(boolean z);

        void onStartedScan();

        void onStoppedScan();
    }

    public enum ScannerType {
        DEFAULT,
        Lollipop
    }

    static /* synthetic */ boolean access$000(BleScanner bleScanner) {
        return bleScanner.anyDeviceFound;
    }

    static /* synthetic */ boolean access$002(BleScanner bleScanner, boolean z) {
        bleScanner.anyDeviceFound = z;
        return z;
    }

    static /* synthetic */ LeScanFilter access$100(BleScanner bleScanner) {
        return bleScanner.mLeScanFilter;
    }

    static /* synthetic */ boolean access$1000(BleScanner bleScanner, LeScanFilter leScanFilter, ScanSettings scanSettings) {
        return bleScanner.startLollipopScan(leScanFilter, scanSettings);
    }

    static /* synthetic */ LeScanSetting access$1100(BleScanner bleScanner) {
        return bleScanner.mLeScanSetting;
    }

    static /* synthetic */ void access$1200(BleScanner bleScanner, long j) {
        bleScanner.startScanningTimeoutTask(j);
    }

    static /* synthetic */ void access$200(BleScanner bleScanner, BluetoothDevice bluetoothDevice, int i, byte[] bArr) {
        bleScanner.onDeviceScanned(bluetoothDevice, i, bArr);
    }

    static /* synthetic */ boolean access$300(BleScanner bleScanner) {
        return bleScanner.extendedAdvertising;
    }

    static /* synthetic */ Handler access$400(BleScanner bleScanner) {
        return bleScanner.mDelayHandler;
    }

    static /* synthetic */ void access$500(BleScanner bleScanner, int i, String str) {
        bleScanner.onScanFailed(i, str);
    }

    static /* synthetic */ void access$600(BleScanner bleScanner, int i) {
        bleScanner.retryLegacyScan(i);
    }

    static /* synthetic */ ScannerCallback access$700(BleScanner bleScanner) {
        return bleScanner.mScannerCallback;
    }

    static /* synthetic */ ScannerType access$800(BleScanner bleScanner) {
        return bleScanner.mScannerType;
    }

    static /* synthetic */ boolean access$900(BleScanner bleScanner, LeScanFilter leScanFilter) {
        return bleScanner.startLeScan(leScanFilter);
    }

    private BleScanner() {
        this.SCANNING_STATE_LOCK = new Object();
        this.isScanning = false;
        this.mLastScanStartTime = 0L;
        this.anyDeviceFound = false;
        this.scanningTimeoutTask = new Runnable() { // from class: com.telink.ble.mesh.core.ble.BleScanner.3
            @Override // java.lang.Runnable
            public void run() {
                BleScanner.this.stopScan();
                if (BleScanner.access$700(BleScanner.this) != null) {
                    BleScanner.access$700(BleScanner.this).onScanTimeout(BleScanner.access$000(BleScanner.this));
                }
            }
        };
        this.scanningStartTask = new Runnable() { // from class: com.telink.ble.mesh.core.ble.BleScanner.4
            @Override // java.lang.Runnable
            public void run() {
                boolean zAccess$1000;
                if (BleScanner.access$800(BleScanner.this) == ScannerType.DEFAULT) {
                    BleScanner bleScanner = BleScanner.this;
                    zAccess$1000 = BleScanner.access$900(bleScanner, BleScanner.access$100(bleScanner));
                } else if (BleScanner.access$800(BleScanner.this) == ScannerType.Lollipop) {
                    BleScanner bleScanner2 = BleScanner.this;
                    zAccess$1000 = BleScanner.access$1000(bleScanner2, BleScanner.access$100(bleScanner2), null);
                } else {
                    zAccess$1000 = false;
                }
                BleScanner bleScanner3 = BleScanner.this;
                BleScanner.access$1200(bleScanner3, BleScanner.access$1100(bleScanner3).timeout);
                if (zAccess$1000) {
                    if (BleScanner.access$700(BleScanner.this) != null) {
                        BleScanner.access$700(BleScanner.this).onStartedScan();
                        return;
                    }
                    return;
                }
                BleScanner.access$500(BleScanner.this, 6, "scan action start failed");
            }
        };
    }

    public void setScannerCallback(ScannerCallback scannerCallback) {
        this.mScannerCallback = scannerCallback;
    }

    public BleScanner(ScannerType scannerType, HandlerThread handlerThread) {
        this(scannerType, handlerThread, false);
    }

    public BleScanner(ScannerType scannerType, HandlerThread handlerThread, boolean z) {
        this.SCANNING_STATE_LOCK = new Object();
        this.isScanning = false;
        this.mLastScanStartTime = 0L;
        this.anyDeviceFound = false;
        this.scanningTimeoutTask = new Runnable() { // from class: com.telink.ble.mesh.core.ble.BleScanner.3
            @Override // java.lang.Runnable
            public void run() {
                BleScanner.this.stopScan();
                if (BleScanner.access$700(BleScanner.this) != null) {
                    BleScanner.access$700(BleScanner.this).onScanTimeout(BleScanner.access$000(BleScanner.this));
                }
            }
        };
        this.scanningStartTask = new Runnable() { // from class: com.telink.ble.mesh.core.ble.BleScanner.4
            @Override // java.lang.Runnable
            public void run() {
                boolean zAccess$1000;
                if (BleScanner.access$800(BleScanner.this) == ScannerType.DEFAULT) {
                    BleScanner bleScanner = BleScanner.this;
                    zAccess$1000 = BleScanner.access$900(bleScanner, BleScanner.access$100(bleScanner));
                } else if (BleScanner.access$800(BleScanner.this) == ScannerType.Lollipop) {
                    BleScanner bleScanner2 = BleScanner.this;
                    zAccess$1000 = BleScanner.access$1000(bleScanner2, BleScanner.access$100(bleScanner2), null);
                } else {
                    zAccess$1000 = false;
                }
                BleScanner bleScanner3 = BleScanner.this;
                BleScanner.access$1200(bleScanner3, BleScanner.access$1100(bleScanner3).timeout);
                if (zAccess$1000) {
                    if (BleScanner.access$700(BleScanner.this) != null) {
                        BleScanner.access$700(BleScanner.this).onStartedScan();
                        return;
                    }
                    return;
                }
                BleScanner.access$500(BleScanner.this, 6, "scan action start failed");
            }
        };
        this.mDelayHandler = new Handler(handlerThread.getLooper());
        this.extendedAdvertising = z;
        if (scannerType == null || !ContextUtil.versionAboveL()) {
            this.mScannerType = ScannerType.DEFAULT;
        } else {
            this.mScannerType = scannerType;
        }
        int i = AnonymousClass5.$SwitchMap$com$telink$ble$mesh$core$ble$BleScanner$ScannerType[this.mScannerType.ordinal()];
        if (i == 1) {
            initDefaultScanner();
        } else {
            if (i != 2) {
                return;
            }
            initLollipopScanner();
        }
    }

    /* renamed from: com.telink.ble.mesh.core.ble.BleScanner$5, reason: invalid class name */
    static /* synthetic */ class AnonymousClass5 {
        static final /* synthetic */ int[] $SwitchMap$com$telink$ble$mesh$core$ble$BleScanner$ScannerType;

        static {
            int[] iArr = new int[ScannerType.values().length];
            $SwitchMap$com$telink$ble$mesh$core$ble$BleScanner$ScannerType = iArr;
            try {
                iArr[ScannerType.DEFAULT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$telink$ble$mesh$core$ble$BleScanner$ScannerType[ScannerType.Lollipop.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    private void initDefaultScanner() {
        this.mLeScanCallback = new BluetoothAdapter.LeScanCallback() { // from class: com.telink.ble.mesh.core.ble.BleScanner.1
            @Override // android.bluetooth.BluetoothAdapter.LeScanCallback
            public void onLeScan(BluetoothDevice bluetoothDevice, int i, byte[] bArr) {
                boolean z;
                boolean z2 = true;
                BleScanner.access$002(BleScanner.this, true);
                if (BleScanner.access$100(BleScanner.this) != null) {
                    LeScanFilter leScanFilterAccess$100 = BleScanner.access$100(BleScanner.this);
                    if (leScanFilterAccess$100.macExclude != null && leScanFilterAccess$100.macExclude.length != 0) {
                        for (String str : leScanFilterAccess$100.macExclude) {
                            if (str.equalsIgnoreCase(bluetoothDevice.getAddress())) {
                                return;
                            }
                        }
                    }
                    if (leScanFilterAccess$100.macInclude == null || leScanFilterAccess$100.macInclude.length == 0) {
                        z = true;
                        break;
                    }
                    for (String str2 : leScanFilterAccess$100.macInclude) {
                        if (str2.equalsIgnoreCase(bluetoothDevice.getAddress())) {
                            z = true;
                            break;
                        }
                    }
                    z = false;
                    if (!z || leScanFilterAccess$100.nameInclude == null || leScanFilterAccess$100.nameInclude.length == 0) {
                        z2 = z;
                    } else {
                        String name = bluetoothDevice.getName();
                        if (TextUtils.isEmpty(bluetoothDevice.getName())) {
                            z2 = false;
                        } else {
                            for (String str3 : leScanFilterAccess$100.nameInclude) {
                                if (name.equals(str3)) {
                                    break;
                                }
                            }
                            z2 = false;
                        }
                    }
                    if (z2) {
                        BleScanner.access$200(BleScanner.this, bluetoothDevice, i, bArr);
                        return;
                    }
                    return;
                }
                BleScanner.access$200(BleScanner.this, bluetoothDevice, i, bArr);
            }
        };
    }

    /* renamed from: com.telink.ble.mesh.core.ble.BleScanner$2, reason: invalid class name */
    class AnonymousClass2 extends ScanCallback {
        AnonymousClass2() {
        }

        @Override // android.bluetooth.le.ScanCallback
        public void onScanResult(int i, ScanResult scanResult) {
            super.onScanResult(i, scanResult);
            if (scanResult.getScanRecord() == null) {
                return;
            }
            BleScanner.access$002(BleScanner.this, true);
            BluetoothDevice device = scanResult.getDevice();
            byte[] bytes = scanResult.getScanRecord().getBytes();
            int rssi = scanResult.getRssi();
            if (BleScanner.access$100(BleScanner.this) != null) {
                LeScanFilter leScanFilterAccess$100 = BleScanner.access$100(BleScanner.this);
                if (leScanFilterAccess$100.macExclude != null && leScanFilterAccess$100.macExclude.length != 0) {
                    for (String str : leScanFilterAccess$100.macExclude) {
                        if (str.equalsIgnoreCase(device.getAddress())) {
                            return;
                        }
                    }
                }
            }
            BleScanner.access$200(BleScanner.this, device, rssi, bytes);
        }

        @Override // android.bluetooth.le.ScanCallback
        public void onBatchScanResults(List<ScanResult> list) {
            super.onBatchScanResults(list);
        }

        @Override // android.bluetooth.le.ScanCallback
        public void onScanFailed(final int i) {
            super.onScanFailed(i);
            if (i == 4 && BleScanner.access$300(BleScanner.this)) {
                BleScanner.access$400(BleScanner.this).post(new Runnable() { // from class: com.telink.ble.mesh.core.ble.BleScanner$2$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m105lambda$onScanFailed$0$comtelinkblemeshcorebleBleScanner$2(i);
                    }
                });
                return;
            }
            BleScanner.access$500(BleScanner.this, i, "scanner failed by : " + i);
        }

        /* renamed from: lambda$onScanFailed$0$com-telink-ble-mesh-core-ble-BleScanner$2, reason: not valid java name */
        /* synthetic */ void m105lambda$onScanFailed$0$comtelinkblemeshcorebleBleScanner$2(int i) {
            BleScanner.access$600(BleScanner.this, i);
        }
    }

    private void initLollipopScanner() {
        this.mLeScanner = BluetoothAdapter.getDefaultAdapter().getBluetoothLeScanner();
        this.mScanCallback = new AnonymousClass2();
    }

    private void onDeviceScanned(BluetoothDevice bluetoothDevice, int i, byte[] bArr) {
        ScannerCallback scannerCallback;
        if (bArr == null || (scannerCallback = this.mScannerCallback) == null) {
            return;
        }
        scannerCallback.onLeScan(bluetoothDevice, i, bArr);
    }

    public synchronized void stopScan() {
        if (this.isScanning) {
            stopScanningTimeoutTask();
            stopScanningTask();
            if (this.mScannerType == ScannerType.DEFAULT) {
                stopLeScan();
            } else if (this.mScannerType == ScannerType.Lollipop) {
                stopLollipopScan();
            }
            this.isScanning = false;
            ScannerCallback scannerCallback = this.mScannerCallback;
            if (scannerCallback != null) {
                scannerCallback.onStoppedScan();
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0040 A[PHI: r2
      0x0040: PHI (r2v1 long) = (r2v0 long), (r2v0 long), (r2v3 long) binds: [B:11:0x002d, B:13:0x0035, B:15:0x003d] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public synchronized void startScan(com.telink.ble.mesh.core.ble.LeScanFilter r9, com.telink.ble.mesh.core.ble.LeScanSetting r10) {
        /*
            r8 = this;
            monitor-enter(r8)
            android.os.Handler r0 = r8.mDelayHandler     // Catch: java.lang.Throwable -> L48
            r1 = 0
            r0.removeCallbacksAndMessages(r1)     // Catch: java.lang.Throwable -> L48
            boolean r0 = r8.isScanning     // Catch: java.lang.Throwable -> L48
            if (r0 == 0) goto Le
            r8.stopScan()     // Catch: java.lang.Throwable -> L48
        Le:
            r0 = 0
            r8.anyDeviceFound = r0     // Catch: java.lang.Throwable -> L48
            r0 = 1
            r8.isScanning = r0     // Catch: java.lang.Throwable -> L48
            r8.mLeScanFilter = r9     // Catch: java.lang.Throwable -> L48
            if (r10 != 0) goto L1f
            com.telink.ble.mesh.core.ble.LeScanSetting r9 = com.telink.ble.mesh.core.ble.LeScanSetting.getDefault()     // Catch: java.lang.Throwable -> L48
            r8.mLeScanSetting = r9     // Catch: java.lang.Throwable -> L48
            goto L21
        L1f:
            r8.mLeScanSetting = r10     // Catch: java.lang.Throwable -> L48
        L21:
            com.telink.ble.mesh.core.ble.LeScanSetting r9 = r8.mLeScanSetting     // Catch: java.lang.Throwable -> L48
            long r9 = r9.spacing     // Catch: java.lang.Throwable -> L48
            long r0 = java.lang.System.currentTimeMillis()     // Catch: java.lang.Throwable -> L48
            r2 = 0
            int r4 = (r9 > r2 ? 1 : (r9 == r2 ? 0 : -1))
            if (r4 <= 0) goto L40
            long r4 = r8.mLastScanStartTime     // Catch: java.lang.Throwable -> L48
            long r6 = r0 - r4
            int r6 = (r6 > r9 ? 1 : (r6 == r9 ? 0 : -1))
            if (r6 >= 0) goto L40
            long r2 = r0 - r4
            long r2 = r9 - r2
            int r4 = (r2 > r9 ? 1 : (r2 == r9 ? 0 : -1))
            if (r4 <= 0) goto L40
            goto L41
        L40:
            r9 = r2
        L41:
            r8.mLastScanStartTime = r0     // Catch: java.lang.Throwable -> L48
            r8.startScanningTask(r9)     // Catch: java.lang.Throwable -> L48
            monitor-exit(r8)
            return
        L48:
            r9 = move-exception
            monitor-exit(r8)
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: com.telink.ble.mesh.core.ble.BleScanner.startScan(com.telink.ble.mesh.core.ble.LeScanFilter, com.telink.ble.mesh.core.ble.LeScanSetting):void");
    }

    private void startScanningTimeoutTask(long j) {
        this.mDelayHandler.removeCallbacks(this.scanningTimeoutTask);
        this.mDelayHandler.postDelayed(this.scanningTimeoutTask, j);
    }

    private void stopScanningTimeoutTask() {
        this.mDelayHandler.removeCallbacks(this.scanningTimeoutTask);
    }

    private void startScanningTask(long j) {
        this.mDelayHandler.removeCallbacks(this.scanningStartTask);
        this.mDelayHandler.postDelayed(this.scanningStartTask, j);
    }

    private void stopScanningTask() {
        this.mDelayHandler.removeCallbacks(this.scanningStartTask);
    }

    private void onScanFailed(int i, String str) {
        this.isScanning = false;
        ScannerCallback scannerCallback = this.mScannerCallback;
        if (scannerCallback != null) {
            scannerCallback.onScanFail(i);
        }
    }

    private boolean startLeScan(LeScanFilter leScanFilter) {
        if (this.mLeScanCallback != null) {
            return BluetoothAdapter.getDefaultAdapter().startLeScan(leScanFilter == null ? null : leScanFilter.uuidInclude, this.mLeScanCallback);
        }
        return false;
    }

    private boolean startLollipopScan(LeScanFilter leScanFilter, ScanSettings scanSettings) {
        if (this.mLeScanner == null || this.mScanCallback == null) {
            return false;
        }
        List<ScanFilter> listBuildLeScanFilter = buildLeScanFilter(leScanFilter);
        if (scanSettings == null) {
            scanSettings = buildDefaultScanSettings();
        }
        try {
            this.mLeScanner.startScan(listBuildLeScanFilter, scanSettings, this.mScanCallback);
            return true;
        } catch (IllegalArgumentException | UnsupportedOperationException e) {
            if (!this.extendedAdvertising) {
                throw e;
            }
            this.extendedAdvertising = false;
            this.mLeScanner.startScan(listBuildLeScanFilter, buildDefaultScanSettings(), this.mScanCallback);
            return true;
        }
    }

    private synchronized void retryLegacyScan(int i) {
        if (this.isScanning && this.extendedAdvertising) {
            this.extendedAdvertising = false;
            try {
                stopLollipopScan();
                if (startLollipopScan(this.mLeScanFilter, null)) {
                    return;
                }
            } catch (RuntimeException unused) {
            }
            onScanFailed(i, "scanner failed by : " + i);
        }
    }

    private void stopLeScan() {
        if (this.mLeScanCallback != null) {
            BluetoothAdapter.getDefaultAdapter().stopLeScan(this.mLeScanCallback);
        }
    }

    private void stopLollipopScan() {
        ScanCallback scanCallback;
        BluetoothLeScanner bluetoothLeScanner = this.mLeScanner;
        if (bluetoothLeScanner == null || (scanCallback = this.mScanCallback) == null) {
            return;
        }
        bluetoothLeScanner.stopScan(scanCallback);
    }

    public boolean isBluetoothSupported() {
        return BluetoothAdapter.getDefaultAdapter() != null;
    }

    public boolean isBluetoothEnabled() {
        return BluetoothAdapter.getDefaultAdapter() != null && BluetoothAdapter.getDefaultAdapter().isEnabled();
    }

    private List<ScanFilter> buildLeScanFilter(LeScanFilter leScanFilter) {
        if (leScanFilter == null) {
            return null;
        }
        int iIntValue = ((Integer) Collections.max(Arrays.asList(Integer.valueOf(leScanFilter.uuidInclude == null ? 0 : leScanFilter.uuidInclude.length), Integer.valueOf(leScanFilter.macInclude == null ? 0 : leScanFilter.macInclude.length), Integer.valueOf(leScanFilter.nameInclude == null ? 0 : leScanFilter.nameInclude.length)))).intValue();
        if (iIntValue == 0) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < iIntValue; i++) {
            ScanFilter.Builder builder = new ScanFilter.Builder();
            if (leScanFilter.uuidInclude != null && leScanFilter.uuidInclude.length > i) {
                builder.setServiceUuid(ParcelUuid.fromString(leScanFilter.uuidInclude[i].toString()));
            }
            if (leScanFilter.macInclude != null && leScanFilter.macInclude.length > i) {
                builder.setDeviceAddress(leScanFilter.macInclude[i]);
            }
            if (leScanFilter.nameInclude != null && leScanFilter.nameInclude.length > i) {
                builder.setDeviceName(leScanFilter.nameInclude[i]);
            }
            arrayList.add(builder.build());
        }
        return arrayList;
    }

    private ScanSettings buildDefaultScanSettings() {
        ScanSettings.Builder reportDelay = new ScanSettings.Builder().setScanMode(2).setReportDelay(0L);
        if (ContextUtil.SDK_VERSION >= 23) {
            reportDelay.setCallbackType(1);
            reportDelay.setMatchMode(1);
            reportDelay.setNumOfMatches(3);
        }
        if (ContextUtil.SDK_VERSION >= 26) {
            reportDelay.setLegacy(!this.extendedAdvertising);
            reportDelay.setPhy(255);
        }
        return reportDelay.build();
    }
}
