package com.telink.ble.mesh.core.message.firmwareupdate.blobtransfer;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;

/* loaded from: classes.dex */
public class BlobBlockGetMessage extends UpdatingMessage {
    public static BlobBlockGetMessage getSimple(int i, int i2) {
        BlobBlockGetMessage blobBlockGetMessage = new BlobBlockGetMessage(i, i2);
        blobBlockGetMessage.setResponseMax(1);
        return blobBlockGetMessage;
    }

    public BlobBlockGetMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.BLOB_BLOCK_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.BLOB_BLOCK_STATUS.value;
    }
}
