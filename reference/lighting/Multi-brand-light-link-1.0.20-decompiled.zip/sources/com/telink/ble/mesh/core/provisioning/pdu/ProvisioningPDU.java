package com.telink.ble.mesh.core.provisioning.pdu;

/* loaded from: classes.dex */
public abstract class ProvisioningPDU implements PDU {
    public static final byte TYPE_CAPABILITIES = 1;
    public static final byte TYPE_COMPLETE = 8;
    public static final byte TYPE_CONFIRMATION = 5;
    public static final byte TYPE_DATA = 7;
    public static final byte TYPE_FAILED = 9;
    public static final byte TYPE_INPUT_COMPLETE = 4;
    public static final byte TYPE_INVITE = 0;
    public static final byte TYPE_PUBLIC_KEY = 3;
    public static final byte TYPE_RANDOM = 6;
    public static final byte TYPE_RECORDS_GET = 12;
    public static final byte TYPE_RECORDS_LIST = 13;
    public static final byte TYPE_RECORD_REQUEST = 10;
    public static final byte TYPE_RECORD_RESPONSE = 11;
    public static final byte TYPE_START = 2;
    private byte[] params;
    private byte type;

    @Override // com.telink.ble.mesh.core.provisioning.pdu.PDU
    public byte[] toBytes() {
        byte[] bArr = this.params;
        byte[] bArr2 = new byte[bArr == null ? 1 : bArr.length + 1];
        bArr2[0] = this.type;
        if (bArr != null) {
            System.arraycopy(bArr, 0, bArr2, 1, bArr.length);
        }
        return bArr2;
    }
}
