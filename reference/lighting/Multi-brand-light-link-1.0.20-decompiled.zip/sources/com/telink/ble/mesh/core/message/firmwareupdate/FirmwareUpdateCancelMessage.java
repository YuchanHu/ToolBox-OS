package com.telink.ble.mesh.core.message.firmwareupdate;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class FirmwareUpdateCancelMessage extends UpdatingMessage {
    public static FirmwareUpdateCancelMessage getSimple(int i, int i2) {
        FirmwareUpdateCancelMessage firmwareUpdateCancelMessage = new FirmwareUpdateCancelMessage(i, i2);
        firmwareUpdateCancelMessage.setResponseMax(1);
        return firmwareUpdateCancelMessage;
    }

    public FirmwareUpdateCancelMessage(int i, int i2) {
        super(i, i2);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FIRMWARE_UPDATE_CANCEL.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FIRMWARE_UPDATE_STATUS.value;
    }
}
