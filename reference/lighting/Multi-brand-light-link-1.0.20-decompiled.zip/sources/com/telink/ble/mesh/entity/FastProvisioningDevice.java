package com.telink.ble.mesh.entity;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.util.Arrays;

/* loaded from: classes.dex */
public class FastProvisioningDevice implements Parcelable {
    public static final Parcelable.Creator<FastProvisioningDevice> CREATOR = new Parcelable.Creator<FastProvisioningDevice>() { // from class: com.telink.ble.mesh.entity.FastProvisioningDevice.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FastProvisioningDevice createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FastProvisioningDevice[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FastProvisioningDevice createFromParcel(Parcel parcel) {
            return new FastProvisioningDevice(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FastProvisioningDevice[] newArray(int i) {
            return new FastProvisioningDevice[i];
        }
    };
    private byte[] deviceKey;
    private int elementCount;
    private boolean isSetAdrComplete;
    private byte[] mac;
    private int newAddress;
    private int originAddress;
    private int pid;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public FastProvisioningDevice() {
        this.isSetAdrComplete = false;
    }

    public FastProvisioningDevice(int i, int i2, int i3, int i4, byte[] bArr) {
        this.isSetAdrComplete = false;
        this.originAddress = i;
        this.newAddress = i2;
        this.pid = i3;
        this.elementCount = i4;
        this.mac = Arrays.reverse(bArr);
        byte[] bArr2 = new byte[16];
        this.deviceKey = bArr2;
        System.arraycopy(bArr, 0, bArr2, 0, 6);
    }

    protected FastProvisioningDevice(Parcel parcel) {
        this.isSetAdrComplete = false;
        this.originAddress = parcel.readInt();
        this.newAddress = parcel.readInt();
        this.pid = parcel.readInt();
        this.elementCount = parcel.readInt();
        this.mac = parcel.createByteArray();
        this.deviceKey = parcel.createByteArray();
        this.isSetAdrComplete = parcel.readByte() != 0;
    }

    public byte[] getMac() {
        return this.mac;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return java.util.Arrays.equals(this.mac, ((FastProvisioningDevice) obj).mac);
    }

    public int hashCode() {
        return java.util.Arrays.hashCode(this.mac);
    }

    public int getOriginAddress() {
        return this.originAddress;
    }

    public void setOriginAddress(int i) {
        this.originAddress = i;
    }

    public int getNewAddress() {
        return this.newAddress;
    }

    public void setNewAddress(int i) {
        this.newAddress = i;
    }

    public int getPid() {
        return this.pid;
    }

    public void setPid(int i) {
        this.pid = i;
    }

    public void setMac(byte[] bArr) {
        this.mac = bArr;
    }

    public byte[] getDeviceKey() {
        return this.deviceKey;
    }

    public void setDeviceKey(byte[] bArr) {
        this.deviceKey = bArr;
    }

    public int getElementCount() {
        return this.elementCount;
    }

    public void setElementCount(int i) {
        this.elementCount = i;
    }

    public boolean isSetAdrComplete() {
        return this.isSetAdrComplete;
    }

    public void setSetAdrComplete(boolean z) {
        this.isSetAdrComplete = z;
    }

    public String toString() {
        return "FastProvisioningDevice{originAddress=" + this.originAddress + ", newAddress=" + this.newAddress + ", pid=" + this.pid + ", elementCount=" + this.elementCount + ", mac=" + java.util.Arrays.toString(this.mac) + ", deviceKey=" + java.util.Arrays.toString(this.deviceKey) + '}';
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.originAddress);
        parcel.writeInt(this.newAddress);
        parcel.writeInt(this.pid);
        parcel.writeInt(this.elementCount);
        parcel.writeByteArray(this.mac);
        parcel.writeByteArray(this.deviceKey);
        parcel.writeByte(this.isSetAdrComplete ? (byte) 1 : (byte) 0);
    }
}
