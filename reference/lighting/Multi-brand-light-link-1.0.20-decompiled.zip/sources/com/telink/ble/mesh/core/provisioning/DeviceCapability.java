package com.telink.ble.mesh.core.provisioning;

import com.telink.ble.mesh.core.access.fu.FUDistributor;

/* loaded from: classes.dex */
public class DeviceCapability {
    private static final int CPB_DATA_LEN = 11;
    private byte[] rawData;

    private DeviceCapability() {
    }

    public static DeviceCapability getCapability(byte[] bArr) {
        if (bArr == null || bArr.length != 11) {
            return null;
        }
        DeviceCapability deviceCapability = new DeviceCapability();
        deviceCapability.rawData = bArr;
        return deviceCapability;
    }

    public int getElementCnt() {
        return this.rawData[0];
    }

    public int getAlgorithms() {
        byte[] bArr = this.rawData;
        return (bArr[2] & FUDistributor.UPDATE_TTL) | ((bArr[1] & FUDistributor.UPDATE_TTL) << 8);
    }

    public int getPublicKeyType() {
        return this.rawData[3];
    }

    public int getStaticOOBType() {
        return this.rawData[4];
    }

    public int getOutputOOBSize() {
        return this.rawData[5];
    }

    public int getOutputOOBAction() {
        byte[] bArr = this.rawData;
        return (bArr[7] & FUDistributor.UPDATE_TTL) | ((bArr[6] & FUDistributor.UPDATE_TTL) << 8);
    }

    public int getInputOOBSize() {
        return this.rawData[8];
    }

    public int getInputOOBAction() {
        byte[] bArr = this.rawData;
        return (bArr[10] & FUDistributor.UPDATE_TTL) | ((bArr[9] & FUDistributor.UPDATE_TTL) << 8);
    }
}
