package com.telink.ble.mesh.core.message.firmwaredistribution;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;
import com.telink.ble.mesh.core.message.firmwaredistribution.DistributorCapabilities;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class FDCapabilitiesStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<FDCapabilitiesStatusMessage> CREATOR = new Parcelable.Creator<FDCapabilitiesStatusMessage>() { // from class: com.telink.ble.mesh.core.message.firmwaredistribution.FDCapabilitiesStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FDCapabilitiesStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FDCapabilitiesStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FDCapabilitiesStatusMessage createFromParcel(Parcel parcel) {
            return new FDCapabilitiesStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FDCapabilitiesStatusMessage[] newArray(int i) {
            return new FDCapabilitiesStatusMessage[i];
        }
    };
    private int maxImageSize;
    public int maxImagesListSize;
    private int maxReceiversListSize;
    private int maxUploadSpace;
    private int oobRetrievalSupported;
    private int remainingUploadSpace;
    private byte[] uriSchemeNames;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public FDCapabilitiesStatusMessage() {
    }

    protected FDCapabilitiesStatusMessage(Parcel parcel) {
        this.maxReceiversListSize = parcel.readInt();
        this.maxImagesListSize = parcel.readInt();
        this.maxImageSize = parcel.readInt();
        this.maxUploadSpace = parcel.readInt();
        this.remainingUploadSpace = parcel.readInt();
        this.oobRetrievalSupported = parcel.readInt();
        this.uriSchemeNames = parcel.createByteArray();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.maxReceiversListSize = MeshUtils.bytes2Integer(bArr, 0, 2, ByteOrder.LITTLE_ENDIAN);
        this.maxImagesListSize = MeshUtils.bytes2Integer(bArr, 2, 2, ByteOrder.LITTLE_ENDIAN);
        this.maxImageSize = MeshUtils.bytes2Integer(bArr, 4, 4, ByteOrder.LITTLE_ENDIAN);
        this.maxUploadSpace = MeshUtils.bytes2Integer(bArr, 8, 4, ByteOrder.LITTLE_ENDIAN);
        this.remainingUploadSpace = MeshUtils.bytes2Integer(bArr, 12, 4, ByteOrder.LITTLE_ENDIAN);
        int i = bArr[16] & FUDistributor.UPDATE_TTL;
        this.oobRetrievalSupported = i;
        if (i == DistributorCapabilities.OOBRetrievalSupported.SUPPORTED.value) {
            byte[] bArr2 = new byte[bArr.length - 17];
            this.uriSchemeNames = bArr2;
            System.arraycopy(bArr, 17, bArr2, 0, bArr2.length);
            return;
        }
        this.uriSchemeNames = null;
    }

    public int getMaxReceiversListSize() {
        return this.maxReceiversListSize;
    }

    public void setMaxReceiversListSize(int i) {
        this.maxReceiversListSize = i;
    }

    public int getMaxImagesListSize() {
        return this.maxImagesListSize;
    }

    public void setMaxImagesListSize(int i) {
        this.maxImagesListSize = i;
    }

    public int getMaxImageSize() {
        return this.maxImageSize;
    }

    public void setMaxImageSize(int i) {
        this.maxImageSize = i;
    }

    public int getMaxUploadSpace() {
        return this.maxUploadSpace;
    }

    public void setMaxUploadSpace(int i) {
        this.maxUploadSpace = i;
    }

    public int getRemainingUploadSpace() {
        return this.remainingUploadSpace;
    }

    public void setRemainingUploadSpace(int i) {
        this.remainingUploadSpace = i;
    }

    public int getOobRetrievalSupported() {
        return this.oobRetrievalSupported;
    }

    public void setOobRetrievalSupported(int i) {
        this.oobRetrievalSupported = i;
    }

    public byte[] getUriSchemeNames() {
        return this.uriSchemeNames;
    }

    public void setUriSchemeNames(byte[] bArr) {
        this.uriSchemeNames = bArr;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.maxReceiversListSize);
        parcel.writeInt(this.maxImagesListSize);
        parcel.writeInt(this.maxImageSize);
        parcel.writeInt(this.maxUploadSpace);
        parcel.writeInt(this.remainingUploadSpace);
        parcel.writeInt(this.oobRetrievalSupported);
        parcel.writeByteArray(this.uriSchemeNames);
    }
}
