package com.telink.ble.mesh.core.message.firmwaredistribution;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;

/* loaded from: classes.dex */
public class FDFirmwareGetMessage extends UpdatingMessage {
    public int firmwareID;

    public FDFirmwareGetMessage(int i, int i2) {
        super(i, i2);
    }

    public static FDFirmwareGetMessage getSimple(int i, int i2) {
        FDFirmwareGetMessage fDFirmwareGetMessage = new FDFirmwareGetMessage(i, i2);
        fDFirmwareGetMessage.setResponseMax(1);
        return fDFirmwareGetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FD_FIRMWARE_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FD_UPLOAD_STATUS.value;
    }
}
