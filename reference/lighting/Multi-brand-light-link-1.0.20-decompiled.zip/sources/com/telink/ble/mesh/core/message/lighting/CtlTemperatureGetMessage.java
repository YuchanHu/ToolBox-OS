package com.telink.ble.mesh.core.message.lighting;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class CtlTemperatureGetMessage extends LightingMessage {
    public CtlTemperatureGetMessage(int i, int i2) {
        super(i, i2);
    }

    public static CtlTemperatureGetMessage getSimple(int i, int i2, int i3) {
        CtlTemperatureGetMessage ctlTemperatureGetMessage = new CtlTemperatureGetMessage(i, i2);
        ctlTemperatureGetMessage.setResponseMax(i3);
        return ctlTemperatureGetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.LIGHT_CTL_TEMP_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.LIGHT_CTL_TEMP_STATUS.value;
    }
}
