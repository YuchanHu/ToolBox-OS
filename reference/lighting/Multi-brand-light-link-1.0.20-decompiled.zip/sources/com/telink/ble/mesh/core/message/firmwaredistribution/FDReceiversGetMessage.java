package com.telink.ble.mesh.core.message.firmwaredistribution;

import com.telink.ble.mesh.core.message.Opcode;
import com.telink.ble.mesh.core.message.firmwareupdate.UpdatingMessage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class FDReceiversGetMessage extends UpdatingMessage {
    public int entriesLimit;
    public int firstIndex;

    public FDReceiversGetMessage(int i, int i2) {
        super(i, i2);
    }

    public static FDReceiversGetMessage getSimple(int i, int i2, int i3, int i4) {
        FDReceiversGetMessage fDReceiversGetMessage = new FDReceiversGetMessage(i, i2);
        fDReceiversGetMessage.firstIndex = i3;
        fDReceiversGetMessage.entriesLimit = i4;
        fDReceiversGetMessage.setResponseMax(1);
        return fDReceiversGetMessage;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.FD_RECEIVERS_GET.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.FD_RECEIVERS_LIST.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putShort((short) this.firstIndex).putShort((short) this.entriesLimit).array();
    }
}
