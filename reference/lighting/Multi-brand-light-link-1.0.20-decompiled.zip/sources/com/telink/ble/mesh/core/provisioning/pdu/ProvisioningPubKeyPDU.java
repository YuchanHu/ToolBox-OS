package com.telink.ble.mesh.core.provisioning.pdu;

/* loaded from: classes.dex */
public class ProvisioningPubKeyPDU implements ProvisioningStatePDU {
    private static final int LEN = 64;
    private byte[] rawData;
    public byte[] x;
    public byte[] y;

    @Override // com.telink.ble.mesh.core.provisioning.pdu.ProvisioningStatePDU
    public byte getState() {
        return (byte) 3;
    }

    public static ProvisioningPubKeyPDU fromBytes(byte[] bArr) {
        if (bArr.length != 64) {
            return null;
        }
        ProvisioningPubKeyPDU provisioningPubKeyPDU = new ProvisioningPubKeyPDU();
        provisioningPubKeyPDU.rawData = bArr;
        byte[] bArr2 = new byte[32];
        provisioningPubKeyPDU.x = bArr2;
        provisioningPubKeyPDU.y = new byte[32];
        System.arraycopy(bArr, 0, bArr2, 0, 32);
        System.arraycopy(bArr, 32, provisioningPubKeyPDU.y, 0, 32);
        return provisioningPubKeyPDU;
    }

    @Override // com.telink.ble.mesh.core.provisioning.pdu.PDU
    public byte[] toBytes() {
        byte[] bArr = this.rawData;
        if (bArr != null) {
            return bArr;
        }
        byte[] bArr2 = this.x;
        if (bArr2 == null || this.y == null) {
            return null;
        }
        byte[] bArr3 = new byte[64];
        System.arraycopy(bArr2, 0, bArr3, 0, bArr2.length);
        byte[] bArr4 = this.y;
        System.arraycopy(bArr4, 0, bArr3, 32, bArr4.length);
        return bArr3;
    }
}
