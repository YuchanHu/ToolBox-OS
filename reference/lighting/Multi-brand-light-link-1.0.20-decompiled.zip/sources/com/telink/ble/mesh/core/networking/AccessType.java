package com.telink.ble.mesh.core.networking;

/* loaded from: classes.dex */
public enum AccessType {
    APPLICATION(1),
    DEVICE(0);

    public final byte akf;

    public static AccessType getByAkf(byte b) {
        for (AccessType accessType : values()) {
            if (accessType.akf == b) {
                return accessType;
            }
        }
        return null;
    }

    AccessType(int i) {
        this.akf = (byte) i;
    }
}
