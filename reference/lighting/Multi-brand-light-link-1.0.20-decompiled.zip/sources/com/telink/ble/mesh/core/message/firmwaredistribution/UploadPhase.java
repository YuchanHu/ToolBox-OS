package com.telink.ble.mesh.core.message.firmwaredistribution;

/* loaded from: classes.dex */
public enum UploadPhase {
    IDLE(0, "No firmware upload is in progress."),
    TRANSFER_ACTIVE(1, "The Store Firmware or Store Firmware OOB  procedure is being executed."),
    TRANSFER_ERROR(2, "The Store Firmware procedure or Store Firmware OOB procedure failed."),
    TRANSFER_SUCCESS(3, "The Store Firmware procedure or the Store Firmware OOB procedure completed successfully.");

    public final String desc;
    public final int value;

    UploadPhase(int i, String str) {
        this.value = i;
        this.desc = str;
    }
}
