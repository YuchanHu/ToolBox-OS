package com.telink.ble.mesh.core.message.sensor;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;
import com.telink.ble.mesh.entity.SensorDescriptor;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class SensorDescriptorStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<SensorDescriptorStatusMessage> CREATOR = new Parcelable.Creator<SensorDescriptorStatusMessage>() { // from class: com.telink.ble.mesh.core.message.sensor.SensorDescriptorStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SensorDescriptorStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ SensorDescriptorStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SensorDescriptorStatusMessage createFromParcel(Parcel parcel) {
            return new SensorDescriptorStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SensorDescriptorStatusMessage[] newArray(int i) {
            return new SensorDescriptorStatusMessage[i];
        }
    };
    public List<SensorDescriptor> descriptorList;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public SensorDescriptorStatusMessage() {
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.descriptorList = new ArrayList();
        int i = 0;
        while (true) {
            int i2 = i + 8;
            if (i2 > bArr.length) {
                return;
            }
            byte[] bArr2 = new byte[8];
            System.arraycopy(bArr, i, bArr2, 0, 8);
            this.descriptorList.add(SensorDescriptor.fromBytes(bArr2));
            i = i2;
        }
    }

    protected SensorDescriptorStatusMessage(Parcel parcel) {
        this.descriptorList = parcel.createTypedArrayList(SensorDescriptor.CREATOR);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedList(this.descriptorList);
    }
}
