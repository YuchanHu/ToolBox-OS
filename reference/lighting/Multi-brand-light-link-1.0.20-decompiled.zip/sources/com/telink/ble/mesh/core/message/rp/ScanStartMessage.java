package com.telink.ble.mesh.core.message.rp;

import com.telink.ble.mesh.core.message.Opcode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class ScanStartMessage extends RemoteProvisionMessage {
    private byte scannedItemsLimit;
    private byte timeout;
    private byte[] uuid;

    public static ScanStartMessage getSimple(int i, int i2, byte b, byte b2) {
        ScanStartMessage scanStartMessage = new ScanStartMessage(i);
        scanStartMessage.setResponseMax(i2);
        scanStartMessage.scannedItemsLimit = b;
        scanStartMessage.timeout = b2;
        return scanStartMessage;
    }

    public ScanStartMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.REMOTE_PROV_SCAN_START.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return super.getResponseOpcode();
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        ByteBuffer byteBufferPut = ByteBuffer.allocate(this.uuid == null ? 2 : 18).order(ByteOrder.LITTLE_ENDIAN).put(this.scannedItemsLimit).put(this.timeout);
        byte[] bArr = this.uuid;
        if (bArr != null) {
            byteBufferPut.put(bArr);
        }
        return byteBufferPut.array();
    }

    public void setScannedItemsLimit(byte b) {
        this.scannedItemsLimit = b;
    }

    public void setTimeout(byte b) {
        this.timeout = b;
    }

    public void setUuid(byte[] bArr) {
        this.uuid = bArr;
    }
}
