package com.telink.ble.mesh.core.access.fu;

/* loaded from: classes.dex */
public enum FUState {
    IDLE(256, "initiating distributor ..."),
    INITIATING(0, "initiating distributor ..."),
    INITIATE_SUCCESS(1, "initiate distributor success"),
    INITIATE_FAIL(2, "initiate distributor fail"),
    DISTRIBUTING_BY_PHONE(3, "distributing by phone..."),
    DISTRIBUTING_BY_DEVICE(4, "distributing by device..."),
    UPDATE_APPLYING(7, "firmware update applying"),
    DISTRIBUTE_CONFIRMING(8, "getting distribute status util complete"),
    UPDATE_RECHECKING(9, "firmware update rechecking..."),
    UPDATE_COMPLETE(10, "update complete"),
    UPDATE_FAIL(11, "update fail"),
    TRANSFER_START(12, "blob transferring...");

    public final String desc;
    public final int value;

    FUState(int i, String str) {
        this.value = i;
        this.desc = str;
    }
}
