package com.telink.ble.mesh.util;

import java.io.Serializable;

/* loaded from: classes.dex */
public class LogInfo implements Serializable {
    public int level;
    public String logMessage;
    public long millis;
    public String tag;
    public long threadId = Thread.currentThread().getId();
    public String threadName = Thread.currentThread().getName();

    public LogInfo(String str, String str2, int i) {
        this.millis = 0L;
        this.tag = str;
        this.level = i;
        this.logMessage = str2;
        this.millis = System.currentTimeMillis();
    }
}
