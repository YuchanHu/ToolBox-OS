package com.telink.ble.mesh.core.message.config;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.message.StatusMessage;

/* loaded from: classes.dex */
public class DefaultTTLStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<DefaultTTLStatusMessage> CREATOR = new Parcelable.Creator<DefaultTTLStatusMessage>() { // from class: com.telink.ble.mesh.core.message.config.DefaultTTLStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ DefaultTTLStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ DefaultTTLStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public DefaultTTLStatusMessage createFromParcel(Parcel parcel) {
            return new DefaultTTLStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public DefaultTTLStatusMessage[] newArray(int i) {
            return new DefaultTTLStatusMessage[i];
        }
    };
    public byte ttl;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public DefaultTTLStatusMessage() {
    }

    protected DefaultTTLStatusMessage(Parcel parcel) {
        this.ttl = parcel.readByte();
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        this.ttl = bArr[0];
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.ttl);
    }
}
