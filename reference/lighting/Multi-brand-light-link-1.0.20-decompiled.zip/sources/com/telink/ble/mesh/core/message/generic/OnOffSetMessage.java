package com.telink.ble.mesh.core.message.generic;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class OnOffSetMessage extends GenericMessage {
    public static final byte OFF = 0;
    public static final byte ON = 1;
    private boolean ack;
    private byte delay;
    private boolean isComplete;
    private byte onOff;
    private byte tid;
    private byte transitionTime;

    public static OnOffSetMessage getSimple(int i, int i2, int i3, boolean z, int i4) {
        OnOffSetMessage onOffSetMessage = new OnOffSetMessage(i, i2);
        onOffSetMessage.onOff = (byte) i3;
        onOffSetMessage.ack = z;
        onOffSetMessage.setTidPosition(1);
        onOffSetMessage.setResponseMax(i4);
        return onOffSetMessage;
    }

    public OnOffSetMessage(int i, int i2) {
        super(i, i2);
        this.tid = (byte) 0;
        this.transitionTime = (byte) 0;
        this.delay = (byte) 0;
        this.ack = false;
        this.isComplete = false;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return this.ack ? Opcode.G_ONOFF_STATUS.value : super.getResponseOpcode();
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return (this.ack ? Opcode.G_ONOFF_SET : Opcode.G_ONOFF_SET_NOACK).value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        if (this.isComplete) {
            return new byte[]{this.onOff, this.tid, this.transitionTime, this.delay};
        }
        return new byte[]{this.onOff, this.tid};
    }

    public void setOnOff(byte b) {
        this.onOff = b;
    }

    public void setTid(byte b) {
        this.tid = b;
    }

    public void setTransitionTime(byte b) {
        this.transitionTime = b;
    }

    public void setDelay(byte b) {
        this.delay = b;
    }

    public void setAck(boolean z) {
        this.ack = z;
    }

    public void setComplete(boolean z) {
        this.isComplete = z;
    }
}
