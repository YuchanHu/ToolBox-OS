package com.telink.ble.mesh.core.message.rp;

import com.telink.ble.mesh.core.message.Opcode;

/* loaded from: classes.dex */
public class LinkCloseMessage extends RemoteProvisionMessage {
    public static final byte REASON_FAIL = 2;
    public static final byte REASON_PROHIBITED = 1;
    public static final byte REASON_SUCCESS = 0;
    private byte reason;

    public LinkCloseMessage(int i) {
        super(i);
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getOpcode() {
        return Opcode.REMOTE_PROV_LINK_CLOSE.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public int getResponseOpcode() {
        return Opcode.REMOTE_PROV_LINK_STS.value;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public byte[] getParams() {
        return new byte[]{this.reason};
    }

    public void setReason(byte b) {
        this.reason = b;
    }

    public static LinkCloseMessage getSimple(int i, int i2, byte b) {
        LinkCloseMessage linkCloseMessage = new LinkCloseMessage(i);
        linkCloseMessage.setResponseMax(i2);
        linkCloseMessage.reason = b;
        return linkCloseMessage;
    }
}
