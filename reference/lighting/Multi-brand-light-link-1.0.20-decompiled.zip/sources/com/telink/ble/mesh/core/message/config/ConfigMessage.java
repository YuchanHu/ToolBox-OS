package com.telink.ble.mesh.core.message.config;

import com.telink.ble.mesh.core.message.MeshMessage;
import com.telink.ble.mesh.core.networking.AccessType;

/* loaded from: classes.dex */
public abstract class ConfigMessage extends MeshMessage {
    public ConfigMessage() {
    }

    public ConfigMessage(int i) {
        this.destinationAddress = i;
        this.responseMax = 1;
    }

    @Override // com.telink.ble.mesh.core.message.MeshMessage
    public AccessType getAccessType() {
        return AccessType.DEVICE;
    }
}
