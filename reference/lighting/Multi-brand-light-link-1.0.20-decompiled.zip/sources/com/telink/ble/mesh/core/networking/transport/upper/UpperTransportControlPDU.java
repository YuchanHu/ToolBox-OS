package com.telink.ble.mesh.core.networking.transport.upper;

/* loaded from: classes.dex */
public class UpperTransportControlPDU {
}
