package com.telink.ble.mesh.foundation.event;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.foundation.Event;

/* loaded from: classes.dex */
public class NetworkInfoUpdateEvent extends Event<String> implements Parcelable {
    public static final Parcelable.Creator<NetworkInfoUpdateEvent> CREATOR = new Parcelable.Creator<NetworkInfoUpdateEvent>() { // from class: com.telink.ble.mesh.foundation.event.NetworkInfoUpdateEvent.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ NetworkInfoUpdateEvent createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ NetworkInfoUpdateEvent[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public NetworkInfoUpdateEvent createFromParcel(Parcel parcel) {
            return new NetworkInfoUpdateEvent(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public NetworkInfoUpdateEvent[] newArray(int i) {
            return new NetworkInfoUpdateEvent[i];
        }
    };
    public static final String EVENT_TYPE_NETWORKD_INFO_UPDATE = "com.telink.ble.mesh.EVENT_TYPE_NETWORKD_INFO_UPDATE";
    private int ivIndex;
    private int sequenceNumber;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public NetworkInfoUpdateEvent(Object obj, String str, int i, int i2) {
        super(obj, str);
        this.sequenceNumber = i;
        this.ivIndex = i2;
    }

    protected NetworkInfoUpdateEvent(Parcel parcel) {
        this.sequenceNumber = parcel.readInt();
        this.ivIndex = parcel.readInt();
    }

    public int getSequenceNumber() {
        return this.sequenceNumber;
    }

    public int getIvIndex() {
        return this.ivIndex;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.sequenceNumber);
        parcel.writeInt(this.ivIndex);
    }
}
