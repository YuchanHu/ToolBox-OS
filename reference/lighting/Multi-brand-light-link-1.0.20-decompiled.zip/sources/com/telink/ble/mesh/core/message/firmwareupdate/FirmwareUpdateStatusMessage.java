package com.telink.ble.mesh.core.message.firmwareupdate;

import android.os.Parcel;
import android.os.Parcelable;
import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.access.fu.FUDistributor;
import com.telink.ble.mesh.core.message.StatusMessage;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public class FirmwareUpdateStatusMessage extends StatusMessage implements Parcelable {
    public static final Parcelable.Creator<FirmwareUpdateStatusMessage> CREATOR = new Parcelable.Creator<FirmwareUpdateStatusMessage>() { // from class: com.telink.ble.mesh.core.message.firmwareupdate.FirmwareUpdateStatusMessage.1
        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FirmwareUpdateStatusMessage createFromParcel(Parcel parcel) {
            return createFromParcel(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public /* bridge */ /* synthetic */ FirmwareUpdateStatusMessage[] newArray(int i) {
            return newArray(i);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FirmwareUpdateStatusMessage createFromParcel(Parcel parcel) {
            return new FirmwareUpdateStatusMessage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public FirmwareUpdateStatusMessage[] newArray(int i) {
            return new FirmwareUpdateStatusMessage[i];
        }
    };
    private int additionalInfo;
    private boolean isComplete;
    private int phase;
    private int status;
    private long updateBLOBID;
    private int updateFirmwareImageIndex;
    private int updateTimeoutBase;
    private byte updateTtl;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public FirmwareUpdateStatusMessage() {
        this.isComplete = false;
    }

    protected FirmwareUpdateStatusMessage(Parcel parcel) {
        this.isComplete = false;
        this.status = parcel.readInt();
        this.phase = parcel.readInt();
        this.updateTtl = parcel.readByte();
        this.additionalInfo = parcel.readInt();
        this.updateTimeoutBase = parcel.readInt();
        this.updateBLOBID = parcel.readLong();
        this.updateFirmwareImageIndex = parcel.readInt();
        this.isComplete = parcel.readByte() != 0;
    }

    @Override // com.telink.ble.mesh.core.message.StatusMessage
    public void parse(byte[] bArr) {
        byte b = bArr[0];
        this.status = b & 7;
        this.phase = (b & FUDistributor.UPDATE_TTL) >> 5;
        boolean z = bArr.length > 1;
        this.isComplete = z;
        if (z) {
            this.updateTtl = bArr[1];
            this.additionalInfo = bArr[2] & 31;
            this.updateTimeoutBase = MeshUtils.bytes2Integer(bArr, 3, 2, ByteOrder.LITTLE_ENDIAN);
            this.updateBLOBID = MeshUtils.bytes2Integer(bArr, 5, 8, ByteOrder.LITTLE_ENDIAN);
            this.updateFirmwareImageIndex = bArr[13] & FUDistributor.UPDATE_TTL;
        }
    }

    public int getStatus() {
        return this.status;
    }

    public int getPhase() {
        return this.phase;
    }

    public byte getUpdateTtl() {
        return this.updateTtl;
    }

    public int getAdditionalInfo() {
        return this.additionalInfo;
    }

    public int getUpdateTimeoutBase() {
        return this.updateTimeoutBase;
    }

    public long getUpdateBLOBID() {
        return this.updateBLOBID;
    }

    public int getUpdateFirmwareImageIndex() {
        return this.updateFirmwareImageIndex;
    }

    public boolean isComplete() {
        return this.isComplete;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.status);
        parcel.writeInt(this.phase);
        parcel.writeByte(this.updateTtl);
        parcel.writeInt(this.additionalInfo);
        parcel.writeInt(this.updateTimeoutBase);
        parcel.writeLong(this.updateBLOBID);
        parcel.writeInt(this.updateFirmwareImageIndex);
        parcel.writeByte(this.isComplete ? (byte) 1 : (byte) 0);
    }

    public String toString() {
        return "FirmwareUpdateStatusMessage{status=" + this.status + ", phase=" + this.phase + ", updateTtl=" + ((int) this.updateTtl) + ", additionalInfo=" + this.additionalInfo + ", updateTimeoutBase=" + this.updateTimeoutBase + ", updateBLOBID=0x" + Long.toHexString(this.updateBLOBID) + ", updateFirmwareImageIndex=" + this.updateFirmwareImageIndex + ", isComplete=" + this.isComplete + '}';
    }
}
