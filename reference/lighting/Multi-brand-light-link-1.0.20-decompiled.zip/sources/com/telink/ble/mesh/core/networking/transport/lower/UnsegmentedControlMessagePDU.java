package com.telink.ble.mesh.core.networking.transport.lower;

import java.nio.ByteBuffer;

/* loaded from: classes.dex */
public class UnsegmentedControlMessagePDU extends LowerTransportPDU {
    private int opcode;
    byte[] params;
    final int seg = 0;

    @Override // com.telink.ble.mesh.core.networking.transport.lower.LowerTransportPDU
    public boolean segmented() {
        return false;
    }

    @Override // com.telink.ble.mesh.core.networking.NetworkingPDU
    public byte[] toByteArray() {
        byte b = (byte) this.opcode;
        byte[] bArr = this.params;
        if (bArr == null) {
            return new byte[]{b};
        }
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(bArr.length + 1);
        byteBufferAllocate.put(b).put(this.params);
        return byteBufferAllocate.array();
    }

    @Override // com.telink.ble.mesh.core.networking.transport.lower.LowerTransportPDU
    public int getType() {
        return TYPE_UNSEGMENTED_CONTROL_MESSAGE;
    }
}
