package com.telink.ble.mesh.core.message;

import com.telink.ble.mesh.core.MeshUtils;
import com.telink.ble.mesh.core.networking.AccessType;
import com.telink.ble.mesh.foundation.MulticastMessageBroker;

/* loaded from: classes.dex */
public class MeshMessage implements Cloneable {
    public static final int CTL_ACCESS = 0;
    public static final int CTL_CONTROL = 1;
    public static final int DEFAULT_ASZMIC = 0;
    public static final int DEFAULT_RETRY_CNT = 2;
    public static final int DEFAULT_RETRY_INTERVAL = 1280;
    public static final int DEFAULT_TTL = 10;
    public static final int OPCODE_INVALID = -1;
    protected byte[] accessKey;
    protected int appKeyIndex;
    protected MulticastMessageBroker.Config brokerConfig;
    protected int destinationAddress;
    protected int opcode;
    protected byte[] params;
    protected int sourceAddress;
    protected AccessType accessType = AccessType.APPLICATION;
    protected int szmic = 0;
    protected int ctl = 0;
    protected int ttl = 10;
    protected int retryCnt = 2;
    protected long retryInterval = 1280;
    protected int responseMax = 0;
    protected int responseOpcode = -1;
    protected int tidPosition = -1;
    protected boolean isSegmented = false;

    /* renamed from: clone, reason: collision with other method in class */
    public /* bridge */ /* synthetic */ Object m106clone() throws CloneNotSupportedException {
        return clone();
    }

    public boolean isReliable() {
        return getResponseOpcode() != -1;
    }

    public int getResponseOpcode() {
        return this.responseOpcode;
    }

    public void setResponseOpcode(int i) {
        this.responseOpcode = i;
    }

    public int getTidPosition() {
        return this.tidPosition;
    }

    public void setTidPosition(int i) {
        this.tidPosition = i;
    }

    public int getOpcode() {
        return this.opcode;
    }

    public void setOpcode(int i) {
        this.opcode = i;
    }

    public byte[] getParams() {
        return this.params;
    }

    public void setParams(byte[] bArr) {
        this.params = bArr;
    }

    public int getRetryCnt() {
        return this.retryCnt;
    }

    public void setRetryCnt(int i) {
        this.retryCnt = i;
    }

    public int getResponseMax() {
        return this.responseMax;
    }

    public void setResponseMax(int i) {
        this.responseMax = i;
    }

    public AccessType getAccessType() {
        return this.accessType;
    }

    public void setAccessType(AccessType accessType) {
        this.accessType = accessType;
    }

    public int getCtl() {
        return this.ctl;
    }

    public void setCtl(int i) {
        this.ctl = i;
    }

    public int getTtl() {
        return this.ttl;
    }

    public void setTtl(int i) {
        this.ttl = i;
    }

    public int getSzmic() {
        return this.szmic;
    }

    public void setSzmic(int i) {
        this.szmic = i;
    }

    public byte[] getAccessKey() {
        return this.accessKey;
    }

    public void setAccessKey(byte[] bArr) {
        this.accessKey = bArr;
    }

    public int getSourceAddress() {
        return this.sourceAddress;
    }

    public void setSourceAddress(int i) {
        this.sourceAddress = i;
    }

    public int getDestinationAddress() {
        return this.destinationAddress;
    }

    public void setDestinationAddress(int i) {
        this.destinationAddress = i;
    }

    public int getAppKeyIndex() {
        return this.appKeyIndex;
    }

    public void setAppKeyIndex(int i) {
        this.appKeyIndex = i;
    }

    public boolean isSegmented() {
        return this.isSegmented;
    }

    public void setSegmented(boolean z) {
        this.isSegmented = z;
    }

    public long getRetryInterval() {
        return this.retryInterval;
    }

    public void setRetryInterval(long j) {
        this.retryInterval = j;
    }

    public boolean useMultiMessageBroker() {
        return (MeshUtils.validUnicastAddress(getDestinationAddress()) || !isReliable() || this.brokerConfig == null) ? false : true;
    }

    public MulticastMessageBroker.Config getBrokerConfig() {
        return this.brokerConfig;
    }

    public void setBrokerConfig(MulticastMessageBroker.Config config) {
        this.brokerConfig = config;
    }

    public MeshMessage clone() {
        try {
            return (MeshMessage) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return this;
        }
    }
}
